import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import React, { Suspense, lazy, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { useNotificacoes } from './hooks/useNotificacoes';
import { useNotificacoesRealtime } from './hooks/useNotificacoesRealtime.jsx';
import PageTransition from './components/PageTransition';

// Core imports (always needed)
import Home from './pages/Home';
const Leiloes = lazy(() => import('./pages/Leiloes'));
const LeilaoDetalhe = lazy(() => import('./pages/LeilaoDetalhe'));
const Chat = lazy(() => import('./pages/Chat'));
const AdminPanel = lazy(() => import('./pages/AdminPanel'));
const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));
const AnunciarPage = lazy(() => import('./pages/AnunciarPage'));
const FinanceiroDashboard = lazy(() => import('./pages/FinanceiroDashboard'));
const FunilVendas = lazy(() => import('./pages/FunilVendas'));
const Plantel = lazy(() => import('./pages/Plantel'));
const Vitrine = lazy(() => import('./pages/Vitrine'));
const Stories = lazy(() => import('./pages/Stories'));
const Consultoria = lazy(() => import('./pages/Consultoria'));
const Rifas = lazy(() => import('./pages/Rifas'));
const RifaDetalhe = lazy(() => import('./pages/RifaDetalhe'));
const VitrineEspecifica = lazy(() => import('./pages/VitrineEspecifica'));
const PerfilUsuario = lazy(() => import('./pages/PerfilUsuario'));
const LeilaoAoVivo = lazy(() => import('./pages/LeilaoAoVivo'));
const MapaCriadores = lazy(() => import('./pages/MapaCriadores'));
const AnaliseFinanceira = lazy(() => import('./pages/AnaliseFinanceira'));
const MeusFavoritos = lazy(() => import('./pages/MeusFavoritos'));
const MeusLeiloes = lazy(() => import('./pages/MeusLeiloes'));
const PainelCriador = lazy(() => import('./pages/PainelCriador'));
const CursosAdmin = lazy(() => import('./pages/CursosAdmin'));
const CursosUsuario = lazy(() => import('./pages/CursosUsuario'));
const MeusTreinos = lazy(() => import('./pages/MeusTreinos'));
const Calendario = lazy(() => import('./pages/Calendario'));
const MeusRifas = lazy(() => import('./pages/MeusRifas'));
const Planos = lazy(() => import('./pages/Planos'));
const AnimalPublico = lazy(() => import('./pages/AnimalPublico'));
const Social = lazy(() => import('./pages/Social'));
const DM = lazy(() => import('./pages/DM'));

const AdminFinanceiro = lazy(() => import('./pages/AdminFinanceiro'));
const AnimalForm = lazy(() => import('./pages/AnimalForm'));
const AnunciarBanner = lazy(() => import('./pages/AnunciarBanner'));
const AdminSaques = lazy(() => import('./pages/AdminSaques'));
const NinhadaGestao = lazy(() => import('./pages/NinhadaGestao'));

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const [user, setUser] = React.useState(null);
  const [scrollPositions, setScrollPositions] = React.useState({});
  
  // Dark mode toggle based on system preference
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const toggleDarkMode = (e) => {
      if (e.matches) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    };
    toggleDarkMode(mediaQuery);
    mediaQuery.addEventListener('change', toggleDarkMode);
    return () => mediaQuery.removeEventListener('change', toggleDarkMode);
  }, []);
  
  // Fetch current user
  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);
  
  // Restore scroll position when navigating to a tab
  useEffect(() => {
    const pathname = window.location.pathname.split('/')[1] || 'home';
    const savedPosition = scrollPositions[pathname];
    const scrollableContainer = document.querySelector('[data-tab-scroll]');
    if (scrollableContainer && savedPosition !== undefined) {
      setTimeout(() => {
        scrollableContainer.scrollTop = savedPosition;
      }, 0);
    }
  }, [scrollPositions]);

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Loading fallback
  const LoadingFallback = () => (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: 32, height: 32, border: '3px solid #E8ECF0', borderTop: '3px solid #170073', borderRadius: '50%', animation: 'spin 1s linear infinite', margin: '0 auto', marginBottom: 16 }} />
        <div style={{ color: '#57636C', fontSize: 12 }}>Carregando...</div>
        <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
      </div>
    </div>
  );

  // Render the main app
  return (
    <PageTransition>
      <Suspense fallback={<LoadingFallback />}>
        <Routes>
        {/* Add your page Route elements here */}
        <Route path="/" element={<Home />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/chat/:id" element={<Chat />} />
        <Route path="/leiloes" element={<Leiloes />} />
        <Route path="/leilao/:id" element={<LeilaoDetalhe />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
        <Route path="/anunciar" element={<AnunciarPage />} />
        <Route path="/financeiro" element={<FinanceiroDashboard />} />
        <Route path="/funil-vendas" element={<FunilVendas />} />
        <Route path="/plantel" element={<Plantel />} />
        <Route path="/vitrine" element={<Vitrine />} />
        <Route path="/stories" element={<Stories />} />
        <Route path="/consultoria" element={<Consultoria />} />
        <Route path="/rifas" element={<Rifas />} />
        <Route path="/rifa/:id" element={<RifaDetalhe />} />
        <Route path="/vitrine-criatorio/:proprietarioId" element={<VitrineEspecifica />} />
        <Route path="/perfil-usuario" element={<PerfilUsuario />} />
        <Route path="/leilao-ao-vivo/:id" element={<LeilaoAoVivo />} />
        <Route path="/mapa-criadores" element={<MapaCriadores />} />
        <Route path="/analise-financeira" element={<AnaliseFinanceira />} />
        <Route path="/meus-favoritos" element={<MeusFavoritos />} />
        <Route path="/meus-leiloes" element={<MeusLeiloes />} />
        <Route path="/painel-criador" element={<PainelCriador />} />
        <Route path="/cursos-admin" element={<CursosAdmin />} />
        <Route path="/cursos" element={<CursosUsuario />} />
        <Route path="/meus-treinos" element={<MeusTreinos />} />
        <Route path="/planos" element={<Planos />} />
        <Route path="/social" element={<Social />} />
        <Route path="/dm/:conversaId" element={<DM />} />
        <Route path="/calendario" element={<Calendario />} />
        <Route path="/meus-rifas" element={<MeusRifas />} />
        <Route path="/animal/:animalId" element={<AnimalPublico />} />
        <Route path="/admin-financeiro" element={<AdminFinanceiro />} />
        <Route path="/animal-form" element={<AnimalForm />} />
        <Route path="/anunciar-banner" element={<AnunciarBanner />} />
        <Route path="/admin-saques" element={<AdminSaques />} />
        <Route path="/ninhada/:ninhadaId" element={<NinhadaGestao />} />
        <Route path="*" element={<PageNotFound />} />
        </Routes>
      </Suspense>
      </PageTransition>
        );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App