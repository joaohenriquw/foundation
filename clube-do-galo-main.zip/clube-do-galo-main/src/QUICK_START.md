# 🚀 Quick Start - Mobile Components

## Import & Use (Copy-Paste Ready)

### 1️⃣ Add BackHeader to Any Page
```jsx
import BackHeader from "@/components/BackHeader";

export default function MyPage() {
  return (
    <>
      <BackHeader 
        title="Page Title"
        showBackButton={true}
      />
      {/* Page content */}
    </>
  );
}
```

### 2️⃣ Paginate Long Lists
```jsx
import PaginationList from "@/components/PaginationList";

<PaginationList
  items={items}
  itemsPerPage={10}
  renderItem={(item) => <div>{item.name}</div>}
/>
```

### 3️⃣ Replace `<select>` with SelectField
```jsx
import SelectField from "@/components/SelectField";

<SelectField
  value={status}
  onChange={(e) => setStatus(e.target.value)}
  options={['Active', 'Inactive']}
  label="Status"
/>
```

### 4️⃣ Add Pull-to-Refresh
```jsx
import PullToRefresh from "@/components/PullToRefresh";

<PullToRefresh onRefresh={async () => {
  await loadData();
}}>
  {/* Scrollable content */}
</PullToRefresh>
```

---

## Common Patterns

### Root Screen (Shows Logo, No Back Button)
```jsx
<BackHeader 
  title="Leilões"
  showBackButton={false}  // ← Root screens
  rightAction={<Button>Create</Button>}
/>
```

### Child Screen (Shows Back Button)
```jsx
<BackHeader 
  title="Leilão Details"
  showBackButton={true}   // ← Child screens
  subtitle="Animal info"
/>
```

### Paginated List with Refresh
```jsx
<PullToRefresh onRefresh={carregar}>
  <PaginationList
    items={data}
    itemsPerPage={10}
    renderItem={(item) => <Card item={item} />}
  />
</PullToRefresh>
```

### Form with Dropdowns
```jsx
<form>
  <SelectField
    label="Animal"
    options={animals.map(a => ({ value: a.id, label: a.name }))}
    value={animalId}
    onChange={(e) => setAnimalId(e.target.value)}
    required
  />
  
  <SelectField
    label="Status"
    options={['Ativo', 'Encerrado']}
    value={status}
    onChange={(e) => setStatus(e.target.value)}
  />
  
  <button type="submit">Save</button>
</form>
```

---

## Fix Common Issues

### Issue: SelectField options not showing?
```jsx
// ❌ Wrong format
options=['A', 'B']

// ✅ Correct format
options={[
  { value: 'a', label: 'Option A' },
  { value: 'b', label: 'Option B' }
]}
```

### Issue: BackHeader not sticky?
```jsx
// Make sure it's at the top of the page
<BackHeader />
<div>{/* Content */}</div>
```

### Issue: Pagination not working?
```jsx
// Make sure items array is properly populated
<PaginationList
  items={items}  // ← Must be array
  itemsPerPage={10}
  renderItem={(item) => <div key={item.id}>{item.name}</div>}
/>
```

---

## Mobile Testing Checklist

- [ ] Test on iPhone SE (375px)
- [ ] Test on tablet (768px+)
- [ ] Touch targets are 44x44px
- [ ] No horizontal scroll on mobile
- [ ] Back button works
- [ ] Dropdowns open on tap
- [ ] Page transitions smooth
- [ ] Pull-to-refresh works on iOS/Android

---

## Performance Tips

1. **Use PaginationList** for lists with 10+ items
2. **Use SelectField** instead of `<select>` for mobile
3. **Add PullToRefresh** to all feed/list screens
4. **Use BackHeader** for consistent navigation
5. **Lazy load images** with `loading="lazy"`

---

## Accessibility Checklist

- [ ] All buttons 44x44px minimum
- [ ] Focus indicators visible
- [ ] Color contrast 4.5:1 minimum for text
- [ ] Keyboard navigation works
- [ ] Screen reader friendly
- [ ] Proper ARIA labels

---

## Need Help?

- **Full docs:** Read `MOBILE_REFACTORING_GUIDE.md`
- **Step-by-step:** Follow `MIGRATION_TEMPLATE.md`
- **Working example:** Check `pages/Leiloes.jsx`
- **API details:** Check component JSDoc comments

---

**Happy refactoring! 🎉**