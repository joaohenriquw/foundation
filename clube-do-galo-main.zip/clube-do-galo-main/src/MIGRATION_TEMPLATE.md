# Page Migration Template - Mobile Refactoring

Use this template to refactor remaining pages for mobile compatibility.

---

## Step 1: Add Imports

```jsx
// Replace/add these imports
import BackHeader from "@/components/BackHeader";
import PaginationList from "@/components/PaginationList";
import SelectField from "@/components/SelectField";
import PullToRefresh from "@/components/PullToRefresh";
```

---

## Step 2: Replace Custom Header with BackHeader

### BEFORE
```jsx
<div style={{ background: "#fff", padding: "16px", display: "flex", justifyContent: "space-between" }}>
  <Link to="/" style={{ fontSize: 20 }}>←</Link>
  <div style={{ fontSize: 18, fontWeight: 900 }}>Page Title</div>
  <NotificacoesSino />
</div>
```

### AFTER
```jsx
<BackHeader 
  title="Page Title"
  subtitle="Optional subtitle"
  showBackButton={true}
  rightAction={<NotificacoesSino />}
/>
```

---

## Step 3: Replace Pagination with PaginationList

### BEFORE
```jsx
const [page, setPage] = useState(1);
const itemsPerPage = 10;
const start = (page - 1) * itemsPerPage;
const paginatedData = data.slice(start, start + itemsPerPage);

return (
  <div>
    {paginatedData.map(item => <div key={item.id}>{item.name}</div>)}
    <button onClick={() => setPage(p => p - 1)}>Previous</button>
    <span>Page {page}</span>
    <button onClick={() => setPage(p => p + 1)}>Next</button>
  </div>
);
```

### AFTER
```jsx
<PaginationList
  items={data}
  itemsPerPage={10}
  renderItem={(item) => (
    <div key={item.id}>{item.name}</div>
  )}
  emptyComponent={
    <div style={{ textAlign: "center", padding: 40 }}>
      <div style={{ fontSize: 48 }}>📭</div>
      <div style={{ fontWeight: 700 }}>No items</div>
    </div>
  }
/>
```

---

## Step 4: Replace `<select>` with SelectField

### BEFORE
```jsx
<select 
  value={status} 
  onChange={(e) => setStatus(e.target.value)}
>
  <option value="">Select Status</option>
  <option value="ativo">Ativo</option>
  <option value="encerrado">Encerrado</option>
</select>
```

### AFTER
```jsx
<SelectField
  value={status}
  onChange={(e) => setStatus(e.target.value)}
  options={[
    { value: "ativo", label: "Ativo" },
    { value: "encerrado", label: "Encerrado" }
  ]}
  label="Status"
  placeholder="Selecionar status"
  required
/>
```

---

## Step 5: Wrap Lists with PullToRefresh

### BEFORE
```jsx
<div>
  {items.map(item => <ItemCard key={item.id} item={item} />)}
</div>
```

### AFTER
```jsx
<PullToRefresh onRefresh={async () => {
  await carregar(); // Your refresh function
}}>
  <div>
    {items.map(item => <ItemCard key={item.id} item={item} />)}
  </div>
</PullToRefresh>
```

---

## Step 6: Remove Old Pagination State

```jsx
// DELETE these from state
const [page, setPage] = useState(1);
const [paginaAtual, setPaginaAtual] = useState(1);
const [currentPage, setCurrentPage] = useState(1);

// DELETE pagination logic
const totalPages = Math.ceil(data.length / itemsPerPage);
const start = (page - 1) * itemsPerPage;
const paginatedData = data.slice(start, start + itemsPerPage);
```

---

## Step 7: Update Layout Spacing

### Mobile-First Spacing Rules

```jsx
// Content padding
padding: "16px", // was "20px" or more

// Gap between items
gap: 12, // was 8 or less

// Minimum heights for touch targets
minHeight: 44,
minWidth: 44,

// Header/Footer safe area
paddingTop: "env(safe-area-inset-top, 12px)",
paddingBottom: "env(safe-area-inset-bottom, 8px)",
paddingLeft: "env(safe-area-inset-left)",
paddingRight: "env(safe-area-inset-right)",
```

---

## Checklist

- [ ] Import BackHeader, PaginationList, SelectField, PullToRefresh
- [ ] Replace custom header with `<BackHeader />`
- [ ] Replace pagination logic with `<PaginationList />`
- [ ] Replace all `<select>` with `<SelectField />`
- [ ] Wrap lists with `<PullToRefresh />`
- [ ] Remove old pagination state/logic
- [ ] Update spacing to mobile-first (16px padding, 12px gap)
- [ ] Test on mobile (375px width)
- [ ] Test keyboard navigation
- [ ] Test touch targets (44x44px minimum)
- [ ] Test dark mode (if applicable)

---

## Common Issues & Fixes

### Issue: SelectField doesn't appear
**Fix:** Make sure options are in correct format: `[{value, label}]`

### Issue: PaginationList doesn't paginate
**Fix:** Pass `itemsPerPage={10}` (default is 10, but be explicit)

### Issue: BackHeader doesn't show back button
**Fix:** Check if route is in rootPaths array. Edit BackHeader to add your route if it's a root screen.

### Issue: PullToRefresh doesn't work
**Fix:** 
- Make sure onRefresh is an async function
- Wrap entire scrollable list, not individual items
- Test on actual mobile device (not browser)

---

## Performance Tips

1. **Don't over-paginate** - Start with 10-20 items per page
2. **Lazy load images** - Add `loading="lazy"` to images
3. **Memoize lists** - Use `useMemo` if list is expensive to render
4. **Debounce search** - If filtering, debounce input changes

---

## Questions?

Refer to:
1. `MOBILE_REFACTORING_GUIDE.md` - Full documentation
2. `pages/Leiloes.jsx` - Example implementation
3. Component JSDoc comments - Usage examples