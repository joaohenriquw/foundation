import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';

export default function ListaConversasDM({ user }) {
  const [conversas, setConversas] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    carregarConversas();
    const unsub = base44.entities.ConversaDM.subscribe((ev) => {
      if (ev.type === 'create' || ev.type === 'update') {
        carregarConversas();
      }
    });
    return unsub;
  }, []);

  const carregarConversas = async () => {
    try {
      const res = await base44.functions.invoke('listarConversasDM', {});
      setConversas(res.data.conversas || []);
    } catch (e) {
      console.error('Erro:', e);
    } finally {
      setCarregando(false);
    }
  };

  if (carregando) {
    return <div style={{ textAlign: 'center', padding: 20 }}>⏳</div>;
  }

  if (conversas.length === 0) {
    return (
      <div style={{
        textAlign: 'center',
        padding: '20px',
        color: '#57636C',
        fontSize: 12
      }}>
        Nenhuma conversa
      </div>
    );
  }

  return (
    <div style={{ display: 'grid', gap: 8 }}>
      {conversas.map(conv => {
        const outrNome = conv.usuario1_email === user.email ? conv.usuario2_nome : conv.usuario1_nome;
        const outraEmail = conv.usuario1_email === user.email ? conv.usuario2_email : conv.usuario1_email;
        const avatar = (outrNome?.[0] || outraEmail?.[0] || 'U').toUpperCase();

        return (
        <Link
           key={conv.id}
            to={`/dm/${conv.id}`}
            style={{
            display: 'flex',
            gap: 10,
            padding: '12px',
            background: conv.nao_lidas > 0 ? '#F0F4FF' : '#fff',
            borderRadius: 10,
            border: `1px solid ${conv.nao_lidas > 0 ? '#D0D8FF' : '#E8ECF0'}`,
            textDecoration: 'none',
            color: '#101213',
            cursor: 'pointer',
            transition: '.2s'
          }}
        >
          <div style={{
            width: 36,
            height: 36,
            borderRadius: '50%',
            background: 'linear-gradient(135deg,#170073,#00A893)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontSize: 12,
            fontWeight: 900,
            flexShrink: 0
          }}>
            {avatar}
          </div>

          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontFamily: 'Montserrat,sans-serif',
              fontSize: 12,
              fontWeight: 800,
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              marginBottom: 2
            }}>
              {outrNome || outraEmail}
              {conv.nao_lidas > 0 && (
                <span style={{
                  background: '#170073',
                  color: '#fff',
                  borderRadius: 10,
                  padding: '1px 6px',
                  fontSize: 9,
                  fontWeight: 900
                }}>
                  {conv.nao_lidas}
                </span>
              )}
            </div>
            <div style={{
              fontSize: 11,
              color: '#57636C',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap'
            }}>
              {conv.ultima_preview || 'Sem mensagens'}
            </div>
          </div>
        </Link>
      );
      })}
    </div>
  );
}