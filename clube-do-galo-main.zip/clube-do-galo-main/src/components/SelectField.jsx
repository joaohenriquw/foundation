import Dropdown from "./Dropdown";

/**
 * Wrapper that converts native <select> API to Dropdown component
 * Drop-in replacement for HTML select elements with mobile optimization
 */
export default function SelectField({
  value = "",
  onChange = () => {},
  options = [],
  placeholder = "Selecionar...",
  label = "",
  required = false,
  disabled = false,
  className = "",
  name = "",
}) {
  // Convert options from various formats:
  // 1. Array of strings: ["Opção A", "Opção B"]
  // 2. Array of objects: [{value: "a", label: "Opção A"}]
  // 3. Grouped/nested: handled by user before passing
  const normalizedOptions = Array.isArray(options)
    ? options.map((opt) => {
        if (typeof opt === "string") {
          return { value: opt, label: opt };
        }
        return opt;
      })
    : [];

  const handleChange = (newValue) => {
    onChange({
      target: {
        value: newValue,
        name: name,
      },
    });
  };

  return (
    <Dropdown
      options={normalizedOptions}
      value={value}
      onChange={handleChange}
      placeholder={placeholder}
      label={label}
      disabled={disabled}
      className={className}
      required={required}
    />
  );
}