import { useState } from "react";
import { base44 } from "@/api/base44Client";
import BuscaGenealogiaGlobal from "./BuscaGenealogiaGlobal";

const CORES = [
  { label: "Azul",     value: "azul",     hex: "#1565C0" },
  { label: "Vermelho", value: "vermelho", hex: "#C62828" },
  { label: "Verde",    value: "verde",    hex: "#2E7D32" },
  { label: "Amarelo",  value: "amarelo",  hex: "#F0A500" },
  { label: "Laranja",  value: "laranja",  hex: "#E65100" },
  { label: "Rosa",     value: "rosa",     hex: "#AD1457" },
  { label: "Roxo",     value: "roxo",     hex: "#6A1B9A" },
  { label: "Branco",   value: "branco",   hex: "#BDBDBD" },
  { label: "Preto",    value: "preto",    hex: "#212121" },
];

function dataDefault(diasExtra = 40) {
  const d = new Date();
  d.setDate(d.getDate() + diasExtra);
  return d.toISOString().split("T")[0];
}

function novaAnilha() {
  return { data: dataDefault(40) };
}

export default function AnilhasFilhas({ animal, user, onClose }) {
  const isPai = animal.sexo === "macho";

  // Pré-selecionar o animal como pai ou mãe conforme sexo
  const [pai, setPai] = useState(isPai ? { id: animal.id, nome: animal.nome } : null);
  const [mae, setMae] = useState(!isPai ? { id: animal.id, nome: animal.nome } : null);

  const [cor, setCor] = useState("azul");
  const [anilhas, setAnilhas] = useState(() => Array.from({ length: 10 }, novaAnilha));
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const corSel = CORES.find((c) => c.value === cor) || CORES[0];

  const updateData = (idx, value) =>
    setAnilhas((prev) => prev.map((a, i) => (i === idx ? { ...a, data: value } : a)));

  const remover = (idx) =>
    setAnilhas((prev) => prev.filter((_, i) => i !== idx));

  const adicionar = () =>
    setAnilhas((prev) => [...prev, novaAnilha()]);

  const salvar = async () => {
    if (!pai || !mae) {
      alert("Selecione o Pai e a Mãe antes de salvar.");
      return;
    }
    if (anilhas.length === 0) return;
    setSaving(true);
    const registros = anilhas.map((a) => ({
      usuario_email:       user?.email || "",
      usuario_id:          user?.id || user?.email || "",
      cor_anilha_definitiva: cor,
      data_troca_definitiva: a.data,
      status:              "incubando",
      animal_pai_id:       pai.id,
      animal_pai_nome:     pai.nome,
      animal_mae_id:       mae.id,
      animal_mae_nome:     mae.nome,
      anilha_numero:       "",
      data_criacao:        new Date().toISOString().split("T")[0],
    }));
    await base44.entities.AnilhaFilha.bulkCreate(registros);
    if (user?.email) {
      await base44.entities.Notificacao.create({
        destinatario_email: user.email,
        titulo: "🐣 Anilhas Filhas Registradas",
        mensagem: `${anilhas.length} anilha(s) filhas registradas. Você será notificado(a) na data definida para troca definitiva.`,
        tipo: "anilha",
        icone: "🐣",
        lida: false,
      }).catch(() => {});
    }
    setSaving(false);
    setSaved(true);
  };

  return (
    <div
      style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 620, maxHeight: "92vh", overflowY: "auto", padding: "20px 20px 40px" }}>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🐣 Anilhas Filhas / Ninhada</div>
            <div style={{ fontSize: 12, color: "#57636C", marginTop: 2 }}>
              {isPai ? "♂️ Pai:" : "♀️ Mãe:"} <strong>{animal.nome}</strong> · {animal.anilha}
            </div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        {saved ? (
          <div style={{ textAlign: "center", padding: "40px 20px" }}>
            <div style={{ fontSize: 52, marginBottom: 12 }}>✅</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#2E7D32" }}>
              {anilhas.length} anilha{anilhas.length !== 1 ? "s" : ""} registrada{anilhas.length !== 1 ? "s" : ""}!
            </div>
            <div style={{ fontSize: 13, color: "#57636C", marginTop: 8, marginBottom: 24 }}>
              Você receberá uma notificação na data definida para trocar para a anilha definitiva.
            </div>
            <button onClick={onClose}
              style={{ padding: "12px 32px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 800, cursor: "pointer" }}>
              Fechar
            </button>
          </div>
        ) : (
          <>
            {/* Seleção Pai */}
            <div style={{ background: "#F0F4FF", borderRadius: 12, padding: 12, marginBottom: 10 }}>
              <BuscaGenealogiaGlobal label="♂️ Selecionar Pai" onSelect={setPai} />
              {pai && (
                <div style={{ fontSize: 11, color: "#170073", marginTop: 6, fontWeight: 700 }}>✅ {pai.nome}</div>
              )}
            </div>

            {/* Seleção Mãe */}
            <div style={{ background: "#F0F4FF", borderRadius: 12, padding: 12, marginBottom: 16 }}>
              <BuscaGenealogiaGlobal label="♀️ Selecionar Mãe" onSelect={setMae} />
              {mae && (
                <div style={{ fontSize: 11, color: "#170073", marginTop: 6, fontWeight: 700 }}>✅ {mae.nome}</div>
              )}
            </div>

            {/* Seleção de cor */}
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 }}>🎨 Cor das Anilhas</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {CORES.map((c) => (
                  <button key={c.value} onClick={() => setCor(c.value)}
                    style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", borderRadius: 20, border: `2px solid ${cor === c.value ? c.hex : "#E8ECF0"}`, background: cor === c.value ? c.hex + "20" : "#fff", cursor: "pointer", fontSize: 12, fontWeight: 700, color: cor === c.value ? c.hex : "#57636C" }}>
                    <span style={{ width: 12, height: 12, borderRadius: "50%", background: c.hex, display: "inline-block", border: "1px solid rgba(0,0,0,.15)" }} />
                    {c.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Banner info */}
            <div style={{ background: corSel.hex + "18", border: `1.5px solid ${corSel.hex}40`, borderRadius: 12, padding: "10px 14px", marginBottom: 16, display: "flex", alignItems: "center", gap: 10 }}>
              <span style={{ width: 20, height: 20, borderRadius: "50%", background: corSel.hex, display: "inline-block", flexShrink: 0, border: "1px solid rgba(0,0,0,.15)" }} />
              <div style={{ fontSize: 12, color: "#101213" }}>
                <strong>Cor: {corSel.label}</strong> · O número da anilha ficará em branco até a notificação de troca chegar na data definida.
              </div>
            </div>

            {/* Lista de anilhas */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: 0.5 }}>
                📿 {anilhas.length} Anilha{anilhas.length !== 1 ? "s" : ""} — Data de Notificação
              </div>
            </div>

            <div style={{ display: "grid", gap: 8 }}>
              {anilhas.map((a, i) => (
                <div key={i} style={{ display: "grid", gridTemplateColumns: "36px 1fr auto", gap: 8, alignItems: "center", background: "#F8FAFC", borderRadius: 10, padding: "8px 12px" }}>
                  <div style={{ width: 30, height: 30, borderRadius: "50%", background: corSel.hex, border: corSel.value === "branco" ? "1.5px solid #ccc" : "none", flexShrink: 0 }} />
                  <div>
                    <div style={{ fontSize: 9, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 3 }}>Data p/ notificação</div>
                    <input
                      type="date"
                      value={a.data}
                      onChange={(e) => updateData(i, e.target.value)}
                      style={{ padding: "7px 10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", width: "100%", boxSizing: "border-box" }}
                    />
                  </div>
                  <button onClick={() => remover(i)}
                    style={{ background: "#FFEBEE", border: "none", borderRadius: 8, width: 32, height: 32, cursor: "pointer", fontSize: 15, color: "#C62828", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    🗑️
                  </button>
                </div>
              ))}
            </div>

            <button onClick={adicionar}
              style={{ width: "100%", marginTop: 10, padding: "11px", borderRadius: 10, border: "1.5px dashed #170073", background: "#F0F4FF", color: "#170073", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800 }}>
              + Adicionar mais uma anilha
            </button>

            <div style={{ background: "#FFF8E1", borderRadius: 10, padding: "10px 14px", marginTop: 12, fontSize: 12, color: "#795548" }}>
              📅 <strong>Dica:</strong> Na data escolhida, você receberá uma notificação para trocar a cor da anilha e cadastrar o número definitivo.
            </div>

            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
              <button onClick={onClose}
                style={{ flex: 1, padding: "12px", borderRadius: 12, border: "1.5px solid #E8ECF0", background: "#fff", color: "#57636C", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 700 }}>
                Cancelar
              </button>
              <button onClick={salvar} disabled={saving || anilhas.length === 0 || !pai || !mae}
                style={{ flex: 2, padding: "12px", borderRadius: 12, border: "none", background: (saving || anilhas.length === 0 || !pai || !mae) ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: (saving || anilhas.length === 0 || !pai || !mae) ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
                {saving ? "Salvando..." : `✅ Criar ${anilhas.length} Anilha${anilhas.length !== 1 ? "s" : ""}`}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}