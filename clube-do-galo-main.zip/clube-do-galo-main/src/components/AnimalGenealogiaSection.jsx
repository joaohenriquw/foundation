import { useState } from "react";
import SeletorPaiMae from "./SeletorPaiMae";

export default function AnimalGenealogiaSection({ form, setForm, userEmail }) {
  const [expandirAvos, setExpandirAvos] = useState(false);

  return (
    <div style={{ display: "grid", gap: 14, borderBottom: `1px solid hsl(var(--border))`, paddingBottom: 16, marginBottom: 16 }}>
      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "hsl(var(--foreground))" }}>
        🧬 Genealogia
      </div>

      {/* Pai e Mãe */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <div>
          <SeletorPaiMae label="Pai" value={form.pai_id} valueName={form.pai_nome} userEmail={userEmail}
            onChange={sel => setForm(p => ({ ...p, pai_id: sel?.id || null, pai_nome: sel?.nome || "" }))} />
        </div>
        <div>
          <SeletorPaiMae label="Mãe" value={form.mae_id} valueName={form.mae_nome} userEmail={userEmail}
            onChange={sel => setForm(p => ({ ...p, mae_id: sel?.id || null, mae_nome: sel?.nome || "" }))} />
        </div>
      </div>

      {/* Expandir Avós */}
      <button onClick={() => setExpandirAvos(!expandirAvos)}
        style={{ padding: "10px 14px", borderRadius: 10, border: `1px dashed hsl(var(--border))`, background: "hsl(var(--background))", color: "hsl(var(--muted-foreground))", cursor: "pointer", fontSize: 12, fontWeight: 700, textAlign: "left" }}>
        {expandirAvos ? "▼ Ocultar Avós" : "▶ Adicionar Avós (Opcional)"}
      </button>

      {expandirAvos && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, background: "hsl(var(--muted))", padding: 12, borderRadius: 10 }}>
          <div>
            <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginBottom: 6, fontWeight: 700 }}>Avô Paterno</div>
            <SeletorPaiMae label="Avô Paterno" value={form.avo_paterno_id || ""} valueName={form.avo_paterno_nome || ""} userEmail={userEmail}
              onChange={sel => setForm(p => ({ ...p, avo_paterno_id: sel?.id || null, avo_paterno_nome: sel?.nome || "" }))} />
          </div>
          <div>
            <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginBottom: 6, fontWeight: 700 }}>Avó Paterna</div>
            <SeletorPaiMae label="Avó Paterna" value={form.avo_paterna_id || ""} valueName={form.avo_paterna_nome || ""} userEmail={userEmail}
              onChange={sel => setForm(p => ({ ...p, avo_paterna_id: sel?.id || null, avo_paterna_nome: sel?.nome || "" }))} />
          </div>
          <div>
            <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginBottom: 6, fontWeight: 700 }}>Avô Materno</div>
            <SeletorPaiMae label="Avô Materno" value={form.avo_materno_id || ""} valueName={form.avo_materno_nome || ""} userEmail={userEmail}
              onChange={sel => setForm(p => ({ ...p, avo_materno_id: sel?.id || null, avo_materno_nome: sel?.nome || "" }))} />
          </div>
          <div>
            <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginBottom: 6, fontWeight: 700 }}>Avó Materna</div>
            <SeletorPaiMae label="Avó Materna" value={form.avo_materna_id || ""} valueName={form.avo_materna_nome || ""} userEmail={userEmail}
              onChange={sel => setForm(p => ({ ...p, avo_materna_id: sel?.id || null, avo_materna_nome: sel?.nome || "" }))} />
          </div>
        </div>
      )}
    </div>
  );
}