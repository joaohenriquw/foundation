import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export default function SuporteAoUsuario({ user }) {
  const [usuarios, setUsuarios] = useState([]);
  const [mensagens, setMensagens] = useState([]);
  const [usuarioSelecionado, setUsuarioSelecionado] = useState(null);
  const [novaMensagem, setNovaMensagem] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [enviando, setEnviando] = useState(false);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      const usuariosData = await base44.entities.User.list('-created_date', 100);
      setUsuarios(usuariosData.filter(u => u.email !== user.email));
    } catch (e) {
      console.error('Erro ao carregar usuários:', e);
    } finally {
      setCarregando(false);
    }
  };

  const selecionarUsuario = async (usuario) => {
    setUsuarioSelecionado(usuario);
    try {
      // Buscar mensagens de suporte para este usuário
      const msgs = await base44.entities.Notificacao.filter(
        { destinatario_email: usuario.email, tipo: 'suporte' },
        '-created_date',
        50
      );
      setMensagens(msgs);
    } catch (e) {
      console.error('Erro ao carregar mensagens:', e);
    }
  };

  const enviarResposta = async () => {
    if (!novaMensagem.trim() || !usuarioSelecionado) return;

    setEnviando(true);
    try {
      await base44.entities.Notificacao.create({
        destinatario_email: usuarioSelecionado.email,
        titulo: '💬 Resposta de Suporte',
        mensagem: novaMensagem,
        tipo: 'suporte',
        lida: false,
        icone: '💬',
      });
      setNovaMensagem('');
      await selecionarUsuario(usuarioSelecionado);
    } catch (e) {
      alert('Erro ao enviar resposta: ' + e.message);
    } finally {
      setEnviando(false);
    }
  };

  if (carregando) {
    return <div style={{ textAlign: 'center', padding: 20 }}>Carregando...</div>;
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 16 }}>
      {/* Lista de Usuários */}
      <div style={{ background: '#fff', borderRadius: 14, border: '1px solid #E8ECF0', padding: 14, maxHeight: 600, overflowY: 'auto' }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: '#101213', marginBottom: 12 }}>Usuários</div>
        {usuarios.length === 0 ? (
          <div style={{ fontSize: 11, color: '#BDBDBD', textAlign: 'center', padding: 20 }}>Nenhum usuário</div>
        ) : (
          usuarios.map(u => (
            <div
              key={u.id}
              onClick={() => selecionarUsuario(u)}
              style={{
                padding: '10px 12px',
                borderRadius: 10,
                marginBottom: 8,
                cursor: 'pointer',
                background: usuarioSelecionado?.id === u.id ? '#170073' : '#F8FAFC',
                color: usuarioSelecionado?.id === u.id ? '#fff' : '#101213',
                transition: '.15s',
              }}>
              <div style={{ fontSize: 11, fontWeight: 700 }}>{u.full_name || u.email}</div>
              <div style={{ fontSize: 9, opacity: 0.7 }}>{u.email}</div>
            </div>
          ))
        )}
      </div>

      {/* Chat de Suporte */}
      {usuarioSelecionado ? (
        <div style={{ background: '#fff', borderRadius: 14, border: '1px solid #E8ECF0', padding: 14, display: 'flex', flexDirection: 'column' }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: '#101213', marginBottom: 12 }}>
            💬 Suporte - {usuarioSelecionado.full_name}
          </div>

          {/* Mensagens */}
          <div style={{ flex: 1, minHeight: 300, maxHeight: 400, overflowY: 'auto', marginBottom: 12, background: '#F8FAFC', borderRadius: 10, padding: 12 }}>
            {mensagens.length === 0 ? (
              <div style={{ fontSize: 11, color: '#BDBDBD', textAlign: 'center', padding: 40 }}>Nenhuma mensagem</div>
            ) : (
              mensagens.map(msg => (
                <div key={msg.id} style={{ marginBottom: 12, padding: 10, background: '#fff', borderRadius: 8, border: '1px solid #E8ECF0' }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: '#170073', marginBottom: 4 }}>
                    {msg.titulo}
                  </div>
                  <div style={{ fontSize: 11, color: '#57636C', lineHeight: 1.5 }}>{msg.mensagem}</div>
                  <div style={{ fontSize: 9, color: '#BDBDBD', marginTop: 6 }}>
                    {new Date(msg.created_date).toLocaleString('pt-BR')}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Input de Resposta */}
          <div style={{ display: 'grid', gap: 8 }}>
            <textarea
              value={novaMensagem}
              onChange={e => setNovaMensagem(e.target.value)}
              placeholder="Digite sua resposta de suporte..."
              style={{
                width: '100%',
                padding: '10px 12px',
                borderRadius: 10,
                border: '1.5px solid #E8ECF0',
                fontSize: 12,
                fontFamily: 'inherit',
                outline: 'none',
                minHeight: 60,
                boxSizing: 'border-box',
              }}
            />
            <button
              onClick={enviarResposta}
              disabled={enviando || !novaMensagem.trim()}
              style={{
                padding: '10px 12px',
                borderRadius: 10,
                border: 'none',
                background: enviando ? '#ccc' : 'linear-gradient(135deg, #170073, #00A893)',
                color: '#fff',
                cursor: enviando ? 'default' : 'pointer',
                fontFamily: 'Montserrat, sans-serif',
                fontWeight: 700,
                fontSize: 12,
              }}>
              {enviando ? '⏳ Enviando...' : '✉️ Enviar Resposta'}
            </button>
          </div>
        </div>
      ) : (
        <div style={{ background: '#fff', borderRadius: 14, border: '1px solid #E8ECF0', padding: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 300 }}>
          <div style={{ textAlign: 'center', color: '#BDBDBD' }}>
            <div style={{ fontSize: 32, marginBottom: 10 }}>💬</div>
            <div style={{ fontSize: 12, fontWeight: 700 }}>Selecione um usuário</div>
          </div>
        </div>
      )}
    </div>
  );
}