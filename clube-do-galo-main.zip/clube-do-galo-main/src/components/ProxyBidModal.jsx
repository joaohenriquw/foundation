import { useState } from "react";
import { base44 } from "@/api/base44Client";

export default function ProxyBidModal({ leilao, user, onClose, onConcluido }) {
  const [valorMax, setValorMax] = useState("");
  const [processando, setProcessando] = useState(false);

  const salvar = async () => {
    if (!valorMax || Number(valorMax) < (leilao.maior_lance || leilao.lance_minimo)) {
      alert("Valor deve ser superior ao maior lance atual!");
      return;
    }

    setProcessando(true);

    // Criar meta-lance armazenando o valorMax
    await base44.entities.LeilaoLance.create({
      leilao_id: leilao.id,
      user_id: user.id,
      user_nome: user.full_name,
      user_email: user.email,
      valor: Number(valorMax),
      parcelas: 1,
      valor_parcela: Number(valorMax),
      proxy_bid_ativo: true,
      valor_max_proxy: Number(valorMax),
    });

    setProcessando(false);
    onClose();
    if (onConcluido) onConcluido();
    alert("✅ Proxy bid ativado! Você lançará automaticamente até R$ " + Number(valorMax).toLocaleString("pt-BR"));
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={onClose}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🤖 Proxy Bid Automático</div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        <div style={{ background: "#F0F4FF", borderRadius: 10, padding: 12, marginBottom: 16, fontSize: 11, color: "#170073", fontWeight: 700, lineHeight: 1.6 }}>
          ℹ️ Defina o valor máximo que você quer gastar. Você lançará automaticamente quando outros lançarem, até atingir esse limite.
        </div>

        <div style={{ display: "grid", gap: 12 }}>
          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Valor Máximo (R$)</label>
            <input
              type="number"
              value={valorMax}
              onChange={e => setValorMax(e.target.value)}
              placeholder="Ex: 5000"
              style={{ width: "100%", padding: "12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }}
            />
            <div style={{ fontSize: 10, color: "#57636C", marginTop: 6 }}>
              Maior lance atual: R$ {Number(leilao.maior_lance || leilao.lance_minimo).toLocaleString("pt-BR")}
            </div>
          </div>

          <button
            onClick={salvar}
            disabled={processando || !valorMax}
            style={{
              width: "100%",
              padding: "12px",
              borderRadius: 10,
              border: "none",
              background: processando || !valorMax ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
              color: "#fff",
              cursor: processando || !valorMax ? "default" : "pointer",
              fontFamily: "Montserrat,sans-serif",
              fontWeight: 700,
            }}
          >
            {processando ? "Ativando..." : "🤖 Ativar Proxy Bid"}
          </button>
        </div>
      </div>
    </div>
  );
}