import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";

function CoracaoAnimado({ onEnd }) {
  useEffect(() => {
    const t = setTimeout(onEnd, 900);
    return () => clearTimeout(t);
  }, []);

  return (
    <div style={{
      position: "absolute",
      left: "50%",
      bottom: "30%",
      transform: "translateX(-50%)",
      fontSize: 64,
      animation: "heartPop 0.9s ease-out forwards",
      pointerEvents: "none",
      zIndex: 10,
    }}>
      ❤️
    </div>
  );
}

export default function StoriesFeed({ user }) {
  const [stories, setStories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [curtidas, setCurtidas] = useState({});
  const [storyVisualizado, setStoryVisualizado] = useState(null);
  const [mostrarCoracao, setMostrarCoracao] = useState(false);
  const lastTap = useRef(0);

  // Persiste curtidas no localStorage
  const STORAGE_KEY = `story_likes_${user?.email || "anon"}`;
  const getCurtidasSalvas = () => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); } catch { return {}; }
  };

  useEffect(() => {
    const carregar = async () => {
      const storiesData = await base44.entities.Story.filter({ ativo: true }, "-created_date", 50);
      setStories(storiesData);
      setCurtidas(getCurtidasSalvas());
      setLoading(false);
    };
    carregar();

    const unsub = base44.entities.Story.subscribe((ev) => {
      if (ev.type === "update" && storyVisualizado?.id === ev.id) {
        setStoryVisualizado(ev.data);
      }
      if (ev.type === "create" || ev.type === "update") {
        setStories(prev => {
          const idx = prev.findIndex(s => s.id === ev.id);
          if (idx >= 0) { const n = [...prev]; n[idx] = ev.data; return n; }
          return ev.type === "create" ? [ev.data, ...prev] : prev;
        });
      } else if (ev.type === "delete") {
        setStories(prev => prev.filter(s => s.id !== ev.id));
      }
    });

    return unsub;
  }, [user?.email]);

  const reagir = async (story, duplo = false) => {
    if (!user) return;
    const saved = getCurtidasSalvas();
    const jaCurtiu = saved[story.id];

    if (jaCurtiu && !duplo) {
      // Descurtir
      const novas = { ...saved };
      delete novas[story.id];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(novas));
      setCurtidas(novas);
      await base44.entities.Story.update(story.id, { curtidas: Math.max(0, (story.curtidas || 0) - 1) });
    } else if (!jaCurtiu) {
      // Curtir com animação
      const novas = { ...saved, [story.id]: true };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(novas));
      setCurtidas(novas);
      setMostrarCoracao(true);
      await base44.entities.Story.update(story.id, { curtidas: (story.curtidas || 0) + 1 });
    }
  };

  const handleTapStory = (e) => {
    if (!storyVisualizado) return;
    const now = Date.now();
    if (now - lastTap.current < 350) {
      // Duplo toque
      reagir(storyVisualizado, true);
    }
    lastTap.current = now;
  };

  const abrirStory = async (story) => {
    setStoryVisualizado(story);
    await base44.entities.Story.update(story.id, { visualizacoes: (story.visualizacoes || 0) + 1 });
  };

  if (loading) {
    return <div style={{ textAlign: "center", padding: 24, color: "#57636C" }}>Carregando stories...</div>;
  }

  if (stories.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>
        <div style={{ fontSize: 48, marginBottom: 10 }}>📸</div>
        <div style={{ fontWeight: 700 }}>Nenhum story postado ainda</div>
        <div style={{ fontSize: 12, marginTop: 6 }}>Seja o primeiro a criar um!</div>
      </div>
    );
  }

  const jaReagiu = storyVisualizado ? !!curtidas[storyVisualizado.id] : false;

  return (
    <div>
      <style>{`
        @keyframes heartPop {
          0%   { transform: translateX(-50%) scale(0); opacity: 1; }
          50%  { transform: translateX(-50%) scale(1.4); opacity: 1; }
          100% { transform: translateX(-50%) scale(1) translateY(-60px); opacity: 0; }
        }
        @keyframes heartBeat {
          0%   { transform: scale(1); }
          30%  { transform: scale(1.4); }
          60%  { transform: scale(0.9); }
          100% { transform: scale(1); }
        }
      `}</style>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: 10, marginBottom: 20 }}>
        {stories.map(story => (
          <div key={story.id}
            onClick={() => abrirStory(story)}
            style={{ background: "#fff", borderRadius: 12, overflow: "hidden", border: "1px solid #E8ECF0", cursor: "pointer", transition: "transform 0.2s" }}
            onMouseEnter={e => e.currentTarget.style.transform = "scale(1.02)"}
            onMouseLeave={e => e.currentTarget.style.transform = "scale(1)"}
          >
            <div style={{ height: 140, background: story.midia_url ? `url(${story.midia_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
              {!story.midia_url && <span style={{ fontSize: 48 }}>🐓</span>}
              <div style={{ position: "absolute", top: 6, right: 6, background: "rgba(0,0,0,.5)", color: "#fff", borderRadius: 6, padding: "2px 6px", fontSize: 9, fontWeight: 700 }}>
                {story.tipo === "foto" ? "📸" : story.tipo === "video" ? "🎥" : "📊"}
              </div>
              {/* Contador de corações no card */}
              {(story.curtidas || 0) > 0 && (
                <div style={{ position: "absolute", bottom: 6, right: 8, background: "rgba(0,0,0,.55)", borderRadius: 20, padding: "2px 8px", display: "flex", alignItems: "center", gap: 4, fontSize: 11, color: "#fff", fontWeight: 700 }}>
                  ❤️ {story.curtidas}
                </div>
              )}
            </div>
            <div style={{ padding: "8px 10px" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 800, color: "#101213", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {story.usuario_nome}
              </div>
              {story.titulo && (
                <div style={{ fontSize: 10, color: "#57636C", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", marginTop: 2 }}>
                  {story.titulo}
                </div>
              )}
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6, paddingTop: 6, borderTop: "1px solid #F1F4F8", fontSize: 10, color: "#57636C" }}>
                <span>👁️ {story.visualizacoes || 0}</span>
                <span style={{ color: (story.curtidas || 0) > 0 ? "#E21C3D" : "#57636C" }}>❤️ {story.curtidas || 0}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Visualizador fullscreen */}
      {storyVisualizado && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.92)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center" }}
          onClick={() => { setStoryVisualizado(null); setMostrarCoracao(false); }}>
          <div style={{ width: "100%", maxWidth: 400, background: "#000", borderRadius: 16, overflow: "hidden", boxShadow: "0 20px 60px rgba(0,0,0,.6)" }}
            onClick={e => e.stopPropagation()}>

            {/* Barra de progresso */}
            <div style={{ height: 3, background: "rgba(255,255,255,.2)", position: "relative" }}>
              <div style={{ position: "absolute", left: 0, top: 0, height: "100%", background: "#fff", width: "100%", animation: "progress 5s linear forwards" }} />
            </div>

            {/* Header */}
            <div style={{ padding: "12px 16px", display: "flex", alignItems: "center", gap: 10, background: "rgba(0,0,0,.4)" }}>
              <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, fontWeight: 900, color: "#fff", fontFamily: "Montserrat,sans-serif", border: "2px solid rgba(255,255,255,.4)" }}>
                {storyVisualizado.usuario_nome?.[0] || "U"}
              </div>
              <div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#fff" }}>{storyVisualizado.usuario_nome}</div>
                <div style={{ fontSize: 10, color: "rgba(255,255,255,.6)" }}>{new Date(storyVisualizado.created_date).toLocaleDateString("pt-BR")}</div>
              </div>
              <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
                {user?.email === storyVisualizado.usuario_email && (
                  <button onClick={async () => {
                    if (!confirm("Apagar este story?")) return;
                    await base44.entities.Story.delete(storyVisualizado.id);
                    setStoryVisualizado(null);
                    setMostrarCoracao(false);
                  }}
                    style={{ background: "rgba(226,28,61,.25)", border: "1px solid #E21C3D", borderRadius: "50%", width: 32, height: 32, color: "#E21C3D", fontSize: 14, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>🗑️</button>
                )}
                <button onClick={() => { setStoryVisualizado(null); setMostrarCoracao(false); }}
                  style={{ background: "rgba(255,255,255,.15)", border: "none", borderRadius: "50%", width: 32, height: 32, color: "#fff", fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
              </div>
            </div>

            {/* Mídia — duplo toque para reagir */}
            <div style={{ aspectRatio: "9/16", maxHeight: 500, background: storyVisualizado.midia_url ? `url(${storyVisualizado.midia_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative", cursor: "pointer" }}
              onClick={handleTapStory}>

              {!storyVisualizado.midia_url && <span style={{ fontSize: 80 }}>🐓</span>}

              {/* Animação de coração flutuante */}
              {mostrarCoracao && <CoracaoAnimado onEnd={() => setMostrarCoracao(false)} />}

              {/* Texto sobreposto */}
              {storyVisualizado.descricao && (
                <div style={{ position: "absolute", bottom: 16, left: 16, right: 16, background: "rgba(0,0,0,.65)", borderRadius: 12, padding: "10px 14px", fontSize: 14, fontWeight: 700, color: "#fff", backdropFilter: "blur(4px)" }}>
                  {storyVisualizado.descricao}
                </div>
              )}

              {/* Enquete */}
              {storyVisualizado.tipo === "enquete" && storyVisualizado.titulo && (
                <div style={{ position: "absolute", bottom: storyVisualizado.descricao ? 80 : 16, left: 16, right: 16, background: "rgba(255,255,255,.93)", borderRadius: 14, padding: "12px 16px", backdropFilter: "blur(8px)" }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213", marginBottom: 10 }}>{storyVisualizado.titulo}</div>
                  {(storyVisualizado.opcoes_enquete || []).map((op, i) => (
                    <div key={i} style={{ background: i === 0 ? "#EEF0FF" : "#FFF8E1", borderRadius: 10, padding: "8px 12px", marginBottom: 6, fontSize: 12, fontWeight: 700, color: "#101213", border: `1.5px solid ${i === 0 ? "#170073" : "#F0A500"}` }}>
                      {op.texto}
                    </div>
                  ))}
                </div>
              )}

              {/* Dica duplo toque */}
              <div style={{ position: "absolute", top: 12, left: 0, right: 0, textAlign: "center", fontSize: 10, color: "rgba(255,255,255,.4)", pointerEvents: "none" }}>
                toque 2x para reagir ❤️
              </div>
            </div>

            {/* Footer */}
            <div style={{ background: "rgba(0,0,0,.6)", padding: "12px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 16, fontSize: 12, color: "rgba(255,255,255,.7)" }}>
                <span>👁️ {storyVisualizado.visualizacoes || 0}</span>
                <span style={{ color: (storyVisualizado.curtidas || 0) > 0 ? "#ff6b81" : "rgba(255,255,255,.7)" }}>
                  ❤️ {storyVisualizado.curtidas || 0}
                </span>
              </div>

              {/* Botão coração */}
              <button
                onClick={() => reagir(storyVisualizado)}
                style={{
                  background: jaReagiu ? "rgba(226,28,61,.2)" : "rgba(255,255,255,.1)",
                  border: jaReagiu ? "1.5px solid #E21C3D" : "1.5px solid rgba(255,255,255,.2)",
                  borderRadius: 24,
                  padding: "8px 18px",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  transition: "all 0.25s",
                  animation: jaReagiu ? "heartBeat 0.4s ease" : "none",
                }}>
                <span style={{ fontSize: 18 }}>{jaReagiu ? "❤️" : "🤍"}</span>
                <span style={{ color: jaReagiu ? "#ff6b81" : "rgba(255,255,255,.8)", fontSize: 13, fontWeight: 700, fontFamily: "Montserrat,sans-serif" }}>
                  {jaReagiu ? "Curtido" : "Curtir"}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}