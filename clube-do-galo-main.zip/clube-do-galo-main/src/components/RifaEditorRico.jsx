import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css";

export default function RifaEditorRico({ value, onChange, placeholder }) {
  const modules = {
    toolbar: [
      ["bold", "italic", "underline"],
      [{ list: "bullet" }],
      ["link"],
    ],
  };

  const formats = ["bold", "italic", "underline", "list", "bullet", "link"];

  return (
    <div style={{ border: "1.5px solid #E8ECF0", borderRadius: 10, overflow: "hidden" }}>
      <style>{`
        .ql-toolbar.ql-snow { padding: 2px 4px !important; border: none !important; border-bottom: 1px solid #E8ECF0 !important; }
        .ql-toolbar.ql-snow .ql-formats { margin-right: 3px !important; }
        .ql-toolbar.ql-snow button { width: 16px !important; height: 16px !important; padding: 1px !important; }
        .ql-toolbar.ql-snow button svg { width: 11px !important; height: 11px !important; }
        .ql-toolbar.ql-snow .ql-picker { height: 16px !important; font-size: 10px !important; }
        .ql-container.ql-snow { border: none !important; font-size: 13px !important; }
      `}</style>
      <ReactQuill
        value={value}
        onChange={onChange}
        modules={modules}
        formats={formats}
        placeholder={placeholder}
        theme="snow"
        style={{ minHeight: 100, background: "#fff" }}
      />
    </div>
  );
}