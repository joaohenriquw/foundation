import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { base44 } from "@/api/base44Client";
import SelectField from "./SelectField";

export default function CriarLeilaoModal({ user, animalPreSelecionado, onClose, onCriado }) {
  const [animais, setAnimais]     = useState([]);
  const [anilhasQtd, setAnilhasQtd] = useState(0);
  const [form, setForm] = useState({
    animal_id:     animalPreSelecionado?.id || "",
    titulo:        animalPreSelecionado ? `Leilão — ${animalPreSelecionado.nome}` : "",
    descricao:     "",
    lance_minimo:  "",
    dono_whatsapp: "",
    duracao_horas: "24",
  });
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (user?.email) {
      Promise.all([
        base44.entities.Animal.filter({ proprietario_email: user.email }, "nome", 200).catch(() => []),
        base44.entities.Animal.filter({ created_by: user.email }, "nome", 200).catch(() => []),
      ]).then(([a, b]) => {
        const combined = [...a, ...b];
        const unique = Array.from(new Map(combined.map(x => [x.id, x])).values());
        setAnimais(unique);
      });
    }
  }, [user?.email]);

  useEffect(() => {
    if (form.animal_id) {
      base44.entities.AnilhaFilha.filter({ animal_origem_id: form.animal_id }).then(r => setAnilhasQtd(r.length));
    }
  }, [form.animal_id]);

  const animalSel = animais.find(a => a.id === form.animal_id) || animalPreSelecionado;

  const criar = async () => {
    if (!form.animal_id || !form.lance_minimo || !form.titulo || !form.dono_whatsapp) return;
    setSalvando(true);
    const agora = new Date();
    const fim = new Date(agora.getTime() + Number(form.duracao_horas) * 3600000);
    await base44.entities.Leilao.create({
      animal_id:          form.animal_id,
      animal_nome:        animalSel?.nome || "",
      animal_anilha:      animalSel?.anilha || "",
      animal_foto_url:    animalSel?.foto_url || "",
      animal_especie:     animalSel?.especie || "",
      anilhas_filhas_qtd: anilhasQtd,
      dono_id:            user?.id || user?.email,
      dono_nome:          user?.full_name || user?.email,
      dono_email:         user?.email,
      dono_whatsapp:      form.dono_whatsapp,
      titulo:             form.titulo,
      descricao:          form.descricao,
      lance_minimo:       Number(form.lance_minimo),
      maior_lance:        Number(form.lance_minimo),
      data_inicio:        agora.toISOString(),
      data_fim:           fim.toISOString(),
      status:             "ativo",
    });
    setSalvando(false);
    onCriado && onCriado();
    onClose();
  };

  const content = (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
      background: "rgba(0,0,0,.65)", zIndex: 99999,
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: "16px"
    }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: "#fff", borderRadius: 20,
        width: "100%", maxWidth: 520,
        maxHeight: "85dvh",
        overflowY: "auto", padding: "20px 18px 28px",
        boxSizing: "border-box"
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🔨 Criar Leilão</div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", minWidth: 44, minHeight: 44, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
        </div>

        <div style={{ display: "grid", gap: 14 }}>
          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>🐓 Animal *</label>
            <SelectField
              value={form.animal_id}
              onChange={e => setForm(p => ({ ...p, animal_id: e.target.value, titulo: animais.find(a=>a.id===e.target.value) ? `Leilão — ${animais.find(a=>a.id===e.target.value).nome}` : p.titulo }))}
              options={[{ value: "", label: "Selecione um animal do plantel" }, ...animais.map(a => ({ value: a.id, label: `${a.nome} · ${a.anilha}` }))]}
            />
          </div>

          {animalSel && (
            <div style={{ background: "#F0F4FF", borderRadius: 12, padding: "12px 14px", display: "flex", gap: 12, alignItems: "center" }}>
              <div style={{ width: 52, height: 52, borderRadius: 10, background: animalSel.foto_url ? `url(${animalSel.foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>
                {!animalSel.foto_url && "🐓"}
              </div>
              <div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800 }}>{animalSel.nome}</div>
                <div style={{ fontSize: 11, color: "#57636C" }}>Anilha: {animalSel.anilha} · {animalSel.especie || "—"}</div>
                {anilhasQtd > 0 && <div style={{ fontSize: 11, color: "#00A893", fontWeight: 700 }}>📿 {anilhasQtd} anilhas filhas produzidas</div>}
              </div>
            </div>
          )}

          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>📋 Título *</label>
            <input value={form.titulo} onChange={e => setForm(p => ({ ...p, titulo: e.target.value }))} placeholder="Ex: Leilão Galo Guerreiro — Linha Pura"
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
          </div>

          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>📝 Descrição</label>
            <textarea value={form.descricao} onChange={e => setForm(p => ({ ...p, descricao: e.target.value }))} placeholder="Descreva o animal, sua procedência, características..."
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", height: 70, resize: "none" }} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>💰 Lance Mín. (R$) *</label>
              <input type="number" value={form.lance_minimo} onChange={e => setForm(p => ({ ...p, lance_minimo: e.target.value }))} placeholder="500"
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>⏱️ Duração</label>
              <SelectField
                value={form.duracao_horas}
                onChange={e => setForm(p => ({ ...p, duracao_horas: e.target.value }))}
                options={[["6","6 horas"],["12","12 horas"],["24","24 horas"],["48","48 horas"],["72","72 horas"]].map(([v,l]) => ({ value: v, label: l }))}
              />
            </div>
          </div>

          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>📱 Seu WhatsApp *</label>
            <input value={form.dono_whatsapp} onChange={e => setForm(p => ({ ...p, dono_whatsapp: e.target.value }))} placeholder="(99) 99999-9999"
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
          </div>

          <div style={{ background: "#E8F5E9", borderRadius: 12, padding: "10px 14px", fontSize: 11, color: "#2E7D32" }}>
            💡 <strong>Taxas:</strong> R$ 0,38 (gateway) + 10% taxa administrativa entre os sócios.
          </div>
        </div>

        <button onClick={criar} disabled={!form.animal_id || !form.lance_minimo || !form.titulo || !form.dono_whatsapp || salvando}
          style={{ width: "100%", padding: 14, borderRadius: 12, border: "none", background: !form.animal_id || !form.lance_minimo || !form.titulo || !form.dono_whatsapp ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: !form.animal_id || !form.lance_minimo || !form.titulo || !form.dono_whatsapp ? "not-allowed" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, marginTop: 16 }}>
          {salvando ? "Criando..." : "🔨 Publicar Leilão"}
        </button>
      </div>
    </div>
  );

  return createPortal(content, document.body);
}