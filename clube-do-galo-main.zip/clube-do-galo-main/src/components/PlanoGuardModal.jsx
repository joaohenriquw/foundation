import { useState } from 'react';

export default function PlanoGuardModal({ tipo, validacao, onFechar }) {
  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      background: 'rgba(0,0,0,.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999,
    }}>
      <div style={{
        background: '#fff',
        borderRadius: 16,
        padding: '24px',
        maxWidth: 400,
        boxShadow: '0 16px 40px rgba(0,0,0,.2)',
      }}>
        <div style={{ fontSize: 40, marginBottom: 16, textAlign: 'center' }}>💎</div>

        <div style={{
          fontFamily: 'Montserrat,sans-serif',
          fontSize: 18,
          fontWeight: 900,
          color: '#170073',
          marginBottom: 8,
          textAlign: 'center',
        }}>
          Upgrade Necessário
        </div>

        <div style={{
          fontSize: 13,
          color: '#57636C',
          lineHeight: 1.6,
          marginBottom: 16,
          textAlign: 'center',
        }}>
          {validacao.mensagem}
        </div>

        {/* Info do plano */}
        <div style={{
          background: '#F0F4FF',
          borderRadius: 12,
          padding: '12px',
          marginBottom: 16,
          fontSize: 11,
          color: '#170073',
          fontWeight: 700,
        }}>
          📊 <strong>Seu plano:</strong> {validacao.plano_atual || 'Iniciante'}<br/>
          {validacao.limite_permitido && (
            <>
              📈 <strong>Limite:</strong> {validacao.limite_permitido}<br/>
              ✅ <strong>Usado:</strong> {validacao.jaUsou || validacao.animais_na_vitrine || validacao.rifas_ativas || validacao.leiloes_ativos || 0}
            </>
          )}
        </div>

        {/* Planos permitidos */}
        {validacao.planos_permitidos && (
          <div style={{
            background: '#E8F5E9',
            borderRadius: 12,
            padding: '12px',
            marginBottom: 16,
            fontSize: 11,
            color: '#2E7D32',
            fontWeight: 700,
          }}>
            ✅ <strong>Planos com acesso:</strong> {validacao.planos_permitidos.join(', ')}
          </div>
        )}

        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={onFechar}
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: 10,
              border: '1.5px solid #E8ECF0',
              background: '#fff',
              color: '#57636C',
              cursor: 'pointer',
              fontWeight: 700,
              fontSize: 13,
            }}>
            Fechar
          </button>
          <a href="/planos"
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: 10,
              border: 'none',
              background: 'linear-gradient(135deg,#170073,#00A893)',
              color: '#fff',
              cursor: 'pointer',
              fontWeight: 700,
              fontSize: 13,
              textDecoration: 'none',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            💳 Ver Planos
          </a>
        </div>
      </div>
    </div>
  );
}