import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const MODALIDADE_CFG = {
  venda_externa: { emoji: "💰", label: "Venda Externa",  cor: "#170073" },
  rifa:          { emoji: "🎰", label: "Rifa",            cor: "#E21C3D" },
  leilao:        { emoji: "🔨", label: "Leilão",          cor: "#F0A500" },
};

export default function TrocaPosseModal({ animal, user, onClose, onConcluido }) {
  const [step, setStep]               = useState("modalidade"); // modalidade | dados | confirmacao
  const [modalidade, setModalidade]   = useState(null);
  const [form, setForm]               = useState({ cessionario_nome: "", cessionario_email: "", valor: "", data_transferencia: "", observacoes: "" });
  const [rifas, setRifas]             = useState([]);
  const [leiloes, setLeiloes]         = useState([]);
  const [rifaSelecionada, setRifaSel] = useState(null);
  const [leilaoSelecionado, setLeilSel] = useState(null);
  const [salvando, setSalvando]       = useState(false);

  useEffect(() => {
    if (modalidade === "rifa") {
      // Busca rifas encerradas vinculadas a este animal
      base44.entities.FunilVendas.filter({ animal_id: animal.id, status: "concluido" }).then(setRifas);
    }
    if (modalidade === "leilao") {
      base44.entities.FunilVendas.filter({ animal_id: animal.id, status: "concluido" }).then(setLeiloes);
    }
  }, [modalidade]);

  const aoSelecionarRifa = (r) => {
    setRifaSel(r);
    setForm(p => ({
      ...p,
      cessionario_nome:  r.comprador_nome || "",
      cessionario_email: r.comprador_whatsapp || "",
      valor:             r.valor_final || r.valor_proposta || "",
    }));
  };

  const aoSelecionarLeilao = (l) => {
    setLeilSel(l);
    setForm(p => ({
      ...p,
      cessionario_nome:  l.comprador_nome || "",
      cessionario_email: l.comprador_whatsapp || "",
      valor:             l.valor_final || l.valor_proposta || "",
    }));
  };

  const confirmar = async () => {
    setSalvando(true);
    const payload = {
      animal_id:          animal.id,
      animal_nome:        animal.nome,
      animal_anilha:      animal.anilha,
      cedente_id:         user?.id || user?.email,
      cedente_nome:       user?.full_name || user?.email,
      cedente_email:      user?.email,
      cessionario_nome:   form.cessionario_nome,
      cessionario_email:  form.cessionario_email,
      modalidade,
      valor:              form.valor ? Number(form.valor) : null,
      data_transferencia: form.data_transferencia || new Date().toISOString().split("T")[0],
      status:             "pendente_aceite",
      referencia_id:      rifaSelecionada?.id || leilaoSelecionado?.id || "",
      observacoes:        form.observacoes,
    };
    await base44.entities.TrocaPosse.create(payload);

    // Notifica cedente
    await base44.entities.Notificacao.create({
      destinatario_id:    user?.id || user?.email,
      destinatario_email: user?.email,
      titulo:             `🔄 Troca de posse iniciada`,
      mensagem:           `A transferência de "${animal.nome}" para ${form.cessionario_nome} foi registrada e aguarda aceite.`,
      tipo:               "sistema",
      lida:               false,
      icone:              "🔄",
    });

    setSalvando(false);
    onConcluido && onConcluido();
    onClose();
  };

  const pudeAvancar = () => {
    if (!modalidade) return false;
    if (modalidade === "rifa" && !rifaSelecionada && !form.cessionario_nome) return false;
    if (modalidade === "leilao" && !leilaoSelecionado && !form.cessionario_nome) return false;
    if (modalidade === "venda_externa" && !form.cessionario_nome) return false;
    return true;
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 580, maxHeight: "90vh", overflowY: "auto", padding: "20px 20px 40px" }}>

        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🔄 Troca de Posse</div>
            <div style={{ fontSize: 12, color: "#57636C", marginTop: 2 }}>
              Animal: <strong>{animal.nome}</strong> · Anilha: <strong>{animal.anilha}</strong>
            </div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        {/* Step 1 — Modalidade */}
        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: .5, marginBottom: 10 }}>Como está sendo transferido?</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {Object.entries(MODALIDADE_CFG).map(([key, cfg]) => (
              <div key={key} onClick={() => { setModalidade(key); setRifaSel(null); setLeilSel(null); }}
                style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 16px", borderRadius: 12, border: `2px solid ${modalidade === key ? cfg.cor : "#E8ECF0"}`, background: modalidade === key ? cfg.cor + "10" : "#fff", cursor: "pointer" }}>
                <span style={{ fontSize: 24 }}>{cfg.emoji}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: modalidade === key ? cfg.cor : "#101213" }}>{cfg.label}</div>
                  <div style={{ fontSize: 11, color: "#57636C" }}>
                    {key === "venda_externa" && "Venda direta para comprador externo"}
                    {key === "rifa" && "Ganhador encontrado automaticamente pelo histórico de rifas"}
                    {key === "leilao" && "Arrematante encontrado pelo histórico de leilões"}
                  </div>
                </div>
                {modalidade === key && <span style={{ fontSize: 18, color: cfg.cor }}>✅</span>}
              </div>
            ))}
          </div>
        </div>

        {/* Step 2 — Busca automática: Rifa */}
        {modalidade === "rifa" && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 8 }}>🎰 Rifas concluídas para este animal</div>
            {rifas.length === 0 ? (
              <div style={{ background: "#FFF8E1", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#795548" }}>
                Nenhuma rifa encerrada encontrada. Preencha os dados do ganhador manualmente abaixo.
              </div>
            ) : rifas.map(r => (
              <div key={r.id} onClick={() => aoSelecionarRifa(r)}
                style={{ background: rifaSelecionada?.id === r.id ? "#FFF3E0" : "#F8FAFC", borderRadius: 10, padding: "10px 14px", marginBottom: 8, border: `1.5px solid ${rifaSelecionada?.id === r.id ? "#F0A500" : "#E8ECF0"}`, cursor: "pointer" }}>
                <div style={{ fontWeight: 700, fontSize: 12, color: "#101213" }}>🏆 {r.comprador_nome}</div>
                <div style={{ fontSize: 11, color: "#57636C" }}>Valor: R$ {Number(r.valor_final || r.valor_proposta || 0).toFixed(2)} · {r.data_contato || "—"}</div>
              </div>
            ))}
          </div>
        )}

        {/* Step 2 — Busca automática: Leilão */}
        {modalidade === "leilao" && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 8 }}>🔨 Leilões concluídos para este animal</div>
            {leiloes.length === 0 ? (
              <div style={{ background: "#FFF8E1", borderRadius: 10, padding: "10px 14px", fontSize: 12, color: "#795548" }}>
                Nenhum leilão encontrado. Preencha os dados do arrematante manualmente abaixo.
              </div>
            ) : leiloes.map(l => (
              <div key={l.id} onClick={() => aoSelecionarLeilao(l)}
                style={{ background: leilaoSelecionado?.id === l.id ? "#E8EAF6" : "#F8FAFC", borderRadius: 10, padding: "10px 14px", marginBottom: 8, border: `1.5px solid ${leilaoSelecionado?.id === l.id ? "#170073" : "#E8ECF0"}`, cursor: "pointer" }}>
                <div style={{ fontWeight: 700, fontSize: 12, color: "#101213" }}>🏆 {l.comprador_nome}</div>
                <div style={{ fontSize: 11, color: "#57636C" }}>Valor: R$ {Number(l.valor_final || l.valor_proposta || 0).toFixed(2)} · {l.data_contato || "—"}</div>
              </div>
            ))}
          </div>
        )}

        {/* Dados do cessionário */}
        {modalidade && (
          <div style={{ display: "grid", gap: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: .5 }}>
              {rifaSelecionada || leilaoSelecionado ? "✅ Dados preenchidos automaticamente — confirme:" : "Dados do novo dono"}
            </div>
            {[
              { key: "cessionario_nome",  label: "👤 Nome do novo dono *",    placeholder: "Nome completo" },
              { key: "cessionario_email", label: "📱 WhatsApp ou E-mail *",    placeholder: "(99) 99999-9999 ou email@..." },
              { key: "valor",             label: "💰 Valor da transferência (R$)", placeholder: "0,00", type: "number" },
              { key: "data_transferencia", label: "📅 Data",                  placeholder: "", type: "date" },
            ].map(f => (
              <div key={f.key}>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>{f.label}</label>
                <input
                  type={f.type || "text"}
                  value={form[f.key] || ""}
                  placeholder={f.placeholder}
                  onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }}
                />
              </div>
            ))}
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>📝 Observações</label>
              <textarea value={form.observacoes} onChange={e => setForm(p => ({ ...p, observacoes: e.target.value }))} placeholder="Detalhes adicionais..."
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", height: 60, resize: "none" }} />
            </div>
          </div>
        )}

        {/* Aviso */}
        {modalidade && (
          <div style={{ background: "#E3F2FD", borderRadius: 10, padding: "10px 14px", marginTop: 14, fontSize: 12, color: "#1565C0" }}>
            ℹ️ A transferência ficará com status <strong>Pendente Aceite</strong> até que o novo dono confirme o recebimento.
          </div>
        )}

        {/* Botão confirmar */}
        <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
          <button onClick={onClose} style={{ flex: 1, padding: 12, borderRadius: 12, border: "1.5px solid #E8ECF0", background: "#fff", color: "#57636C", cursor: "pointer", fontWeight: 700 }}>Cancelar</button>
          <button onClick={confirmar} disabled={!pudeAvancar() || salvando}
            style={{ flex: 2, padding: 12, borderRadius: 12, border: "none", background: !pudeAvancar() || salvando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: !pudeAvancar() || salvando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
            {salvando ? "Registrando..." : "✅ Confirmar Transferência"}
          </button>
        </div>
      </div>
    </div>
  );
}