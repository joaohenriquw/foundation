import { useState, useEffect } from "react";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";
import { base44 } from "@/api/base44Client";

export default function CarteirinhaDigital({ user, userMeta }) {
  const [gerando, setGerando] = useState(false);
  const [totalAnilhas, setTotalAnilhas] = useState(0);

  useEffect(() => {
    if (!user?.email) return;
    base44.entities.AnilhaFilha.filter({ usuario_email: user.email }, "-created_date", 500)
      .then(data => setTotalAnilhas(data.length))
      .catch(() => {});
  }, [user?.email]);

  const gerarCarteirinha = async () => {
    if (!user || !userMeta) return;
    setGerando(true);

    const element = document.getElementById("carteirinha-preview");
    
    // Gera imagem da carteirinha
    const canvas = await html2canvas(element, { scale: 2 });
    const image = canvas.toDataURL("image/png");

    // Cria PDF com tamanho de cartão (85.6 x 53.98 mm)
    const doc = new jsPDF({
      orientation: "landscape",
      unit: "mm",
      format: [85.6, 53.98],
    });

    doc.addImage(image, "PNG", 0, 0, 85.6, 53.98);
    doc.save(`carteirinha_${user.full_name.replace(" ", "_")}.pdf`);

    setGerando(false);
  };

  // Apenas Premium e Admin têm acesso
   const temAcesso = userMeta?.role === "admin" || userMeta?.plano === "premium";
  
  if (!temAcesso) {
    return (
      <div style={{ background: "#FFF8E1", borderRadius: 12, padding: 14, border: "1px solid #F0A500", textAlign: "center", color: "#856404" }}>
        🔒 A carteirinha digital é exclusiva para planos Gold e Premium
      </div>
    );
  }

  return (
    <div style={{ display: "grid", gap: 14 }}>
      {/* Preview da carteirinha */}
      <div style={{ display: "flex", justifyContent: "center", marginBottom: 10 }}>
        <div
          id="carteirinha-preview"
          style={{
            width: 320,
            height: 200,
            borderRadius: 16,
            background: "linear-gradient(135deg, #170073 0%, #00A893 100%)",
            padding: 20,
            boxSizing: "border-box",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            color: "#fff",
            fontFamily: "'Montserrat', sans-serif",
            boxShadow: "0 8px 32px rgba(0,0,0,0.2)",
            position: "relative",
            overflow: "hidden",
          }}
        >
          {/* Padrão decorativo */}
          <div style={{ position: "absolute", top: -50, right: -50, width: 200, height: 200, background: "rgba(255,255,255,0.05)", borderRadius: "50%" }} />
          <div style={{ position: "absolute", bottom: -30, left: -30, width: 150, height: 150, background: "rgba(255,255,255,0.05)", borderRadius: "50%" }} />

          {/* Conteúdo da carteirinha */}
          <div style={{ position: "relative", zIndex: 2 }}>
            <div style={{ fontSize: 24, fontWeight: 900, marginBottom: 4 }}>🐓 CLUBE DO GALO</div>
            <div style={{ fontSize: 10, fontWeight: 700, opacity: 0.9 }}>CARTEIRINHA PREMIUM</div>
          </div>

          <div style={{ position: "relative", zIndex: 2 }}>
           <div style={{ fontSize: 12, fontWeight: 700, color: "#E8E8E8", marginBottom: 8 }}>
             {user?.full_name || "—"}
           </div>
           {userMeta?.nome_criatorio && (
             <div style={{ fontSize: 9, fontWeight: 600, opacity: 0.85, marginBottom: 8 }}>
               🏠 {userMeta.nome_criatorio}
             </div>
           )}
           <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, fontSize: 10 }}>
             <div>
               <div style={{ opacity: 0.8, marginBottom: 2 }}>ID</div>
               <div style={{ fontFamily: "monospace", fontWeight: 700 }}>{user?.id?.substring(0, 8).toUpperCase() || "—"}</div>
             </div>
             <div>
               <div style={{ opacity: 0.8, marginBottom: 2 }}>PLANO</div>
               <div style={{ fontWeight: 700 }}>{(userMeta?.plano || "—").toUpperCase()}</div>
             </div>
           </div>
           <div style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid rgba(255,255,255,.2)" }}>
             <div style={{ opacity: 0.8, marginBottom: 2, fontSize: 9 }}>ANILHAS</div>
             <div style={{ fontWeight: 700, fontSize: 11 }}>📿 {totalAnilhas}</div>
           </div>
          </div>

          {/* Rodapé */}
          <div style={{ position: "relative", zIndex: 2, fontSize: 8, fontWeight: 700, opacity: 0.7, textAlign: "right" }}>
            Válido até {new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toLocaleDateString("pt-BR")}
          </div>
        </div>
      </div>

      {/* Botão para baixar */}
      <button
        onClick={gerarCarteirinha}
        disabled={gerando}
        style={{
          width: "100%",
          padding: 14,
          borderRadius: 12,
          border: "none",
          background: gerando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
          color: "#fff",
          cursor: gerando ? "default" : "pointer",
          fontFamily: "Montserrat,sans-serif",
          fontWeight: 700,
          fontSize: 14,
          transition: ".2s",
        }}
        onMouseEnter={e => !gerando && (e.target.style.transform = "translateY(-2px)")}
        onMouseLeave={e => !gerando && (e.target.style.transform = "translateY(0)")}
      >
        {gerando ? "⏳ Gerando PDF..." : "📥 Baixar Carteirinha"}
      </button>

      {/* Info */}
      <div style={{ background: "#F0F4FF", borderRadius: 10, padding: 12, border: "1px solid #E3E8FF", fontSize: 11, color: "#170073", fontWeight: 700 }}>
        ℹ️ A carteirinha será baixada em formato PDF no tamanho padrão de cartão (85.6 x 53.98 mm) e pode ser impressa em papel ou cartão.
      </div>
    </div>
  );
}