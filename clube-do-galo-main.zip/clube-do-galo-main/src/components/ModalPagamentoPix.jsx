import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function ModalPagamentoPix({ aberto, onFechar, valor, tipo, leilao_id, rifa_id, plano }) {
  const [carregando, setCarregando] = useState(false);
  const [pixData, setPixData] = useState(null);
  const [copiado, setCopiado] = useState(false);
  const [processando, setProcessando] = useState(false);

  const iniciarPagamento = async () => {
    setCarregando(true);
    try {
      const response = await base44.functions.invoke('criarTransacaoPix', {
        amount: valor,
        tipo,
        leilao_id,
        rifa_id,
        plano,
      });

      setPixData(response.data);
    } catch (error) {
      alert('Erro ao processar pagamento: ' + error.message);
    }
    setCarregando(false);
  };

  const copiarChave = () => {
    navigator.clipboard.writeText(pixData.pix_key);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2000);
  };

  if (!aberto) return null;

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={onFechar}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 20 }}>
          💳 Pagamento PIX
        </div>

        {!pixData ? (
          <div style={{ display: "grid", gap: 14 }}>
            <div style={{ background: "#F0F4FF", borderRadius: 10, padding: 14 }}>
              <div style={{ fontSize: 11, color: "#170073", fontWeight: 700, marginBottom: 6 }}>Valor a pagar</div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 24, fontWeight: 900, color: "#170073" }}>
                R$ {Number(valor || 0).toFixed(2).replace(".", ",")}
              </div>
            </div>

            <div style={{ background: "#E8F5E9", borderRadius: 10, padding: 12, fontSize: 10, color: "#2E7D32", fontWeight: 700 }}>
              ℹ️ Você será direcionado para gerar um PIX. Escaneie o QR code ou copie a chave para pagar.
            </div>

            <button onClick={iniciarPagamento} disabled={carregando || processando}
              style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: carregando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: carregando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
              {carregando ? "Gerando PIX..." : "💳 Gerar PIX"}
            </button>
          </div>
        ) : (
          <div style={{ display: "grid", gap: 14 }}>
            {/* QR Code */}
            {pixData.pix_qrcode && (
              <div style={{ textAlign: "center", background: "#F8FAFC", borderRadius: 10, padding: 14 }}>
                <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginBottom: 10 }}>Escaneie o QR Code</div>
                <img src={pixData.pix_qrcode} alt="PIX QR Code" style={{ width: "100%", maxWidth: 250, borderRadius: 8 }} />
              </div>
            )}

            {/* Chave Cópia */}
            <div>
              <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginBottom: 6 }}>Ou copie a chave PIX</div>
              <div style={{ display: "flex", gap: 8 }}>
                <input type="text" value={pixData.pix_key || ""} readOnly
                  style={{ flex: 1, padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 11, fontFamily: "monospace", backgroundColor: "#F8FAFC" }} />
                <button onClick={copiarChave}
                  style={{ padding: "10px 14px", borderRadius: 8, border: "none", background: copiado ? "#00A893" : "#170073", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 11 }}>
                  {copiado ? "✅" : "📋"}
                </button>
              </div>
            </div>

            {/* Informações */}
            <div style={{ background: "#FFF8E1", borderRadius: 10, padding: 12, fontSize: 10, color: "#F0A500", fontWeight: 700 }}>
              ⏳ Este PIX expira em: {pixData.expires_at ? new Date(pixData.expires_at).toLocaleTimeString("pt-BR") : "30 minutos"}
            </div>

            <div style={{ background: "#E8F5E9", borderRadius: 10, padding: 12, fontSize: 10, color: "#2E7D32", fontWeight: 700, lineHeight: 1.5 }}>
              ✅ Após confirmar o pagamento, seu status será atualizado automaticamente. Você receberá uma notificação quando aprovado.
            </div>

            <button onClick={onFechar}
              style={{ width: "100%", padding: "12px", borderRadius: 10, border: "1.5px solid #170073", background: "#fff", color: "#170073", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
              ✅ Já Paguei
            </button>
          </div>
        )}
      </div>
    </div>
  );
}