import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function GestaoSocios({ user }) {
  const [socios, setSocios] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalAberto, setModalAberto] = useState(false);
  const [editando, setEditando] = useState(null);
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    percentual_leilao: 0,
    percentual_rifa: 0,
    percentual_mensalidade: 0,
  });
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    const init = async () => {
      const dados = await base44.entities.Socio.list("-created_date", 50);
      setSocios(dados);
      setLoading(false);
    };
    init();

    const unsub = base44.entities.Socio.subscribe(() => {
      init();
    });
    return unsub;
  }, []);

  const abrirModal = (socio = null) => {
    if (socio) {
      setEditando(socio.id);
      setFormData({
        nome: socio.nome,
        email: socio.email,
        percentual_leilao: socio.percentual_leilao || 0,
        percentual_rifa: socio.percentual_rifa || 0,
        percentual_mensalidade: socio.percentual_mensalidade || 0,
      });
    } else {
      setEditando(null);
      setFormData({
        nome: "",
        email: "",
        percentual_leilao: 0,
        percentual_rifa: 0,
        percentual_mensalidade: 0,
      });
    }
    setModalAberto(true);
  };

  const salvarSocio = async () => {
    if (!formData.nome || !formData.email) {
      alert("Preencha nome e e-mail!");
      return;
    }

    // Validar percentuais
    if (formData.percentual_leilao < 0 || formData.percentual_rifa < 0 || formData.percentual_mensalidade < 0) {
      alert("Percentuais não podem ser negativos!");
      return;
    }

    setSalvando(true);

    if (editando) {
      // Atualizar
      await base44.entities.Socio.update(editando, formData);
    } else {
      // Criar novo
      await base44.entities.Socio.create({
        ...formData,
        ativo: true,
      });
    }

    setSalvando(false);
    setModalAberto(false);
  };

  const deletarSocio = async (id) => {
    if (confirm("Tem certeza que deseja deletar este sócio?")) {
      await base44.entities.Socio.delete(id);
    }
  };

  const totalLeilao = socios.reduce((sum, s) => sum + (s.percentual_leilao || 0), 0);
  const totalRifa = socios.reduce((sum, s) => sum + (s.percentual_rifa || 0), 0);
  const totalMensalidade = socios.reduce((sum, s) => sum + (s.percentual_mensalidade || 0), 0);

  if (loading) {
    return <div style={{ textAlign: "center", padding: 20, color: "#57636C" }}>Carregando sócios...</div>;
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {/* Resumo */}
      <div style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", border: "1px solid #E8ECF0" }}>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213", marginBottom: 10 }}>
          📊 Resumo de Percentuais
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
          <div style={{ background: "#F0F4FF", borderRadius: 10, padding: 10 }}>
            <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>LEILÃO (dos 10%)</div>
            <div style={{ fontSize: 14, fontFamily: "Montserrat,sans-serif", fontWeight: 900, color: totalLeilao === 100 ? "#2E7D32" : "#E21C3D" }}>
              {totalLeilao}%
            </div>
          </div>
          <div style={{ background: "#F0F4FF", borderRadius: 10, padding: 10 }}>
            <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>RIFA (dos 10%)</div>
            <div style={{ fontSize: 14, fontFamily: "Montserrat,sans-serif", fontWeight: 900, color: totalRifa === 100 ? "#2E7D32" : "#E21C3D" }}>
              {totalRifa}%
            </div>
          </div>
          <div style={{ background: "#F0F4FF", borderRadius: 10, padding: 10 }}>
            <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>MENSALIDADES (dos 100%)</div>
            <div style={{ fontSize: 14, fontFamily: "Montserrat,sans-serif", fontWeight: 900, color: totalMensalidade === 100 ? "#2E7D32" : "#E21C3D" }}>
              {totalMensalidade}%
            </div>
          </div>
        </div>
      </div>

      {/* Lista de sócios */}
      <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", overflow: "hidden" }}>
        <div style={{ padding: "12px 16px", borderBottom: "1px solid #E8ECF0", background: "#F8FAFC", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>
            👥 Sócios ({socios.length})
          </div>
          <button
            onClick={() => abrirModal()}
            style={{
              padding: "6px 12px",
              borderRadius: 8,
              border: "none",
              background: "#170073",
              color: "#fff",
              cursor: "pointer",
              fontWeight: 700,
              fontSize: 11,
              fontFamily: "Montserrat,sans-serif",
            }}
          >
            ➕ Novo Sócio
          </button>
        </div>

        {socios.length === 0 ? (
          <div style={{ padding: 20, textAlign: "center", color: "#57636C", fontSize: 12 }}>
            Nenhum sócio registrado
          </div>
        ) : (
          socios.map(socio => (
            <div key={socio.id} style={{ padding: "14px 16px", borderBottom: "1px solid #F8FAFC", display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213" }}>
                  {socio.nome}
                </div>
                <div style={{ fontSize: 10, color: "#57636C", marginBottom: 6 }}>{socio.email}</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 6 }}>
                  <div style={{ fontSize: 9, background: "#F0F4FF", borderRadius: 6, padding: "4px 6px", color: "#170073", fontWeight: 700 }}>
                    Leilão: {socio.percentual_leilao || 0}%
                  </div>
                  <div style={{ fontSize: 9, background: "#FFF8E1", borderRadius: 6, padding: "4px 6px", color: "#F0A500", fontWeight: 700 }}>
                    Rifa: {socio.percentual_rifa || 0}%
                  </div>
                  <div style={{ fontSize: 9, background: "#E8F5E9", borderRadius: 6, padding: "4px 6px", color: "#2E7D32", fontWeight: 700 }}>
                    Mensalidade: {socio.percentual_mensalidade || 0}%
                  </div>
                </div>
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <button
                  onClick={() => abrirModal(socio)}
                  style={{
                    padding: "6px 10px",
                    borderRadius: 8,
                    border: "1px solid #170073",
                    background: "#fff",
                    color: "#170073",
                    cursor: "pointer",
                    fontWeight: 700,
                    fontSize: 10,
                    fontFamily: "Montserrat,sans-serif",
                  }}
                >
                  ✏️
                </button>
                <button
                  onClick={() => deletarSocio(socio.id)}
                  style={{
                    padding: "6px 10px",
                    borderRadius: 8,
                    border: "1px solid #E21C3D",
                    background: "#fff",
                    color: "#E21C3D",
                    cursor: "pointer",
                    fontWeight: 700,
                    fontSize: 10,
                    fontFamily: "Montserrat,sans-serif",
                  }}
                >
                  🗑️
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal */}
      {modalAberto && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalAberto(false)}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
                {editando ? "✏️ Editar Sócio" : "➕ Novo Sócio"}
              </div>
              <button onClick={() => setModalAberto(false)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>
                ✕
              </button>
            </div>

            <div style={{ display: "grid", gap: 14, marginBottom: 20 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                  Nome
                </label>
                <input
                  type="text"
                  value={formData.nome}
                  onChange={e => setFormData({ ...formData, nome: e.target.value })}
                  placeholder="Ex: Jeder"
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                />
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                  E-mail
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  placeholder="ex@email.com"
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                />
              </div>

              <div style={{ background: "#F0F4FF", borderRadius: 10, padding: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#170073", textTransform: "uppercase", display: "block", marginBottom: 8 }}>
                  % do Leilão (dos 10%)
                </label>
                <input
                  type="number"
                  value={formData.percentual_leilao}
                  onChange={e => setFormData({ ...formData, percentual_leilao: Number(e.target.value) })}
                  min="0"
                  max="100"
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #D0D8FF", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                />
              </div>

              <div style={{ background: "#FFF8E1", borderRadius: 10, padding: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#F0A500", textTransform: "uppercase", display: "block", marginBottom: 8 }}>
                  % da Rifa (dos 10%)
                </label>
                <input
                  type="number"
                  value={formData.percentual_rifa}
                  onChange={e => setFormData({ ...formData, percentual_rifa: Number(e.target.value) })}
                  min="0"
                  max="100"
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #FFE8A8", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                />
              </div>

              <div style={{ background: "#E8F5E9", borderRadius: 10, padding: 12 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#2E7D32", textTransform: "uppercase", display: "block", marginBottom: 8 }}>
                  % da Mensalidade (dos 100%)
                </label>
                <input
                  type="number"
                  value={formData.percentual_mensalidade}
                  onChange={e => setFormData({ ...formData, percentual_mensalidade: Number(e.target.value) })}
                  min="0"
                  max="100"
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #C8E6C9", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                />
              </div>
            </div>

            <div style={{ display: "flex", gap: 8 }}>
              <button
                onClick={() => setModalAberto(false)}
                style={{
                  flex: 1,
                  padding: "12px",
                  borderRadius: 10,
                  border: "1.5px solid #E8ECF0",
                  background: "#fff",
                  color: "#57636C",
                  cursor: "pointer",
                  fontFamily: "Montserrat,sans-serif",
                  fontWeight: 700,
                }}
              >
                ✕ Cancelar
              </button>
              <button
                onClick={salvarSocio}
                disabled={salvando || !formData.nome || !formData.email}
                style={{
                  flex: 1,
                  padding: "12px",
                  borderRadius: 10,
                  border: "none",
                  background: salvando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
                  color: "#fff",
                  cursor: salvando ? "default" : "pointer",
                  fontFamily: "Montserrat,sans-serif",
                  fontWeight: 700,
                }}
              >
                {salvando ? "Salvando..." : editando ? "✏️ Atualizar" : "➕ Criar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}