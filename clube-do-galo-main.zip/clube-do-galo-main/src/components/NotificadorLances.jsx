import { useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function NotificadorLances({ leilaoId, userEmail, onNovoLance }) {
  useEffect(() => {
    if (!leilaoId || !userEmail) return;

    const unsub = base44.entities.LeilaoLance.subscribe((event) => {
      if (event.data?.leilao_id === leilaoId && event.type === "create") {
        // Se não for seu próprio lance, notificar
        if (event.data.user_email !== userEmail) {
          base44.entities.Notificacao.create({
            destinatario_email: userEmail,
            titulo: "💰 Novo lance!",
            mensagem: `${event.data.user_nome} lançou R$ ${Number(event.data.valor).toLocaleString("pt-BR")} no leilão`,
            tipo: "leilao",
            icone: "💰",
            link: `/leilao/${leilaoId}`,
          });
        }
        if (onNovoLance) onNovoLance();
      }
    });

    return unsub;
  }, [leilaoId, userEmail, onNovoLance]);

  return null;
}