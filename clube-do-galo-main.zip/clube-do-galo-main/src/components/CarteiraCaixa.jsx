import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

export default function CarteiraCaixa({ user }) {
  const [saldo, setSaldo] = useState(0);
  const [transacoes, setTransacoes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalAberto, setModalAberto] = useState(null);
  const [valor, setValor] = useState("");
  const [processando, setProcessando] = useState(false);

  useEffect(() => {
    const init = async () => {
      if (!user) return;
      const users = await base44.entities.User.filter({ email: user.email });
      const userData = users[0] || {};
      setSaldo(userData.saldo || 0);

      // Buscar transações
      const txns = await base44.entities.Transacao.filter({ cliente_email: user.email }, "-created_date", 50);
      setTransacoes(txns);
      setLoading(false);
    };
    init();

    const unsub = base44.entities.Transacao.subscribe(() => {
      init();
    });
    return unsub;
  }, [user?.email]);

  const processarDeposito = async () => {
    if (!valor || Number(valor) <= 0) {
      alert("Valor inválido!");
      return;
    }
    setProcessando(true);
    
    // Simulando integração com NyxPay
    await base44.entities.Transacao.create({
      txn_id: `TXN-${Date.now()}`,
      evento: "deposito",
      status: "pending",
      valor: Number(valor),
      forma_pagamento: "pix",
      cliente_nome: user.full_name,
      cliente_email: user.email,
      payload_raw: JSON.stringify({ tipo: "deposito", valor }),
    });

    setProcessando(false);
    setModalAberto(null);
    setValor("");
    alert("Depósito enviado! Aguarde a confirmação.");
  };

  const processarSaque = async () => {
    if (!valor || Number(valor) <= 0) {
      alert("Valor inválido!");
      return;
    }
    if (Number(valor) > saldo) {
      alert("Saldo insuficiente!");
      return;
    }
    setProcessando(true);

    await base44.entities.Transacao.create({
      txn_id: `TXN-${Date.now()}`,
      evento: "saque",
      status: "pending",
      valor: Number(valor),
      forma_pagamento: "pix",
      cliente_nome: user.full_name,
      cliente_email: user.email,
      payload_raw: JSON.stringify({ tipo: "saque", valor }),
    });

    setProcessando(false);
    setModalAberto(null);
    setValor("");
    alert("Saque solicitado! Você receberá em até 2 dias úteis.");
  };

  return (
    <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E8ECF0", overflow: "hidden" }}>
      {/* Saldo em destaque */}
      <div style={{ background: "linear-gradient(135deg,#F0A500,#E21C3D)", padding: "20px 16px", color: "#fff" }}>
        <div style={{ fontSize: 12, opacity: 0.9, marginBottom: 4 }}>Saldo Disponível</div>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 32, fontWeight: 900, marginBottom: 16 }}>
          {fmt(saldo)}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
          <button onClick={() => setModalAberto("deposito")}
            style={{ padding: "10px", background: "rgba(255,255,255,.2)", border: "none", borderRadius: 10, color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12, transition: ".2s" }}
            onMouseEnter={(e) => e.target.style.background = "rgba(255,255,255,.3)"}
            onMouseLeave={(e) => e.target.style.background = "rgba(255,255,255,.2)"}>
            💳 Depositar
          </button>
          <button onClick={() => setModalAberto("saque")}
            style={{ padding: "10px", background: "rgba(255,255,255,.2)", border: "none", borderRadius: 10, color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12, transition: ".2s" }}
            onMouseEnter={(e) => e.target.style.background = "rgba(255,255,255,.3)"}
            onMouseLeave={(e) => e.target.style.background = "rgba(255,255,255,.2)"}>
            🏦 Sacar
          </button>
        </div>
      </div>

      {/* Histórico de transações */}
      <div style={{ padding: "16px" }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: "#101213", marginBottom: 12 }}>📋 Últimas Transações</div>
        {loading ? (
          <div style={{ fontSize: 11, color: "#57636C", textAlign: "center", padding: "20px" }}>Carregando...</div>
        ) : transacoes.length === 0 ? (
          <div style={{ fontSize: 11, color: "#57636C", textAlign: "center", padding: "20px" }}>Nenhuma transação ainda</div>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {transacoes.slice(0, 5).map(t => {
              const isDeposito = t.evento === "deposito";
              const isSaque = t.evento === "saque";
              const statusColor = t.status === "approved" ? "#00A893" : t.status === "rejected" ? "#E21C3D" : "#F0A500";
              return (
                <div key={t.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px", background: "#F8FAFC", borderRadius: 10 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 18 }}>{isDeposito ? "💳" : isSaque ? "🏦" : "💰"}</span>
                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, color: "#101213" }}>
                        {t.evento.toUpperCase()}
                      </div>
                      <div style={{ fontSize: 9, color: "#57636C" }}>
                        {new Date(t.created_date).toLocaleDateString("pt-BR")}
                      </div>
                    </div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 12, fontWeight: 800, color: isDeposito ? "#00A893" : "#E21C3D" }}>
                      {isDeposito ? "+" : "-"}{fmt(t.valor)}
                    </div>
                    <div style={{ fontSize: 8, color: statusColor, fontWeight: 700 }}>
                      {t.status === "approved" ? "✅ Confirmado" : t.status === "pending" ? "⏳ Pendente" : "❌ Rejeitado"}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal Depositar */}
      {modalAberto === "deposito" && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalAberto(null)}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>💳 Depositar</div>
              <button onClick={() => setModalAberto(null)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            <div style={{ display: "grid", gap: 14 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Valor (R$)</label>
                <input type="number" value={valor} onChange={e => setValor(e.target.value)} placeholder="0,00"
                  style={{ width: "100%", padding: "12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
              </div>

              <div style={{ background: "#FFF8E1", borderRadius: 10, padding: 10, fontSize: 11, color: "#F0A500", fontWeight: 700 }}>
                ℹ️ Você será redirecionado para o PIX para completar o pagamento
              </div>

              <button onClick={processarDeposito} disabled={processando || !valor}
                style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: processando || !valor ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: processando || !valor ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                {processando ? "Processando..." : "💳 Continuar para PIX"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Sacar */}
      {modalAberto === "saque" && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalAberto(null)}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🏦 Sacar</div>
              <button onClick={() => setModalAberto(null)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            <div style={{ display: "grid", gap: 14 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Valor (R$)</label>
                <input type="number" value={valor} onChange={e => setValor(e.target.value)} placeholder="0,00"
                  style={{ width: "100%", padding: "12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
              </div>

              <div style={{ background: "#E3F2FD", borderRadius: 10, padding: 10, fontSize: 10, color: "#1565C0", fontWeight: 700, lineHeight: 1.5 }}>
                ℹ️ Saque para PIX · Processamento em até 2 dias úteis · Sem taxa
              </div>

              <button onClick={processarSaque} disabled={processando || !valor || Number(valor) > saldo}
                style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: processando || !valor || Number(valor) > saldo ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: processando || !valor || Number(valor) > saldo ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                {processando ? "Processando..." : "🏦 Solicitar Saque"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}