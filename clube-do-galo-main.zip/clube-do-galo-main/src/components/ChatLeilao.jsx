import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";

export default function ChatLeilao({ leilaoId, user, donoNome, donoEmail }) {
  const [mensagens, setMensagens] = useState([]);
  const [novaMsg, setNovaMsg] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [carregando, setCarregando] = useState(true);
  const scrollRef = useRef(null);

  useEffect(() => {
    const init = async () => {
      const leiloes = await base44.entities.Leilao.filter({ id: leilaoId });
      if (leiloes[0]?.chat_historico) {
        try {
          const parsed = typeof leiloes[0].chat_historico === "string" 
            ? JSON.parse(leiloes[0].chat_historico) 
            : leiloes[0].chat_historico;
          setMensagens(Array.isArray(parsed) ? parsed : []);
        } catch {
          setMensagens([]);
        }
      }
      setCarregando(false);
    };
    init();
  }, [leilaoId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [mensagens]);

  const enviarMensagem = async () => {
    if (!novaMsg.trim() || !user) return;
    
    setEnviando(true);
    const novaMensagem = {
      id: Date.now(),
      remetente_email: user.email,
      remetente_nome: user.full_name || user.email,
      conteudo: novaMsg,
      data: new Date().toISOString(),
    };

    const mensagensAtualizadas = [...mensagens, novaMensagem];
    setMensagens(mensagensAtualizadas);

    // Salvar histórico na entidade Leilao
    await base44.entities.Leilao.update(leilaoId, {
      chat_historico: JSON.stringify(mensagensAtualizadas),
    });

    setNovaMsg("");
    setEnviando(false);
  };

  if (carregando) {
    return <div style={{ textAlign: "center", padding: 20, color: "#57636C" }}>Carregando chat...</div>;
  }

  return (
    <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E8ECF0", overflow: "hidden", marginBottom: 14, display: "flex", flexDirection: "column", height: 420 }}>
      {/* Header */}
      <div style={{ padding: "12px 16px", borderBottom: "1px solid #E8ECF0", background: "#F8FAFC" }}>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>💬 Chat com {donoNome}</div>
        <div style={{ fontSize: 10, color: "#57636C" }}>Negocie valores e tire dúvidas sobre o animal</div>
      </div>

      {/* Histórico de mensagens */}
      <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: "12px 14px", display: "flex", flexDirection: "column", gap: 8 }}>
        {mensagens.length === 0 ? (
          <div style={{ textAlign: "center", padding: "20px 10px", color: "#57636C", fontSize: 12 }}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>💬</div>
            Inicie uma conversa com {donoNome}
          </div>
        ) : (
          mensagens.map(msg => {
            const ehMeu = msg.remetente_email === user?.email;
            return (
              <div key={msg.id} style={{ display: "flex", justifyContent: ehMeu ? "flex-end" : "flex-start" }}>
                <div style={{
                  maxWidth: "75%",
                  background: ehMeu ? "linear-gradient(135deg,#170073,#1F0080)" : "#F1F4F8",
                  color: ehMeu ? "#fff" : "#101213",
                  padding: "10px 14px",
                  borderRadius: ehMeu ? "14px 14px 4px 14px" : "14px 14px 14px 4px",
                  wordBreak: "break-word",
                }}>
                  <div style={{ fontSize: 11, fontWeight: 700, marginBottom: 3, opacity: ehMeu ? 0.9 : 1 }}>
                    {msg.remetente_nome}
                  </div>
                  <div style={{ fontSize: 12, lineHeight: 1.4 }}>{msg.conteudo}</div>
                  <div style={{ fontSize: 9, marginTop: 4, opacity: 0.7 }}>
                    {new Date(msg.data).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Input */}
      <div style={{ padding: "10px 14px", borderTop: "1px solid #E8ECF0", background: "#F8FAFC", display: "flex", gap: 8 }}>
        <input
          type="text"
          value={novaMsg}
          onChange={e => setNovaMsg(e.target.value)}
          onKeyPress={e => e.key === "Enter" && !enviando && enviarMensagem()}
          placeholder="Escreva uma mensagem..."
          disabled={enviando}
          style={{
            flex: 1,
            padding: "10px 12px",
            borderRadius: 10,
            border: "1px solid #E8ECF0",
            fontSize: 12,
            outline: "none",
            boxSizing: "border-box",
            opacity: enviando ? 0.6 : 1,
          }}
        />
        <button
          onClick={enviarMensagem}
          disabled={enviando || !novaMsg.trim()}
          style={{
            padding: "10px 14px",
            borderRadius: 10,
            border: "none",
            background: enviando || !novaMsg.trim() ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
            color: "#fff",
            cursor: enviando || !novaMsg.trim() ? "default" : "pointer",
            fontWeight: 700,
            fontSize: 12,
            fontFamily: "Montserrat,sans-serif",
            flexShrink: 0,
          }}
        >
          {enviando ? "..." : "📤"}
        </button>
      </div>
    </div>
  );
}