import { useState, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import { base44 } from "@/api/base44Client";

export default function RifaPreview({ rifa, animalSelecionado, onEditar, onPublicar, publicando }) {
  const [animal, setAnimal] = useState(null);

  useEffect(() => {
    if (animalSelecionado) {
      base44.entities.Animal.filter({ id: animalSelecionado }).then(data => setAnimal(data[0])).catch(() => {});
    }
  }, [animalSelecionado]);
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 3000, display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={(e) => e.target === e.currentTarget && onEditar()}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 560, maxHeight: "92vh", overflowY: "auto", padding: "20px 20px 44px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>👁️ Pré-visualização</div>
          <button onClick={onEditar} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        {/* Imagens carousel */}
        {rifa.imagens && rifa.imagens.length > 0 && (
          <div style={{ borderRadius: 12, overflow: "hidden", marginBottom: 16, height: 200, background: `url(${rifa.imagens[0]}) center/cover` }} />
        )}

        {/* Conteúdo */}
        <div style={{ display: "grid", gap: 12 }}>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 4 }}>
              {rifa.titulo || rifa.animal_nome}
            </div>
            <div style={{ fontSize: 12, color: "#57636C" }}>Animal: {animal?.nome || "—"} · Anilha: {animal?.anilha || "—"}</div>
          </div>

          {/* Descrição com markdown */}
          {rifa.descricao && (
            <div style={{ background: "#F8FAFC", borderRadius: 10, padding: "12px 14px" }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 6 }}>Descrição</div>
              <div style={{ fontSize: 13, color: "#101213", lineHeight: 1.6 }}>
                <ReactMarkdown>{rifa.descricao}</ReactMarkdown>
              </div>
            </div>
          )}

          {/* Stats */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <div style={{ background: "#F0F4FF", borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>
                R$ {Number(rifa.valor_arrecadar || 0).toFixed(2).replace(".", ",")}
              </div>
              <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>Meta</div>
            </div>
            <div style={{ background: "#F0F4FF", borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>
                R$ {Number(rifa.valor_por_numero || 0).toFixed(2).replace(".", ",")}
              </div>
              <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>Por número</div>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <div style={{ background: "#F8FAFC", borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>
                {(rifa.qtd_numeros || 0).toLocaleString("pt-BR")}
              </div>
              <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>Números totais</div>
            </div>
            <div style={{ background: "#F8FAFC", borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>
                {new Date(rifa.data_sorteio + "T12:00:00").toLocaleDateString("pt-BR")}
              </div>
              <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>Data sorteio</div>
            </div>
          </div>
        </div>

        <div style={{ display: "grid", gap: 8, marginTop: 18 }}>
          <button onClick={onPublicar} disabled={publicando}
            style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", background: publicando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: publicando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
            {publicando ? "Publicando..." : "✅ Publicar Rifa"}
          </button>
          <button onClick={onEditar}
            style={{ width: "100%", padding: "14px", borderRadius: 12, border: "1.5px solid #E8ECF0", background: "#fff", color: "#57636C", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
            ← Voltar para edição
          </button>
        </div>
      </div>
    </div>
  );
}