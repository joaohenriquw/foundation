import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function ModalCriarDuelo({ eventoId, onClose, onDueloCriado }) {
  const [animais, setAnimais] = useState([]);
  const [filtrados, setFiltrados] = useState([]);
  const [busca, setBusca] = useState("");
  const [animal1, setAnimal1] = useState(null);
  const [animal2, setAnimal2] = useState(null);
  const [categoria, setCategoria] = useState("");
  const [dataHora, setDataHora] = useState("");
  const [odd1, setOdd1] = useState(1.0);
  const [odd2, setOdd2] = useState(1.0);
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    const init = async () => {
      const data = await base44.entities.Animal.list("nome", 500);
      setAnimais(data);
      setFiltrados(data);
      setLoading(false);
    };
    init();
  }, []);

  useEffect(() => {
    if (!busca) {
      setFiltrados(animais);
      return;
    }
    const resultado = animais.filter(a => 
      a.nome?.toLowerCase().includes(busca.toLowerCase()) || 
      a.anilha?.toLowerCase().includes(busca.toLowerCase())
    );
    setFiltrados(resultado);
  }, [busca, animais]);

  const criarDuelo = async () => {
    if (!animal1 || !animal2 || !dataHora) return;
    if (animal1.id === animal2.id) {
      alert("Selecione dois animais diferentes!");
      return;
    }

    setSalvando(true);
    const numero = Math.floor(Math.random() * 1000);
    await base44.entities.Duelo.create({
      evento_id: eventoId,
      numero,
      animal1_id: animal1.id,
      animal1_nome: animal1.nome,
      animal1_anilha: animal1.anilha,
      animal1_proprietario: animal1.proprietario_nome,
      animal1_foto: animal1.foto_url,
      animal2_id: animal2.id,
      animal2_nome: animal2.nome,
      animal2_anilha: animal2.anilha,
      animal2_proprietario: animal2.proprietario_nome,
      animal2_foto: animal2.foto_url,
      odd_animal1: odd1,
      odd_animal2: odd2,
      data_hora: dataHora,
      categoria: categoria || "Geral",
      status: "agendado",
    });
    setSalvando(false);
    setAnimal1(null);
    setAnimal2(null);
    setBusca("");
    setDataHora("");
    setOdd1(1.0);
    setOdd2(1.0);
    onDueloCriado();
    onClose();
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 3000, display: "flex", alignItems: "flex-end" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px", maxHeight: "90vh", overflowY: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>⚔️ Criar Duelo</div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>⏳ Carregando animais...</div>
        ) : (
          <div style={{ display: "grid", gap: 12 }}>
            {/* Seleção Animal 1 */}
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>🐓 Animal 1 *</label>
              <input type="text" placeholder="Buscar por nome ou anilha..." value={busca}
                onChange={e => setBusca(e.target.value)}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", marginBottom: 8 }} />
              
              <div style={{ maxHeight: 150, overflowY: "auto", background: "#F8FAFC", borderRadius: 10, border: "1px solid #E8ECF0" }}>
                {filtrados.length === 0 ? (
                  <div style={{ padding: 16, textAlign: "center", color: "#57636C", fontSize: 12 }}>Nenhum animal encontrado</div>
                ) : filtrados.map(a => (
                  <button key={a.id} onClick={() => setAnimal1(a)}
                    style={{ width: "100%", padding: "10px 12px", border: "none", background: animal1?.id === a.id ? "#170073" : "#fff", color: animal1?.id === a.id ? "#fff" : "#101213", textAlign: "left", cursor: "pointer", borderBottom: "1px solid #E8ECF0", fontSize: 12, fontWeight: 700 }}>
                    🐓 {a.nome} · {a.anilha} ({a.proprietario_nome})
                  </button>
                ))}
              </div>

              {animal1 && (
                <div style={{ background: "#E8F5E9", borderRadius: 10, padding: 10, marginTop: 8, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ fontSize: 12, fontWeight: 800, color: "#2E7D32" }}>✅ {animal1.nome} selecionado</div>
                  <button onClick={() => setAnimal1(null)} style={{ background: "none", border: "none", color: "#2E7D32", cursor: "pointer", fontSize: 16 }}>✕</button>
                </div>
              )}
            </div>

            {/* Seleção Animal 2 */}
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>🐓 Animal 2 *</label>
              <div style={{ maxHeight: 150, overflowY: "auto", background: "#F8FAFC", borderRadius: 10, border: "1px solid #E8ECF0" }}>
                {filtrados.length === 0 ? (
                  <div style={{ padding: 16, textAlign: "center", color: "#57636C", fontSize: 12 }}>Nenhum animal encontrado</div>
                ) : filtrados.filter(a => a.id !== animal1?.id).map(a => (
                  <button key={a.id} onClick={() => setAnimal2(a)}
                    style={{ width: "100%", padding: "10px 12px", border: "none", background: animal2?.id === a.id ? "#170073" : "#fff", color: animal2?.id === a.id ? "#fff" : "#101213", textAlign: "left", cursor: "pointer", borderBottom: "1px solid #E8ECF0", fontSize: 12, fontWeight: 700 }}>
                    🐓 {a.nome} · {a.anilha} ({a.proprietario_nome})
                  </button>
                ))}
              </div>

              {animal2 && (
                <div style={{ background: "#E8F5E9", borderRadius: 10, padding: 10, marginTop: 8, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ fontSize: 12, fontWeight: 800, color: "#2E7D32" }}>✅ {animal2.nome} selecionado</div>
                  <button onClick={() => setAnimal2(null)} style={{ background: "none", border: "none", color: "#2E7D32", cursor: "pointer", fontSize: 16 }}>✕</button>
                </div>
              )}
            </div>

            {/* Data/Hora */}
            <input type="datetime-local" value={dataHora}
              onChange={e => setDataHora(e.target.value)}
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

            {/* Categoria */}
            <input type="text" placeholder="Categoria (ex: Peso, Tamanho)" value={categoria}
              onChange={e => setCategoria(e.target.value)}
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

            {/* Odds */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div>
                <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", display: "block", marginBottom: 4 }}>Odd Animal 1</label>
                <input type="number" step="0.1" value={odd1}
                  onChange={e => setOdd1(parseFloat(e.target.value) || 1.0)}
                  style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
              </div>
              <div>
                <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", display: "block", marginBottom: 4 }}>Odd Animal 2</label>
                <input type="number" step="0.1" value={odd2}
                  onChange={e => setOdd2(parseFloat(e.target.value) || 1.0)}
                  style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
              </div>
            </div>

            <button onClick={criarDuelo} disabled={savando || !animal1 || !animal2 || !dataHora}
              style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", marginTop: 8, cursor: savando ? "default" : "pointer",
                background: savando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
              {savando ? "Criando..." : "⚔️ Criar Duelo"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}