import { useState } from "react";
import { base44 } from "@/api/base44Client";

export default function RifaUploadImagens({ imagens, onImagensChange }) {
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    setUploading(true);
    const novasImagens = [...imagens];

    for (const file of files) {
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        novasImagens.push(file_url);
      } catch (err) {
        console.error("Erro ao fazer upload:", err);
      }
    }

    onImagensChange(novasImagens);
    setUploading(false);
  };

  const removerImagem = (idx) => {
    onImagensChange(imagens.filter((_, i) => i !== idx));
  };

  return (
    <div>
      <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 8 }}>
        🖼️ Imagens Adicionais (até 5)
      </label>

      <div style={{ marginBottom: 12 }}>
        <label style={{ display: "block", padding: "12px 14px", borderRadius: 10, border: "2px dashed #E8ECF0", textAlign: "center", cursor: "pointer", background: "#F8FAFC", fontSize: 12, fontWeight: 700, color: "#57636C", transition: ".2s" }}
          onMouseEnter={(e) => e.target.style.borderColor = "#170073"}
          onMouseLeave={(e) => e.target.style.borderColor = "#E8ECF0"}>
          {uploading ? "Enviando..." : "📤 Clique para adicionar imagens"}
          <input type="file" multiple accept="image/*" onChange={handleUpload} disabled={uploading || imagens.length >= 5} style={{ display: "none" }} />
        </label>
      </div>

      {imagens.length > 0 && (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(60px, 1fr))", gap: 8 }}>
          {imagens.map((url, idx) => (
            <div key={idx} style={{ position: "relative", borderRadius: 8, overflow: "hidden", aspectRatio: "1", background: `url(${url}) center/cover` }}>
              <button onClick={() => removerImagem(idx)}
                style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,.5)", color: "#fff", border: "none", cursor: "pointer", fontSize: 20, fontWeight: 700, opacity: 0, transition: ".2s", hover: { opacity: 1 } }}
                onMouseEnter={(e) => e.target.style.opacity = "1"}
                onMouseLeave={(e) => e.target.style.opacity = "0"}>
                ✕
              </button>
            </div>
          ))}
        </div>
      )}

      {imagens.length > 0 && (
        <div style={{ fontSize: 10, color: "#57636C", marginTop: 6 }}>
          {imagens.length} de 5 imagens adicionadas
        </div>
      )}
    </div>
  );
}