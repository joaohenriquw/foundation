import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';

export default function PanelRecomendacoes() {
  const [recomendacoes, setRecomendacoes] = useState(null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    carregarRecomendacoes();
  }, []);

  const carregarRecomendacoes = async () => {
    try {
      const res = await base44.functions.invoke('gerarRecomendacoes', {});
      setRecomendacoes(res.data);
    } catch (e) {
      console.error('Erro ao carregar recomendações:', e);
    } finally {
      setCarregando(false);
    }
  };

  if (carregando) {
    return <div style={{ textAlign: 'center', padding: 20, color: '#57636C' }}>Carregando recomendações...</div>;
  }

  if (!recomendacoes) return null;

  return (
    <div style={{ background: '#fff', borderRadius: 14, padding: '16px', border: '1px solid #E8ECF0', marginBottom: 16 }}>
      <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 14, fontWeight: 900, color: '#170073', marginBottom: 12 }}>
        ✨ Recomendações Personalizadas
      </div>

      {recomendacoes.recomendacoes.leiloes && recomendacoes.recomendacoes.leiloes.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#57636C', marginBottom: 8, textTransform: 'uppercase' }}>
            🔨 Leilões Similares
          </div>
          <div style={{ display: 'grid', gap: 8 }}>
            {recomendacoes.recomendacoes.leiloes.slice(0, 3).map((l, i) => (
              <Link key={i} to={`/leilao/${l.id}`}
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  padding: '10px',
                  background: '#F8FAFC',
                  borderRadius: 10,
                  textDecoration: 'none',
                  color: '#170073',
                  fontSize: 12,
                  fontWeight: 700,
                  cursor: 'pointer'
                }}>
                <span>{l.titulo}</span>
                <span style={{ color: '#00A893' }}>R$ {Number(l.maior_lance || l.lance_minimo).toFixed(2)}</span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {recomendacoes.usuario.favoritos_count > 0 && (
        <div style={{ background: '#F0F4FF', borderRadius: 10, padding: '10px', fontSize: 11, color: '#170073', fontWeight: 700 }}>
          💡 Baseado em seus {recomendacoes.usuario.favoritos_count} favoritos
        </div>
      )}
    </div>
  );
}