import { useState } from "react";
import { base44 } from "@/api/base44Client";

export default function AvaliacaoModal({ tipo, referenciaId, vendedorEmail, vendedorNome, animalNome, compradorUser, onClose, onAvaliado }) {
  const [nota, setNota] = useState(0);
  const [comentario, setComentario] = useState("");
  const [enviando, setEnviando] = useState(false);

  const enviar = async () => {
    if (nota === 0) {
      alert("Selecione uma nota antes de enviar!");
      return;
    }
    setEnviando(true);
    await base44.entities.Avaliacao.create({
      tipo,
      referencia_id: referenciaId,
      comprador_id: compradorUser?.id || compradorUser?.email,
      comprador_nome: compradorUser?.full_name || compradorUser?.email,
      comprador_email: compradorUser?.email,
      vendedor_id: vendedorEmail,
      vendedor_email: vendedorEmail,
      nota,
      comentario: comentario.trim(),
      animal_nome: animalNome,
    });
    setEnviando(false);
    onAvaliado && onAvaliado();
    onClose();
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>⭐ Avaliar {tipo === "leilao" ? "leilão" : "rifa"}</div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        <div style={{ fontSize: 13, color: "#57636C", marginBottom: 16, lineHeight: 1.5 }}>
          Como foi sua experiência com <strong>{vendedorNome}</strong> na compra de <strong>{animalNome}</strong>?
        </div>

        {/* Seleção de estrelas */}
        <div style={{ display: "flex", justifyContent: "center", gap: 12, marginBottom: 20 }}>
          {[1, 2, 3, 4, 5].map(n => (
            <button key={n} onClick={() => setNota(n)}
              style={{ fontSize: 36, cursor: "pointer", background: "none", border: "none", padding: 0, opacity: nota >= n ? 1 : 0.3, transition: ".2s" }}>
              ⭐
            </button>
          ))}
        </div>

        {nota > 0 && (
          <div style={{ background: "#F0F4FF", borderRadius: 10, padding: "10px 14px", marginBottom: 16, textAlign: "center", fontSize: 12, fontWeight: 700, color: "#170073" }}>
            {nota === 1 && "😞 Péssimo"}
            {nota === 2 && "😕 Ruim"}
            {nota === 3 && "😐 Regular"}
            {nota === 4 && "🙂 Bom"}
            {nota === 5 && "😍 Excelente"}
          </div>
        )}

        {/* Comentário */}
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>📝 Comentário (opcional)</label>
          <textarea value={comentario} onChange={e => setComentario(e.target.value)}
            placeholder="Compartilhe sua experiência de compra..."
            style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", resize: "none", height: 80, fontFamily: "DM Sans,sans-serif" }} />
        </div>

        <button onClick={enviar} disabled={nota === 0 || enviando}
          style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", cursor: enviando || nota === 0 ? "default" : "pointer",
            background: enviando || nota === 0 ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
            color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
          {enviando ? "Enviando avaliação..." : "✅ Enviar avaliação"}
        </button>
      </div>
    </div>
  );
}