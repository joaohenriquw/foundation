import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import SelectField from "./SelectField";

export default function CarteiraPix({ user }) {
  const [saldo, setSaldo] = useState(0);
  const [abaMostrada, setAbaMostrada] = useState("deposito"); // deposito ou saque
  const [loading, setLoading] = useState(true);
  const [processando, setProcessando] = useState(false);
  const [historico, setHistorico] = useState([]);
  const [erroDeposito, setErroDeposito] = useState("");

  // Depósito
  const [valorDeposito, setValorDeposito] = useState("");
  const [cpfDeposito, setCpfDeposito] = useState("");
  const [qrCodeGerado, setQrCodeGerado] = useState(null);
  const [copiaCola, setCopiaCola] = useState(null);

  // Saque
  const [valorSaque, setValorSaque] = useState("");
  const [pixChave, setPixChave] = useState("");
  const [pixTipo, setPixTipo] = useState("cpf");
  const [mensagemSaque, setMensagemSaque] = useState("");

  useEffect(() => {
    const init = async () => {
      try {
        // Buscar saldo do usuário (pode ser armazenado no User entity)
        const me = await base44.auth.me();
        setSaldo(me.saldo_carteira || 0);

        // Buscar histórico de transações com tratamento de erro
        let depositos = [];
        let saques = [];
        
        try {
          depositos = await base44.entities.Deposito.filter(
            { usuario_email: me.email },
            "-created_date",
            10
          );
        } catch (e) {
          console.log("Aviso: Entidade Deposito não carregada");
        }

        try {
          saques = await base44.entities.Saque.filter(
            { usuario_email: me.email },
            "-created_date",
            10
          );
        } catch (e) {
          console.log("Aviso: Entidade Saque não carregada");
        }

        const todasTransacoes = [
          ...depositos.map(d => ({ ...d, tipo: "Depósito", sinal: "+" })),
          ...saques.map(s => ({ ...s, tipo: "Saque", sinal: "-" })),
        ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

        setHistorico(todasTransacoes.slice(0, 10));
      } catch (e) {
        console.error("Erro ao carregar CarteiraPix:", e);
      }
      setLoading(false);
    };
    init();
  }, []);

  const gerarQrCodeDeposito = async () => {
    setErroDeposito("");
    if (!valorDeposito || parseFloat(valorDeposito) <= 0) {
      setErroDeposito("Digite um valor válido");
      return;
    }
    if (!cpfDeposito || cpfDeposito.replace(/\D/g, '').length < 11) {
      setErroDeposito("Digite um CPF válido (11 dígitos)");
      return;
    }

    setProcessando(true);
    try {
      const resposta = await base44.functions.invoke("depositoPixNyxpay", {
        valor: parseFloat(valorDeposito),
        cpf: cpfDeposito,
        nome: user?.full_name,
      });

      if (resposta.data?.qr_code) {
        setQrCodeGerado(resposta.data.qr_code);
        setCopiaCola(resposta.data.pix_copia_cola);
      } else {
        setErroDeposito("Erro ao gerar QR Code: " + (resposta.data?.error || "Tente novamente"));
      }
    } catch (erro) {
      console.error("Erro depositoPixNyxpay:", erro);
      setErroDeposito("Erro ao gerar QR Code: " + (erro.response?.data?.message || erro.message));
    }
    setProcessando(false);
  };

  const solicitarSaque = async () => {
    if (!valorSaque || parseFloat(valorSaque) <= 0) {
      alert("Digite um valor válido");
      return;
    }

    if (!pixChave) {
      alert("Digite sua chave PIX");
      return;
    }

    if (parseFloat(valorSaque) > saldo) {
      alert("Saldo insuficiente");
      return;
    }

    setProcessando(true);
    setMensagemSaque("");

    try {
      const resposta = await base44.functions.invoke("saquePixNyxpay", {
        valor: parseFloat(valorSaque),
        pixChave,
        pixTipo,
      });

      if (resposta.data?.success) {
        setMensagemSaque("✅ " + resposta.data.mensagem);
        setValorSaque("");
        setPixChave("");
        setPixTipo("cpf");
        setSaldo(saldo - parseFloat(valorSaque));
      } else {
        setMensagemSaque("❌ " + (resposta.data?.message || "Erro ao processar saque"));
      }
    } catch (erro) {
      console.error("Erro saquePixNyxpay:", erro);
      setMensagemSaque("❌ Erro: " + (erro.response?.data?.message || erro.message));
    }
    setProcessando(false);
  };

  const copiarCopiaCola = () => {
    if (copiaCola) {
      navigator.clipboard.writeText(copiaCola);
      alert("PIX copia e cola copiado!");
    }
  };

  if (loading) {
    return <div style={{ padding: 20, textAlign: "center" }}>Carregando...</div>;
  }

  return (
    <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", overflow: "hidden" }}>
      {/* Saldo */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", padding: "20px 16px" }}>
        <div style={{ fontSize: 11, opacity: 0.9, marginBottom: 6 }}>Saldo Disponível</div>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 28, fontWeight: 900 }}>
          R$ {saldo.toFixed(2)}
        </div>
      </div>

      {/* Abas */}
      <div style={{ display: "flex", borderBottom: "1px solid #E8ECF0" }}>
        <button
          onClick={() => {
            setAbaMostrada("deposito");
            setQrCodeGerado(null);
            setCopiaCola(null);
          }}
          style={{
            flex: 1,
            padding: "12px",
            border: "none",
            background: abaMostrada === "deposito" ? "#F0F4FF" : "#fff",
            color: abaMostrada === "deposito" ? "#170073" : "#57636C",
            cursor: "pointer",
            fontWeight: 700,
            fontSize: 12,
            fontFamily: "Montserrat,sans-serif",
            borderBottom: abaMostrada === "deposito" ? "2px solid #170073" : "none",
          }}
        >
          📥 Depositar
        </button>
        <button
          onClick={() => setAbaMostrada("saque")}
          style={{
            flex: 1,
            padding: "12px",
            border: "none",
            background: abaMostrada === "saque" ? "#F0F4FF" : "#fff",
            color: abaMostrada === "saque" ? "#170073" : "#57636C",
            cursor: "pointer",
            fontWeight: 700,
            fontSize: 12,
            fontFamily: "Montserrat,sans-serif",
            borderBottom: abaMostrada === "saque" ? "2px solid #170073" : "none",
          }}
        >
          📤 Sacar
        </button>
      </div>

      <div style={{ padding: "16px" }}>
        {/* Aba: Depositar */}
        {abaMostrada === "deposito" && (
          <div>
            {!qrCodeGerado ? (
                  <div style={{ display: "grid", gap: 12 }}>
                    {erroDeposito && (
                      <div style={{
                        background: "#FFEBEE",
                        color: "#E21C3D",
                        padding: 10,
                        borderRadius: 8,
                        fontSize: 11,
                        fontWeight: 700,
                      }}>
                        ⚠️ {erroDeposito}
                      </div>
                    )}
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                      Valor (R$)
                    </label>
                    <input
                      type="number"
                      value={valorDeposito}
                      onChange={e => setValorDeposito(e.target.value)}
                      placeholder="Ex: 50.00"
                      min="1"
                      step="0.01"
                      style={{
                        width: "100%",
                        padding: "10px",
                        borderRadius: 8,
                        border: "1.5px solid #E8ECF0",
                        fontSize: 12,
                        outline: "none",
                        boxSizing: "border-box",
                      }}
                    />
                  </div>

                  <div>
                    <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                      CPF do Titular
                    </label>
                    <input
                      type="text"
                      value={cpfDeposito}
                      onChange={e => setCpfDeposito(e.target.value)}
                      placeholder="000.000.000-00"
                      maxLength={14}
                      style={{
                        width: "100%",
                        padding: "10px",
                        borderRadius: 8,
                        border: "1.5px solid #E8ECF0",
                        fontSize: 12,
                        outline: "none",
                        boxSizing: "border-box",
                      }}
                    />
                  </div>

                  <button
                    onClick={gerarQrCodeDeposito}
                    disabled={processando || !valorDeposito || !cpfDeposito}
                  style={{
                    padding: "12px",
                    borderRadius: 10,
                    border: "none",
                    background: processando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
                    color: "#fff",
                    cursor: processando ? "default" : "pointer",
                    fontFamily: "Montserrat,sans-serif",
                    fontWeight: 700,
                  }}
                >
                  {processando ? "Gerando QR Code..." : "📱 Gerar QR Code PIX"}
                </button>
              </div>
            ) : (
              <div style={{ textAlign: "center", display: "grid", gap: 12 }}>
                <div style={{ fontSize: 11, color: "#57636C", fontWeight: 700 }}>
                  Valor: <strong>R$ {valorDeposito}</strong>
                </div>

                {qrCodeGerado && (
                   <div style={{
                     background: "#fff",
                     border: "2px solid #170073",
                     borderRadius: 10,
                     padding: 12,
                     display: "flex",
                     justifyContent: "center",
                     alignItems: "center",
                   }}>
                     <img
                       src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrCodeGerado)}`}
                       alt="QR Code PIX"
                       style={{ width: 200, height: 200 }}
                     />
                   </div>
                 )}

                {copiaCola && (
                  <div style={{ background: "#F0F4FF", borderRadius: 10, padding: 10 }}>
                    <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginBottom: 6 }}>
                      📋 PIX Copia e Cola
                    </div>
                    <div style={{
                      fontSize: 10,
                      color: "#170073",
                      fontFamily: "monospace",
                      wordBreak: "break-word",
                      fontWeight: 700,
                      marginBottom: 8,
                      padding: 8,
                      background: "#fff",
                      borderRadius: 6,
                      lineHeight: 1.4,
                      maxHeight: 120,
                      overflowY: "auto",
                    }}>
                      {copiaCola}
                    </div>
                    <button
                      onClick={copiarCopiaCola}
                      style={{
                        width: "100%",
                        padding: "8px 12px",
                        borderRadius: 8,
                        border: "1px solid #170073",
                        background: "#fff",
                        color: "#170073",
                        cursor: "pointer",
                        fontWeight: 700,
                        fontSize: 11,
                        fontFamily: "Montserrat,sans-serif",
                      }}
                    >
                      📋 Copiar PIX
                    </button>
                  </div>
                )}

                <div style={{ fontSize: 10, color: "#856404", background: "#FFF8E1", borderRadius: 8, padding: 10, textAlign: "center" }}>
                  <div style={{ fontWeight: 700, marginBottom: 4 }}>💡 Pagamento Pendente</div>
                  <div>Abra seu banco e cole o código acima para completar o pagamento</div>
                </div>

                <button
                  onClick={() => {
                    setQrCodeGerado(null);
                    setCopiaCola(null);
                    setValorDeposito("");
                    setCpfDeposito("");
                  }}
                  style={{
                    padding: "10px",
                    borderRadius: 8,
                    border: "1px solid #E8ECF0",
                    background: "#fff",
                    color: "#57636C",
                    cursor: "pointer",
                    fontWeight: 700,
                    fontSize: 11,
                    fontFamily: "Montserrat,sans-serif",
                  }}
                >
                  ✕ Voltar
                </button>
              </div>
            )}
          </div>
        )}

        {/* Aba: Sacar */}
        {abaMostrada === "saque" && (
          <div style={{ display: "grid", gap: 12 }}>
            {mensagemSaque && (
              <div style={{
                background: mensagemSaque.includes("✅") ? "#E8F5E9" : "#FFEBEE",
                color: mensagemSaque.includes("✅") ? "#2E7D32" : "#E21C3D",
                padding: 10,
                borderRadius: 8,
                fontSize: 11,
                fontWeight: 700,
              }}>
                {mensagemSaque}
              </div>
            )}

            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                Valor (R$)
              </label>
              <input
                type="number"
                value={valorSaque}
                onChange={e => setValorSaque(e.target.value)}
                placeholder="Ex: 50.00"
                min="1"
                step="0.01"
                max={saldo}
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: 8,
                  border: "1.5px solid #E8ECF0",
                  fontSize: 12,
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>

            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                Tipo de Chave PIX
              </label>
              <SelectField
                value={pixTipo}
                onChange={e => setPixTipo(e.target.value)}
                options={[
                  { value: "cpf", label: "CPF" },
                  { value: "email", label: "E-mail" },
                  { value: "telefone", label: "Telefone" },
                  { value: "aleatoria", label: "Chave Aleatória" }
                ]}
              />
            </div>

            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                Chave PIX
              </label>
              <input
                type="text"
                value={pixChave}
                onChange={e => setPixChave(e.target.value)}
                placeholder="Ex: 12345678900"
                style={{
                  width: "100%",
                  padding: "10px",
                  borderRadius: 8,
                  border: "1.5px solid #E8ECF0",
                  fontSize: 12,
                  outline: "none",
                  boxSizing: "border-box",
                }}
              />
            </div>

            <button
              onClick={solicitarSaque}
              disabled={processando || !valorSaque || !pixChave}
              style={{
                padding: "12px",
                borderRadius: 10,
                border: "none",
                background: processando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
                color: "#fff",
                cursor: processando ? "default" : "pointer",
                fontFamily: "Montserrat,sans-serif",
                fontWeight: 700,
              }}
            >
              {processando ? "Processando..." : "📤 Solicitar Saque"}
            </button>
          </div>
        )}
      </div>

      {/* Histórico */}
      {historico.length > 0 && (
        <div style={{ borderTop: "1px solid #E8ECF0", padding: "12px 16px" }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#101213", marginBottom: 10 }}>
            📋 Histórico
          </div>
          {historico.map(t => (
            <div key={t.id} style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "8px 0",
              borderBottom: "1px solid #F8FAFC",
              fontSize: 11,
            }}>
              <div>
                <div style={{ fontWeight: 700, color: "#101213" }}>{t.tipo}</div>
                <div style={{ fontSize: 9, color: "#57636C" }}>
                  {new Date(t.created_date).toLocaleDateString("pt-BR")} - Status: {t.status}
                </div>
              </div>
              <div style={{
                fontWeight: 900,
                color: t.tipo === "Depósito" ? "#2E7D32" : "#E21C3D",
              }}>
                {t.sinal}R$ {(Number(t.valor) || 0).toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}