import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';

export default function ListaConsultorias({ user }) {
  const [conversas, setConversas] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    carregarConversas();
    const unsub = base44.entities.ChatConversa.subscribe((ev) => {
      if (ev.type === 'create' || ev.type === 'update') {
        carregarConversas();
      }
    });
    return unsub;
  }, []);

  const carregarConversas = async () => {
    try {
      const res = await base44.functions.invoke('listarConversasChat', {});
      setConversas(res.data.conversas || []);
    } catch (e) {
      console.error('Erro ao carregar conversas:', e);
    } finally {
      setCarregando(false);
    }
  };

  if (carregando) {
    return <div style={{ textAlign: 'center', padding: 20 }}>Carregando conversas...</div>;
  }

  if (conversas.length === 0) {
    return (
      <div style={{
        background: '#F8FAFC',
        borderRadius: 14,
        padding: '32px 16px',
        textAlign: 'center',
        border: '1px dashed #E8ECF0'
      }}>
        <div style={{ fontSize: 32, marginBottom: 10 }}>💬</div>
        <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 13, fontWeight: 800, color: '#101213', marginBottom: 4 }}>
          Nenhuma consulta ainda
        </div>
        <div style={{ fontSize: 11, color: '#57636C' }}>
          Inicie uma consultoria com um profissional
        </div>
      </div>
    );
  }

  const tiposEmoji = {
    advogado_civil: '⚖️',
    advogado_criminal: '🔒',
    veterinario: '🩺'
  };

  return (
    <div style={{ display: 'grid', gap: 10 }}>
      {conversas.map(conv => (
        <Link key={conv.id} to={`/chat/${conv.id}`}
          style={{
            display: 'flex',
            gap: 12,
            padding: '12px 14px',
            background: conv.nao_lidas > 0 ? '#F0F4FF' : '#fff',
            borderRadius: 12,
            border: `1px solid ${conv.nao_lidas > 0 ? '#D0D8FF' : '#E8ECF0'}`,
            textDecoration: 'none',
            color: '#101213',
            cursor: 'pointer',
            transition: '.2s'
          }}>
          <div style={{
            width: 40,
            height: 40,
            borderRadius: '50%',
            background: '#F1F4F8',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 18,
            flexShrink: 0
          }}>
            {tiposEmoji[conv.tipo] || '💬'}
          </div>

          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 12, fontWeight: 800, display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
              {conv.outra_parte?.nome}
              {conv.nao_lidas > 0 && (
                <span style={{
                  background: '#170073',
                  color: '#fff',
                  borderRadius: 10,
                  padding: '1px 6px',
                  fontSize: 9,
                  fontWeight: 900,
                  fontFamily: 'Montserrat,sans-serif'
                }}>
                  {conv.nao_lidas}
                </span>
              )}
            </div>
            <div style={{
              fontSize: 11,
              color: '#57636C',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap',
              marginBottom: 4
            }}>
              {conv.ultima_mensagem_preview || 'Sem mensagens'}
            </div>
            <div style={{ fontSize: 9, color: '#BDBDBD' }}>
              {conv.status === 'ativa' ? '🟢 Ativa' : '⚪ Encerrada'} • {conv.total_mensagens} mensagens
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}