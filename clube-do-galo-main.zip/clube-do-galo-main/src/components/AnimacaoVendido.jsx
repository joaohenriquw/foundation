import { useEffect, useState } from "react";

export default function AnimacaoVendido({ ganhadorNome, donoNome, visible, onClose }) {
  const [mostrar, setMostrar] = useState(false);

  useEffect(() => {
    if (visible) {
      setMostrar(true);
      const timer = setTimeout(() => {
        setMostrar(false);
        setTimeout(onClose, 500);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [visible, onClose]);

  if (!visible) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.7)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 9999,
        animation: mostrar ? "fadeIn 0.3s ease-in" : "fadeOut 0.3s ease-out",
      }}
    >
      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; } }
        @keyframes slideDown {
          from {
            transform: translateY(-100px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        @keyframes confetti {
          0% { transform: translate(0, 0) rotate(0deg); opacity: 1; }
          100% { transform: translate(var(--tx), 200px) rotate(720deg); opacity: 0; }
        }
        .animacao-vendido {
          animation: slideDown 0.5s ease-out;
        }
        .confetti-item {
          position: fixed;
          pointer-events: none;
          animation: confetti 2s ease-in forwards;
        }
      `}</style>

      {/* Confetti */}
      {mostrar && [...Array(20)].map((_, i) => (
        <div
          key={i}
          className="confetti-item"
          style={{
            left: Math.random() * 100 + "%",
            top: "-10px",
            width: "8px",
            height: "8px",
            background: [
              "linear-gradient(135deg,#170073,#00A893)",
              "#F0A500",
              "#E21C3D",
              "#2E7D32",
            ][i % 4],
            borderRadius: "50%",
            "--tx": (Math.random() - 0.5) * 200 + "px",
          }}
        />
      ))}

      {/* Cartão Vendido */}
      <div
        className="animacao-vendido"
        style={{
          background: "linear-gradient(135deg,#170073,#00A893)",
          borderRadius: 20,
          padding: "40px 50px",
          textAlign: "center",
          color: "#fff",
          position: "relative",
          zIndex: 10,
          maxWidth: "90%",
          boxShadow: "0 20px 60px rgba(23,0,115,0.4)",
        }}
      >
        <div style={{ fontSize: 60, marginBottom: 20 }}>🎉</div>
        <div
          style={{
            fontFamily: "Montserrat,sans-serif",
            fontSize: 32,
            fontWeight: 900,
            marginBottom: 12,
          }}
        >
          Vendido para
        </div>
        <div
          style={{
            fontFamily: "Montserrat,sans-serif",
            fontSize: 24,
            fontWeight: 800,
            marginBottom: 4,
          }}
        >
          {ganhadorNome}
        </div>
        <div style={{ fontSize: 16, opacity: 0.9 }}>
          Criador: {donoNome}
        </div>
      </div>
    </div>
  );
}