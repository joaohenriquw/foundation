import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import OpcoesPagamento from "./OpcoesPagamento";

export default function CheckoutModal({ leilao, parcelas, onPago, onClose }) {
  const [tela, setTela] = useState("opcoes"); // "opcoes", "pix", "sucesso"
  const [gerando, setGerando] = useState(false);
  const [copiado, setCopiado] = useState(false);
  const [pixData, setPixData] = useState(null);
  const [processando, setProcessando] = useState(false);
  const user = null;

  // Obter usuário atual
  React.useEffect(() => {
    base44.auth.me().then(me => {
      window.currentCheckoutUser = me;
    }).catch(() => {});
  }, []);

  const valorParcela = (leilao.maior_lance / parcelas).toFixed(2);

  const gerarPix = async () => {
    setGerando(true);
    try {
      const me = await base44.auth.me();
      const res = await base44.functions.invoke("depositoPixNyxpay", {
        valor: parseFloat(valorParcela),
        cpf: me?.cpf || "00000000000",
        nome: me?.full_name,
      });
      if (res.data?.qr_code) {
        setPixData({
          qrCode: res.data.qr_code,
          chave: res.data.pix_copia_cola,
          valor: valorParcela,
          txnId: res.data.transaction_id,
        });
        setTela("pix");
      } else {
        alert("Erro ao gerar QR Code: " + (res.data?.error || "Tente novamente"));
      }
    } catch (err) {
      alert("Erro: " + err.message);
    }
    setGerando(false);
  };

  const pagarComCarteira = async (saldo) => {
    setProcessando(true);
    try {
      const me = await base44.auth.me();
      const novoSaldo = Math.max(0, saldo - parseFloat(valorParcela));
      await base44.auth.updateMe({ saldo_carteira: novoSaldo });
      await base44.entities.Leilao.update(leilao.id, {
        pagamento_confirmado: true,
      });
      setTela("sucesso");
      setTimeout(() => {
        onPago?.();
        onClose?.();
      }, 2000);
    } catch (err) {
      alert("Erro ao processar: " + err.message);
    }
    setProcessando(false);
  };

  const copiarChave = () => {
    if (pixData?.chave) {
      navigator.clipboard.writeText(pixData.chave);
      setCopiado(true);
      setTimeout(() => setCopiado(false), 2000);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,.7)",
        zIndex: 2000,
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
      }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div
        style={{
          background: "#fff",
          borderRadius: "20px 20px 0 0",
          width: "100%",
          maxWidth: 500,
          maxHeight: "92vh",
          overflowY: "auto",
          padding: "20px 20px 40px",
        }}
      >
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
            {tela === "opcoes" ? "💳 Pagar 1ª Parcela" : tela === "pix" ? "📱 Pagamento via PIX" : "✅ Sucesso!"}
          </div>
          <button
            onClick={onClose}
            style={{
              background: "none",
              border: "none",
              fontSize: 20,
              cursor: "pointer",
              color: "#57636C",
            }}
            disabled={processando}
          >
            ✕
          </button>
        </div>

        {/* Resumo */}
        <div style={{ background: "#F0F4FF", borderRadius: 12, padding: 14, marginBottom: 16, border: "1px solid #D0D8FF" }}>
          <div style={{ fontSize: 11, color: "#170073", fontWeight: 700, marginBottom: 6 }}>LEILÃO: {leilao.animal_nome}</div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ color: "#57636C", fontSize: 12 }}>Valor total do lance</span>
            <span style={{ fontWeight: 700, fontSize: 12, color: "#101213 " }}>R$ {Number(leilao.maior_lance).toFixed(2)}</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
            <span style={{ color: "#57636C", fontSize: 12 }}>Parcelamento</span>
            <span style={{ fontWeight: 700, fontSize: 12, color: "#101213" }}>{parcelas}x</span>
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", borderTop: "1px solid #D0D8FF", paddingTop: 8 }}>
            <span style={{ color: "#101213", fontSize: 12, fontWeight: 700 }}>1ª Parcela (agora)</span>
            <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
              R$ {valorParcela}
            </span>
          </div>
        </div>

        {/* Tela de Opções */}
        {tela === "opcoes" && (
          <OpcoesPagamento
            valor={parseFloat(valorParcela)}
            onCarteira={pagarComCarteira}
            onPix={gerarPix}
            disabled={processando || gerando}
          />
        )}

        {/* Tela Sucesso */}
        {tela === "sucesso" && (
          <div style={{ textAlign: "center", padding: "40px 20px" }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>✅</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#2E7D32", marginBottom: 8 }}>
              Pagamento Confirmado!
            </div>
            <div style={{ fontSize: 12, color: "#57636C", lineHeight: 1.6 }}>
              Sua 1ª parcela foi paga com sucesso. Você pode agora entrar em contato com o vendedor para combinarem as demais parcelas.
            </div>
          </div>
        )}

        {/* QR Code */}
        {tela === "pix" && gerando ? (
          <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>
            <div className="w-6 h-6 border-3 border-slate-200 border-t-slate-800 rounded-full animate-spin inline-block"></div>
            <div style={{ marginTop: 8, fontSize: 12 }}>Gerando QR Code...</div>
          </div>
        ) : tela === "pix" && pixData ? (
          <div>
            <div style={{ background: "#FFF8E1", borderRadius: 12, padding: 12, marginBottom: 16, border: "1px solid #F0A500" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#856404", marginBottom: 4 }}>📱 Não feche este modal</div>
              <div style={{ fontSize: 10, color: "#856404" }}>
                Deixe a janela aberta enquanto realiza o pagamento para receber a confirmação.
              </div>
            </div>
            <div style={{ textAlign: "center", marginBottom: 20 }}>
              <div
                style={{
                  background: "#fff",
                  border: "2px solid #E8ECF0",
                  borderRadius: 12,
                  padding: 16,
                  display: "inline-block",
                  marginBottom: 12,
                }}
              >
                <div
                  style={{
                    width: 180,
                    height: 180,
                    background: `url('https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
                      pixData.qrCode
                    )}') center/contain`,
                    backgroundRepeat: "no-repeat",
                  }}
                />
              </div>
              <div style={{ fontSize: 10, color: "#57636C", marginBottom: 4 }}>Aponte a câmera do seu celular para o QR Code</div>
              <div style={{ fontSize: 9, color: "#999", fontStyle: "italic" }}>ou copie a chave PIX abaixo</div>
            </div>

            {/* Chave PIX */}
            <div style={{ background: "#F8FAFC", borderRadius: 12, padding: 14, marginBottom: 12, border: "1px solid #E8ECF0" }}>
              <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginBottom: 8, textTransform: "uppercase" }}>Ou copie a chave PIX</div>
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  type="text"
                  value={pixData.chave}
                  readOnly
                  style={{
                    flex: 1,
                    padding: "10px 12px",
                    borderRadius: 8,
                    border: "1px solid #E8ECF0",
                    fontSize: 11,
                    fontFamily: "monospace",
                    outline: "none",
                  }}
                />
                <button
                  onClick={copiarChave}
                  style={{
                    padding: "10px 12px",
                    borderRadius: 8,
                    border: "1.5px solid #170073",
                    background: copiado ? "#E8F5E9" : "#fff",
                    color: copiado ? "#2E7D32" : "#170073",
                    cursor: "pointer",
                    fontWeight: 700,
                    fontSize: 11,
                  }}
                >
                  {copiado ? "✓ Copiado" : "📋 Copiar"}
                </button>
              </div>
            </div>

            {/* Instruções */}
            <div style={{ background: "#FFF8E1", borderRadius: 12, padding: 14, marginBottom: 12, border: "1px solid #F0A500" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#856404", marginBottom: 8 }}>📱 Como fazer a transferência:</div>
              <ol style={{ fontSize: 10, color: "#856404", paddingLeft: 16, margin: 0, lineHeight: 1.6 }}>
                <li>Abra o seu aplicativo bancário</li>
                <li>Selecione a opção PIX</li>
                <li>Escolha "Ler QR Code" ou "Copiar e Colar"</li>
                <li>Confirme o pagamento</li>
              </ol>
            </div>

            {/* Info confirmação automática */}
            <div style={{ background: "#E8F5E9", borderRadius: 12, padding: 14, border: "1px solid #00A893" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#2E7D32", marginBottom: 6 }}>✅ Confirmação Automática</div>
              <div style={{ fontSize: 10, color: "#2E7D32", lineHeight: 1.5 }}>
                O pagamento será confirmado automaticamente. Você receberá uma notificação assim que for processado.
              </div>
            </div>
            <button
              onClick={() => setTela("opcoes")}
              style={{
                width: "100%",
                marginTop: 16,
                padding: 12,
                borderRadius: 10,
                border: "1px solid #E8ECF0",
                background: "#fff",
                color: "#57636C",
                cursor: "pointer",
                fontWeight: 700,
                fontSize: 12,
              }}
            >
              ← Voltar
            </button>
          </div>
        ) : null}
      </div>
    </div>
  );
}