import { useState } from "react";
import { base44 } from "@/api/base44Client";
import jsPDF from "jspdf";

export default function RelatoriosExportacao({ user }) {
  const [exportando, setExportando] = useState(null);

  const exportarLeiloesCSV = async () => {
    setExportando("leiloes-csv");
    const leiloes = await base44.entities.Leilao.filter({ dono_id: user.id }, "-created_date", 500);
    
    let csv = "Data,Animal,Status,Lance Mínimo,Maior Lance,Ganhador,Valor Final,Duração\n";
    leiloes.forEach(l => {
      const dataInicio = new Date(l.created_date).toLocaleDateString("pt-BR");
      csv += `"${dataInicio}","${l.animal_nome}","${l.status}","R$ ${l.lance_minimo.toFixed(2)}","R$ ${(l.maior_lance || 0).toFixed(2)}","${l.ganhador_nome || "—"}","R$ ${(l.maior_lance || 0).toFixed(2)}","${l.data_fim}"\n`;
    });

    const link = document.createElement("a");
    link.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    link.download = `relatorio_leiloes_${new Date().toLocaleDateString("pt-BR")}.csv`;
    link.click();
    setExportando(null);
  };

  const exportarLeiloesPDF = async () => {
    setExportando("leiloes-pdf");
    const [leiloes, animais] = await Promise.all([
      base44.entities.Leilao.filter({ dono_id: user.id }, "-created_date", 500),
      base44.entities.Animal.filter({}),
    ]);

    const doc = new jsPDF();
    let yPos = 20;

    // Cabeçalho
    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    doc.text("Relatório de Leilões", 20, yPos);
    yPos += 10;

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`Gerado em: ${new Date().toLocaleDateString("pt-BR")}`, 20, yPos);
    yPos += 15;

    // Sumário
    const leiloesAtivos = leiloes.filter(l => l.status === "ativo").length;
    const leiloesEncerrados = leiloes.filter(l => l.status === "encerrado").length;
    const faturamentoTotal = leiloes.reduce((sum, l) => sum + (l.maior_lance || 0), 0);

    doc.setFont("helvetica", "bold");
    doc.text("Resumo:", 20, yPos);
    yPos += 6;
    doc.setFont("helvetica", "normal");
    doc.text(`• Total de Leilões: ${leiloes.length}`, 25, yPos);
    yPos += 5;
    doc.text(`• Leilões Ativos: ${leiloesAtivos}`, 25, yPos);
    yPos += 5;
    doc.text(`• Leilões Encerrados: ${leiloesEncerrados}`, 25, yPos);
    yPos += 5;
    doc.text(`• Faturamento Total: R$ ${faturamentoTotal.toLocaleString("pt-BR")}`, 25, yPos);
    yPos += 12;

    // Tabela de leilões
    doc.setFont("helvetica", "bold");
    doc.text("Animal", 20, yPos);
    doc.text("Status", 80, yPos);
    doc.text("Maior Lance", 120, yPos);
    doc.text("Ganhador", 160, yPos);
    yPos += 6;

    doc.setDrawColor(150, 150, 150);
    doc.line(15, yPos, 200, yPos);
    yPos += 5;

    doc.setFont("helvetica", "normal");
    leiloes.slice(0, 30).forEach(l => {
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      }
      doc.text(l.animal_nome.substring(0, 20), 20, yPos);
      doc.text(l.status, 80, yPos);
      doc.text(`R$ ${(l.maior_lance || 0).toFixed(2)}`, 120, yPos);
      doc.text(l.ganhador_nome ? l.ganhador_nome.substring(0, 20) : "—", 160, yPos);
      yPos += 5;
    });

    if (leiloes.length > 30) {
      yPos += 5;
      doc.setFont("helvetica", "italic");
      doc.text(`... e mais ${leiloes.length - 30} leilões`, 20, yPos);
    }

    doc.save(`relatorio_leiloes_${new Date().toLocaleDateString("pt-BR")}.pdf`);
    setExportando(null);
  };

  const exportarAnimaisPDF = async () => {
    setExportando("animais-pdf");
    const animais = await base44.entities.Animal.filter({});

    const doc = new jsPDF();
    let yPos = 20;

    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    doc.text("Catálogo de Animais", 20, yPos);
    yPos += 12;

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text(`Total: ${animais.length} animais | Gerado em: ${new Date().toLocaleDateString("pt-BR")}`, 20, yPos);
    yPos += 10;

    animais.forEach((animal, idx) => {
      if (yPos > 200) {
        doc.addPage();
        yPos = 20;
      }

      // Foto (se disponível)
      if (animal.foto_url) {
        try {
          doc.addImage(animal.foto_url, "JPEG", 20, yPos, 40, 40);
        } catch (e) {
          // Imagem não carregada, continuar
        }
      }

      // Dados do animal
      const startX = animal.foto_url ? 65 : 20;
      doc.setFont("helvetica", "bold");
      doc.text(`${animal.nome}`, startX, yPos);
      yPos += 5;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);
      doc.text(`Anilha: ${animal.anilha}`, startX, yPos);
      yPos += 4;
      if (animal.especie) doc.text(`Espécie: ${animal.especie}`, startX, yPos), (yPos += 4);
      if (animal.data_de_nascimento) doc.text(`Nascimento: ${new Date(animal.data_de_nascimento + "T12:00:00").toLocaleDateString("pt-BR")}`, startX, yPos), (yPos += 4);
      doc.text(`Sexo: ${animal.sexo === "macho" ? "Macho" : "Fêmea"}`, startX, yPos);
      yPos += 4;
      if (animal.cor_plumagem) doc.text(`Cor: ${animal.cor_plumagem}`, startX, yPos), (yPos += 4);
      if (animal.peso_gramas) doc.text(`Peso: ${animal.peso_gramas}g`, startX, yPos), (yPos += 4);
      doc.text(`Saúde: ${animal.saude_status}`, startX, yPos);
      yPos += 4;
      if (animal.valor_estimado) doc.text(`Valor: R$ ${Number(animal.valor_estimado).toLocaleString("pt-BR")}`, startX, yPos), (yPos += 4);
      if (animal.premiacoes) doc.text(`Premiações: ${animal.premiacoes}`, startX, yPos), (yPos += 4);
      if (animal.observacoes) doc.text(`Obs: ${animal.observacoes.substring(0, 50)}...`, startX, yPos), (yPos += 4);

      yPos += animal.foto_url ? 45 : 8;
      doc.setDrawColor(220, 220, 220);
      doc.line(15, yPos, 195, yPos);
      yPos += 5;

      doc.setFontSize(10);
    });

    doc.save(`catalogo_animais_${new Date().toLocaleDateString("pt-BR")}.pdf`);
    setExportando(null);
  };

  const exportarAnimaisCSV = async () => {
    setExportando("animais-csv");
    const animais = await base44.entities.Animal.filter({});

    let csv = "Nome,Anilha,Espécie,Sexo,Data Nascimento,Cor,Peso (g),Saúde,Valor Estimado,Premiações,Observações\n";
    animais.forEach(a => {
      csv += `"${a.nome}","${a.anilha}","${a.especie || ""}","${a.sexo}","${a.data_de_nascimento || ""}","${a.cor_plumagem || ""}","${a.peso_gramas || ""}","${a.saude_status}","R$ ${a.valor_estimado || "0"}","${a.premiacoes || ""}","${(a.observacoes || "").substring(0, 100)}"\n`;
    });

    const link = document.createElement("a");
    link.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    link.download = `catalogo_animais_${new Date().toLocaleDateString("pt-BR")}.csv`;
    link.click();
    setExportando(null);
  };

  return (
    <div style={{ background: "#fff", borderRadius: 14, padding: "16px 18px", border: "1px solid #E8ECF0", marginBottom: 16 }}>
      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 12 }}>
        📥 Exportar Relatórios
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 10 }}>
        <button
          onClick={exportarLeiloesPDF}
          disabled={exportando === "leiloes-pdf"}
          style={{
            padding: "10px 12px",
            borderRadius: 10,
            border: "1.5px solid #170073",
            background: exportando === "leiloes-pdf" ? "#E8EEFF" : "#fff",
            color: "#170073",
            cursor: exportando === "leiloes-pdf" ? "default" : "pointer",
            fontWeight: 700,
            fontSize: 11,
            fontFamily: "Montserrat,sans-serif",
          }}
        >
          {exportando === "leiloes-pdf" ? "⏳ Gerando..." : "📄 Leilões PDF"}
        </button>

        <button
          onClick={exportarLeiloesCSV}
          disabled={exportando === "leiloes-csv"}
          style={{
            padding: "10px 12px",
            borderRadius: 10,
            border: "1.5px solid #00A893",
            background: exportando === "leiloes-csv" ? "#E8F5F0" : "#fff",
            color: "#00A893",
            cursor: exportando === "leiloes-csv" ? "default" : "pointer",
            fontWeight: 700,
            fontSize: 11,
            fontFamily: "Montserrat,sans-serif",
          }}
        >
          {exportando === "leiloes-csv" ? "⏳ Gerando..." : "📊 Leilões CSV"}
        </button>

        <button
          onClick={exportarAnimaisPDF}
          disabled={exportando === "animais-pdf"}
          style={{
            padding: "10px 12px",
            borderRadius: 10,
            border: "1.5px solid #F0A500",
            background: exportando === "animais-pdf" ? "#FFF8E1" : "#fff",
            color: "#F0A500",
            cursor: exportando === "animais-pdf" ? "default" : "pointer",
            fontWeight: 700,
            fontSize: 11,
            fontFamily: "Montserrat,sans-serif",
          }}
        >
          {exportando === "animais-pdf" ? "⏳ Gerando..." : "🐓 Animais PDF"}
        </button>

        <button
          onClick={exportarAnimaisCSV}
          disabled={exportando === "animais-csv"}
          style={{
            padding: "10px 12px",
            borderRadius: 10,
            border: "1.5px solid #E21C3D",
            background: exportando === "animais-csv" ? "#FFEBEE" : "#fff",
            color: "#E21C3D",
            cursor: exportando === "animais-csv" ? "default" : "pointer",
            fontWeight: 700,
            fontSize: 11,
            fontFamily: "Montserrat,sans-serif",
          }}
        >
          {exportando === "animais-csv" ? "⏳ Gerando..." : "🐓 Animais CSV"}
        </button>
      </div>

      <div style={{ marginTop: 10, padding: 10, background: "#F0F4FF", borderRadius: 8, fontSize: 10, color: "#170073", fontWeight: 600 }}>
        💡 Exporte dados de leilões, vendas e seu catálogo de animais em PDF ou CSV para análise e backup
      </div>
    </div>
  );
}