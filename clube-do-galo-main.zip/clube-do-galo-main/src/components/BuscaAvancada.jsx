import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import SelectField from './SelectField';

export default function BuscaAvancada({ tipo = 'leilao', onBusca }) {
  const [termo, setTermo] = useState('');
  const [filtros, setFiltros] = useState({});
  const [buscando, setBuscando] = useState(false);
  const [mostraFiltros, setMostraFiltros] = useState(false);

  const buscar = async () => {
    setBuscando(true);
    try {
      const res = await base44.functions.invoke('buscaAvancada', {
        tipo,
        termo,
        filtros,
        limite: 20
      });
      onBusca?.(res.data);
    } catch (e) {
      console.error('Erro na busca:', e);
    } finally {
      setBuscando(false);
    }
  };

  const renderFiltros = () => {
    if (tipo === 'leilao') {
      return (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div>
            <label style={{ fontSize: 10, fontWeight: 700, color: '#57636C' }}>Status</label>
            <SelectField
              value={filtros.status || 'ativo'}
              onChange={e => setFiltros({ ...filtros, status: e.target.value })}
              options={[
                { value: 'ativo', label: 'Ativo' },
                { value: 'encerrado', label: 'Encerrado' },
                { value: 'agendado', label: 'Agendado' }
              ]}
            />
          </div>
          <div>
            <label style={{ fontSize: 10, fontWeight: 700, color: '#57636C' }}>Espécie</label>
            <input type="text" value={filtros.animal_especie || ''}
              onChange={e => setFiltros({ ...filtros, animal_especie: e.target.value })}
              placeholder="Ex: Galinha" style={{ width: '100%', padding: '8px', borderRadius: 8, border: '1px solid #E8ECF0', fontSize: 12, boxSizing: 'border-box' }} />
          </div>
        </div>
      );
    }
  };

  return (
    <div style={{ background: '#fff', borderRadius: 14, padding: '16px', border: '1px solid #E8ECF0', marginBottom: 16 }}>
      <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
        <input
          type="text"
          value={termo}
          onChange={e => setTermo(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && buscar()}
          placeholder={`🔍 Buscar ${tipo}...`}
          style={{ flex: 1, padding: '10px', borderRadius: 10, border: '1.5px solid #E8ECF0', fontSize: 13, outline: 'none' }}
        />
        <button onClick={() => setMostraFiltros(!mostraFiltros)}
          style={{ padding: '10px 14px', borderRadius: 10, border: '1.5px solid #E8ECF0', background: '#fff', cursor: 'pointer', fontSize: 12, fontWeight: 700, color: '#170073' }}>
          ⚙️ Filtros
        </button>
        <button onClick={buscar} disabled={buscando}
          style={{ padding: '10px 14px', borderRadius: 10, border: 'none', background: buscando ? '#ccc' : '#170073', color: '#fff', cursor: buscando ? 'default' : 'pointer', fontSize: 12, fontWeight: 700 }}>
          {buscando ? '⏳' : '🔍'} Buscar
        </button>
      </div>

      {mostraFiltros && (
        <div style={{ background: '#F8FAFC', borderRadius: 10, padding: '12px', marginTop: 10 }}>
          {renderFiltros()}
        </div>
      )}
    </div>
  );
}