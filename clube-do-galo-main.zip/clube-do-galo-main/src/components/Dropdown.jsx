import { useState, useRef, useEffect } from "react";
import { ChevronDown } from "lucide-react";

export default function Dropdown({ 
  options = [], 
  value = "", 
  onChange = () => {}, 
  placeholder = "Selecionar...",
  label = "",
  disabled = false,
  className = "",
  required = false
}) {
  const [open, setOpen] = useState(false);
  const containerRef = useRef(null);
  const buttonRef = useRef(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Get selected label
  const selectedLabel = options.find(o => o.value === value)?.label || placeholder;

  const handleSelect = (optionValue) => {
    onChange(optionValue);
    setOpen(false);
  };

  // Keyboard navigation
  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      setOpen(!open);
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  };

  return (
    <div ref={containerRef} className={className} style={{ position: "relative" }}>
      {label && (
        <label style={{
          fontSize: "11px",
          fontWeight: 700,
          color: "#57636C",
          textTransform: "uppercase",
          display: "block",
          marginBottom: 6
        }}>
          {label} {required && "*"}
        </label>
      )}
      
      <button
        ref={buttonRef}
        onClick={() => !disabled && setOpen(!open)}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        style={{
          width: "100%",
          padding: "11px 12px",
          borderRadius: "10px",
          border: `1.5px solid ${disabled ? "#E8ECF0" : open ? "#170073" : "#E8ECF0"}`,
          background: disabled ? "#F8FAFC" : "#fff",
          color: value ? "#101213" : "#999",
          cursor: disabled ? "default" : "pointer",
          fontFamily: "DM Sans, sans-serif",
          fontSize: "13px",
          fontWeight: 500,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          minHeight: "44px",
          transition: "all 0.15s",
          opacity: disabled ? 0.6 : 1,
        }}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={label || placeholder}
      >
        <span>{selectedLabel}</span>
        <ChevronDown 
          size={18} 
          style={{ 
            transition: "transform 0.2s",
            transform: open ? "rotate(180deg)" : "rotate(0deg)"
          }} 
        />
      </button>

      {/* Dropdown menu */}
      {open && (
        <div style={{
          position: "absolute",
          top: "100%",
          left: 0,
          right: 0,
          marginTop: 4,
          background: "#fff",
          borderRadius: 12,
          border: "1px solid #E8ECF0",
          boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
          zIndex: 1000,
          maxHeight: "280px",
          overflowY: "auto",
        }}
        role="listbox"
        >
          {options.length === 0 ? (
            <div style={{ padding: "12px 16px", color: "#999", fontSize: "13px" }}>
              Nenhuma opção
            </div>
          ) : (
            options.map((option) => (
              <button
                key={option.value}
                onClick={() => handleSelect(option.value)}
                role="option"
                aria-selected={value === option.value}
                style={{
                  width: "100%",
                  padding: "12px 16px",
                  border: "none",
                  background: value === option.value ? "#F0F4FF" : "#fff",
                  color: value === option.value ? "#170073" : "#101213",
                  textAlign: "left",
                  cursor: "pointer",
                  fontSize: "13px",
                  fontWeight: value === option.value ? 600 : 500,
                  transition: "all 0.1s",
                  borderBottom: "1px solid #F8FAFC",
                  minHeight: "44px",
                  display: "flex",
                  alignItems: "center",
                }}
                onMouseEnter={(e) => {
                  if (value !== option.value) {
                    e.target.style.background = "#F8FAFC";
                  }
                }}
                onMouseLeave={(e) => {
                  if (value !== option.value) {
                    e.target.style.background = "#fff";
                  }
                }}
              >
                {option.label}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}