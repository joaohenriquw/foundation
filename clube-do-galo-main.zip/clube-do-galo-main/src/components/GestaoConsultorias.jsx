import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export default function GestaoConsultorias() {
  const [conversas, setConversas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandido, setExpandido] = useState(null);
  const [mensagens, setMensagens] = useState({});

  useEffect(() => {
    carregar();
  }, []);

  const carregar = async () => {
    try {
      const convs = await base44.entities.ChatConversa.list('-created_date', 200);
      setConversas(convs);
      
      // Carrega mensagens para cada conversa
      for (const conv of convs) {
        const msgs = await base44.entities.ChatMensagem.filter({ conversa_id: conv.id }, '-created_date', 50);
        setMensagens(prev => ({ ...prev, [conv.id]: msgs }));
      }
    } catch (e) {
      console.error('Erro ao carregar conversas:', e);
    } finally {
      setLoading(false);
    }
  };

  const atualizarStatus = async (conversaId, novoStatus) => {
    await base44.entities.ChatConversa.update(conversaId, { status: novoStatus });
    setConversas(prev => prev.map(c => c.id === conversaId ? { ...c, status: novoStatus } : c));
  };

  const tipoEmoji = {
    advogado_civil: '⚖️',
    advogado_criminal: '🔒',
    veterinario: '🩺'
  };

  const tipoLabel = {
    advogado_civil: 'Advogado Civil',
    advogado_criminal: 'Advogado Criminal',
    veterinario: 'Veterinário'
  };

  return (
    <div>
      <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 14, fontWeight: 900, color: '#170073', marginBottom: 16 }}>
        💬 Gerenciar Consultorias
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40, color: '#57636C' }}>Carregando...</div>
      ) : (
        <div style={{ display: 'grid', gap: 12 }}>
          {conversas.length === 0 ? (
            <div style={{ background: '#F8FAFC', borderRadius: 14, padding: 40, textAlign: 'center', color: '#57636C' }}>
              <div style={{ fontSize: 40, marginBottom: 8 }}>💬</div>
              <div>Nenhuma consultoria iniciada</div>
            </div>
          ) : (
            conversas.map(conv => {
              const msgs = mensagens[conv.id] || [];
              const ultimaMsg = msgs[0];
              
              return (
                <div key={conv.id} style={{ background: '#fff', borderRadius: 14, border: '1px solid #E8ECF0', overflow: 'hidden' }}>
                  {/* Header */}
                  <div onClick={() => setExpandido(expandido === conv.id ? null : conv.id)}
                    style={{ padding: '14px 16px', cursor: 'pointer', background: '#F8FAFC', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                        <span style={{ fontSize: 18 }}>{tipoEmoji[conv.tipo] || '💬'}</span>
                        <div>
                          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 12, fontWeight: 800, color: '#101213' }}>
                            {tipoLabel[conv.tipo]}
                          </div>
                          <div style={{ fontSize: 11, color: '#57636C' }}>
                            {conv.usuario_nome} ↔️ {conv.profissional_nome}
                          </div>
                        </div>
                      </div>
                      {ultimaMsg && (
                        <div style={{ fontSize: 11, color: '#888', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {ultimaMsg.remetente_nome}: {ultimaMsg.conteudo}
                        </div>
                      )}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
                      <div style={{ fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 6, background: conv.status === 'ativa' ? '#E8F5E9' : '#F1F4F8', color: conv.status === 'ativa' ? '#2E7D32' : '#57636C' }}>
                        {conv.status === 'ativa' ? '🟢 Ativa' : '⚪ Encerrada'}
                      </div>
                      <span style={{ fontSize: 14, color: '#BDBDBD' }}>{expandido === conv.id ? '▼' : '▶'}</span>
                    </div>
                  </div>

                  {/* Expandido */}
                  {expandido === conv.id && (
                    <div style={{ padding: '0 16px 16px', borderTop: '1px solid #E8ECF0' }}>
                      {/* Info */}
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14, marginTop: 14 }}>
                        <div style={{ background: '#F8FAFC', padding: 10, borderRadius: 8 }}>
                          <div style={{ fontSize: 10, color: '#57636C', fontWeight: 700 }}>👤 Cliente</div>
                          <div style={{ fontSize: 11, fontWeight: 700, color: '#101213', marginTop: 2 }}>{conv.usuario_nome}</div>
                          <div style={{ fontSize: 10, color: '#888' }}>{conv.usuario_email}</div>
                        </div>
                        <div style={{ background: '#F8FAFC', padding: 10, borderRadius: 8 }}>
                          <div style={{ fontSize: 10, color: '#57636C', fontWeight: 700 }}>🩺 Profissional</div>
                          <div style={{ fontSize: 11, fontWeight: 700, color: '#101213', marginTop: 2 }}>{conv.profissional_nome}</div>
                          <div style={{ fontSize: 10, color: '#888' }}>{conv.profissional_email}</div>
                        </div>
                      </div>

                      {/* Mensagens */}
                      <div style={{ background: '#F8FAFC', borderRadius: 10, padding: 12, maxHeight: 250, overflowY: 'auto', marginBottom: 14 }}>
                        {msgs.length === 0 ? (
                          <div style={{ textAlign: 'center', color: '#BDBDBD', fontSize: 11 }}>Nenhuma mensagem</div>
                        ) : (
                          msgs.map((msg, idx) => (
                            <div key={idx} style={{ marginBottom: 8, paddingBottom: 8, borderBottom: idx < msgs.length - 1 ? '1px solid #E8ECF0' : 'none' }}>
                              <div style={{ fontSize: 10, fontWeight: 700, color: '#170073' }}>{msg.remetente_nome}</div>
                              <div style={{ fontSize: 11, color: '#101213', marginTop: 2, wordBreak: 'break-word' }}>{msg.conteudo}</div>
                              <div style={{ fontSize: 9, color: '#BDBDBD', marginTop: 2 }}>
                                {new Date(msg.created_date).toLocaleString('pt-BR')}
                              </div>
                            </div>
                          ))
                        )}
                      </div>

                      {/* Ações */}
                      <div style={{ display: 'flex', gap: 8 }}>
                        {conv.status === 'ativa' ? (
                          <button onClick={() => atualizarStatus(conv.id, 'encerrada')}
                            style={{ flex: 1, padding: '8px 12px', borderRadius: 8, background: '#FFE0E6', color: '#E21C3D', border: 'none', fontWeight: 700, fontSize: 11, cursor: 'pointer' }}>
                            ⛔ Encerrar
                          </button>
                        ) : (
                          <button onClick={() => atualizarStatus(conv.id, 'ativa')}
                            style={{ flex: 1, padding: '8px 12px', borderRadius: 8, background: '#E8F5E9', color: '#2E7D32', border: 'none', fontWeight: 700, fontSize: 11, cursor: 'pointer' }}>
                            ✅ Reabrir
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}