import { useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function GerenciamentoDados({ user }) {
  const [abaMostrada, setAbaMostrada] = useState('importar');
  const [arquivo, setArquivo] = useState(null);
  const [processando, setProcessando] = useState(false);
  const [resultado, setResultado] = useState(null);
  const [previewDados, setPreviewDados] = useState([]);

  const handleArquivo = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setArquivo(file);
    const text = await file.text();

    // Parse CSV simples
    const linhas = text.split('\n').filter(l => l.trim());
    const dados = [];

    for (let i = 1; i < Math.min(linhas.length, 6); i++) {
      const [email, full_name, role] = linhas[i].split(',').map(v => v.replace(/"/g, '').trim());
      if (email) dados.push({ email, full_name, role: role || 'user' });
    }

    setPreviewDados(dados);
  };

  const importar = async () => {
    if (!arquivo) {
      alert('Selecione um arquivo CSV');
      return;
    }

    setProcessando(true);
    try {
      const text = await arquivo.text();
      const linhas = text.split('\n').filter(l => l.trim());
      const usuarios = [];

      for (let i = 1; i < linhas.length; i++) {
        const [email, full_name, role] = linhas[i].split(',').map(v => v.replace(/"/g, '').trim());
        if (email) usuarios.push({ email, full_name, role: role || 'user' });
      }

      const res = await base44.functions.invoke('importarUsuarios', { usuarios });

      setResultado({
        sucesso: true,
        total: res.data.total,
        importados: res.data.importados,
        erros: res.data.erros
      });

      setArquivo(null);
      setPreviewDados([]);
    } catch (erro) {
      setResultado({
        sucesso: false,
        erro: erro.message
      });
    } finally {
      setProcessando(false);
    }
  };

  const exportar = async () => {
    try {
      const response = await base44.functions.invoke('exportarUsuarios', {});
      // A resposta é um blob, então vamos criar um download
      const blob = new Blob([response.data], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'usuarios_export.csv';
      a.click();
    } catch (erro) {
      alert('Erro ao exportar: ' + erro.message);
    }
  };

  return (
    <div style={{ padding: '16px 0' }}>
      {/* Abas */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 16, borderBottom: '1px solid #E8ECF0', overflowX: 'auto', paddingBottom: 6 }}>
        <button onClick={() => setAbaMostrada('importar')}
          style={{
            padding: '8px 14px',
            borderRadius: '10px 10px 0 0',
            border: 'none',
            cursor: 'pointer',
            fontSize: 12,
            fontFamily: 'Montserrat,sans-serif',
            fontWeight: 700,
            background: abaMostrada === 'importar' ? '#170073' : 'transparent',
            color: abaMostrada === 'importar' ? '#fff' : '#57636C'
          }}>
          📥 Importar Usuários
        </button>
        <button onClick={() => setAbaMostrada('exportar')}
          style={{
            padding: '8px 14px',
            borderRadius: '10px 10px 0 0',
            border: 'none',
            cursor: 'pointer',
            fontSize: 12,
            fontFamily: 'Montserrat,sans-serif',
            fontWeight: 700,
            background: abaMostrada === 'exportar' ? '#170073' : 'transparent',
            color: abaMostrada === 'exportar' ? '#fff' : '#57636C'
          }}>
          📤 Exportar Usuários
        </button>
      </div>

      {/* Aba: Importar */}
      {abaMostrada === 'importar' && (
        <div>
          <div style={{ background: '#FFF8E1', borderRadius: 14, padding: '12px 14px', border: '1px solid #F0A500', marginBottom: 16, fontSize: 11, color: '#856404' }}>
            ℹ️ Arquivo CSV com colunas: <strong>email, full_name, role</strong>
          </div>

          {/* Upload */}
          <div style={{
            background: '#fff',
            borderRadius: 14,
            border: '2px dashed #170073',
            padding: '24px 16px',
            textAlign: 'center',
            marginBottom: 16,
            cursor: 'pointer'
          }}>
            <input
              type="file"
              accept=".csv"
              onChange={handleArquivo}
              style={{ display: 'none' }}
              id="csvInput"
            />
            <label htmlFor="csvInput" style={{ cursor: 'pointer', display: 'block' }}>
              <div style={{ fontSize: 32, marginBottom: 8 }}>📁</div>
              <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 13, fontWeight: 700, color: '#170073', marginBottom: 4 }}>
                {arquivo ? arquivo.name : 'Clique para selecionar arquivo CSV'}
              </div>
              <div style={{ fontSize: 11, color: '#57636C' }}>
                Máximo 100MB
              </div>
            </label>
          </div>

          {/* Preview */}
          {previewDados.length > 0 && (
            <div style={{ background: '#fff', borderRadius: 14, padding: '14px 16px', marginBottom: 16, border: '1px solid #E8ECF0' }}>
              <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 12, fontWeight: 900, color: '#101213', marginBottom: 10 }}>
                ✓ Preview (primeiras 5 linhas)
              </div>
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', fontSize: 11, borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: '#F8FAFC' }}>
                      <th style={{ padding: '8px', textAlign: 'left', fontWeight: 700, borderBottom: '1px solid #E8ECF0' }}>Email</th>
                      <th style={{ padding: '8px', textAlign: 'left', fontWeight: 700, borderBottom: '1px solid #E8ECF0' }}>Nome</th>
                      <th style={{ padding: '8px', textAlign: 'left', fontWeight: 700, borderBottom: '1px solid #E8ECF0' }}>Role</th>
                    </tr>
                  </thead>
                  <tbody>
                    {previewDados.map((d, i) => (
                      <tr key={i} style={{ borderBottom: '1px solid #F1F4F8' }}>
                        <td style={{ padding: '8px' }}>{d.email}</td>
                        <td style={{ padding: '8px' }}>{d.full_name}</td>
                        <td style={{ padding: '8px' }}>{d.role}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Resultado */}
          {resultado && (
            <div style={{
              background: resultado.sucesso ? '#E8F5E9' : '#FFEBEE',
              borderRadius: 14,
              padding: '14px 16px',
              border: `1px solid ${resultado.sucesso ? '#00A893' : '#C62828'}`,
              marginBottom: 16
            }}>
              {resultado.sucesso ? (
                <>
                  <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 12, fontWeight: 900, color: '#2E7D32', marginBottom: 4 }}>
                    ✅ Importação Concluída
                  </div>
                  <div style={{ fontSize: 11, color: '#2E7D32' }}>
                    <strong>{resultado.importados}</strong> usuários importados de <strong>{resultado.total}</strong> total
                    {resultado.erros.length > 0 && ` (${resultado.erros.length} chunks com erro)`}
                  </div>
                </>
              ) : (
                <>
                  <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 12, fontWeight: 900, color: '#B71C1C', marginBottom: 4 }}>
                    ❌ Erro na Importação
                  </div>
                  <div style={{ fontSize: 11, color: '#B71C1C' }}>{resultado.erro}</div>
                </>
              )}
            </div>
          )}

          {/* Botões */}
          <button
            onClick={importar}
            disabled={processando || !arquivo}
            style={{
              width: '100%',
              padding: '12px',
              borderRadius: 10,
              border: 'none',
              background: processando || !arquivo ? '#E8ECF0' : 'linear-gradient(135deg,#170073,#00A893)',
              color: '#fff',
              cursor: processando || !arquivo ? 'default' : 'pointer',
              fontFamily: 'Montserrat,sans-serif',
              fontWeight: 700,
              fontSize: 12
            }}
          >
            {processando ? '⏳ Processando...' : '📥 Iniciar Importação'}
          </button>
        </div>
      )}

      {/* Aba: Exportar */}
      {abaMostrada === 'exportar' && (
        <div>
          <div style={{ background: '#fff', borderRadius: 14, padding: '24px 16px', textAlign: 'center', border: '1px solid #E8ECF0', marginBottom: 16 }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📊</div>
            <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 13, fontWeight: 700, color: '#101213', marginBottom: 8 }}>
              Exportar Todos os Usuários
            </div>
            <div style={{ fontSize: 11, color: '#57636C', marginBottom: 16 }}>
              Gera um arquivo CSV com todos os usuários do sistema
            </div>
            <button
              onClick={exportar}
              style={{
                padding: '12px 24px',
                borderRadius: 10,
                border: 'none',
                background: 'linear-gradient(135deg,#170073,#00A893)',
                color: '#fff',
                cursor: 'pointer',
                fontFamily: 'Montserrat,sans-serif',
                fontWeight: 700,
                fontSize: 12
              }}
            >
              📤 Baixar CSV
            </button>
          </div>
        </div>
      )}
    </div>
  );
}