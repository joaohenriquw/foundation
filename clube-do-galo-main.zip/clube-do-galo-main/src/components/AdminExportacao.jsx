import { useState } from "react";

export default function AdminExportacao({ dados, tipo, nome }) {
  const [exportando, setExportando] = useState(false);

  const exportarCSV = async () => {
    setExportando(true);

    // Headers baseado no tipo
    const headers = tipo === "usuarios"
      ? ["ID", "Nome", "Email", "Cargo", "Plano", "Data Criação"]
      : ["ID", "Título", "Animal", "Dono", "Valor", "Status", "Data Sorteio"];

    // Rows baseado no tipo
    const rows = tipo === "usuarios"
      ? dados.map(u => [
          u.id,
          u.full_name || "—",
          u.email,
          u.role || "user",
          u.plano || "—",
          u.created_date ? new Date(u.created_date).toLocaleDateString("pt-BR") : "—",
        ])
      : dados.map(r => [
          r.id,
          r.titulo || r.animal_nome,
          r.animal_nome,
          r.dono_nome || r.dono_email,
          Number(r.valor_arrecadar || 0).toFixed(2),
          r.status,
          r.data_sorteio ? new Date(r.data_sorteio).toLocaleDateString("pt-BR") : "—",
        ]);

    // Monta CSV
    const csv = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(",")),
    ].join("\n");

    // Download
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${nome}-${new Date().toISOString().split("T")[0]}.csv`;
    link.click();

    setExportando(false);
  };

  return (
    <button onClick={exportarCSV} disabled={exportando || !dados.length}
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        padding: "8px 14px",
        borderRadius: 10,
        border: "1.5px solid #170073",
        background: "#fff",
        color: "#170073",
        cursor: (exportando || !dados.length) ? "default" : "pointer",
        fontFamily: "Montserrat,sans-serif",
        fontSize: 12,
        fontWeight: 800,
        opacity: (exportando || !dados.length) ? 0.5 : 1,
      }}>
      📊 {exportando ? "Exportando..." : `Exportar ${tipo}`}
    </button>
  );
}