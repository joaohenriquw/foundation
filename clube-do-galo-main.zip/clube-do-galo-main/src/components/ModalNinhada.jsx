import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import SelectField from './SelectField';
import BuscaGenealogiaGlobal from './BuscaGenealogiaGlobal';

const CORES_ANILHA = {
  vermelho:  { label: "Vermelho",  bg: "#ffecec", cor: "#ef4444" },
  azul:      { label: "Azul",      bg: "#ecf4ff", cor: "#3b82f6" },
  verde:     { label: "Verde",     bg: "#ecfdf5", cor: "#10b981" },
  amarelo:   { label: "Amarelo",   bg: "#fffbeb", cor: "#f59e0b" },
  laranja:   { label: "Laranja",   bg: "#ffedd5", cor: "#f97316" },
  roxo:      { label: "Roxo",      bg: "#f3e8ff", cor: "#a855f7" },
  preto:     { label: "Preto",     bg: "#f3f4f6", cor: "#1f2937" },
};

export default function ModalNinhada({ animal, user, onClose, onConcluido }) {
  const [pai, setPai] = useState(null);
  const [mae, setMae] = useState(null);
  const [anilhas, setAnilhas] = useState(Array(10).fill({ numero: '', cor: 'amarelo' }));
  const [salvando, setSalvando] = useState(false);

  // Auto-preencher o animal como um dos pais
  useEffect(() => {
    if (animal && !pai && !mae) {
      // Assumir que o animal é a mãe (padrão)
      setMae({ id: animal.id, nome: animal.nome });
    }
  }, [animal, pai, mae]);

  const salvar = async () => {
    if (!pai) {
      alert('⚠️ Erro: Selecione o Pai obrigatoriamente.');
      return;
    }
    if (!mae) {
      alert('⚠️ Erro: Selecione a Mãe obrigatoriamente.');
      return;
    }
    const anilhasVazias = anilhas.some(a => !a.numero);
    if (anilhasVazias) {
      alert('⚠️ Erro: Preencha o número de todas as 10 anilhas filhas.');
      return;
    }

    setSalvando(true);
    const dataTroca = new Date();
    dataTroca.setDate(dataTroca.getDate() + 120); // 120 dias
    const dataTrocaStr = dataTroca.toISOString().split('T')[0];

    try {
      for (const anilha of anilhas) {
        if (!anilha.numero) continue;
        await base44.entities.AnilhaFilha.create({
          usuario_id: user.id || user.email,
          usuario_email: user.email,
          animal_pai_id: pai.id,
          animal_pai_nome: pai.nome,
          animal_mae_id: mae.id,
          animal_mae_nome: mae.nome,
          anilha_numero: anilha.numero,
          cor_anilha_definitiva: anilha.cor,
          data_criacao: new Date().toISOString().split('T')[0],
          data_troca_definitiva: dataTrocaStr,
          status: 'incubando',
        });
      }

      await base44.entities.Notificacao.create({
        destinatario_email: user.email,
        titulo: '🐣 Ninhada Registrada',
        mensagem: `10 anilhas filhas foram registradas. Elas serão convertidas em animais adultos em ${dataTrocaStr}.`,
        tipo: 'anilha',
        icone: '🐣',
        lida: false,
      });

      setSalvando(false);
      onConcluido();
      onClose();
    } catch (e) {
      console.error(e);
      setSalvando(false);
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0,0,0,.5)',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'center',
      }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div
        style={{
          background: '#fff',
          borderRadius: '20px 20px 0 0',
          width: '100%',
          maxWidth: 600,
          maxHeight: '92vh',
          overflowY: 'auto',
          padding: '20px 20px 40px',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 16, fontWeight: 900, color: '#170073' }}>
            🐣 Registrar Ninhada
          </div>
          <button
            onClick={onClose}
            style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: '#57636C' }}
          >
            ✕
          </button>
        </div>

        <div style={{ display: 'grid', gap: 12 }}>
          {/* Seleção de Pai e Mãe */}
          <div style={{ background: '#F0F4FF', borderRadius: 12, padding: 12 }}>
            <BuscaGenealogiaGlobal label="♂️ Selecionar Pai" onSelect={setPai} />
            {pai && (
              <div style={{ fontSize: 11, color: '#170073', marginTop: 6, fontWeight: 700 }}>
                ✅ {pai.nome}
              </div>
            )}
          </div>

          <div style={{ background: '#F0F4FF', borderRadius: 12, padding: 12 }}>
            <BuscaGenealogiaGlobal label="♀️ Selecionar Mãe" onSelect={setMae} />
            {mae && (
              <div style={{ fontSize: 11, color: '#170073', marginTop: 6, fontWeight: 700 }}>
                ✅ {mae.nome}
              </div>
            )}
          </div>

          {/* Grid de 10 Anilhas */}
          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: '#57636C', textTransform: 'uppercase', display: 'block', marginBottom: 8 }}>
              📿 Registre as 10 Anilhas Filhas
            </label>
            <div style={{ display: 'grid', gap: 10 }}>
              {anilhas.map((anilha, i) => (
                <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                  <input
                    type="text"
                    placeholder={`Anilha ${i + 1}`}
                    value={anilha.numero}
                    onChange={e => {
                      const nova = [...anilhas];
                      nova[i] = { ...nova[i], numero: e.target.value };
                      setAnilhas(nova);
                    }}
                    style={{
                      flex: 1,
                      padding: '8px 10px',
                      borderRadius: 8,
                      border: '1.5px solid #E8ECF0',
                      fontSize: 12,
                      outline: 'none',
                    }}
                  />
                  <SelectField
                    value={anilha.cor}
                    onChange={e => {
                      const nova = [...anilhas];
                      nova[i] = { ...nova[i], cor: e.target.value };
                      setAnilhas(nova);
                    }}
                    options={Object.entries(CORES_ANILHA).map(([k, v]) => ({ value: k, label: v.label }))}
                    style={{ minWidth: 100 }}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Botão salvar */}
          <button
            onClick={salvar}
            disabled={salvando || !pai || !mae}
            style={{
              width: '100%',
              padding: '14px',
              borderRadius: 12,
              border: 'none',
              background: salvando || !pai || !mae ? '#ccc' : 'linear-gradient(135deg,#170073,#00A893)',
              color: '#fff',
              cursor: salvando || !pai || !mae ? 'default' : 'pointer',
              fontFamily: 'Montserrat,sans-serif',
              fontSize: 14,
              fontWeight: 900,
              marginTop: 16,
            }}
          >
            {salvando ? '⏳ Registrando...' : '🐣 Registrar Ninhada'}
          </button>
        </div>
      </div>
    </div>
  );
}