import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const ANO_ATUAL = new Date().getFullYear();

export default function TemporadaCombateModal({ animal, user, onClose }) {
  const [temporadas, setTemporadas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandida, setExpandida] = useState(null);
  const [novaTemporada, setNovaTemporada] = useState(false);
  const [novoAno, setNovoAno] = useState(String(ANO_ATUAL));
  const [editando, setEditando] = useState(null); // { id, vitorias, empates, derrotas }
  const [saving, setSaving] = useState(false);

  const carregar = async () => {
    const data = await base44.entities.TemporadaCombate.filter({ animal_id: animal.id }, "-temporada", 50);
    setTemporadas(data);
    setLoading(false);
  };

  useEffect(() => { carregar(); }, [animal.id]);

  const criarTemporada = async () => {
    if (!novoAno) return;
    const jaExiste = temporadas.find(t => t.temporada === novoAno);
    if (jaExiste) { alert("Temporada já existe!"); return; }
    setSaving(true);
    await base44.entities.TemporadaCombate.create({
      animal_id: animal.id,
      animal_nome: animal.nome,
      animal_anilha: animal.anilha,
      temporada: novoAno,
      vitorias: 0, empates: 0, derrotas: 0,
      usuario_email: user.email,
    });
    setNovaTemporada(false);
    setSaving(false);
    carregar();
  };

  const salvarEdicao = async () => {
    setSaving(true);
    await base44.entities.TemporadaCombate.update(editando.id, {
      vitorias: Number(editando.vitorias),
      empates: Number(editando.empates),
      derrotas: Number(editando.derrotas),
    });
    setEditando(null);
    setSaving(false);
    carregar();
  };

  const excluirTemporada = async (id) => {
    if (!confirm("Excluir esta temporada?")) return;
    await base44.entities.TemporadaCombate.delete(id);
    carregar();
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.7)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#0D0D0D", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 520, maxHeight: "92vh", overflowY: "auto", paddingBottom: 40 }}>

        {/* Header */}
        <div style={{ padding: "20px 20px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #222" }}>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#fff" }}>🏆 Temporadas de Apresentações</div>
            <div style={{ fontSize: 11, color: "#888", marginTop: 2 }}>{animal.nome} · Anilha {animal.anilha}</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button onClick={() => setNovaTemporada(true)}
              style={{ width: 34, height: 34, borderRadius: "50%", background: "#fff", border: "none", fontSize: 18, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900 }}>+</button>
            <button onClick={onClose}
              style={{ background: "#333", border: "none", borderRadius: "50%", width: 32, height: 32, color: "#fff", fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
          </div>
        </div>

        <div style={{ padding: "14px 16px" }}>
          {/* Modal nova temporada */}
          {novaTemporada && (
            <div style={{ background: "#1A1A1A", borderRadius: 14, padding: "14px 16px", marginBottom: 14, border: "1px solid #333" }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#aaa", marginBottom: 10 }}>Nova Temporada</div>
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  type="number" value={novoAno} onChange={e => setNovoAno(e.target.value)}
                  placeholder="Ano (ex: 2025)"
                  style={{ flex: 1, padding: "10px 12px", borderRadius: 10, border: "1px solid #333", background: "#111", color: "#fff", fontSize: 14, fontWeight: 700, outline: "none" }}
                />
                <button onClick={criarTemporada} disabled={saving}
                  style={{ padding: "10px 18px", borderRadius: 10, border: "none", background: "#fff", color: "#000", fontWeight: 800, fontSize: 13, cursor: "pointer" }}>
                  Criar
                </button>
                <button onClick={() => setNovaTemporada(false)}
                  style={{ padding: "10px 14px", borderRadius: 10, border: "1px solid #333", background: "transparent", color: "#aaa", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
                  ✕
                </button>
              </div>
            </div>
          )}

          {loading ? (
            <div style={{ textAlign: "center", padding: 40, color: "#666" }}>Carregando...</div>
          ) : temporadas.length === 0 ? (
            <div style={{ textAlign: "center", padding: 40, color: "#666" }}>
              <div style={{ fontSize: 36, marginBottom: 10 }}>⚔️</div>
              <div style={{ fontWeight: 700 }}>Nenhuma temporada cadastrada</div>
              <div style={{ fontSize: 12, marginTop: 6 }}>Clique em + para adicionar</div>
            </div>
          ) : (
            temporadas.map(t => {
              const total = (t.vitorias || 0) + (t.empates || 0) + (t.derrotas || 0);
              const aberta = expandida === t.id;
              const editandoEsta = editando?.id === t.id;
              return (
                <div key={t.id} style={{ background: "#1A1A1A", borderRadius: 16, marginBottom: 12, overflow: "hidden", border: "1px solid #2a2a2a" }}>
                  {/* Header da temporada */}
                  <div style={{ padding: "14px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>{t.temporada}</div>
                    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                      <button onClick={() => excluirTemporada(t.id)}
                        style={{ background: "none", border: "none", fontSize: 14, color: "#555", cursor: "pointer" }}>🗑️</button>
                      <button onClick={() => {
                         if (aberta) { setExpandida(null); setEditando(null); }
                         else { setExpandida(t.id); setEditando({ id: t.id, vitorias: t.vitorias || 0, empates: t.empates || 0, derrotas: t.derrotas || 0 }); }
                       }}
                        style={{ background: "none", border: "none", fontSize: 16, color: "#aaa", cursor: "pointer" }}>
                        {aberta ? "▲" : "▼"}
                      </button>
                    </div>
                  </div>

                  {/* Linha "Eventos" clicável */}
                  <div style={{ padding: "10px 16px", borderTop: "1px solid #222", cursor: "pointer" }}
                    onClick={() => {
                      if (aberta) { setExpandida(null); setEditando(null); }
                      else { setExpandida(t.id); setEditando({ id: t.id, vitorias: t.vitorias || 0, empates: t.empates || 0, derrotas: t.derrotas || 0 }); }
                    }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 20, fontWeight: 900, color: "#fff" }}>Eventos</div>
                    <div style={{ fontSize: 11, color: "#555", marginTop: 2 }}>Clique para ver todos os eventos</div>
                  </div>

                  {/* Barras de resultado */}
                  <div style={{ padding: "6px 12px 12px" }}>
                    {[
                      { key: "vitorias", label: "Vitórias", val: t.vitorias || 0, cor: "#22c55e" },
                      { key: "empates",  label: "Empates",  val: t.empates  || 0, cor: "#eab308" },
                      { key: "derrotas", label: "Derrotas", val: t.derrotas || 0, cor: "#ef4444" },
                    ].map(r => (
                      <div key={r.label} style={{ display: "flex", alignItems: "center", background: "#111", borderRadius: 10, marginBottom: 6, overflow: "hidden" }}>
                        <div style={{ width: 4, background: r.cor, alignSelf: "stretch", flexShrink: 0 }} />
                        <div style={{ flex: 1, padding: "10px 14px", fontSize: 14, fontWeight: 700, color: "#fff" }}>{r.label}</div>
                        {aberta && editandoEsta ? (
                          <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 10px" }}>
                            <button onClick={() => setEditando(prev => ({ ...prev, [r.key]: Math.max(0, Number(prev[r.key]) - 1) }))}
                              style={{ width: 32, height: 32, borderRadius: 8, border: "1px solid #333", background: "#222", color: "#aaa", fontSize: 18, fontWeight: 900, cursor: "pointer" }}>−</button>
                            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff", minWidth: 28, textAlign: "center" }}>{editando[r.key]}</div>
                            <button onClick={() => setEditando(prev => ({ ...prev, [r.key]: Number(prev[r.key]) + 1 }))}
                              style={{ width: 32, height: 32, borderRadius: 8, border: `1.5px solid ${r.cor}60`, background: `${r.cor}22`, color: r.cor, fontSize: 18, fontWeight: 900, cursor: "pointer" }}>+</button>
                          </div>
                        ) : (
                          <div style={{ padding: "10px 16px", fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#fff" }}>{r.val}</div>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Salvar expandido */}
                  {aberta && editandoEsta && (
                    <div style={{ padding: "0 12px 14px", display: "flex", gap: 8 }}>
                      <button onClick={salvarEdicao} disabled={saving}
                        style={{ flex: 1, padding: "12px", borderRadius: 10, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontWeight: 800, fontSize: 14, cursor: "pointer" }}>
                        {saving ? "Salvando..." : "💾 Salvar"}
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}