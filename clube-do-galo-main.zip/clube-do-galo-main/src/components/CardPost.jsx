import { useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function CardPost({ post, user, onAtualizar }) {
  const [curtido, setCurtido] = useState(post.curtido_por_mim);
  const [curtidas, setCurtidas] = useState(post.curtidas || 0);
  const [mostraComentarios, setMostraComentarios] = useState(false);
  const [novoComentario, setNovoComentario] = useState('');
  const [comentando, setComentando] = useState(false);

  const toggleCurtida = async () => {
    try {
      await base44.functions.invoke('curtirPost', {
        post_id: post.id,
        descurtir: curtido
      });
      setCurtido(!curtido);
      setCurtidas(curtido ? curtidas - 1 : curtidas + 1);
    } catch (e) {
      console.error('Erro ao curtir:', e);
    }
  };

  const adicionarComentario = async () => {
    if (!novoComentario.trim()) return;
    setComentando(true);
    try {
      await base44.functions.invoke('criarComentarioPost', {
        post_id: post.id,
        conteudo: novoComentario
      });
      setNovoComentario('');
      onAtualizar?.();
    } catch (e) {
      console.error('Erro ao comentar:', e);
    } finally {
      setComentando(false);
    }
  };

  return (
    <div style={{
      background: '#fff',
      borderRadius: 12,
      padding: '14px',
      marginBottom: 12,
      border: '1px solid #E8ECF0'
    }}>
      {/* Header */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 12 }}>
        <div style={{
          width: 36,
          height: 36,
          borderRadius: '50%',
          background: 'linear-gradient(135deg,#170073,#00A893)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#fff',
          fontSize: 14,
          fontWeight: 900,
          flexShrink: 0
        }}>
          {(post.autor_nome?.[0] || 'U').toUpperCase()}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 12, fontWeight: 800, color: '#101213' }}>
            {post.autor_nome}
          </div>
          <div style={{ fontSize: 10, color: '#BDBDBD' }}>
            {new Date(post.created_date).toLocaleDateString('pt-BR')}
          </div>
        </div>
      </div>

      {/* Conteúdo */}
      <div style={{ fontSize: 13, color: '#101213', lineHeight: 1.5, marginBottom: 12 }}>
        {post.conteudo}
      </div>

      {/* Mídia */}
      {post.midia_url && (
        <div style={{
          width: '100%',
          height: 200,
          background: `url(${post.midia_url}) center/cover`,
          borderRadius: 10,
          marginBottom: 12
        }} />
      )}

      {/* Ações */}
      <div style={{
        display: 'flex',
        gap: 12,
        padding: '10px 0',
        borderTop: '1px solid #F1F4F8',
        borderBottom: '1px solid #F1F4F8',
        marginBottom: 12,
        fontSize: 11,
        fontWeight: 700,
        color: '#57636C'
      }}>
        <button onClick={toggleCurtida}
          style={{
            flex: 1,
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            color: curtido ? '#E21C3D' : '#57636C',
            fontFamily: 'DM Sans, sans-serif'
          }}>
          {curtido ? '❤️' : '🤍'} {curtidas}
        </button>
        <button onClick={() => setMostraComentarios(!mostraComentarios)}
          style={{
            flex: 1,
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            color: '#57636C',
            fontFamily: 'DM Sans, sans-serif'
          }}>
          💬 {post.comentarios_count || 0}
        </button>
        <button style={{
          flex: 1,
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          color: '#57636C',
          fontFamily: 'DM Sans, sans-serif'
        }}>
          📤 {post.compartilhamentos || 0}
        </button>
      </div>

      {/* Comentários */}
      {mostraComentarios && (
        <div style={{ marginTop: 12 }}>
          {post.comentarios?.map(c => (
            <div key={c.id} style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', gap: 8 }}>
                <div style={{
                  width: 28,
                  height: 28,
                  borderRadius: '50%',
                  background: '#F1F4F8',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 10,
                  flexShrink: 0
                }}>
                  {(c.autor_nome?.[0] || 'U').toUpperCase()}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 11, fontWeight: 700, color: '#101213' }}>
                    {c.autor_nome}
                  </div>
                  <div style={{ fontSize: 11, color: '#57636C', lineHeight: 1.4 }}>
                    {c.conteudo}
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Input comentário */}
          <div style={{ display: 'flex', gap: 8, marginTop: 10, paddingTop: 10, borderTop: '1px solid #F1F4F8' }}>
            <input
              type="text"
              value={novoComentario}
              onChange={e => setNovoComentario(e.target.value)}
              placeholder="Adicionar comentário..."
              style={{
                flex: 1,
                padding: '8px 10px',
                borderRadius: 8,
                border: '1px solid #E8ECF0',
                fontSize: 11,
                outline: 'none'
              }}
            />
            <button onClick={adicionarComentario} disabled={comentando || !novoComentario.trim()}
              style={{
                padding: '8px 12px',
                borderRadius: 8,
                border: 'none',
                background: comentando || !novoComentario.trim() ? '#ccc' : '#170073',
                color: '#fff',
                cursor: comentando ? 'default' : 'pointer',
                fontSize: 11,
                fontWeight: 700,
                fontFamily: 'Montserrat,sans-serif'
              }}>
              {comentando ? '⏳' : '✓'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}