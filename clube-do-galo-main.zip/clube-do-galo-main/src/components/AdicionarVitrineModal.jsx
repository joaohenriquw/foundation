import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { getPlano } from "../lib/planos";

export default function AdicionarVitrineModal({ animal, user, userMeta, onClose, onConcluido }) {
  const [loading, setLoading] = useState(false);
  const [descricao, setDescricao] = useState("");
  const [existente, setExistente] = useState(null);

  const plano = getPlano(userMeta?.plano || "iniciante");
  const diasExpiracao = plano.vitrine_dias_intervalo; // null = ilimitado (Premium) // Premium = ilimitado

  useEffect(() => {
    // Verificar se animal já está na vitrine
    const verificar = async () => {
      const vitrineData = await base44.entities.VitrineExposicao.filter({
        animal_id: animal.id,
        proprietario_id: user.id,
        ativa: true,
      });
      if (vitrineData.length > 0) {
        setExistente(vitrineData[0]);
      }
    };
    verificar();
  }, [animal, user]);

  const adicionar = async () => {
    if (!animal.anilha) {
      alert("Animal deve ter anilha registrada");
      return;
    }

    setLoading(true);

    const dataExpiracao = new Date();
    dataExpiracao.setDate(dataExpiracao.getDate() + (diasExpiracao ?? 3650)); // Premium = 10 anos (ilimitado prático)

    await base44.entities.VitrineExposicao.create({
      animal_id: animal.id,
      animal_nome: animal.nome,
      animal_anilha: animal.anilha,
      animal_especie: animal.especie,
      animal_foto_url: animal.foto_url,
      animal_valor: animal.valor_estimado,
      proprietario_id: user.id,
      proprietario_nome: user.full_name || user.email,
      proprietario_email: user.email,
      plano_expositore: userMeta?.plano || "iniciante",
      data_expiracao: dataExpiracao.toISOString().split("T")[0],
      ativa: true,
      descricao: descricao,
    });

    // Notificar
    await base44.entities.Notificacao.create({
      destinatario_email: user.email,
      titulo: "🏪 Na Vitrine!",
      mensagem: `${animal.nome} foi adicionado à vitrine por ${diasExpiracao ? diasExpiracao + ' dias' : 'tempo ilimitado'}`,
      tipo: "vitrine",
      link: "/vitrine",
      icone: "🏪",
    });

    setLoading(false);
    onConcluido?.();
    onClose();
  };

  const remover = async () => {
    if (!existente) return;
    setLoading(true);
    await base44.entities.VitrineExposicao.update(existente.id, { ativa: false });
    setLoading(false);
    onConcluido?.();
    onClose();
  };

  if (!plano.pode_vitrine) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ background: "#fff", borderRadius: 16, padding: 24, maxWidth: 340 }}>
          <div style={{ fontSize: 40, marginBottom: 12, textAlign: "center" }}>🔒</div>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 8, textAlign: "center" }}>
            Vitrine não disponível
          </div>
          <div style={{ fontSize: 12, color: "#57636C", marginBottom: 16, textAlign: "center" }}>
            Você precisa do plano Standard ou superior para adicionar animais à vitrine.
          </div>
          <button onClick={onClose} style={{ width: "100%", padding: "10px", borderRadius: 10, border: "none", background: "#170073", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
            Fechar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 600, padding: "20px 20px 40px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
            🏪 {existente ? "Remover da Vitrine" : "Adicionar à Vitrine"}
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        {existente ? (
          <div style={{ display: "grid", gap: 12 }}>
            <div style={{ background: "#FFF8E1", borderRadius: 10, padding: 12, fontSize: 12, color: "#F0A500", fontWeight: 700 }}>
              ✓ Este animal já está na vitrine até {new Date(existente.data_expiracao).toLocaleDateString("pt-BR")}
            </div>
            <button onClick={remover} disabled={loading} style={{ padding: "12px", borderRadius: 10, border: "none", background: loading ? "#ccc" : "#E21C3D", color: "#fff", cursor: loading ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
              {loading ? "Removendo..." : "Remover da Vitrine"}
            </button>
          </div>
        ) : (
          <div style={{ display: "grid", gap: 12 }}>
            {/* Info de duração */}
            <div style={{ background: "#E8F5E9", borderRadius: 10, padding: 12, fontSize: 12, color: "#2E7D32", fontWeight: 700 }}>
              📅 Este animal ficará na vitrine por {diasExpiracao ? `${diasExpiracao} dias` : "tempo ilimitado (Premium)"}
            </div>

            {/* Descrição */}
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                📝 Descrição (opcional)
              </label>
              <textarea value={descricao} onChange={e => setDescricao(e.target.value)} placeholder="Destaques, características especiais..."
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", height: 80, resize: "none" }} />
            </div>

            {/* Resumo do animal */}
            <div style={{ background: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 12, color: "#57636C" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "#101213", marginBottom: 8 }}>
                {animal.nome}
              </div>
              <div style={{ display: "grid", gap: 4 }}>
                <div>🏷️ <strong>Anilha:</strong> {animal.anilha}</div>
                {animal.especie && <div>📋 <strong>Espécie:</strong> {animal.especie}</div>}
                {animal.valor_estimado && <div>💰 <strong>Valor:</strong> R$ {Number(animal.valor_estimado).toLocaleString("pt-BR")}</div>}
              </div>
            </div>

            {/* Botão adicionar */}
            <button onClick={adicionar} disabled={loading} style={{ padding: "12px", borderRadius: 10, border: "none", background: loading ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: loading ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
              {loading ? "Adicionando..." : "✓ Adicionar à Vitrine"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}