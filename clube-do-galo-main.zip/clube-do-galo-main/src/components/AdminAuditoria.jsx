import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const ICONES_ACAO = {
  criar_rifa: "🎰",
  editar_rifa: "✏️",
  deletar_rifa: "🗑️",
  alterar_cargo_usuario: "👤",
  conceder_plano: "👑",
  exportar_usuarios: "📥",
  exportar_rifas: "📥",
  editar_usuario: "✏️",
  deletar_usuario: "🗑️",
  configurar_gateway: "💳",
  gerenciar_socios: "👥",
};

export default function AdminAuditoria() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const carregar = async () => {
      const data = await base44.entities.AuditoriaLog.list("-created_date", 50);
      setLogs(data);
      setLoading(false);
    };
    carregar();
  }, []);

  if (loading) return <div style={{ textAlign: "center", padding: 20, color: "#57636C" }}>⏳ Carregando...</div>;

  return (
    <div style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", border: "1px solid #E8ECF0" }}>
      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, marginBottom: 12, color: "#101213" }}>
        📋 Histórico de Auditoria
      </div>
      {logs.length === 0 ? (
        <div style={{ fontSize: 12, color: "#57636C", textAlign: "center", padding: 20 }}>Nenhum log registrado</div>
      ) : (
        <div style={{ maxHeight: 300, overflowY: "auto" }}>
          {logs.map((log, i) => (
            <div key={i} style={{ display: "flex", gap: 10, padding: "10px 0", borderBottom: "1px solid #F8FAFC", fontSize: 11 }}>
              <div style={{ fontSize: 14 }}>{ICONES_ACAO[log.acao] || "📌"}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, color: "#101213" }}>{log.acao}</div>
                <div style={{ color: "#57636C", fontSize: 10 }}>
                  {log.admin_nome} • {new Date(log.created_date).toLocaleDateString("pt-BR")}
                </div>
                {log.detalhes && <div style={{ color: "#57636C", fontSize: 9, marginTop: 2 }}>{log.detalhes}</div>}
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{
                  fontSize: 9,
                  fontWeight: 700,
                  padding: "2px 6px",
                  borderRadius: 4,
                  background: log.status === "sucesso" ? "#E8F5E9" : log.status === "erro" ? "#FFEBEE" : "#FFF8E1",
                  color: log.status === "sucesso" ? "#2E7D32" : log.status === "erro" ? "#C62828" : "#F0A500",
                }}>
                  {log.status}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}