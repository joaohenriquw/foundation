import { useNavigate } from 'react-router-dom';

export default function AvisoLimitePlan({ validacao }) {
  const navigate = useNavigate();
  if (!validacao || validacao.limite_atingido !== true) return null;

  return (
    <div 
      onClick={() => navigate('/planos')} 
      onMouseEnter={(e) => e.currentTarget.style.opacity = '1'} 
      onMouseLeave={(e) => e.currentTarget.style.opacity = '0.9'}
      style={{
        cursor: 'pointer',
        background: '#FFF8E1',
        borderRadius: 12,
        padding: '12px 14px',
        border: '1px solid #FFE0B2',
        transition: 'all 0.2s',
        opacity: 0.9,
        display: 'flex',
        gap: 8,
        alignItems: 'flex-start',
        marginBottom: 12
      }}
    >
      <span style={{ fontSize: 16, flexShrink: 0 }}>⚠️</span>
      <div style={{ flex: 1 }}>
        <div style={{
          fontSize: 11,
          fontWeight: 700,
          color: '#E65100',
          lineHeight: 1.4
        }}>
          {validacao.mensagem}
        </div>
      </div>
    </div>
  );
}