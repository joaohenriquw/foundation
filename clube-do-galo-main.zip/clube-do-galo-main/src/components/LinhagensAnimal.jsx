import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function LinhagensAnimal({ animalId }) {
  const [animal, setAnimal] = useState(null);
  const [pais, setPais] = useState({ pai: null, mae: null });
  const [avos, setAvos] = useState({ paiPai: null, paiMae: null, maePai: null, maeMae: null });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const carregar = async () => {
      try {
        // Busca o animal atual
        const [anim] = await base44.entities.Animal.filter({ id: animalId });
        if (!anim) {
          setLoading(false);
          return;
        }
        setAnimal(anim);

        // Tenta buscar pais através de AnilhaFilha onde este é o filhote
        const anilhas = await base44.entities.AnilhaFilha.filter({ animal_origem_id: animalId }, "-created_date", 1);
        if (anilhas.length > 0) {
          const anilha = anilhas[0];
          const [pai, mae] = await Promise.all([
            anilha.animal_pai_id ? base44.entities.Animal.filter({ id: anilha.animal_pai_id }).then(a => a[0]) : null,
            anilha.animal_mae_id ? base44.entities.Animal.filter({ id: anilha.animal_mae_id }).then(a => a[0]) : null,
          ]);
          setPais({ pai, mae });

          // Busca avós
          if (pai || mae) {
            const avisAnilha = await base44.entities.AnilhaFilha.filter({
              $or: [
                { animal_origem_id: pai?.id },
                { animal_origem_id: mae?.id },
              ]
            }, "-created_date", 2);

            const avisDict = {};
            for (const av of avisAnilha) {
              if (av.animal_origem_id === pai?.id) {
                const [avoPai, avoMae] = await Promise.all([
                  av.animal_pai_id ? base44.entities.Animal.filter({ id: av.animal_pai_id }).then(a => a[0]) : null,
                  av.animal_mae_id ? base44.entities.Animal.filter({ id: av.animal_mae_id }).then(a => a[0]) : null,
                ]);
                avisDict.paiPai = avoPai;
                avisDict.paiMae = avoMae;
              }
              if (av.animal_origem_id === mae?.id) {
                const [avoPai, avoMae] = await Promise.all([
                  av.animal_pai_id ? base44.entities.Animal.filter({ id: av.animal_pai_id }).then(a => a[0]) : null,
                  av.animal_mae_id ? base44.entities.Animal.filter({ id: av.animal_mae_id }).then(a => a[0]) : null,
                ]);
                avisDict.maePai = avoPai;
                avisDict.maeMae = avoMae;
              }
            }
            setAvos(avisDict);
          }
        }
      } catch (err) {
        console.error("Erro ao carregar linhagem:", err);
      } finally {
        setLoading(false);
      }
    };

    carregar();
  }, [animalId]);

  if (loading) {
    return <div style={{ padding: "16px", textAlign: "center", color: "#57636C", fontSize: 12 }}>⏳ Carregando linhagem...</div>;
  }

  if (!animal) {
    return null;
  }

  const CartaoAnimal = ({ animal, tamanho = "normal" }) => {
    if (!animal) return <div style={{ opacity: 0.3, fontSize: tamanho === "pequeno" ? 10 : 11 }}>❓</div>;
    
    const tamFonte = tamanho === "pequeno" ? 10 : tamanho === "medio" ? 12 : 13;
    const padding = tamanho === "pequeno" ? "6px 8px" : tamanho === "medio" ? "8px 10px" : "10px 12px";
    
    return (
      <div style={{
        background: "linear-gradient(135deg,#170073,#00A893)",
        color: "#fff",
        borderRadius: tamanho === "pequeno" ? 6 : 10,
        padding,
        textAlign: "center",
        minWidth: tamanho === "pequeno" ? 60 : 90,
        fontSize: tamFonte,
        fontFamily: "Montserrat,sans-serif",
        fontWeight: 700,
        lineHeight: 1.3,
        wordBreak: "break-word",
      }}>
        {animal.nome}
        {animal.sexo && <div style={{ fontSize: tamFonte - 2, opacity: 0.8, marginTop: 2 }}>
          {animal.sexo === "macho" ? "♂️" : "♀️"}
        </div>}
      </div>
    );
  };

  const Linha = ({ vertical = false }) => (
    <div style={{
      background: "#E8ECF0",
      position: "absolute",
      ...(vertical ? { width: 2, height: 20, left: "50%", top: -20, transform: "translateX(-50%)" } : { height: 2, width: 30, top: "50%", left: -30, transform: "translateY(-50%)" })
    }} />
  );

  const Conexao = () => (
    <>
      <div style={{ position: "absolute", width: 2, height: 20, left: "50%", top: -20, background: "#E8ECF0", transform: "translateX(-50%)" }} />
      <div style={{ position: "absolute", height: 2, width: 30, top: -1, left: "50%", background: "#E8ECF0", transform: "translateX(-50%)" }} />
    </>
  );

  return (
    <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E8ECF0", padding: "20px", marginTop: 14 }}>
      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 16, display: "flex", alignItems: "center", gap: 8 }}>
        🧬 Linhagem
      </div>

      {/* Avós */}
      {(avos.paiPai || avos.paiMae || avos.maePai || avos.maeMae) && (
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 12, textAlign: "center" }}>Avós</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, justifyItems: "center", position: "relative", paddingBottom: 20 }}>
            <CartaoAnimal animal={avos.paiPai} tamanho="pequeno" />
            <CartaoAnimal animal={avos.paiMae} tamanho="pequeno" />
            <CartaoAnimal animal={avos.maePai} tamanho="pequeno" />
            <CartaoAnimal animal={avos.maeMae} tamanho="pequeno" />
            
            {/* Linhas conectoras */}
            <div style={{ position: "absolute", bottom: 0, left: "12.5%", width: 2, height: 20, background: "#E8ECF0", transform: "translateX(-50%)" }} />
            <div style={{ position: "absolute", bottom: 0, left: "37.5%", width: 2, height: 20, background: "#E8ECF0", transform: "translateX(-50%)" }} />
            <div style={{ position: "absolute", bottom: 0, left: "62.5%", width: 2, height: 20, background: "#E8ECF0", transform: "translateX(-50%)" }} />
            <div style={{ position: "absolute", bottom: 0, left: "87.5%", width: 2, height: 20, background: "#E8ECF0", transform: "translateX(-50%)" }} />
            <div style={{ position: "absolute", bottom: 20, left: "25%", right: "25%", height: 2, background: "#E8ECF0" }} />
          </div>
        </div>
      )}

      {/* Pais */}
      {(pais.pai || pais.mae) && (
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 12, textAlign: "center" }}>Pais</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12, justifyItems: "center", position: "relative", paddingBottom: 20 }}>
            <CartaoAnimal animal={pais.pai} tamanho="medio" />
            <CartaoAnimal animal={pais.mae} tamanho="medio" />
            
            {/* Linhas conectoras */}
            <div style={{ position: "absolute", bottom: 0, left: "25%", width: 2, height: 20, background: "#E8ECF0", transform: "translateX(-50%)" }} />
            <div style={{ position: "absolute", bottom: 0, left: "75%", width: 2, height: 20, background: "#E8ECF0", transform: "translateX(-50%)" }} />
            <div style={{ position: "absolute", bottom: 20, left: "25%", right: "25%", height: 2, background: "#E8ECF0" }} />
          </div>
        </div>
      )}

      {/* Animal Atual */}
      <div style={{ display: "flex", justifyContent: "center", paddingTop: (pais.pai || pais.mae) ? 20 : 0 }}>
        <div style={{ position: "relative" }}>
          {(pais.pai || pais.mae) && (
            <div style={{ position: "absolute", top: -20, left: "50%", width: 2, height: 20, background: "#E8ECF0", transform: "translateX(-50%)" }} />
          )}
          <div style={{
            background: "linear-gradient(135deg,#F0A500,#E21C3D)",
            color: "#fff",
            borderRadius: 12,
            padding: "12px 16px",
            textAlign: "center",
            minWidth: 120,
            fontSize: 14,
            fontFamily: "Montserrat,sans-serif",
            fontWeight: 900,
            lineHeight: 1.4,
            boxShadow: "0 4px 12px rgba(240,165,0,.3)",
          }}>
            {animal.nome}
            {animal.sexo && <div style={{ fontSize: 16, marginTop: 4 }}>
              {animal.sexo === "macho" ? "♂️" : "♀️"}
            </div>}
            {animal.anilha && <div style={{ fontSize: 10, opacity: 0.9, marginTop: 4, fontFamily: "DM Sans,sans-serif" }}>
              Anilha: {animal.anilha}
            </div>}
          </div>
        </div>
      </div>

      {/* Info */}
      {!(pais.pai || pais.mae) && (
        <div style={{ textAlign: "center", fontSize: 12, color: "#57636C", paddingTop: 12 }}>
          📍 Sem pais registrados nesta linhagem
        </div>
      )}
    </div>
  );
}