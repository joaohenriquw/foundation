import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

const PLANOS_DISPONIVEIS = [
  { id: 'iniciante', nome: 'Iniciante', cor: '#57636C' },
  { id: 'standard', nome: 'Standard', cor: '#1565C0' },
  { id: 'gold', nome: 'Gold', cor: '#F0A500' },
  { id: 'premium', nome: 'Premium', cor: '#170073' },
];

export default function GestaoPlanos({ user }) {
  const [usuarios, setUsuarios] = useState([]);
  const [filtro, setFiltro] = useState('');
  const [atribuindo, setAtribuindo] = useState(null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    carregarUsuarios();
  }, []);

  const carregarUsuarios = async () => {
    try {
      const lista = await base44.entities.User.list('-created_date', 200);
      setUsuarios(lista.filter(u => u.role === 'user'));
      setCarregando(false);
    } catch (e) {
      console.error('Erro ao carregar usuários:', e);
      setCarregando(false);
    }
  };

  const atribuirPlano = async (usuarioId, planoId) => {
    setAtribuindo(usuarioId);
    try {
      const planoSelecionado = PLANOS_DISPONIVEIS.find(p => p.id === planoId);
      const usuarioAtribuido = usuarios.find(u => u.id === usuarioId);
      
      // Atualizar plano do usuário
      await base44.entities.User.update(usuarioId, { plano: planoId });

      // Notificar usuário
      await base44.entities.Notificacao.create({
        destinatario_email: usuarioAtribuido?.email,
        titulo: '👑 Novo Plano Atribuído',
        mensagem: `Seu plano foi atualizado para ${planoSelecionado.nome}!`,
        tipo: 'sistema',
        lida: false,
        icone: '👑',
      });

      // Notificar todos os admins sobre a atribuição
      const admins = await base44.asServiceRole.entities.User.filter({ role: { $in: ['admin', 'master_admin'] } });
      for (const admin of admins) {
        await base44.entities.Notificacao.create({
          destinatario_email: admin.email,
          titulo: '📊 Novo Plano Atribuído',
          mensagem: `${user.full_name || user.email} atribuiu plano ${planoSelecionado.nome} para ${usuarioAtribuido?.full_name || usuarioAtribuido?.email}`,
          tipo: 'admin',
          lida: false,
          icone: '📊',
          metadata_json: JSON.stringify({ usuario_id: usuarioId, plano: planoId, atribuidor_email: user.email }),
        });
      }

      alert('✅ Plano atribuído com sucesso!');
      await carregarUsuarios();
    } catch (e) {
      alert('❌ Erro: ' + e.message);
    } finally {
      setAtribuindo(null);
    }
  };

  const usuariosFiltrados = usuarios.filter(u =>
    !filtro || `${u.full_name || ''} ${u.email || ''}`.toLowerCase().includes(filtro.toLowerCase())
  );

  if (carregando) {
    return <div style={{ textAlign: 'center', padding: 20 }}>Carregando...</div>;
  }

  return (
    <div>
      <div style={{ marginBottom: 16 }}>
        <input
          placeholder="🔍 Buscar usuário..."
          value={filtro}
          onChange={e => setFiltro(e.target.value)}
          style={{
            width: '100%',
            padding: '10px 14px',
            borderRadius: 12,
            border: '1.5px solid #E8ECF0',
            fontSize: 13,
            outline: 'none',
            boxSizing: 'border-box',
          }}
        />
      </div>

      <div style={{ display: 'grid', gap: 10 }}>
        {usuariosFiltrados.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#BDBDBD' }}>
            Nenhum usuário encontrado
          </div>
        ) : (
          usuariosFiltrados.map(u => (
            <div key={u.id} style={{ background: '#fff', borderRadius: 14, padding: '14px 16px', border: '1px solid #E8ECF0' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <div>
                  <div style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 13, fontWeight: 800, color: '#101213' }}>
                    {u.full_name || 'Usuário'}
                  </div>
                  <div style={{ fontSize: 11, color: '#57636C' }}>{u.email}</div>
                </div>
                <div style={{
                  fontSize: 10,
                  fontWeight: 700,
                  background: '#F0F4FF',
                  color: '#170073',
                  padding: '4px 8px',
                  borderRadius: 8,
                }}>
                  {u.role === 'user' ? '👤 Usuário' : u.role}
                </div>
              </div>

              {/* Seletor de Planos */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(100px, 1fr))', gap: 8 }}>
                {PLANOS_DISPONIVEIS.map(plano => (
                  <button
                    key={plano.id}
                    onClick={() => atribuirPlano(u.id, plano.id)}
                    disabled={atribuindo === u.id}
                    style={{
                      padding: '8px 12px',
                      borderRadius: 10,
                      border: `1.5px solid ${plano.cor}`,
                      background: atribuindo === u.id ? '#ccc' : plano.cor + '15',
                      color: plano.cor,
                      cursor: atribuindo === u.id ? 'default' : 'pointer',
                      fontFamily: 'Montserrat, sans-serif',
                      fontWeight: 700,
                      fontSize: 11,
                      transition: '.15s',
                    }}>
                    {atribuindo === u.id ? '⏳' : '👑'} {plano.nome}
                  </button>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Info */}
      <div style={{
        background: '#F0F4FF',
        borderRadius: 12,
        padding: '12px',
        marginTop: 16,
        fontSize: 11,
        color: '#170073',
        lineHeight: 1.6,
      }}>
        <strong>ℹ️ Sobre Planos Parceiros:</strong><br/>
        Atribua planos premium a usuários parceiros. Eles receberão notificação automática e terão acesso aos benefícios exclusivos por um ano.
      </div>
    </div>
  );
}