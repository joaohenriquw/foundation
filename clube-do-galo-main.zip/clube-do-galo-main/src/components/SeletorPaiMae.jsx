import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function SeletorPaiMae({ label, value, valueName, onChange, userEmail }) {
  const [animais, setAnimais] = useState([]);
  const [busca, setBusca] = useState(valueName || "");
  const [aberto, setAberto] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!userEmail) return;
    setLoading(true);
    base44.entities.Animal.filter({ created_by: userEmail }, "-created_date", 200)
      .then(data => { setAnimais(data); setLoading(false); });
  }, [userEmail]);

  // Sync nome externo
  useEffect(() => { if (valueName) setBusca(valueName); }, [valueName]);

  const filtrados = busca.trim()
    ? animais.filter(a => `${a.nome} ${a.anilha}`.toLowerCase().includes(busca.toLowerCase()))
    : animais.slice(0, 8);

  const selecionar = (animal) => {
    onChange({ id: animal.id, nome: animal.nome, anilha: animal.anilha });
    setBusca(`${animal.nome} (${animal.anilha})`);
    setAberto(false);
  };

  const limpar = () => {
    onChange(null);
    setBusca("");
    setAberto(false);
  };

  return (
    <div style={{ position: "relative" }}>
      <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>{label}</label>
      <div style={{ display: "flex", gap: 6 }}>
        <input
          type="text"
          value={busca}
          onChange={e => { setBusca(e.target.value); setAberto(true); }}
          onFocus={() => setAberto(true)}
          placeholder="Buscar por nome ou anilha..."
          style={{ flex: 1, padding: "9px 11px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", color: "#101213", fontWeight: 600, background: "#fff" }}
        />
        {value && (
          <button onClick={limpar} style={{ padding: "9px 11px", borderRadius: 10, border: "1.5px solid #fee2e2", background: "#fff", color: "#E21C3D", fontSize: 12, cursor: "pointer", fontWeight: 700 }}>✕</button>
        )}
      </div>

      {aberto && busca.length > 0 && (
        <div style={{ position: "absolute", top: "100%", left: 0, right: 0, background: "#fff", borderRadius: 10, border: "1.5px solid #E8ECF0", zIndex: 100, maxHeight: 200, overflowY: "auto", boxShadow: "0 8px 24px rgba(0,0,0,.12)" }}>
          {loading ? (
            <div style={{ padding: 12, fontSize: 12, color: "#57636C" }}>Carregando...</div>
          ) : filtrados.length === 0 ? (
            <div style={{ padding: 12, fontSize: 12, color: "#57636C" }}>Nenhum encontrado</div>
          ) : filtrados.map(a => (
            <div key={a.id} onClick={() => selecionar(a)}
              style={{ padding: "10px 12px", display: "flex", alignItems: "center", gap: 10, cursor: "pointer", borderBottom: "1px solid #F1F4F8" }}
              onMouseEnter={e => e.currentTarget.style.background = "#F0F4FF"}
              onMouseLeave={e => e.currentTarget.style.background = "#fff"}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: a.foto_url ? `url(${a.foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>
                {!a.foto_url && "🐓"}
              </div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 800, color: "#101213" }}>{a.nome}</div>
                <div style={{ fontSize: 10, color: "#57636C" }}>Anilha: {a.anilha}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}