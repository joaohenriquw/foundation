import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export default function BuscaGenealogiaGlobal({ label = "Selecionar Animal", onSelect }) {
  const [animais, setAnimais] = useState([]);
  const [busca, setBusca] = useState('');
  const [aberto, setAberto] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const carregar = async () => {
      setLoading(true);
      const dados = await base44.entities.Animal.list('-created_date', 500);
      setAnimais(dados || []);
      setLoading(false);
    };
    carregar();
  }, []);

  const filtrados = animais.filter(a =>
    `${a.nome} ${a.anilha}`.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div style={{ position: 'relative' }}>
      <label style={{ fontSize: 11, fontWeight: 700, color: '#57636C', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
        {label}
      </label>
      <button
        onClick={() => setAberto(!aberto)}
        style={{
          width: '100%',
          padding: '10px 12px',
          borderRadius: 10,
          border: '1.5px solid #E8ECF0',
          fontSize: 13,
          outline: 'none',
          cursor: 'pointer',
          textAlign: 'left',
          background: '#fff',
        }}
      >
        🔍 Buscar animal...
      </button>

      {aberto && (
        <>
          <div
            onClick={() => setAberto(false)}
            style={{ position: 'fixed', inset: 0, zIndex: 999 }}
          />
          <div
            style={{
              position: 'absolute',
              top: '100%',
              left: 0,
              right: 0,
              background: '#fff',
              border: '1.5px solid #E8ECF0',
              borderRadius: 10,
              marginTop: 6,
              zIndex: 1000,
              boxShadow: '0 4px 12px rgba(0,0,0,.1)',
              maxHeight: 300,
              overflowY: 'auto',
            }}
          >
            <input
              autoFocus
              placeholder="Nome ou anilha..."
              value={busca}
              onChange={e => setBusca(e.target.value)}
              style={{
                width: '100%',
                padding: '8px 12px',
                border: 'none',
                borderBottom: '1px solid #F1F4F8',
                fontSize: 12,
                outline: 'none',
                boxSizing: 'border-box',
                position: 'sticky',
                top: 0,
                background: '#fff',
              }}
            />

            {loading ? (
              <div style={{ padding: 12, textAlign: 'center', fontSize: 12, color: '#57636C' }}>
                Carregando...
              </div>
            ) : filtrados.length === 0 ? (
              <div style={{ padding: 12, textAlign: 'center', fontSize: 12, color: '#57636C' }}>
                Nenhum animal encontrado
              </div>
            ) : (
              filtrados.map(a => (
                <div
                  key={a.id}
                  onClick={() => {
                    onSelect({ id: a.id, nome: a.nome });
                    setAberto(false);
                    setBusca('');
                  }}
                  style={{
                    padding: '10px 12px',
                    borderBottom: '1px solid #F8FAFC',
                    cursor: 'pointer',
                    transition: '.15s',
                  }}
                  onMouseOver={e => (e.target.style.background = '#F8FAFC')}
                  onMouseOut={e => (e.target.style.background = '#fff')}
                >
                  <div style={{ fontWeight: 700, fontSize: 12, color: '#101213' }}>
                    🐓 {a.nome}
                  </div>
                  <div style={{ fontSize: 10, color: '#57636C' }}>
                    Anilha: {a.anilha}
                  </div>
                </div>
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}