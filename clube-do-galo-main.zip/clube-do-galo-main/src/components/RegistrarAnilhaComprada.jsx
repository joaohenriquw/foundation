import { useState } from "react";
import { base44 } from "@/api/base44Client";

const CORES_ANILHA = [
  { valor: "vermelha", label: "🔴 Vermelha", hex: "#C62828" },
  { valor: "azul", label: "🔵 Azul", hex: "#1565C0" },
  { valor: "verde", label: "🟢 Verde", hex: "#2E7D32" },
  { valor: "amarela", label: "🟡 Amarela", hex: "#F0A500" },
  { valor: "branca", label: "⚪ Branca", hex: "#F5F5F5" },
  { valor: "preta", label: "⚫ Preta", hex: "#212121" },
];

export default function RegistrarAnilhaComprada({ user, onClose, onConcluido }) {
  const [corSelecionada, setCorSelecionada] = useState("");
  const [anilhas, setAnilhas] = useState(Array(10).fill(null).map(() => ({ dataTroca: "" })));
  const [saving, setSaving] = useState(false);

  const deletarAnilha = (idx) => {
    setAnilhas(prev => prev.filter((_, i) => i !== idx));
  };

  const adicionarAnilha = () => {
    setAnilhas(prev => [...prev, { dataTroca: "" }]);
  };

  const atualizarData = (idx, valor) => {
    setAnilhas(prev => {
      const nova = [...prev];
      nova[idx] = { ...nova[idx], dataTroca: valor };
      return nova;
    });
  };

  const salvar = async () => {
    if (!corSelecionada) {
      alert("Escolha uma cor para as anilhas");
      return;
    }

    const preenchidas = anilhas.filter(a => a.dataTroca);
    if (preenchidas.length === 0) {
      alert("Preencha pelo menos uma data");
      return;
    }

    setSaving(true);
    try {
      for (const anilha of preenchidas) {
        await base44.entities.AnilhaFilha.create({
          usuario_id: user?.id || user?.email,
          usuario_email: user?.email,
          anilha_numero: `COMPRADA-${Date.now()}-${Math.random()}`,
          cor_anilha_definitiva: corSelecionada,
          data_criacao: new Date().toISOString().split("T")[0],
          data_troca_definitiva: anilha.dataTroca,
          status: "incubando",
          animal_pai_id: null,
          animal_pai_nome: "Origem Externa",
          animal_mae_id: null,
          animal_mae_nome: "Origem Externa",
        });
      }

      await base44.entities.Notificacao.create({
        destinatario_email: user?.email,
        titulo: "📅 Lembretes de Troca de Anilhas",
        mensagem: `Você registrou ${preenchidas.length} anilha(s) ${corSelecionada}. Você será notificado nas datas agendadas.`,
        tipo: "anilha",
        lida: false,
        icone: "🐣",
      });

      onConcluido?.();
      onClose();
    } catch (e) {
      console.error(e);
      alert("Erro ao salvar");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }} onClick={onClose}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, maxHeight: "90vh", overflowY: "auto", padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#170073" }}>🐣 Anilhas Compradas</div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        {/* Seleção de Cor */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 10, letterSpacing: 0.5 }}>🎨 Cor de todas as anilhas *</label>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 8 }}>
            {CORES_ANILHA.map(c => (
              <button
                key={c.valor}
                onClick={() => setCorSelecionada(c.valor)}
                style={{
                  padding: "10px 12px",
                  borderRadius: 10,
                  border: `2.5px solid ${corSelecionada === c.valor ? c.hex : "#E8ECF0"}`,
                  background: corSelecionada === c.valor ? c.hex : "#fff",
                  color: corSelecionada === c.valor ? (c.valor === "branca" ? "#101213" : "#fff") : "#57636C",
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 12,
                  transition: ".2s",
                  boxShadow: corSelecionada === c.valor ? `0 4px 12px ${c.hex}40` : "none",
                }}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Lista de Datas */}
        <div style={{ display: "grid", gap: 12, marginBottom: 20 }}>
          {anilhas.map((anilha, idx) => (
            <div key={idx} style={{ background: "#F8FAFC", borderRadius: 12, padding: "12px 14px", display: "grid", gridTemplateColumns: "1fr 40px", gap: 10, alignItems: "center" }}>
              {/* Data */}
              <div>
                <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", display: "block", marginBottom: 4 }}>📅 Anilha {idx + 1}</label>
                <input
                  type="date"
                  value={anilha.dataTroca}
                  onChange={e => atualizarData(idx, e.target.value)}
                  style={{
                    width: "100%",
                    padding: "8px 10px",
                    borderRadius: 8,
                    border: "1px solid #E8ECF0",
                    fontSize: 12,
                    outline: "none",
                  }}
                />
              </div>

              {/* Delete */}
              <button
                onClick={() => deletarAnilha(idx)}
                style={{
                  background: "none",
                  border: "none",
                  color: "#E21C3D",
                  cursor: "pointer",
                  fontSize: 16,
                  padding: 0,
                  width: 24,
                  height: 24,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 20,
                }}
              >
                🗑️
              </button>
            </div>
          ))}
        </div>

        <button
          onClick={adicionarAnilha}
          style={{
            width: "100%",
            padding: "10px 14px",
            borderRadius: 10,
            border: "1.5px dashed #170073",
            background: "#F0F4FF",
            color: "#170073",
            cursor: "pointer",
            fontWeight: 700,
            fontSize: 12,
            marginBottom: 16,
          }}
        >
          + Adicionar mais anilhas
        </button>

        <button
          onClick={salvar}
          disabled={!corSelecionada || anilhas.filter(a => a.dataTroca).length === 0 || saving}
          style={{
            width: "100%",
            padding: "14px",
            borderRadius: 12,
            border: "none",
            background: !corSelecionada || anilhas.filter(a => a.dataTroca).length === 0 || saving ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
            color: "#fff",
            cursor: "pointer",
            fontFamily: "Montserrat,sans-serif",
            fontSize: 14,
            fontWeight: 900,
          }}
        >
          {saving ? "Salvando..." : `✅ Registrar ${anilhas.filter(a => a.dataTroca).length} anilha(s)`}
        </button>
      </div>
    </div>
  );
}