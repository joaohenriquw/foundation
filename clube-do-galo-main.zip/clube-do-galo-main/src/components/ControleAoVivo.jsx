import { useState } from 'react';
import { base44 } from '@/api/base44Client';

export default function ControleAoVivo({ leilao, user, isOwner }) {
  const [encerrando, setEncerrando] = useState(false);

  if (!isOwner || !leilao) return null;

  const handleEncerrar = async () => {
    if (!window.confirm('Encerrar este leilão agora?')) return;
    setEncerrando(true);
    await base44.entities.Leilao.update(leilao.id, {
      status: 'encerrado',
      ganhador_id: leilao.maior_lance_user_id || '',
      ganhador_nome: leilao.maior_lance_user_nome || '',
      ganhador_email: leilao.maior_lance_user_email || '',
    });
    setEncerrando(false);
  };

  return (
    <div style={{
      background: '#E8F5E9',
      borderRadius: 14,
      padding: '14px 16px',
      marginBottom: 16,
      border: '1.5px solid #00A893',
    }}>
      <div style={{
        fontSize: 12,
        fontWeight: 700,
        color: '#2E7D32',
        marginBottom: 10,
        display: 'flex',
        alignItems: 'center',
        gap: 6,
      }}>
        🎮 Controle do Leiloador

      </div>

      <button
        onClick={handleEncerrar}
        disabled={encerrando || leilao.status !== 'ativo'}
        style={{
          width: '100%',
          padding: '10px 12px',
          borderRadius: 10,
          border: 'none',
          background: encerrando ? '#ccc' : leilao.status !== 'ativo' ? '#E0E0E0' : 'linear-gradient(135deg, #FF6F00, #E65100)',
          color: '#fff',
          cursor: encerrando || leilao.status !== 'ativo' ? 'default' : 'pointer',
          fontFamily: 'Montserrat, sans-serif',
          fontWeight: 700,
          fontSize: 12,
          transition: '.2s',
        }}
      >
        {encerrando ? '⏳ Encerrando...' : '🏁 Encerrar Leilão'}
      </button>

      {leilao.status !== 'ativo' && (
        <div style={{
          fontSize: 10,
          color: '#D32F2F',
          marginTop: 8,
          textAlign: 'center',
        }}>
          Leilão já foi encerrado
        </div>
      )}
    </div>
  );
}