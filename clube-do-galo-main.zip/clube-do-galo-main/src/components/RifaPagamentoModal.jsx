import { useState } from "react";
import { base44 } from "@/api/base44Client";
import OpcoesPagamento from "./OpcoesPagamento";

export default function RifaPagamentoModal({ rifa, qtdCompra, cpf, user, onClose, onSucesso }) {
  const [etapa, setEtapa] = useState("opcoes"); // "opcoes" | "pix" | "sucesso"
  const [qrCode, setQrCode] = useState(null);
  const [pixChave, setPixChave] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [txnId, setTxnId] = useState(null);

  const valor = qtdCompra * rifa.valor_por_numero;

  const processarCarteira = async (saldoCarteira) => {
    if (!user) return;
    setCarregando(true);
    try {
      // Debita carteira
      const novoSaldo = saldoCarteira >= valor ? saldoCarteira - valor : 0;
      const faltante = valor - saldoCarteira;

      if (faltante > 0) {
        // Precisa PIX para o faltante
        const res = await base44.functions.invoke("depositoPixNyxpay", {
          valor: faltante,
          cpf: cpf.replace(/\D/g, ""),
          nome: user.full_name,
        });
        if (!res.data?.qr_code) throw new Error("Erro ao gerar QR Code PIX");
        
        setQrCode(res.data.qr_code);
        setPixChave(res.data.pix_copia_cola);
        setTxnId(res.data.transaction_id);
        
        await base44.auth.updateMe({ saldo_carteira: 0 });
        setEtapa("pix");
      } else {
        // Carteira cobre tudo
        await base44.auth.updateMe({ saldo_carteira: novoSaldo });
        setEtapa("sucesso");
      }
    } catch (e) {
      alert("Erro: " + e.message);
    } finally {
      setCarregando(false);
    }
  };

  const processarPix = async () => {
    if (!user) return;
    setCarregando(true);
    try {
      const res = await base44.functions.invoke("depositoPixNyxpay", {
        valor,
        cpf: cpf.replace(/\D/g, ""),
        nome: user.full_name,
      });
      
      if (!res?.data?.qr_code && !res?.data?.pix_copia_cola) {
        console.error("Resposta da função:", res);
        throw new Error("QR Code não gerado. Tente novamente.");
      }
      
      setQrCode(res.data.qr_code);
      setPixChave(res.data.pix_copia_cola);
      setTxnId(res.data.transaction_id);
      setEtapa("pix");
    } catch (e) {
      console.error("Erro processarPix:", e);
      alert("Erro ao gerar PIX: " + e.message);
      setCarregando(false);
    }
  };

  const copiarChave = () => {
    navigator.clipboard.writeText(pixChave);
    alert("Chave PIX copiada!");
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px", maxHeight: "90vh", overflowY: "auto" }}>
        
        {/* Cabeçalho */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
            {etapa === "opcoes" ? "🎟️ Pagamento da Rifa" : etapa === "pix" ? "📱 QR Code PIX" : "✅ Pagamento Confirmado"}
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        {/* Resumo */}
        <div style={{ background: "#F0F4FF", borderRadius: 12, padding: "12px 14px", marginBottom: 16, textAlign: "center" }}>
          <div style={{ fontSize: 11, color: "#57636C", marginBottom: 4 }}>{qtdCompra} número{qtdCompra > 1 ? "s" : ""} da rifa</div>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#170073" }}>R$ {valor.toFixed(2)}</div>
        </div>

        {/* Etapa: Opções de Pagamento */}
        {etapa === "opcoes" && (
          <OpcoesPagamento
            valor={valor}
            onCarteira={() => processarCarteira(user?.saldo_carteira || 0)}
            onPix={processarPix}
            disabled={carregando}
          />
        )}

        {/* Etapa: PIX */}
        {etapa === "pix" && (
          <div style={{ textAlign: "center" }}>
            {carregando ? (
              <div style={{ padding: 20, textAlign: "center", color: "#57636C" }}>
                <div className="w-6 h-6 border-3 border-slate-200 border-t-slate-800 rounded-full animate-spin inline-block" style={{ marginBottom: 10 }}></div>
                <div>Gerando QR Code...</div>
              </div>
            ) : qrCode ? (
              <>
                <div style={{ marginBottom: 16 }}>
                  <img src={qrCode} alt="QR Code PIX" style={{ width: "100%", maxWidth: 260, borderRadius: 12 }} />
                </div>
                <div style={{ background: "#FFF8E1", borderRadius: 10, padding: "10px 12px", marginBottom: 12, fontSize: 11, color: "#856404" }}>
                  📱 Escaneie o código ou copie a chave abaixo
                </div>
                <div style={{ background: "#F8FAFC", borderRadius: 10, padding: "12px", marginBottom: 12, border: "1px solid #E8ECF0", wordBreak: "break-all", fontSize: 12, fontFamily: "monospace", color: "#57636C" }}>
                  {pixChave}
                </div>
                <button onClick={copiarChave} style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: "#00A893", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, marginBottom: 12 }}>
                  📋 Copiar Chave PIX
                </button>
                <div style={{ fontSize: 10, color: "#57636C", lineHeight: 1.5 }}>
                  ⏳ Após confirmar o pagamento, seus números serão liberados automaticamente.
                </div>
              </>
            ) : (
              <div style={{ padding: 20, textAlign: "center", color: "#C62828" }}>
                ❌ Erro ao gerar QR Code. Tente novamente.
              </div>
            )}
          </div>
        )}

        {/* Etapa: Sucesso */}
        {etapa === "sucesso" && (
          <div style={{ textAlign: "center", padding: "20px 0" }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>✅</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 8 }}>Pagamento Confirmado!</div>
            <div style={{ fontSize: 12, color: "#57636C", marginBottom: 20, lineHeight: 1.5 }}>
              Seus números foram gerados e confirmados na rifa.
            </div>
            <button onClick={() => {
              onSucesso?.();
              onClose();
            }}
              style={{ width: "100%", padding: "13px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
              ✓ Fechar e Ver Números
            </button>
          </div>
        )}
      </div>
    </div>
  );
}