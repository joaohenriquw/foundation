export default function CardRanking({ posicao, usuario }) {
  const medalhas = {
    1: '🥇',
    2: '🥈',
    3: '🥉'
  };

  return (
    <div style={{
      background: '#fff',
      borderRadius: 12,
      padding: '14px',
      marginBottom: 10,
      border: '1px solid #E8ECF0',
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }}>
      <div style={{
        width: 40,
        height: 40,
        borderRadius: '50%',
        background: posicao <= 3 ? 'linear-gradient(135deg,#F0A500,#E21C3D)' : '#F1F4F8',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 18,
        fontWeight: 900,
        color: '#fff',
        flexShrink: 0
      }}>
        {medalhas[posicao] || posicao}
      </div>

      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 13, fontWeight: 800, color: '#101213' }}>
          {usuario.usuario || usuario.nome}
        </div>
        <div style={{ fontSize: 10, color: '#57636C' }}>
          {usuario.leiloes_criados ? `${usuario.leiloes_criados} leilões` : `${usuario.lances_totais} lances`}
          {usuario.nota_media && ` • ⭐ ${usuario.nota_media}`}
        </div>
      </div>

      <div style={{ textAlign: 'right' }}>
        <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 14, fontWeight: 900, color: '#170073' }}>
          R$ {Number(usuario.receita_total || usuario.gasto_total).toFixed(2)}
        </div>
        <div style={{ fontSize: 9, color: '#BDBDBD' }}>
          Score: {usuario.score.toFixed(0)}
        </div>
      </div>
    </div>
  );
}