import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import PlanoGuardModal from './PlanoGuardModal';

export default function ValidacaoPlanoWrapper({ 
  tipo, 
  children, 
  onValidacaoFalha,
  autoValidar = false 
}) {
  const [mostraModal, setMostraModal] = useState(false);
  const [validacao, setValidacao] = useState(null);
  const [temAcesso, setTemAcesso] = useState(null);
  const [carregando, setCarregando] = useState(autoValidar);

  useEffect(() => {
    if (autoValidar) {
      validarAcesso();
    }
  }, [tipo]);

  const validarAcesso = async () => {
    setCarregando(true);
    try {
      const funcao = `validarAcesso${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`;
      const res = await base44.functions.invoke(funcao, {});

      setValidacao(res.data);
      setTemAcesso(res.data.tem_acesso);

      if (!res.data.tem_acesso) {
        setMostraModal(true);
        onValidacaoFalha?.(res.data);
      }
    } catch (error) {
      console.error('Erro na validação:', error);
      setTemAcesso(false);
    } finally {
      setCarregando(false);
    }
  };

  if (carregando && autoValidar) {
    return <div style={{ textAlign: 'center', padding: 20 }}>Validando acesso...</div>;
  }

  if (!autoValidar) {
    // Wrapper que permite validar sob demanda
    return (
      <>
        {children({ validar: validarAcesso, temAcesso, validacao })}
        {mostraModal && validacao && (
          <PlanoGuardModal
            tipo={tipo}
            validacao={validacao}
            onFechar={() => setMostraModal(false)}
          />
        )}
      </>
    );
  }

  if (temAcesso === false) {
    return (
      <>
        <PlanoGuardModal
          tipo={tipo}
          validacao={validacao}
          onFechar={() => setMostraModal(false)}
        />
        {mostraModal && null}
      </>
    );
  }

  return children({ validar: validarAcesso, temAcesso, validacao });
}