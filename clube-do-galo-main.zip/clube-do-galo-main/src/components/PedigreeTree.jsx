import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function PedigreeTree({ animal, onClose }) {
  const [pedigree, setPedigree] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const montar = async () => {
      const arvore = await construirArvore(animal);
      setPedigree(arvore);
      setLoading(false);
    };
    montar();
  }, [animal]);

  const construirArvore = async (a) => {
    let pai = null, mae = null;

    if (a.pai_id) {
      try {
        const paiData = await base44.entities.Animal.filter({ id: a.pai_id });
        pai = paiData[0] || null;
      } catch {}
    }

    if (a.mae_id) {
      try {
        const maeData = await base44.entities.Animal.filter({ id: a.mae_id });
        mae = maeData[0] || null;
      } catch {}
    }

    return {
      id: a.id,
      nome: a.nome,
      anilha: a.anilha,
      especie: a.especie,
      sexo: a.sexo,
      pai: pai ? await construirArvore(pai) : null,
      mae: mae ? await construirArvore(mae) : null,
    };
  };

  if (loading) {
    return (
      <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ background: "#fff", borderRadius: 16, padding: 24 }}>
          <div style={{ fontSize: 12, color: "#57636C" }}>⏳ Carregando pedigree...</div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 800, maxHeight: "90vh", overflowY: "auto", padding: "20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
            🌳 Árvore Genealógica - {pedigree?.nome}
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        <div style={{ overflowX: "auto", background: "#F8FAFC", borderRadius: 14, padding: 20 }}>
          <Nodo node={pedigree} />
        </div>
      </div>
    </div>
  );
}

function Nodo({ node, nivel = 0 }) {
  if (!node) return null;

  const temPai = node.pai !== null;
  const temMae = node.mae !== null;

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20, marginBottom: 20 }}>
      {/* Próprio animal */}
      <CartaoAnimal animal={node} destaque={nivel === 0} />

      {/* Linhas e pais/mães */}
      {(temPai || temMae) && (
        <div style={{ position: "relative", width: "100%", minHeight: 40 }}>
          {/* Linha vertical descendente */}
          <div style={{ position: "absolute", top: -20, left: "50%", transform: "translateX(-50%)", width: 2, height: 20, background: "#170073" }} />

          {/* Linha horizontal conectando */}
          {(temPai || temMae) && (
            <div style={{ position: "absolute", top: 0, left: temPai ? "25%" : "50%", right: temMae && !temPai ? "25%" : "auto", height: 2, background: "#170073" }} />
          )}

          {/* Linhas verticais para cada genitor */}
          {temPai && (
            <div style={{ position: "absolute", top: 0, left: "25%", width: 2, height: 20, background: "#170073", transform: "translateX(-50%)" }} />
          )}
          {temMae && (
            <div style={{ position: "absolute", top: 0, right: "25%", width: 2, height: 20, background: "#170073", transform: "translateX(50%)" }} />
          )}
        </div>
      )}

      {/* Grid de pais/mães */}
      {(temPai || temMae) && (
        <div style={{ display: "grid", gridTemplateColumns: temPai && temMae ? "1fr 1fr" : "1fr", gap: 40, width: "100%" }}>
          {temPai && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
              <CartaoAnimal animal={node.pai} sexo="♂️" />
              {(node.pai?.pai || node.pai?.mae) && (
                <div style={{ marginTop: 20, width: "100%", paddingLeft: 20 }}>
                  <Nodo node={node.pai} nivel={nivel + 1} />
                </div>
              )}
            </div>
          )}

          {temMae && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
              <CartaoAnimal animal={node.mae} sexo="♀️" />
              {(node.mae?.pai || node.mae?.mae) && (
                <div style={{ marginTop: 20, width: "100%", paddingRight: 20 }}>
                  <Nodo node={node.mae} nivel={nivel + 1} />
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {!temPai && !temMae && (
        <div style={{ fontSize: 12, color: "#BDBDBD", fontStyle: "italic", marginTop: 10 }}>
          Sem registros de pais
        </div>
      )}
    </div>
  );
}

function CartaoAnimal({ animal, destaque = false, sexo = null }) {
  const sexoLabel = sexo || (animal.sexo === "macho" ? "♂️" : animal.sexo === "femea" ? "♀️" : "🐓");

  return (
    <div style={{
      background: destaque ? "linear-gradient(135deg,#170073,#00A893)" : "#fff",
      borderRadius: 12,
      padding: destaque ? 16 : 12,
      minWidth: destaque ? 200 : 160,
      border: destaque ? "none" : "1.5px solid #E8ECF0",
      textAlign: "center",
      boxShadow: destaque ? "0 8px 24px rgba(23,0,115,.2)" : "none",
    }}>
      <div style={{ fontSize: destaque ? 24 : 20, marginBottom: 6 }}>
        {sexoLabel}
      </div>
      <div style={{
        fontFamily: "Montserrat,sans-serif",
        fontSize: destaque ? 14 : 12,
        fontWeight: 900,
        color: destaque ? "#fff" : "#101213",
        marginBottom: 4,
      }}>
        {animal.nome}
      </div>
      {animal.anilha && (
        <div style={{ fontSize: 10, color: destaque ? "rgba(255,255,255,.85)" : "#57636C", marginBottom: 2 }}>
          🏷️ {animal.anilha}
        </div>
      )}
      {animal.especie && (
        <div style={{ fontSize: 9, color: destaque ? "rgba(255,255,255,.7)" : "#BDBDBD" }}>
          {animal.especie}
        </div>
      )}
    </div>
  );
}