import { useState, useRef, useEffect } from "react";
import { RotateCw } from "lucide-react";

export default function PullToRefresh({ children, onRefresh = () => {} }) {
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [startY, setStartY] = useState(0);
  const scrollRef = useRef(null);
  const refreshThreshold = 80;

  const handleTouchStart = (e) => {
    if (scrollRef.current?.scrollTop === 0) {
      setStartY(e.touches[0].clientY);
    }
  };

  const handleTouchMove = (e) => {
    if (scrollRef.current?.scrollTop === 0 && startY > 0) {
      const distance = e.touches[0].clientY - startY;
      if (distance > 0) {
        setPullDistance(Math.min(distance, refreshThreshold * 1.5));
      }
    }
  };

  const handleTouchEnd = async () => {
    if (pullDistance >= refreshThreshold && !isRefreshing) {
      setIsRefreshing(true);
      try {
        await onRefresh();
      } finally {
        setIsRefreshing(false);
      }
    }
    setPullDistance(0);
    setStartY(0);
  };

  return (
    <div
      ref={scrollRef}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      style={{
        width: "100%",
        height: "100%",
        overflowY: "auto",
        overflowX: "hidden",
        WebkitOverflowScrolling: "touch",
        position: "relative",
      }}
    >
      {/* Pull indicator */}
      {pullDistance > 0 && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            height: Math.min(pullDistance, 60),
            background: "linear-gradient(180deg, rgba(23,0,115,0.05) 0%, transparent 100%)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 10,
            pointerEvents: "none",
          }}
        >
          <RotateCw
            size={20}
            style={{
              color: "#170073",
              opacity: Math.min(pullDistance / refreshThreshold, 1),
              transform: `rotate(${(pullDistance / refreshThreshold) * 360}deg)`,
              transition: isRefreshing ? "none" : "opacity 0.2s",
            }}
          />
        </div>
      )}

      {/* Loading spinner */}
      {isRefreshing && (
        <div
          style={{
            position: "fixed",
            top: 20,
            left: "50%",
            transform: "translateX(-50%)",
            zIndex: 20,
          }}
        >
          <RotateCw size={20} style={{ color: "#170073", animation: "spin 1s linear infinite" }} />
        </div>
      )}

      {/* Add CSS animation */}
      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>

      {/* Content */}
      <div style={{ paddingTop: isRefreshing ? 40 : 0, transition: "padding 0.2s" }}>
        {children}
      </div>
    </div>
  );
}