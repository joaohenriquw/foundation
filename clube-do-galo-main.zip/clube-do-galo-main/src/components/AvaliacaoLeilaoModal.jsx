import { useState } from "react";
import { base44 } from "@/api/base44Client";

export default function AvaliacaoLeilaoModal({ leilao, user, onClose, onConcluido }) {
  const [nota, setNota] = useState(5);
  const [comentario, setComentario] = useState("");
  const [processando, setProcessando] = useState(false);

  const salvar = async () => {
    if (!nota) {
      alert("Selecione uma nota!");
      return;
    }

    setProcessando(true);

    await base44.entities.Avaliacao.create({
      tipo: "leilao",
      referencia_id: leilao.id,
      comprador_email: user.email,
      comprador_id: user.id,
      comprador_nome: user.full_name,
      vendedor_email: leilao.dono_email,
      vendedor_id: leilao.dono_id,
      nota: Number(nota),
      comentario,
      animal_nome: leilao.animal_nome,
    });

    // Notificar vendedor
    await base44.entities.Notificacao.create({
      destinatario_email: leilao.dono_email,
      titulo: "⭐ Nova avaliação recebida",
      mensagem: `${user.full_name} avaliou seu leilão com ${nota}⭐`,
      tipo: "leilao",
      icone: "⭐",
    });

    setProcessando(false);
    onClose();
    if (onConcluido) onConcluido();
    alert("✅ Avaliação enviada com sucesso!");
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={onClose}>
      <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>⭐ Avaliar Leilão</div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
        </div>

        <div style={{ display: "grid", gap: 14 }}>
          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 10 }}>Sua Avaliação</label>
            <div style={{ display: "flex", gap: 8, fontSize: 28 }}>
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  onClick={() => setNota(n)}
                  style={{
                    background: "none",
                    border: "none",
                    fontSize: 28,
                    cursor: "pointer",
                    opacity: n <= nota ? 1 : 0.3,
                    transition: ".2s",
                  }}
                >
                  ⭐
                </button>
              ))}
            </div>
            <div style={{ fontSize: 11, color: "#57636C", marginTop: 8 }}>
              {["Péssimo", "Ruim", "Regular", "Bom", "Excelente"][nota - 1]}
            </div>
          </div>

          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Comentário (opcional)</label>
            <textarea
              value={comentario}
              onChange={e => setComentario(e.target.value)}
              placeholder="Sua experiência neste leilão..."
              style={{
                width: "100%",
                padding: "10px 12px",
                borderRadius: 10,
                border: "1.5px solid #E8ECF0",
                fontSize: 13,
                outline: "none",
                boxSizing: "border-box",
                height: 80,
                resize: "none",
              }}
            />
          </div>

          <button
            onClick={salvar}
            disabled={processando}
            style={{
              width: "100%",
              padding: "12px",
              borderRadius: 10,
              border: "none",
              background: processando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
              color: "#fff",
              cursor: processando ? "default" : "pointer",
              fontFamily: "Montserrat,sans-serif",
              fontWeight: 700,
            }}
          >
            {processando ? "Enviando..." : "⭐ Enviar Avaliação"}
          </button>
        </div>
      </div>
    </div>
  );
}