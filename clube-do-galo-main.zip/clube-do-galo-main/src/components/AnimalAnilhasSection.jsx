export default function AnimalAnilhasSection({ form, setForm }) {
  return (
    <div style={{ display: "grid", gap: 14, borderBottom: `1px solid hsl(var(--border))`, paddingBottom: 16, marginBottom: 16 }}>
      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "hsl(var(--foreground))" }}>
        🏷️ Ciclo de Anilhas
      </div>

      {/* Info */}
      <div style={{ background: "hsl(var(--muted))", padding: 12, borderRadius: 10, fontSize: 12, color: "hsl(var(--muted-foreground))", lineHeight: 1.5 }}>
        <strong>Fase 1 (0-30 dias):</strong> Anilha colorida no pé para identificação inicial.<br/>
        <strong>Fase 2 (Após 30 dias):</strong> Anilha numerada definitiva na asa — o identificador principal.
      </div>

      {/* Fase 1: Anilha de Pé */}
      <div>
        <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
          Fase 1: Cor da Anilha de Pé
        </label>
        <input type="text" value={form.anilha_pe_cor || ""} placeholder="Ex: Amarela, Vermelha, Azul"
          onChange={e => setForm(p => ({ ...p, anilha_pe_cor: e.target.value }))}
          style={{ width: "100%", padding: "12px 16px", borderRadius: 10, border: `1.5px solid hsl(var(--border))`, fontSize: 13, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
      </div>

      {/* Fase 2: Anilha de Asa */}
      <div>
        <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
          Fase 2: Numeração da Anilha de Asa (Identificador Principal)
        </label>
        <input type="text" value={form.anilha_asa_numero || ""} placeholder="Ex: BR-2024-001234"
          onChange={e => setForm(p => ({ ...p, anilha_asa_numero: e.target.value }))}
          style={{ width: "100%", padding: "12px 16px", borderRadius: 10, border: `1.5px solid hsl(var(--border))`, fontSize: 13, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
        <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginTop: 4 }}>Este será o identificador único do animal após 30 dias.</div>
      </div>
    </div>
  );
}