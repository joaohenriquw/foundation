import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';

export default function ChatConsultoria({ conversaId, user, onEncerrar }) {
  const [mensagens, setMensagens] = useState([]);
  const [novaMsg, setNovaMsg] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [conversa, setConversa] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const scrollRef = useRef(null);

  useEffect(() => {
    carregarConversa();
    const unsub = base44.entities.ChatMensagem.subscribe((ev) => {
      if (ev.data?.conversa_id === conversaId) {
        if (ev.type === 'create') {
          setMensagens(prev => [...prev, ev.data]);
        }
      }
    });
    return unsub;
  }, [conversaId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [mensagens]);

  const carregarConversa = async () => {
    try {
      const [convs, msgs] = await Promise.all([
        base44.entities.ChatConversa.filter({ id: conversaId }),
        base44.entities.ChatMensagem.filter({ conversa_id: conversaId }, '-created_date', 100)
      ]);

      if (convs.length > 0) {
        setConversa(convs[0]);
      }
      setMensagens(msgs);

      // Marcar como lidas
      await base44.functions.invoke('marcarMensagensComoLidas', { conversa_id: conversaId });
    } catch (e) {
      console.error('Erro ao carregar conversa:', e);
    } finally {
      setCarregando(false);
    }
  };

  const enviarMensagem = async () => {
    if (!novaMsg.trim()) return;

    setEnviando(true);
    try {
      await base44.functions.invoke('enviarMensagemChat', {
        conversa_id: conversaId,
        conteudo: novaMsg
      });
      setNovaMsg('');
    } catch (e) {
      console.error('Erro ao enviar:', e);
      alert('❌ Erro ao enviar mensagem. Verifique sua conexão.');
    } finally {
      setEnviando(false);
    }
  };

  const encerrarConversa = async () => {
    if (confirm('Encerrar esta consulta? Vocês não poderão mais trocar mensagens.')) {
      try {
        await base44.entities.ChatConversa.update(conversaId, { status: 'encerrada' });
        setConversa(prev => ({ ...prev, status: 'encerrada' }));
        if (onEncerrar) setTimeout(onEncerrar, 500);
      } catch (e) {
        console.error('Erro ao encerrar:', e);
      }
    }
  };

  if (carregando) {
    return <div style={{ textAlign: 'center', padding: 40, color: '#57636C' }}>Carregando conversa...</div>;
  }

  if (!conversa) {
    return <div style={{ textAlign: 'center', padding: 40, color: '#57636C' }}>Conversa não encontrada</div>;
  }

  const ehProfissional = user?.email === conversa.profissional_email;
  const outraParte = ehProfissional ? conversa.usuario_nome : conversa.profissional_nome;

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      width: '100%',
      background: '#0A0A0A',
      borderRadius: 0,
      overflow: 'hidden',
      border: 'none'
    }}>
      {/* Header */}
      <div style={{
        padding: '16px 20px',
        borderBottom: '1px solid #1C1C1E',
        background: '#0A0A0A',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <div>
          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 15, fontWeight: 900, color: '#00C9B8' }}>
            💬 {outraParte}
          </div>
          <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>
            {conversa.tipo.replace('_', ' ')} • {conversa.status === 'ativa' ? '🟢 Ativa' : '⚪ Encerrada'}
          </div>
        </div>
        {conversa.status === 'ativa' && (
          <button onClick={encerrarConversa} style={{ background: 'rgba(255,0,0,.2)', border: '1px solid rgba(255,0,0,.3)', color: '#FF6B6B', borderRadius: 8, padding: '6px 12px', fontSize: 11, fontWeight: 700, cursor: 'pointer', fontFamily: 'Montserrat,sans-serif' }}>
            ✖️ Encerrar
          </button>
        )}
      </div>

      {/* Mensagens */}
      <div ref={scrollRef} style={{
        flex: 1,
        overflowY: 'auto',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        background: '#000'
      }}>
        {mensagens.length === 0 ? (
          <div style={{ textAlign: 'center', color: '#888', marginTop: 'auto', marginBottom: 'auto' }}>
            <div style={{ fontSize: 14, marginBottom: 8 }}>💬</div>
            <div style={{ fontSize: 13, fontWeight: 700 }}>Nenhuma mensagem ainda</div>
            <div style={{ fontSize: 12, color: '#666', marginTop: 4 }}>Comece a conversa!</div>
          </div>
        ) : (
          mensagens.map(msg => (
            <div
              key={msg.id}
              style={{
                display: 'flex',
                justifyContent: msg.remetente_email === user?.email ? 'flex-end' : 'flex-start',
                marginBottom: 8
              }}
            >
              <div style={{
                maxWidth: '70%',
                padding: '12px 16px',
                borderRadius: 16,
                background: msg.remetente_email === user?.email ? 'linear-gradient(135deg, #170073, #00A893)' : '#1C1C1E',
                color: msg.remetente_email === user?.email ? '#fff' : '#E0E0E0',
                fontSize: 13,
                lineHeight: 1.5,
                wordWrap: 'break-word',
                boxShadow: '0 2px 8px rgba(0,0,0,.3)'
              }}>
                {msg.conteudo}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Input */}
      <div style={{
        padding: '16px 20px',
        borderTop: '1px solid #1C1C1E',
        background: '#0A0A0A'
      }}>
        {conversa.status === 'ativa' ? (
          <div style={{ display: 'flex', gap: 10 }}>
            <input
              type="text"
              value={novaMsg}
              onChange={e => setNovaMsg(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && !e.shiftKey && enviarMensagem()}
              placeholder="Escreva sua mensagem..."
              style={{
                flex: 1,
                padding: '12px 16px',
                border: '1.5px solid #2C2C2E',
                borderRadius: 24,
                fontSize: 13,
                outline: 'none',
                fontFamily: 'DM Sans, sans-serif',
                background: '#1C1C1E',
                color: '#fff',
                transition: '.2s'
              }}
              onFocus={e => e.target.style.borderColor = '#00C9B8'}
              onBlur={e => e.target.style.borderColor = '#2C2C2E'}
            />
            <button
              onClick={enviarMensagem}
              disabled={enviando || !novaMsg.trim()}
              style={{
                padding: '0 16px',
                borderRadius: 24,
                border: 'none',
                background: enviando || !novaMsg.trim() ? '#333' : 'linear-gradient(135deg, #170073, #00A893)',
                color: '#fff',
                cursor: enviando || !novaMsg.trim() ? 'default' : 'pointer',
                fontSize: 16,
                fontWeight: 700,
                fontFamily: 'Montserrat, sans-serif',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                minWidth: 48,
                height: 48,
                flexShrink: 0
              }}
            >
              {enviando ? '⏳' : '➤'}
            </button>
          </div>
        ) : (
          <div style={{
            textAlign: 'center',
            color: '#888',
            fontSize: 11,
            fontWeight: 700,
            padding: '8px 0'
          }}>
            ✅ Esta consulta foi encerrada
          </div>
        )}
      </div>


    </div>
  );
}