import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PLANO_NIVEL, PLANO_LABEL, PLANO_COR, getPlanoBundles } from "../lib/planos";

export default function PlanoGuard({ planoUsuario, planoMinimo, children, mensagem, userRole }) {
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();

  const planoEfetivo = getPlanoBundles(userRole, planoUsuario);
  const nivelUsuario = PLANO_NIVEL[planoEfetivo] || 1;
  const nivelMinimo  = PLANO_NIVEL[planoMinimo]  || 4;
  const temAcesso    = nivelUsuario >= nivelMinimo;

  if (temAcesso) return children;

  return (
    <>
      <div onClick={() => setShowModal(true)} style={{ cursor: "pointer" }}>
        {children}
      </div>
      {showModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 3000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#fff", borderRadius: 20, padding: 28, maxWidth: 340, width: "100%", textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🔒</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 8 }}>
              Recurso exclusivo
            </div>
            <div style={{ fontSize: 13, color: "#57636C", marginBottom: 16, lineHeight: 1.5 }}>
              {mensagem || "Esta função requer o plano "}
              <strong style={{ color: PLANO_COR[planoMinimo] }}>{PLANO_LABEL[planoMinimo]}</strong>.
              <br />Seu plano atual: <strong>{PLANO_LABEL[planoUsuario] || "Iniciante"}</strong>
            </div>
            <div
              style={{ background: "linear-gradient(135deg,#170073,#00A893)", borderRadius: 12, padding: "12px 20px", color: "#fff", fontFamily: "Montserrat,sans-serif", fontWeight: 800, fontSize: 14, cursor: "pointer", marginBottom: 10 }}
              onClick={() => navigate("/planos")}
            >
              🚀 Fazer Upgrade de Plano
            </div>
            <button onClick={() => setShowModal(false)} style={{ background: "none", border: "none", color: "#57636C", fontSize: 12, cursor: "pointer" }}>
              Fechar
            </button>
          </div>
        </div>
      )}
    </>
  );
}

export { PLANO_NIVEL, PLANO_LABEL, PLANO_COR };