import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';

export default function ChatDM({ conversaId, user, outroUsuario }) {
  const [mensagens, setMensagens] = useState([]);
  const [novaMsg, setNovaMsg] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [carregando, setCarregando] = useState(true);
  const scrollRef = useRef(null);

  useEffect(() => {
    carregarMensagens();
    const unsub = base44.entities.MensagemDM.subscribe((ev) => {
      if (ev.data?.conversa_id === conversaId) {
        if (ev.type === 'create') {
          setMensagens(prev => [...prev, ev.data]);
        }
      }
    });
    return unsub;
  }, [conversaId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [mensagens]);

  const carregarMensagens = async () => {
    try {
      const res = await base44.functions.invoke('buscarMensagensDM', { conversa_id: conversaId });
      setMensagens(res.data.mensagens || []);
    } catch (e) {
      console.error('Erro ao carregar mensagens:', e);
    } finally {
      setCarregando(false);
    }
  };

  const enviarMensagem = async () => {
    if (!novaMsg.trim()) return;

    setEnviando(true);
    try {
      await base44.functions.invoke('enviarMensagemDM', {
        destinatario_email: outroUsuario.email,
        conteudo: novaMsg
      });
      setNovaMsg('');
    } catch (e) {
      console.error('Erro ao enviar:', e);
    } finally {
      setEnviando(false);
    }
  };

  if (carregando) {
    return <div style={{ textAlign: 'center', padding: 40 }}>⏳ Carregando...</div>;
  }

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      background: '#fff',
      borderRadius: 14,
      overflow: 'hidden'
    }}>
      {/* Header */}
      <div style={{
        padding: '14px 16px',
        borderBottom: '1px solid #E8ECF0',
        background: '#F8FAFC'
      }}>
        <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 13, fontWeight: 900, color: '#170073' }}>
          💬 {outroUsuario.nome}
        </div>
      </div>

      {/* Mensagens */}
      <div ref={scrollRef} style={{
        flex: 1,
        overflowY: 'auto',
        padding: '16px',
        display: 'flex',
        flexDirection: 'column',
        gap: 10
      }}>
        {mensagens.length === 0 ? (
          <div style={{ textAlign: 'center', color: '#BDBDBD', marginTop: 20 }}>
            Comece a conversa!
          </div>
        ) : (
          mensagens.map(msg => (
            <div
              key={msg.id}
              style={{
                display: 'flex',
                justifyContent: msg.remetente_email === user?.email ? 'flex-end' : 'flex-start'
              }}
            >
              <div style={{
                maxWidth: '70%',
                padding: '10px 14px',
                borderRadius: 12,
                background: msg.remetente_email === user?.email ? '#170073' : '#F1F4F8',
                color: msg.remetente_email === user?.email ? '#fff' : '#101213',
                fontSize: 13,
                wordWrap: 'break-word'
              }}>
                {msg.conteudo}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Input */}
      <div style={{
        padding: '12px 16px',
        borderTop: '1px solid #E8ECF0',
        display: 'flex',
        gap: 10
      }}>
        <input
          type="text"
          value={novaMsg}
          onChange={e => setNovaMsg(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && !e.shiftKey && enviarMensagem()}
          placeholder="Digite uma mensagem..."
          style={{
            flex: 1,
            padding: '10px 12px',
            border: '1.5px solid #E8ECF0',
            borderRadius: 10,
            fontSize: 13,
            outline: 'none'
          }}
        />
        <button
          onClick={enviarMensagem}
          disabled={enviando || !novaMsg.trim()}
          style={{
            padding: '10px 16px',
            borderRadius: 10,
            border: 'none',
            background: enviando || !novaMsg.trim() ? '#E8ECF0' : '#170073',
            color: '#fff',
            cursor: enviando || !novaMsg.trim() ? 'default' : 'pointer',
            fontSize: 14,
            fontWeight: 700,
            fontFamily: 'Montserrat,sans-serif'
          }}
        >
          {enviando ? '⏳' : '➤'}
        </button>
      </div>
    </div>
  );
}