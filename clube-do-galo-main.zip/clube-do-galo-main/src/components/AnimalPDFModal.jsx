import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { jsPDF } from "jspdf";

const corGradiente = "linear-gradient(135deg,#170073,#00A893)";

export default function AnimalPDFModal({ animal, onClose }) {
  const [temporadas, setTemporadas] = useState([]);
  const [gerando, setGerando] = useState(false);

  useEffect(() => {
    base44.entities.TemporadaCombate.filter({ animal_id: animal.id }, "-temporada", 50)
      .then(setTemporadas);
  }, [animal.id]);

  const gerarPDF = async () => {
    setGerando(true);

    // Converter foto para base64 se existir
    let fotoBase64 = null;
    if (animal.foto_url) {
      try {
        const resp = await fetch(animal.foto_url);
        const blob = await resp.blob();
        fotoBase64 = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result);
          reader.readAsDataURL(blob);
        });
      } catch {}
    }

    const totalV = temporadas.reduce((s, t) => s + (t.vitorias || 0), 0);
    const totalE = temporadas.reduce((s, t) => s + (t.empates  || 0), 0);
    const totalD = temporadas.reduce((s, t) => s + (t.derrotas || 0), 0);

    const doc = new jsPDF({ unit: "mm", format: "a4" });
    const W = 210;
    let y = 0;

    // Header gradient background (simulated)
    doc.setFillColor(23, 0, 115);
    doc.rect(0, 0, W, 40, "F");

    // Foto do animal
    if (fotoBase64) {
      try {
        doc.addImage(fotoBase64, "JPEG", 155, 5, 40, 30);
      } catch {}
    }

    // Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.setTextColor(255, 255, 255);
    doc.text(animal.nome, 20, 18);

    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    doc.text(`Anilha: ${animal.anilha}`, 20, 26);
    doc.text("CLUBE DO GALO", 20, 34);

    y = 50;

    // Dados do animal
    doc.setFontSize(12);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(0, 168, 147);
    doc.text("DADOS DO ANIMAL", 20, y);
    y += 6;

    const campos = [
      ["Anilha", animal.anilha || "—"],
      ["Sexo", animal.sexo === "macho" ? "Macho" : animal.sexo === "femea" ? "Femea" : "—"],
      ["Cor / Plumagem", animal.cor_plumagem || "—"],
      ["Nascimento", animal.data_de_nascimento ? new Date(animal.data_de_nascimento + "T12:00").toLocaleDateString("pt-BR") : "—"],
      ["Peso", animal.peso_gramas ? animal.peso_gramas + "g" : "—"],
      ["Saude", animal.saude_status || "—"],
      ["Categoria", animal.tipo_categoria || "—"],
      ["Valor estimado", animal.valor_estimado ? "R$ " + Number(animal.valor_estimado).toFixed(2) : "—"],
      ["Pai", animal.pai_nome || "—"],
      ["Mae", animal.mae_nome || "—"],
    ];

    campos.forEach(([k, v], i) => {
      if (i % 2 === 0) {
        doc.setFillColor(248, 250, 252);
        doc.rect(15, y, W - 30, 8, "F");
      }
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.setTextColor(80, 80, 80);
      doc.text(k, 20, y + 5.5);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(16, 18, 19);
      doc.text(String(v), 100, y + 5.5);
      y += 8;
    });

    y += 8;

    // Resumo combates
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.setTextColor(0, 168, 147);
    doc.text("RESUMO DE APRESENTACOES", 20, y);
    y += 8;

    const resumo = [
      { label: "Apresentacoes", val: totalV, r: 34, g: 197, b: 94 },
      { label: "Empates",  val: totalE, r: 234, g: 179, b: 8 },
      { label: "Derrotas", val: totalD, r: 239, g: 68,  b: 68 },
    ];

    const bw = (W - 40 - 10) / 3;
    resumo.forEach((r, i) => {
      const bx = 15 + i * (bw + 5);
      doc.setFillColor(26, 26, 26);
      doc.rect(bx, y, bw, 22, "F");
      doc.setFillColor(r.r, r.g, r.b);
      doc.rect(bx, y, 3, 22, "F");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(18);
      doc.setTextColor(r.r, r.g, r.b);
      doc.text(String(r.val), bx + bw / 2, y + 13, { align: "center" });
      doc.setFontSize(9);
      doc.setTextColor(200, 200, 200);
      doc.text(r.label, bx + bw / 2, y + 19, { align: "center" });
    });
    y += 30;

    // Temporadas
    if (temporadas.length > 0) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.setTextColor(0, 168, 147);
      doc.text("TEMPORADAS", 20, y);
      y += 8;

      temporadas.forEach(t => {
        if (y > 260) { doc.addPage(); y = 20; }
        doc.setFillColor(26, 26, 26);
        doc.rect(15, y, W - 30, 8, "F");
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.setTextColor(255, 255, 255);
        doc.text(String(t.temporada), 20, y + 5.5);
        y += 8;

        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(34, 197, 94);
        doc.text(`Apresentacoes: ${t.vitorias || 0}`, 20, y + 5);
        doc.setTextColor(234, 179, 8);
        doc.text(`Empates: ${t.empates || 0}`, 80, y + 5);
        doc.setTextColor(239, 68, 68);
        doc.text(`Derrotas: ${t.derrotas || 0}`, 140, y + 5);
        y += 12;
      });
    }

    // Rodape
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(100, 100, 100);
    doc.text(`Gerado em ${new Date().toLocaleDateString("pt-BR")} as ${new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })} - Clube do Galo`, W / 2, 285, { align: "center" });

    doc.save(`${animal.nome.replace(/\s+/g, "_")}_ClubeDoGalo.pdf`);
    setGerando(false);
  };

  const totalV = temporadas.reduce((s, t) => s + (t.vitorias || 0), 0);
  const totalE = temporadas.reduce((s, t) => s + (t.empates  || 0), 0);
  const totalD = temporadas.reduce((s, t) => s + (t.derrotas || 0), 0);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.8)", zIndex: 3000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#0D0D0D", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 520, maxHeight: "90vh", overflowY: "auto", paddingBottom: 40 }}>

        {/* Header */}
        <div style={{ background: corGradiente, padding: "20px 20px 16px", display: "flex", alignItems: "center", gap: 14 }}>
          {animal.foto_url
            ? <div style={{ width: 54, height: 54, borderRadius: "50%", background: `url(${animal.foto_url}) center/cover`, border: "2px solid rgba(255,255,255,.4)", flexShrink: 0 }} />
            : <div style={{ width: 54, height: 54, borderRadius: "50%", background: "rgba(255,255,255,.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28 }}>🐓</div>
          }
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#fff" }}>{animal.nome}</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Anilha: {animal.anilha}</div>
          </div>
          <button onClick={onClose} style={{ background: "rgba(255,255,255,.2)", border: "none", borderRadius: "50%", width: 32, height: 32, color: "#fff", fontSize: 16, cursor: "pointer" }}>✕</button>
        </div>

        <div style={{ padding: "18px 18px" }}>
          {/* Resumo */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 18 }}>
            {[
              { label: "Apresentações", val: totalV, cor: "#22c55e" },
              { label: "Empates",  val: totalE, cor: "#eab308" },
              { label: "Derrotas", val: totalD, cor: "#ef4444" },
            ].map(r => (
              <div key={r.label} style={{ background: "#1A1A1A", borderRadius: 12, padding: "12px 10px", textAlign: "center", borderLeft: `3px solid ${r.cor}` }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 24, fontWeight: 900, color: r.cor }}>{r.val}</div>
                <div style={{ fontSize: 10, color: "#888", marginTop: 3 }}>{r.label}</div>
              </div>
            ))}
          </div>

          {/* Temporadas preview */}
          {temporadas.map(t => (
            <div key={t.id} style={{ background: "#1A1A1A", borderRadius: 12, marginBottom: 10, overflow: "hidden", border: "1px solid #222" }}>
              <div style={{ padding: "12px 16px", fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#fff", borderBottom: "1px solid #222" }}>{t.temporada}</div>
              <div style={{ padding: "8px 16px", display: "flex", gap: 16, fontSize: 12 }}>
                <span style={{ color: "#22c55e", fontWeight: 700 }}>✅ {t.vitorias || 0} Apresentações</span>
                <span style={{ color: "#eab308", fontWeight: 700 }}>🟡 {t.empates || 0} Empates</span>
                <span style={{ color: "#ef4444", fontWeight: 700 }}>❌ {t.derrotas || 0} Derrotas</span>
              </div>
            </div>
          ))}

          {temporadas.length === 0 && (
            <div style={{ textAlign: "center", padding: "20px 0", color: "#555", fontSize: 12 }}>
              Nenhuma temporada registrada ainda
            </div>
          )}

          <button onClick={gerarPDF} disabled={gerando}
            style={{ width: "100%", padding: "15px", borderRadius: 14, border: "none", background: gerando ? "#333" : corGradiente, color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, cursor: gerando ? "default" : "pointer", marginTop: 8, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            {gerando ? "⏳ Gerando PDF..." : "📄 Baixar PDF do Animal"}
          </button>
          <div style={{ textAlign: "center", fontSize: 10, color: "#555", marginTop: 8 }}>
            Abrirá em nova aba — use Compartilhar → Imprimir → Salvar como PDF
          </div>
        </div>
      </div>
    </div>
  );
}