import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function OpcoesPagamento({ valor, onCarteira, onPix, disabled }) {
  const [saldo, setSaldo] = useState(0);
  const [carregando, setCarregando] = useState(true);
  const [metodo, setMetodo] = useState(null); // "carteira" ou "pix"

  // Carregar saldo ao montar
  useEffect(() => {
    base44.auth.me().then(me => {
      setSaldo(me?.saldo_carteira || 0);
      setCarregando(false);
    }).catch(() => setCarregando(false));
  }, []);

  const temSaldo = saldo >= valor;

  const handleCarteira = async () => {
    await onCarteira?.(saldo);
    setMetodo(null);
  };

  const handlePix = async () => {
    await onPix?.();
    setMetodo(null);
  };

  if (carregando) {
    return (
      <div style={{ textAlign: "center", padding: 20, color: "#57636C" }}>
        <div className="w-6 h-6 border-3 border-slate-200 border-t-slate-800 rounded-full animate-spin inline-block"></div>
      </div>
    );
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {/* Opção 1: Carteira */}
      {temSaldo && (
        <button
          onClick={() => setMetodo("carteira")}
          disabled={disabled}
          style={{
            width: "100%",
            padding: "14px 16px",
            borderRadius: 12,
            border: metodo === "carteira" ? "2px solid #00A893" : "1.5px solid #E8ECF0",
            background: metodo === "carteira" ? "#E8F5E9" : "#fff",
            color: "#101213",
            cursor: disabled ? "default" : "pointer",
            fontFamily: "Montserrat,sans-serif",
            fontWeight: 700,
            fontSize: 13,
            display: "flex",
            alignItems: "center",
            gap: 12,
            transition: "all 0.15s",
          }}
        >
          <span style={{ fontSize: 20 }}>💰</span>
          <div style={{ flex: 1, textAlign: "left" }}>
            <div style={{ fontWeight: 800, color: "#101213" }}>Pagar com Carteira</div>
            <div style={{ fontSize: 11, color: "#57636C", marginTop: 2 }}>
              Saldo: R$ {saldo.toFixed(2)}
            </div>
          </div>
          {metodo === "carteira" && <span style={{ fontSize: 18 }}>✓</span>}
        </button>
      )}

      {/* Opção 2: PIX/Gateway */}
      <button
        onClick={() => setMetodo("pix")}
        disabled={disabled}
        style={{
          width: "100%",
          padding: "14px 16px",
          borderRadius: 12,
          border: metodo === "pix" ? "2px solid #170073" : "1.5px solid #E8ECF0",
          background: metodo === "pix" ? "#F0F4FF" : "#fff",
          color: "#101213",
          cursor: disabled ? "default" : "pointer",
          fontFamily: "Montserrat,sans-serif",
          fontWeight: 700,
          fontSize: 13,
          display: "flex",
          alignItems: "center",
          gap: 12,
          transition: "all 0.15s",
        }}
      >
        <span style={{ fontSize: 20 }}>📱</span>
        <div style={{ flex: 1, textAlign: "left" }}>
          <div style={{ fontWeight: 800, color: "#101213" }}>Pagar com PIX</div>
          <div style={{ fontSize: 11, color: "#57636C", marginTop: 2 }}>
            {temSaldo ? "Saldo insuficiente? Use PIX" : "Gerar QR Code"}
          </div>
        </div>
        {metodo === "pix" && <span style={{ fontSize: 18 }}>✓</span>}
      </button>

      {/* Botão confirmar (aparece após seleção) */}
      {metodo && (
        <button
          onClick={metodo === "carteira" ? handleCarteira : handlePix}
          disabled={disabled}
          style={{
            width: "100%",
            padding: "13px",
            borderRadius: 12,
            border: "none",
            background: disabled ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
            color: "#fff",
            cursor: disabled ? "default" : "pointer",
            fontFamily: "Montserrat,sans-serif",
            fontWeight: 900,
            fontSize: 14,
            transition: "all 0.15s",
          }}
        >
          {metodo === "carteira" ? "✓ Débitar da Carteira" : "📱 Gerar QR Code PIX"}
        </button>
      )}

      {/* Info complementar */}
      {temSaldo && (
        <div style={{ fontSize: 10, color: "#57636C", textAlign: "center", padding: "0 4px", lineHeight: 1.5 }}>
          💡 Você tem saldo suficiente. Escolha qualquer uma das opções acima.
        </div>
      )}
    </div>
  );
}