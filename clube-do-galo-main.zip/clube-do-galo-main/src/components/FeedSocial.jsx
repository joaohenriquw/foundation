import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import CardPost from './CardPost';

export default function FeedSocial({ user, tipo = 'seguindo' }) {
  const [posts, setPosts] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [conteudo, setConteudo] = useState('');
  const [postando, setPostando] = useState(false);

  useEffect(() => {
    carregarFeed();
  }, [tipo]);

  const carregarFeed = async () => {
    setCarregando(true);
    try {
      const res = await base44.functions.invoke('listarFeed', { tipo });
      setPosts(res.data.feed || []);
    } catch (e) {
      console.error('Erro ao carregar feed:', e);
    } finally {
      setCarregando(false);
    }
  };

  const criarPost = async () => {
    if (!conteudo.trim()) return;
    setPostando(true);
    try {
      const res = await base44.functions.invoke('criarPost', {
        conteudo,
        tipo: 'texto'
      });
      setConteudo('');
      carregarFeed();
    } catch (e) {
      console.error('Erro ao postar:', e);
    } finally {
      setPostando(false);
    }
  };

  return (
    <div>
      {/* Composer */}
      <div style={{
        background: '#fff',
        borderRadius: 14,
        padding: '16px',
        marginBottom: 16,
        border: '1px solid #E8ECF0'
      }}>
        <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
          <div style={{
            width: 40,
            height: 40,
            borderRadius: '50%',
            background: 'linear-gradient(135deg,#170073,#00A893)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#fff',
            fontSize: 16,
            fontWeight: 900,
            flexShrink: 0
          }}>
            {(user?.full_name?.[0] || 'U').toUpperCase()}
          </div>
          <textarea
            value={conteudo}
            onChange={e => setConteudo(e.target.value)}
            placeholder="O que está em sua mente?"
            style={{
              flex: 1,
              padding: '12px',
              borderRadius: 10,
              border: '1.5px solid #E8ECF0',
              fontSize: 13,
              outline: 'none',
              minHeight: 60,
              fontFamily: 'DM Sans, sans-serif',
              resize: 'none'
            }}
          />
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button onClick={() => setConteudo('')}
            style={{
              padding: '8px 14px',
              borderRadius: 10,
              border: '1.5px solid #E8ECF0',
              background: '#fff',
              cursor: 'pointer',
              fontSize: 12,
              fontWeight: 700,
              fontFamily: 'Montserrat,sans-serif'
            }}>
            Limpar
          </button>
          <button onClick={criarPost} disabled={postando || !conteudo.trim()}
            style={{
              padding: '8px 14px',
              borderRadius: 10,
              border: 'none',
              background: postando || !conteudo.trim() ? '#ccc' : 'linear-gradient(135deg,#170073,#00A893)',
              color: '#fff',
              cursor: postando ? 'default' : 'pointer',
              fontSize: 12,
              fontWeight: 700,
              fontFamily: 'Montserrat,sans-serif'
            }}>
            {postando ? '⏳ Postando' : '📤 Postar'}
          </button>
        </div>
      </div>

      {/* Feed */}
      {carregando ? (
        <div style={{ textAlign: 'center', padding: 40, color: '#57636C' }}>
          ⏳ Carregando feed...
        </div>
      ) : posts.length === 0 ? (
        <div style={{
          textAlign: 'center',
          padding: 40,
          background: '#F8FAFC',
          borderRadius: 14,
          color: '#57636C'
        }}>
          <div style={{ fontSize: 32, marginBottom: 10 }}>📭</div>
          <div style={{ fontWeight: 700 }}>Nenhum post ainda</div>
        </div>
      ) : (
        posts.map(post => (
          <CardPost
            key={post.id}
            post={post}
            user={user}
            onAtualizar={carregarFeed}
          />
        ))
      )}
    </div>
  );
}