import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

export default function PageTransition({ children }) {
  const location = useLocation();
  const [isEntering, setIsEntering] = useState(true);

  useEffect(() => {
    setIsEntering(false);
    const timer = setTimeout(() => setIsEntering(true), 50);
    return () => clearTimeout(timer);
  }, [location.pathname]);

  return (
    <div
      style={{
        animation: isEntering ? "slideUp 0.4s ease-out forwards" : "slideDown 0.4s ease-in forwards",
      }}
    >
      {children}
      <style>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes slideDown {
          from {
            opacity: 1;
            transform: translateY(0);
          }
          to {
            opacity: 0;
            transform: translateY(40px);
          }
        }
      `}</style>
    </div>
  );
}