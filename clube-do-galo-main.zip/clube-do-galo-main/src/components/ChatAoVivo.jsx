import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";

export default function ChatAoVivo({ leilaoId, user }) {
  const [mensagens, setMensagens] = useState([]);
  const [texto, setTexto] = useState("");
  const [enviando, setEnviando] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    if (!leilaoId) return;
    base44.entities.LeilaoComentario.filter({ leilao_id: leilaoId }, "created_date", 50)
      .then(setMensagens);

    const unsub = base44.entities.LeilaoComentario.subscribe((ev) => {
      if (ev.data?.leilao_id !== leilaoId) return;
      if (ev.type === "create") setMensagens(prev => [...prev, ev.data]);
      if (ev.type === "delete") setMensagens(prev => prev.filter(m => m.id !== ev.id));
    });
    return unsub;
  }, [leilaoId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [mensagens]);

  const enviar = async () => {
    if (!texto.trim() || !user) return;
    setEnviando(true);
    await base44.entities.LeilaoComentario.create({
      leilao_id: leilaoId,
      autor_id: user.id,
      autor_nome: user.full_name || user.email,
      autor_email: user.email,
      texto: texto.trim(),
    });
    setTexto("");
    setEnviando(false);
  };

  return (
    <div style={{ background: "#fff", borderRadius: 16, overflow: "hidden", marginBottom: 14, boxShadow: "0 1px 6px rgba(0,0,0,.06)" }}>
      {/* Header */}
      <div style={{ padding: "12px 16px", borderBottom: "1px solid #F1F4F8", display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 16 }}>💬</span>
        <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>Chat ao Vivo</span>
        <span style={{ marginLeft: "auto", fontSize: 11, color: "#2E7D32", fontWeight: 700, background: "#E8F5E9", borderRadius: 12, padding: "2px 10px" }}>
          ● ao vivo
        </span>
      </div>

      {/* Mensagens */}
      <div style={{ height: 220, overflowY: "auto", padding: "10px 14px", display: "flex", flexDirection: "column", gap: 8 }}>
        {mensagens.length === 0 && (
          <div style={{ textAlign: "center", color: "#BDBDBD", fontSize: 12, marginTop: 60 }}>
            Nenhuma mensagem ainda. Seja o primeiro! 👋
          </div>
        )}
        {mensagens.map((m) => {
          const minha = m.autor_email === user?.email;
          return (
            <div key={m.id} style={{ display: "flex", gap: 8, alignItems: "flex-start", flexDirection: minha ? "row-reverse" : "row" }}>
              <div style={{ width: 30, height: 30, borderRadius: "50%", background: minha ? "linear-gradient(135deg,#00A893,#170073)" : "linear-gradient(135deg,#F0A500,#E21C3D)", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 900, color: "#fff", fontFamily: "Montserrat,sans-serif" }}>
                {(m.autor_nome || "?")[0].toUpperCase()}
              </div>
              <div style={{ maxWidth: "75%" }}>
                <div style={{ fontSize: 10, color: "#BDBDBD", marginBottom: 3, textAlign: minha ? "right" : "left" }}>
                  {minha ? "Você" : m.autor_nome}
                </div>
                <div style={{ background: minha ? "#170073" : "#F1F4F8", color: minha ? "#fff" : "#101213", borderRadius: minha ? "12px 4px 12px 12px" : "4px 12px 12px 12px", padding: "8px 12px", fontSize: 13, fontWeight: 500, lineHeight: 1.4, wordBreak: "break-word" }}>
                  {m.texto || m.conteudo}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ padding: "10px 12px", borderTop: "1px solid #F1F4F8", display: "flex", gap: 8 }}>
        {user ? (
          <>
            <input
              value={texto}
              onChange={e => setTexto(e.target.value)}
              onKeyDown={e => e.key === "Enter" && !e.shiftKey && enviar()}
              placeholder="Digite uma mensagem..."
              style={{ flex: 1, minWidth: 0, padding: "10px 12px", borderRadius: 22, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", fontFamily: "Montserrat,sans-serif", boxSizing: "border-box" }}
            />
            <button onClick={enviar} disabled={enviando || !texto.trim()}
              style={{ flexShrink: 0, padding: "10px 16px", borderRadius: 22, border: "none", background: texto.trim() ? "linear-gradient(135deg,#00A893,#170073)" : "#E8ECF0", color: texto.trim() ? "#fff" : "#BDBDBD", cursor: texto.trim() ? "pointer" : "default", fontFamily: "Montserrat,sans-serif", fontWeight: 800, fontSize: 13, transition: "all .15s" }}>
              ➤
            </button>
          </>
        ) : (
          <div style={{ flex: 1, textAlign: "center", fontSize: 12, color: "#BDBDBD", padding: "8px 0" }}>
            Faça login para participar do chat
          </div>
        )}
      </div>
    </div>
  );
}