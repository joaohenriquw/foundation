import { useState, useEffect } from "react";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

export default function ListaLances({ lances, userEmail }) {
  const [scrollTop, setScrollTop] = useState(0);

  const handleScroll = (e) => {
    setScrollTop(e.target.scrollTop);
  };

  return (
    <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", overflow: "hidden" }}>
      {/* Header */}
      <div style={{ padding: "14px 16px", background: "#F8FAFC", borderBottom: "1px solid #E8ECF0", fontFamily: "Montserrat,sans-serif", fontWeight: 700, fontSize: 12, color: "#101213" }}>
        🔨 Histórico de Lances ({lances.length})
      </div>

      {/* Lista scrollável */}
      <div style={{ maxHeight: 400, overflowY: "auto", onScroll: handleScroll }}>
        {lances.length === 0 ? (
          <div style={{ padding: 40, textAlign: "center", color: "#57636C", fontSize: 12 }}>
            Aguardando primeiros lances...
          </div>
        ) : (
          lances.map((lance, idx) => {
            const isUser = lance.user_email === userEmail;
            const isPrimeiro = idx === 0;
            return (
              <div key={lance.id}
                style={{
                  padding: "12px 16px",
                  borderBottom: idx < lances.length - 1 ? "1px solid #F1F4F8" : "none",
                  background: isUser ? "#F0F4FF" : "transparent",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 10,
                }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, flex: 1 }}>
                  {/* Posição */}
                  <div style={{ width: 28, height: 28, borderRadius: "50%", background: isPrimeiro ? "#F0A500" : "#E8ECF0", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 12, color: isPrimeiro ? "#fff" : "#57636C", fontFamily: "Montserrat,sans-serif" }}>
                    {isPrimeiro ? "🥇" : `#${idx + 1}`}
                  </div>

                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: "#101213" }}>
                      {lance.user_nome} {isUser && <span style={{ fontSize: 9, color: "#170073", fontWeight: 800 }}>(você)</span>}
                    </div>
                    <div style={{ fontSize: 10, color: "#57636C", marginTop: 2 }}>
                      {new Date(lance.created_date).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                    </div>
                  </div>
                </div>

                {/* Valor do lance */}
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: isPrimeiro ? "#F0A500" : "#170073" }}>
                    {fmt(lance.valor)}
                  </div>
                  {lance.parcelas > 1 && (
                    <div style={{ fontSize: 9, color: "#57636C", marginTop: 2 }}>
                      {lance.parcelas}x {fmt(lance.valor_parcela)}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}