import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";

const diasAteExpiracao = (dataExp) => {
  const hoje = new Date();
  const expira = new Date(dataExp + "T23:59:59");
  const diff = Math.ceil((expira - hoje) / (1000 * 60 * 60 * 24));
  return diff;
};

export default function MinhaVitrine({ user }) {
  const [animaisExpostos, setAnimaisExpostos] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      if (!user) return;
      
      const hoje = new Date().toISOString().split('T')[0];
      const allExp = await base44.entities.VitrineExposicao.filter(
        { proprietario_id: user.id, ativa: true },
        "-created_date",
        100
      );
      
      // Apenas as não expiradas
      const validas = allExp.filter(e => e.data_expiracao >= hoje);
      setAnimaisExpostos(validas);
      setLoading(false);
    };
    init();

    const unsub = base44.entities.VitrineExposicao.subscribe(() => {
      init();
    });
    return unsub;
  }, [user?.id]);

  if (!user || loading) return null;

  return (
    <Link to={`/vitrine-criatorio/${user.id}`} style={{ textDecoration: "none", display: "block" }}>
      <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E8ECF0", overflow: "hidden", marginBottom: 12 }}>
        <div style={{ background: "linear-gradient(135deg,#F0A500,#E21C3D)", padding: "14px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff" }}>🏪 Minha Vitrine</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.85)" }}>{animaisExpostos.length} animal{animaisExpostos.length !== 1 ? "is" : ""} expostos</div>
          </div>
          <div style={{ fontSize: 24 }}>→</div>
        </div>

        {animaisExpostos.length > 0 && (
          <div style={{ padding: "12px 14px" }}>
            {animaisExpostos.slice(0, 3).map(a => {
              const dias = diasAteExpiracao(a.data_expiracao);
              const urgente = dias < 7;
              return (
                <div key={a.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", paddingBottom: 10, marginBottom: 10, borderBottom: "1px solid #F1F4F8" }}>
                  <div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213" }}>
                      {a.animal_nome}
                    </div>
                    <div style={{ fontSize: 10, color: "#57636C" }}>
                      {a.animal_anilha}
                    </div>
                  </div>
                  <div style={{ fontSize: 10, fontWeight: 800, color: urgente ? "#C62828" : "#57636C" }}>
                    {urgente && "⏰ "}{dias}d
                  </div>
                </div>
              );
            })}
            {animaisExpostos.length > 3 && (
              <div style={{ fontSize: 11, color: "#57636C", textAlign: "center", fontWeight: 700 }}>
                +{animaisExpostos.length - 3} outro{animaisExpostos.length - 3 !== 1 ? "s" : ""}
              </div>
            )}
          </div>
        )}
      </div>
    </Link>
  );
}