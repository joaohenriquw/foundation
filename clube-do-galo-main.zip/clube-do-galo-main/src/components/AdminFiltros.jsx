import { useState } from "react";
import SelectField from "./SelectField";

export default function AdminFiltros({ tipo, filtros, onFiltrosChange }) {
  const [expandido, setExpandido] = useState(false);

  const opcoesFiltro = {
    usuarios: [
      { key: "busca", label: "🔍 Buscar", type: "text", placeholder: "Nome ou email..." },
      { key: "role", label: "👤 Cargo", type: "select", options: ["", "user", "admin", "master_admin", "organizador_evento", "veterinario"] },
      { key: "plano", label: "👑 Plano", type: "select", options: ["", "iniciante", "standard", "gold", "premium"] },
      { key: "data_criacao", label: "📅 Desde", type: "date" },
    ],
    rifas: [
      { key: "busca", label: "🔍 Buscar", type: "text", placeholder: "Título ou animal..." },
      { key: "status", label: "🎯 Status", type: "select", options: ["", "ativa", "encerrada", "cancelada"] },
      { key: "dono", label: "👤 Dono", type: "text", placeholder: "Email do dono..." },
      { key: "valor_minimo", label: "💰 Valor mín", type: "number" },
      { key: "valor_maximo", label: "💰 Valor máx", type: "number" },
    ],
  };

  const config = opcoesFiltro[tipo] || [];

  return (
    <div style={{ marginBottom: 14 }}>
      <button onClick={() => setExpandido(!expandido)}
        style={{ width: "100%", padding: "10px 14px", borderRadius: 10, border: "1.5px solid #E8ECF0", background: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 12, fontWeight: 700, color: "#57636C" }}>
        🔽 Filtros Avançados
        <span style={{ fontSize: 10, opacity: 0.6 }}>{expandido ? "▲" : "▼"}</span>
      </button>

      {expandido && (
        <div style={{ marginTop: 10, display: "grid", gap: 10, padding: "12px 14px", background: "#F8FAFC", borderRadius: 10 }}>
          {config.map(campo => (
            <div key={campo.key}>
              <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>
                {campo.label}
              </label>
              {campo.type === "text" && (
                <input
                  type="text"
                  placeholder={campo.placeholder}
                  value={filtros[campo.key] || ""}
                  onChange={(e) => onFiltrosChange({ ...filtros, [campo.key]: e.target.value })}
                  style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "1px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                />
              )}
              {campo.type === "number" && (
                <input
                  type="number"
                  placeholder={campo.label}
                  value={filtros[campo.key] || ""}
                  onChange={(e) => onFiltrosChange({ ...filtros, [campo.key]: e.target.value })}
                  style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "1px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                />
              )}
              {campo.type === "date" && (
                <input
                  type="date"
                  value={filtros[campo.key] || ""}
                  onChange={(e) => onFiltrosChange({ ...filtros, [campo.key]: e.target.value })}
                  style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "1px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                />
              )}
              {campo.type === "select" && (
                <SelectField
                  value={filtros[campo.key] || ""}
                  onChange={(e) => onFiltrosChange({ ...filtros, [campo.key]: e.target.value })}
                  options={campo.options.map(opt => ({ value: opt, label: opt || "—" }))}
                />
              )}
            </div>
          ))}
          <button onClick={() => onFiltrosChange({})}
            style={{ width: "100%", padding: "8px", borderRadius: 8, border: "none", background: "#E8ECF0", color: "#57636C", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
            Limpar filtros
          </button>
        </div>
      )}
    </div>
  );
}