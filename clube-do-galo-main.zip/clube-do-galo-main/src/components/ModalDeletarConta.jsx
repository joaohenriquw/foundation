import { useState } from "react";
import { base44 } from "@/api/base44Client";

export default function ModalDeletarConta({ user, onClose, onSucesso }) {
  const [etapa, setEtapa] = useState("confirmacao"); // confirmacao, senha, deletando
  const [senhaInput, setSenhaInput] = useState("");
  const [erro, setErro] = useState(null);
  const [deletando, setDeletando] = useState(false);

  const iniciarDelecao = () => {
    setEtapa("senha");
    setErro(null);
  };

  const confirmarDelecao = async () => {
    if (!senhaInput.trim()) {
      setErro("Digite sua senha para confirmar.");
      return;
    }

    setDeletando(true);
    setErro(null);

    try {
      // Chamar função backend para deletar conta
      const res = await base44.functions.invoke("deletarContaUsuario", {
        senha: senhaInput,
        email: user?.email,
      });

      if (!res?.data?.sucesso) {
        throw new Error(res?.data?.erro || "Erro ao deletar conta");
      }

      setEtapa("sucesso");
      setTimeout(() => {
        base44.auth.logout("/");
      }, 2000);
    } catch (e) {
      setErro(e.message || "Erro ao deletar conta. Tente novamente.");
      setDeletando(false);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,.7)",
        zIndex: 2000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
      onClick={(e) => e.target === e.currentTarget && !deletando && onClose()}
    >
      <div
        style={{
          background: "#fff",
          borderRadius: 20,
          padding: "24px 20px",
          maxWidth: 400,
          width: "100%",
        }}
      >
        {/* ETAPA 1: Confirmação */}
        {etapa === "confirmacao" && (
          <div>
            <div style={{ fontSize: 48, textAlign: "center", marginBottom: 16 }}>⚠️</div>
            <div
              style={{
                fontFamily: "Montserrat,sans-serif",
                fontSize: 16,
                fontWeight: 900,
                color: "#170073",
                marginBottom: 4,
                textAlign: "center",
              }}
            >
              Deletar Conta
            </div>
            <div
              style={{
                fontSize: 12,
                color: "#57636C",
                marginBottom: 16,
                lineHeight: 1.6,
                textAlign: "center",
              }}
            >
              Esta ação é <strong>permanente e irreversível</strong>. Todos os seus dados, anilhas,
              leilões e rifas serão deletados.
            </div>

            <div
              style={{
                background: "#FFEBEE",
                borderRadius: 12,
                padding: 12,
                marginBottom: 16,
                border: "1px solid #EF9A9A",
                fontSize: 11,
                color: "#C62828",
                lineHeight: 1.5,
              }}
            >
              ✋ <strong>Cuidado:</strong> Você não poderá recuperar sua conta após deletá-la.
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <button
                onClick={onClose}
                disabled={deletando}
                style={{
                  padding: "12px",
                  borderRadius: 12,
                  border: "1.5px solid #E8ECF0",
                  background: "#fff",
                  color: "#57636C",
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                }}
              >
                ← Cancelar
              </button>
              <button
                onClick={iniciarDelecao}
                style={{
                  padding: "12px",
                  borderRadius: 12,
                  border: "none",
                  background: "#C62828",
                  color: "#fff",
                  cursor: "pointer",
                  fontFamily: "Montserrat,sans-serif",
                  fontWeight: 700,
                  fontSize: 13,
                }}
              >
                🗑️ Continuar
              </button>
            </div>
          </div>
        )}

        {/* ETAPA 2: Confirmação de Senha */}
        {etapa === "senha" && (
          <div>
            <div style={{ fontSize: 36, textAlign: "center", marginBottom: 16 }}>🔐</div>
            <div
              style={{
                fontFamily: "Montserrat,sans-serif",
                fontSize: 16,
                fontWeight: 900,
                color: "#170073",
                marginBottom: 4,
                textAlign: "center",
              }}
            >
              Confirme sua Senha
            </div>
            <div
              style={{
                fontSize: 12,
                color: "#57636C",
                marginBottom: 16,
                textAlign: "center",
              }}
            >
              Digite sua senha para confirmar a exclusão irreversível de sua conta.
            </div>

            <label
              style={{
                fontSize: 11,
                fontWeight: 700,
                color: "#57636C",
                textTransform: "uppercase",
                display: "block",
                marginBottom: 8,
              }}
            >
              Sua Senha
            </label>
            <input
              type="password"
              value={senhaInput}
              onChange={(e) => {
                setSenhaInput(e.target.value);
                setErro(null);
              }}
              placeholder="••••••••"
              style={{
                width: "100%",
                padding: "11px 12px",
                borderRadius: 10,
                border: erro ? "1.5px solid #C62828" : "1.5px solid #E8ECF0",
                fontSize: 13,
                outline: "none",
                boxSizing: "border-box",
                marginBottom: erro ? 6 : 16,
              }}
            />
            {erro && (
              <div style={{ fontSize: 11, color: "#C62828", marginBottom: 12, fontWeight: 700 }}>
                ⚠️ {erro}
              </div>
            )}

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <button
                onClick={() => {
                  setEtapa("confirmacao");
                  setSenhaInput("");
                  setErro(null);
                }}
                disabled={deletando}
                style={{
                  padding: "12px",
                  borderRadius: 12,
                  border: "1.5px solid #E8ECF0",
                  background: "#fff",
                  color: "#57636C",
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                }}
              >
                ← Voltar
              </button>
              <button
                onClick={confirmarDelecao}
                disabled={!senhaInput.trim() || deletando}
                style={{
                  padding: "12px",
                  borderRadius: 12,
                  border: "none",
                  background: !senhaInput.trim() || deletando ? "#ccc" : "#C62828",
                  color: "#fff",
                  cursor: !senhaInput.trim() || deletando ? "default" : "pointer",
                  fontFamily: "Montserrat,sans-serif",
                  fontWeight: 700,
                  fontSize: 13,
                }}
              >
                {deletando ? "Deletando..." : "🗑️ Deletar"}
              </button>
            </div>
          </div>
        )}

        {/* ETAPA 3: Sucesso */}
        {etapa === "sucesso" && (
          <div style={{ textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
            <div
              style={{
                fontFamily: "Montserrat,sans-serif",
                fontSize: 16,
                fontWeight: 900,
                color: "#170073",
                marginBottom: 4,
              }}
            >
              Conta Deletada
            </div>
            <div style={{ fontSize: 12, color: "#57636C", marginBottom: 16 }}>
              Sua conta foi deletada com sucesso. Redirecionando...
            </div>
            <div
              style={{
                width: 40,
                height: 40,
                border: "3px solid #170073",
                borderTop: "3px solid transparent",
                borderRadius: "50%",
                animation: "spin 0.8s linear infinite",
                margin: "0 auto",
              }}
            />
          </div>
        )}

        <style>{`
          @keyframes spin {
            to { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    </div>
  );
}