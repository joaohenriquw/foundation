import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function SeletorAnimal({ userEmail, animalIdSelecionado, onAnimalChange, label = "🐓 Selecione o Animal" }) {
  const [animais, setAnimais] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busca, setBusca] = useState("");

  const animaisFiltrados = animais.filter(a =>
    `${a.nome || ""} ${a.anilha || ""}`.toLowerCase().includes(busca.toLowerCase())
  );

  useEffect(() => {
    if (userEmail) {
      Promise.all([
        base44.entities.Animal.filter({ created_by: userEmail }).catch(() => []),
        base44.entities.Animal.filter({ proprietario_email: userEmail }).catch(() => [])
      ])
        .then(([porCriacao, porPropriedade]) => {
          const combined = [...porCriacao, ...porPropriedade];
          const unique = Array.from(new Map(combined.map(a => [a.id, a])).values());
          setAnimais(unique);
        })
        .finally(() => setLoading(false));
    }
  }, [userEmail]);

  const animalSelecionado = animais.find(a => a.id === animalIdSelecionado);

  if (loading) {
    return (
      <div style={{ padding: 12, borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 12, color: "#57636C" }}>
        ⏳ Carregando animais...
      </div>
    );
  }

  if (animais.length === 0) {
    return (
      <div style={{ padding: 12, borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 12, color: "#C62828" }}>
        ⚠️ Nenhum animal registrado em seu plantel. Registre um animal antes de continuar.
      </div>
    );
  }

  return (
    <div>
      <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
        {label} *
      </label>
      <div style={{ marginBottom: 10 }}>
        <input
          type="text"
          placeholder="🔍 Buscar por nome ou anilha..."
          value={busca}
          onChange={e => setBusca(e.target.value)}
          style={{
            width: "100%",
            padding: "10px 12px",
            borderRadius: 10,
            border: "1.5px solid #E8ECF0",
            fontSize: 12,
            outline: "none",
            boxSizing: "border-box",
            marginBottom: 8,
          }}
        />
      </div>
      {busca.length > 0 && (
      <div style={{ display: "grid", gap: 6, maxHeight: 200, overflowY: "auto" }}>
        {animaisFiltrados.length === 0 ? (
          <div style={{ padding: 12, borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 12, color: "#57636C", textAlign: "center" }}>
            Nenhum animal encontrado
          </div>
        ) : (
          animaisFiltrados.map(a => (
            <div
              key={a.id}
              onClick={() => onAnimalChange(a.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                padding: "10px 12px",
                borderRadius: 10,
                cursor: "pointer",
                border: `1.5px solid ${animalIdSelecionado === a.id ? "#170073" : "#E8ECF0"}`,
                background: animalIdSelecionado === a.id ? "#F0F4FF" : "#fff",
                transition: "all .2s",
              }}
            >
              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 8,
                  background: a.foto_url ? `url(${a.foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)",
                  flexShrink: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 18,
                }}
              >
                {!a.foto_url && "🐓"}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213" }}>
                  {a.nome}
                </div>
                <div style={{ fontSize: 10, color: "#57636C" }}>
                  Anilha: {a.anilha} • {a.especie || "—"}
                </div>
              </div>
              {animalIdSelecionado === a.id && (
                <div style={{ fontSize: 16 }}>✅</div>
              )}
            </div>
          ))
        )}
      </div>
      )}
    </div>
  );
}