import { useState, useEffect } from "react";
import { createPortal } from "react-dom";
import { base44 } from "@/api/base44Client";
import RifaEditorRico from "./RifaEditorRico";
import RifaUploadImagens from "./RifaUploadImagens";
import RifaPreview from "./RifaPreview";
import SeletorAnimal from "./SeletorAnimal";
import SelectField from "./SelectField";

const QTD_OPCOES = [100, 200, 300, 500, 1000, 2000, 5000, 10000, 50000, 100000, 500000, 1000000];
const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

export default function CriarRifaModal({ user, onClose, onCriada }) {
  const [form, setForm]         = useState({
    animal_id: "", titulo: "", descricao: "", dono_whatsapp: "",
    valor_arrecadar: "", qtd_numeros: 100,
    tipo_sorteio: "manual", data_sorteio: "", hora_notificacao: "20:00",
    imagens: [],
  });
  const [animalSel, setAnimalSel] = useState(null);
  const [animaisLista, setAnimaisLista] = useState([]);
  const [saving, setSaving]     = useState(false);
  const [mostrandoPreview, setMostrandoPreview] = useState(false);

  // Carregar animais para encontrar o objeto completo ao selecionar
  useEffect(() => {
    if (user?.email) {
      Promise.all([
        base44.entities.Animal.filter({ created_by: user.email }).catch(() => []),
        base44.entities.Animal.filter({ proprietario_email: user.email }).catch(() => []),
      ]).then(([a, b]) => {
        const combined = [...a, ...b];
        const unique = Array.from(new Map(combined.map(x => [x.id, x])).values());
        setAnimaisLista(unique);
      });
    }
  }, [user?.email]);


  const valorNum    = parseFloat(form.valor_arrecadar) || 0;
  const valorBilhete = valorNum > 0 ? (valorNum / form.qtd_numeros) : 0;

  const salvar = async () => {
    if (!form.animal_id || !valorNum || !form.data_sorteio) return;
    setSaving(true);
    await base44.entities.Rifa.create({
      animal_id:        form.animal_id,
      animal_nome:      animalSel?.nome || "",
      animal_anilha:    animalSel?.anilha || "",
      animal_foto_url:  animalSel?.foto_url || "",
      animal_especie:   animalSel?.especie || "",
      dono_id:          user.id,
      dono_nome:        user.full_name,
      dono_email:       user.email,
      dono_whatsapp:    form.dono_whatsapp,
      titulo:           form.titulo || `Rifa — ${animalSel?.nome}`,
      descricao:        form.descricao,
      imagens:          form.imagens,
      valor_arrecadar:  valorNum,
      qtd_numeros:      form.qtd_numeros,
      valor_por_numero: valorBilhete,
      tipo_sorteio:     form.tipo_sorteio,
      data_sorteio:     form.data_sorteio,
      hora_notificacao: form.hora_notificacao,
      status:           "ativa",
      numeros_vendidos: 0,
      total_arrecadado: 0,
    });
    setSaving(false);
    onCriada && onCriada();
    onClose();
  };

  const content = (
    <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, background: "rgba(0,0,0,.65)", zIndex: 99999, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}
      onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{ background: "#fff", borderRadius: 20, width: "100%", maxWidth: 560, maxHeight: "85dvh", overflowY: "auto", padding: "20px 20px 32px", boxSizing: "border-box" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🎰 Criar Rifa</div>
          <button onClick={onClose} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C", minWidth: 44, minHeight: 44, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
        </div>

        <div style={{ background: "#FFF8E1", border: "1px solid #F0A500", borderRadius: 10, padding: "10px 14px", marginBottom: 14, fontSize: 11, color: "#856404", lineHeight: 1.6 }}>
          ⚠️ <strong>Taxas aplicadas:</strong> R$ 0,38 por transação (gateway) + 10% taxa administrativa sobre o total arrecadado.<br />
          O restante é creditado diretamente na sua conta.
        </div>

        <div style={{ display: "grid", gap: 14 }}>
          <SeletorAnimal userEmail={user.email} animalIdSelecionado={form.animal_id} onAnimalChange={(id) => { setForm(p => ({ ...p, animal_id: id })); setAnimalSel(animaisLista.find(a => a.id === id) || null); }} />

          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>📝 Título (opcional)</label>
            <input type="text" value={form.titulo} placeholder="Ex: Rifa do Campeão 2025"
              onChange={e => setForm(p => ({ ...p, titulo: e.target.value }))}
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
          </div>

          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>📋 Descrição (suporta formatação)</label>
            <RifaEditorRico value={form.descricao} onChange={(v) => setForm(p => ({ ...p, descricao: v }))} placeholder="Descreva o animal, premiações, condições de entrega..." />
          </div>

          <RifaUploadImagens imagens={form.imagens} onImagensChange={(imagens) => setForm(p => ({ ...p, imagens }))} />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>💰 Valor a Arrecadar (R$) *</label>
              <input type="number" value={form.valor_arrecadar} placeholder="Ex: 5000"
                onChange={e => setForm(p => ({ ...p, valor_arrecadar: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>🎫 Qtd. de Números</label>
              <SelectField
                value={form.qtd_numeros}
                onChange={e => setForm(p => ({ ...p, qtd_numeros: Number(e.target.value) }))}
                options={QTD_OPCOES.map(q => ({ value: q, label: q.toLocaleString("pt-BR") }))}
              />
            </div>
          </div>

          {valorNum > 0 && (
            <div style={{ background: "#F0F4FF", borderRadius: 10, padding: "10px 14px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 12, color: "#57636C", fontWeight: 700 }}>Valor por número:</span>
              <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>{fmt(valorBilhete)}</span>
            </div>
          )}

          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>🎲 Tipo de Sorteio</label>
            <div style={{ display: "flex", gap: 8 }}>
              {[["manual", "📋 Loteria Federal"], ["automatico", "🤖 Automático"]].map(([k, label]) => (
                <button key={k} onClick={() => setForm(p => ({ ...p, tipo_sorteio: k }))}
                  style={{ flex: 1, padding: "9px", borderRadius: 10, cursor: "pointer", fontSize: 11, fontWeight: 800,
                    border: `1.5px solid ${form.tipo_sorteio === k ? "#170073" : "#E8ECF0"}`,
                    background: form.tipo_sorteio === k ? "#170073" : "#fff",
                    color: form.tipo_sorteio === k ? "#fff" : "#57636C" }}>
                  {label}
                </button>
              ))}
            </div>
            {form.tipo_sorteio === "manual" && (
              <div style={{ fontSize: 10, color: "#57636C", marginTop: 6, padding: "6px 10px", background: "#F8FAFC", borderRadius: 8 }}>
                O resultado da Loteria Federal será inserido manualmente na data do sorteio para determinar o ganhador.
              </div>
            )}
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>📅 Data do Sorteio *</label>
              <input type="date" value={form.data_sorteio} onChange={e => setForm(p => ({ ...p, data_sorteio: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>⏰ Horário Notificação</label>
              <input type="time" value={form.hora_notificacao} onChange={e => setForm(p => ({ ...p, hora_notificacao: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
            </div>
          </div>

          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>📱 Seu WhatsApp</label>
            <input type="text" value={form.dono_whatsapp} placeholder="Ex: 5511999999999"
              onChange={e => setForm(p => ({ ...p, dono_whatsapp: e.target.value }))}
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
          </div>
        </div>

        <button onClick={() => setMostrandoPreview(true)} disabled={saving || !form.animal_id || !valorNum || !form.data_sorteio}
          style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", marginTop: 18, cursor: (saving || !form.animal_id || !valorNum || !form.data_sorteio) ? "default" : "pointer",
            background: (saving || !form.animal_id || !valorNum || !form.data_sorteio) ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
            color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
          👁️ Pré-visualizar
        </button>
      </div>

      {mostrandoPreview && (
        <RifaPreview
          rifa={form}
          animalSelecionado={form.animal_id}
          onEditar={() => setMostrandoPreview(false)}
          onPublicar={salvar}
          publicando={saving}
        />
      )}
    </div>
  );

  return createPortal(content, document.body);
}