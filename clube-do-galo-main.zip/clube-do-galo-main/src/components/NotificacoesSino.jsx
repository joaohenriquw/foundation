import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function NotificacoesSino({ userEmail }) {
  const [notifs, setNotifs] = useState([]);
  const [aberto, setAberto] = useState(false);

  const carregar = async () => {
    if (!userEmail) return;
    const data = await base44.entities.Notificacao.filter({ destinatario_email: userEmail }, "-created_date", 30);
    setNotifs(data);
  };

  useEffect(() => {
    carregar();
    const unsub = base44.entities.Notificacao.subscribe((ev) => {
      if (ev.data?.destinatario_email === userEmail) carregar();
    });
    return unsub;
  }, [userEmail]);

  const naoLidas = notifs.filter(n => !n.lida).length;

  const marcarLida = async (n) => {
    if (!n.lida) {
      await base44.entities.Notificacao.update(n.id, { lida: true });
      setNotifs(prev => prev.map(x => x.id === n.id ? { ...x, lida: true } : x));
    }
  };

  const marcarTodasLidas = async () => {
    const naoLidasList = notifs.filter(n => !n.lida);
    for (const n of naoLidasList) {
      await base44.entities.Notificacao.update(n.id, { lida: true });
    }
    setNotifs(prev => prev.map(x => ({ ...x, lida: true })));
  };

  return (
    <div style={{ position: "relative" }}>
      <button onClick={() => setAberto(!aberto)}
        style={{ background: "rgba(255,255,255,.2)", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, position: "relative" }}>
        🔔
        {naoLidas > 0 && (
          <span style={{ position: "absolute", top: -4, right: -4, background: "#E21C3D", color: "#fff", borderRadius: "50%", width: 18, height: 18, fontSize: 10, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Montserrat,sans-serif" }}>
            {naoLidas > 9 ? "9+" : naoLidas}
          </span>
        )}
      </button>

      {aberto && (
        <>
          <div onClick={() => setAberto(false)} style={{ position: "fixed", inset: 0, zIndex: 999 }} />
          <div style={{ position: "absolute", top: 46, right: 0, width: 320, background: "#fff", borderRadius: 16, boxShadow: "0 8px 32px rgba(0,0,0,.15)", zIndex: 1000, overflow: "hidden" }}>
            <div style={{ padding: "12px 16px", borderBottom: "1px solid #F1F4F8", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#170073" }}>🔔 Notificações</div>
              {naoLidas > 0 && (
                <button onClick={marcarTodasLidas} style={{ fontSize: 11, color: "#00A893", background: "none", border: "none", cursor: "pointer", fontWeight: 700 }}>
                  Marcar todas como lidas
                </button>
              )}
            </div>
            <div style={{ maxHeight: 380, overflowY: "auto" }}>
              {notifs.length === 0 ? (
                <div style={{ padding: 24, textAlign: "center", color: "#57636C", fontSize: 12 }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>🔕</div>
                  Nenhuma notificação
                </div>
              ) : notifs.map(n => (
                <div key={n.id} onClick={() => marcarLida(n)}
                  style={{ padding: "12px 16px", borderBottom: "1px solid #F8FAFC", background: n.lida ? "#fff" : "#F0F4FF", cursor: "pointer", display: "flex", gap: 10, alignItems: "flex-start" }}>
                  <span style={{ fontSize: 20, flexShrink: 0 }}>{n.icone || "📣"}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213", marginBottom: 2 }}>{n.titulo}</div>
                    <div style={{ fontSize: 11, color: "#57636C", lineHeight: 1.4 }}>{n.mensagem}</div>
                    <div style={{ fontSize: 10, color: "#BDBDBD", marginTop: 4 }}>{new Date(n.created_date).toLocaleDateString("pt-BR")}</div>
                  </div>
                  {!n.lida && <span style={{ width: 8, height: 8, borderRadius: "50%", background: "#170073", flexShrink: 0, marginTop: 4 }} />}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}