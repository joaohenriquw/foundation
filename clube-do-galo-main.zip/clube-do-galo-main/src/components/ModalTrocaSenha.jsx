import { useState } from "react";
import { base44 } from "@/api/base44Client";

export default function ModalTrocaSenha({ user, onClose }) {
  const [senhaAtual, setSenhaAtual] = useState("");
  const [novaSenha, setNovaSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState(false);
  const [processando, setProcessando] = useState(false);

  const handleTrocarSenha = async () => {
    setErro("");
    setSucesso(false);

    if (!senhaAtual || !novaSenha || !confirmarSenha) {
      setErro("Preencha todos os campos");
      return;
    }

    if (novaSenha.length < 6) {
      setErro("Nova senha deve ter no mínimo 6 caracteres");
      return;
    }

    if (novaSenha !== confirmarSenha) {
      setErro("As senhas não conferem");
      return;
    }

    if (novaSenha === senhaAtual) {
      setErro("Nova senha deve ser diferente da atual");
      return;
    }

    setProcessando(true);
    try {
      await base44.functions.invoke("trocarSenhaUsuario", {
        senhaAtual,
        novaSenha,
      });
      setSucesso(true);
      setSenhaAtual("");
      setNovaSenha("");
      setConfirmarSenha("");
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err) {
      setErro(err.message || "Erro ao trocar senha. Verifique sua senha atual.");
    } finally {
      setProcessando(false);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.5)",
        display: "flex",
        alignItems: "flex-end",
        zIndex: 2000,
      }}
      onClick={onClose}
    >
      <div
        style={{
          background: "#fff",
          width: "100%",
          borderRadius: "20px 20px 0 0",
          padding: 24,
          maxWidth: 600,
          margin: "0 auto",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          style={{
            fontFamily: "Montserrat,sans-serif",
            fontSize: 18,
            fontWeight: 900,
            color: "#101213",
            marginBottom: 20,
          }}
        >
          🔒 Trocar Senha
        </div>

        {sucesso ? (
          <div
            style={{
              background: "#E8F5E9",
              borderRadius: 12,
              padding: 20,
              textAlign: "center",
              color: "#2E7D32",
            }}
          >
            <div style={{ fontSize: 32, marginBottom: 8 }}>✅</div>
            <div style={{ fontWeight: 700, marginBottom: 4 }}>
              Senha alterada com sucesso!
            </div>
            <div style={{ fontSize: 12 }}>Você será redirecionado em breve.</div>
          </div>
        ) : (
          <>
            <div style={{ display: "grid", gap: 14, marginBottom: 20 }}>
              <div>
                <label
                  style={{
                    fontSize: 12,
                    fontWeight: 700,
                    color: "#57636C",
                    display: "block",
                    marginBottom: 6,
                  }}
                >
                  Senha Atual
                </label>
                <input
                  type="password"
                  value={senhaAtual}
                  onChange={(e) => setSenhaAtual(e.target.value)}
                  placeholder="Digite sua senha atual"
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: 10,
                    border: "1px solid #E8ECF0",
                    fontSize: 13,
                    boxSizing: "border-box",
                  }}
                />
              </div>

              <div>
                <label
                  style={{
                    fontSize: 12,
                    fontWeight: 700,
                    color: "#57636C",
                    display: "block",
                    marginBottom: 6,
                  }}
                >
                  Nova Senha
                </label>
                <input
                  type="password"
                  value={novaSenha}
                  onChange={(e) => setNovaSenha(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: 10,
                    border: "1px solid #E8ECF0",
                    fontSize: 13,
                    boxSizing: "border-box",
                  }}
                />
              </div>

              <div>
                <label
                  style={{
                    fontSize: 12,
                    fontWeight: 700,
                    color: "#57636C",
                    display: "block",
                    marginBottom: 6,
                  }}
                >
                  Confirmar Nova Senha
                </label>
                <input
                  type="password"
                  value={confirmarSenha}
                  onChange={(e) => setConfirmarSenha(e.target.value)}
                  placeholder="Confirme a nova senha"
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: 10,
                    border: "1px solid #E8ECF0",
                    fontSize: 13,
                    boxSizing: "border-box",
                  }}
                />
              </div>
            </div>

            {erro && (
              <div
                style={{
                  background: "#FFEBEE",
                  borderRadius: 10,
                  padding: 12,
                  color: "#C62828",
                  fontSize: 12,
                  fontWeight: 700,
                  marginBottom: 16,
                  textAlign: "center",
                }}
              >
                {erro}
              </div>
            )}

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <button
                onClick={onClose}
                style={{
                  padding: "12px",
                  borderRadius: 10,
                  border: "1px solid #E8ECF0",
                  background: "#fff",
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  color: "#57636C",
                }}
              >
                Cancelar
              </button>
              <button
                onClick={handleTrocarSenha}
                disabled={processando}
                style={{
                  padding: "12px",
                  borderRadius: 10,
                  border: "none",
                  background: processando
                    ? "#ccc"
                    : "linear-gradient(135deg,#170073,#00A893)",
                  color: "#fff",
                  cursor: processando ? "default" : "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                }}
              >
                {processando ? "⏳ Processando..." : "🔐 Alterar Senha"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}