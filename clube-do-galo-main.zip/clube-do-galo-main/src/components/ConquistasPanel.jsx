import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

const CONQUISTAS_CONFIG = {
  top_vendedor: {
    nome: "🥇 Top Vendedor",
    descricao: "Concluir 10 leilões com sucesso",
    meta: 10,
    emoji: "🥇",
    cor: "#F0A500",
    bg: "#FFF8E1",
  },
  destaque_leiloes: {
    nome: "⭐ Destaque em Leilões",
    descricao: "Média de vendas acima de R$ 5.000",
    meta: 5000,
    emoji: "⭐",
    cor: "#E21C3D",
    bg: "#FFEBEE",
  },
  premium_quality: {
    nome: "💎 Premium Quality",
    descricao: "Avaliação média acima de 4,5 estrelas",
    meta: 4.5,
    emoji: "💎",
    cor: "#1565C0",
    bg: "#E3F2FD",
  },
  ascensao_rapida: {
    nome: "🚀 Ascensão Rápida",
    descricao: "10 leilões em menos de 30 dias",
    meta: 10,
    emoji: "🚀",
    cor: "#8B5CF6",
    bg: "#F3E5FF",
  },
  rei_das_rifas: {
    nome: "👑 Rei das Rifas",
    descricao: "5 ou mais rifas ativas simultaneamente",
    meta: 5,
    emoji: "👑",
    cor: "#EC4899",
    bg: "#FCE4EC",
  },
  campeao: {
    nome: "🏆 Campeão",
    descricao: "50 leilões criados no total",
    meta: 50,
    emoji: "🏆",
    cor: "#00A893",
    bg: "#E0F2F1",
  },
  speed_seller: {
    nome: "⚡ Speed Seller",
    descricao: "Vender um animal em menos de 24 horas",
    meta: 1,
    emoji: "⚡",
    cor: "#F0A500",
    bg: "#FFF8E1",
  },
  milionario: {
    nome: "💰 Milionário",
    descricao: "Faturamento total acima de R$ 1.000.000",
    meta: 1000000,
    emoji: "💰",
    cor: "#2E7D32",
    bg: "#E8F5E9",
  },
};

export default function ConquistasPanel({ user, leiloes, rifas, avaliacoes }) {
  const [conquistas, setConquistas] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const calcularConquistas = async () => {
      if (!user?.email) return;

      // Buscar conquistas já desbloqueadas
      const conquistasExistentes = await base44.entities.Conquista.filter({
        usuario_email: user.email,
        destravada: true,
      });

      const conquistasMap = {};
      conquistasExistentes.forEach(c => {
        conquistasMap[c.tipo] = c;
      });

      // Calcular progresso de cada conquista
      const novasConquistas = {};

      // 1. Top Vendedor (10 leilões encerrados)
      const leiloesEncerrados = leiloes.filter(l => l.status === "encerrado").length;
      novasConquistas.top_vendedor = {
        tipo: "top_vendedor",
        progresso: Math.min((leiloesEncerrados / 10) * 100, 100),
        valor: leiloesEncerrados,
        destravada: leiloesEncerrados >= 10,
      };

      // 2. Destaque em Leilões (média > R$5000)
      const leiloesComValor = leiloes.filter(l => l.maior_lance);
      const mediaValor = leiloesComValor.length > 0 ? leiloesComValor.reduce((sum, l) => sum + l.maior_lance, 0) / leiloesComValor.length : 0;
      novasConquistas.destaque_leiloes = {
        tipo: "destaque_leiloes",
        progresso: Math.min((mediaValor / 5000) * 100, 100),
        valor: Math.round(mediaValor),
        destravada: mediaValor >= 5000,
      };

      // 3. Premium Quality (avaliação > 4.5)
      const avaliacoesCriador = avaliacoes.filter(a => a.vendedor_email === user.email);
      const mediaAvaliacoes = avaliacoesCriador.length > 0 ? avaliacoesCriador.reduce((sum, a) => sum + a.nota, 0) / avaliacoesCriador.length : 0;
      novasConquistas.premium_quality = {
        tipo: "premium_quality",
        progresso: Math.min((mediaAvaliacoes / 4.5) * 100, 100),
        valor: mediaAvaliacoes.toFixed(1),
        destravada: mediaAvaliacoes >= 4.5 && avaliacoesCriador.length > 0,
      };

      // 4. Ascensão Rápida (10 leilões em 30 dias)
      const agora = new Date();
      const trinta_dias_atras = new Date(agora.getTime() - 30 * 24 * 60 * 60 * 1000);
      const leiloes30dias = leiloes.filter(l => new Date(l.created_date) > trinta_dias_atras).length;
      novasConquistas.ascensao_rapida = {
        tipo: "ascensao_rapida",
        progresso: Math.min((leiloes30dias / 10) * 100, 100),
        valor: leiloes30dias,
        destravada: leiloes30dias >= 10,
      };

      // 5. Rei das Rifas (5+ rifas ativas)
      const rifasAtivas = rifas.filter(r => r.status === "ativa").length;
      novasConquistas.rei_das_rifas = {
        tipo: "rei_das_rifas",
        progresso: Math.min((rifasAtivas / 5) * 100, 100),
        valor: rifasAtivas,
        destravada: rifasAtivas >= 5,
      };

      // 6. Campeão (50 leilões total)
      novasConquistas.campeao = {
        tipo: "campeao",
        progresso: Math.min((leiloes.length / 50) * 100, 100),
        valor: leiloes.length,
        destravada: leiloes.length >= 50,
      };

      // 7. Speed Seller (leilão em <24h)
      const speedLeiloes = leiloes.filter(l => {
        const inicio = new Date(l.created_date);
        const fim = new Date(l.data_fim);
        const diferencaHoras = (fim - inicio) / (1000 * 60 * 60);
        return l.status === "encerrado" && diferencaHoras < 24;
      }).length;
      novasConquistas.speed_seller = {
        tipo: "speed_seller",
        progresso: speedLeiloes > 0 ? 100 : 0,
        valor: speedLeiloes,
        destravada: speedLeiloes > 0,
      };

      // 8. Milionário (faturamento > R$1M)
      const faturamentoTotal = leiloes.reduce((sum, l) => sum + (l.maior_lance || 0), 0);
      novasConquistas.milionario = {
        tipo: "milionario",
        progresso: Math.min((faturamentoTotal / 1000000) * 100, 100),
        valor: Math.round(faturamentoTotal),
        destravada: faturamentoTotal >= 1000000,
      };

      // Salvar novas conquistas desbloqueadas
      for (const [tipo, dados] of Object.entries(novasConquistas)) {
        if (dados.destravada && !conquistasMap[tipo]) {
          await base44.entities.Conquista.create({
            usuario_id: user.id,
            usuario_email: user.email,
            tipo,
            data_obtencao: new Date().toISOString(),
            progresso: 100,
            destravada: true,
          });
        }
      }

      setConquistas(novasConquistas);
      setLoading(false);
    };

    calcularConquistas();
  }, [user?.email, user?.id, leiloes, rifas, avaliacoes]);

  if (loading) {
    return <div style={{ textAlign: "center", padding: 20, color: "#57636C" }}>Calculando conquistas...</div>;
  }

  const conquistasDesbloqueadas = Object.values(conquistas).filter(c => c.destravada).length;

  return (
    <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px 18px", marginBottom: 24 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213" }}>
          🏅 Conquistas e Medalhas
        </div>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#170073", background: "#F0F4FF", padding: "4px 10px", borderRadius: 6 }}>
          {conquistasDesbloqueadas} / {Object.keys(CONQUISTAS_CONFIG).length}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 10 }}>
        {Object.entries(CONQUISTAS_CONFIG).map(([tipo, cfg]) => {
          const conquista = conquistas[tipo];
          const desbloqueada = conquista?.destravada;
          const progresso = conquista?.progresso || 0;

          return (
            <div
              key={tipo}
              style={{
                background: desbloqueada ? cfg.bg : "#F8FAFC",
                borderRadius: 12,
                border: `1.5px solid ${desbloqueada ? cfg.cor : "#E8ECF0"}`,
                padding: "12px 14px",
                textAlign: "center",
                opacity: desbloqueada ? 1 : 0.6,
                position: "relative",
                transition: "all 0.3s ease",
                cursor: "default",
              }}
            >
              <div style={{ fontSize: 28, marginBottom: 6, filter: !desbloqueada ? "grayscale(100%)" : "none" }}>
                {cfg.emoji}
              </div>
              <div style={{ fontSize: 11, fontWeight: 800, color: cfg.cor, marginBottom: 3, fontFamily: "Montserrat,sans-serif" }}>
                {cfg.nome}
              </div>
              <div style={{ fontSize: 9, color: "#57636C", marginBottom: 6, lineHeight: 1.3 }}>
                {cfg.descricao}
              </div>

              {/* Barra de progresso */}
              <div style={{ background: "#E8ECF0", borderRadius: 4, height: 4, overflow: "hidden", marginBottom: 6 }}>
                <div
                  style={{
                    background: cfg.cor,
                    height: "100%",
                    width: `${progresso}%`,
                    transition: "width 0.3s ease",
                  }}
                />
              </div>

              <div style={{ fontSize: 10, fontWeight: 700, color: cfg.cor }}>
                {Math.round(progresso)}%
              </div>

              {desbloqueada && (
                <div style={{ fontSize: 8, color: "#00A893", fontWeight: 800, marginTop: 6, textTransform: "uppercase" }}>
                  ✅ Desbloqueada
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: 12, padding: 10, background: "#E8F5E9", borderRadius: 8, fontSize: 10, color: "#2E7D32", fontWeight: 600 }}>
        🎯 Desbloqueie medalhas atingindo metas de vendas e avaliações para aumentar sua reputação
      </div>
    </div>
  );
}