import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function BotaoFavorito({ animal, user, onFavoritoChange }) {
  const [isFavorito, setIsFavorito] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user || !animal) return;
    const verificar = async () => {
      const favs = await base44.entities.Favorito.filter({
        usuario_email: user.email,
        animal_id: animal.id,
      });
      setIsFavorito(favs.length > 0);
    };
    verificar();
  }, [user?.email, animal?.id]);

  const toggleFavorito = async () => {
    if (!user || !animal) return;
    setLoading(true);

    if (isFavorito) {
      const favs = await base44.entities.Favorito.filter({
        usuario_email: user.email,
        animal_id: animal.id,
      });
      if (favs.length > 0) {
        await base44.entities.Favorito.delete(favs[0].id);
      }
    } else {
      await base44.entities.Favorito.create({
        usuario_email: user.email,
        usuario_id: user.id,
        animal_id: animal.id,
        animal_nome: animal.nome,
        animal_anilha: animal.anilha,
        animal_especie: animal.especie,
        animal_foto_url: animal.foto_url,
        proprietario_id: animal.proprietario_id,
        proprietario_nome: animal.proprietario_nome,
        animal_valor: animal.valor_estimado,
      });
      
      // Notificar usuário sobre ativação de notificações
      await base44.entities.Notificacao.create({
        destinatario_email: user.email,
        titulo: '⭐ Leilão marcado como favorito',
        mensagem: `Você receberá uma notificação 10 minutos antes de ${animal.nome} encerrar. Fique atento!`,
        tipo: 'sistema',
        lida: false,
        icone: '⭐',
      });
    }

    setIsFavorito(!isFavorito);
    setLoading(false);
    if (onFavoritoChange) onFavoritoChange();
  };

  return (
    <button
      onClick={toggleFavorito}
      disabled={loading}
      style={{
        background: "none",
        border: "none",
        fontSize: 20,
        cursor: loading ? "default" : "pointer",
        opacity: loading ? 0.6 : 1,
      }}
      title={isFavorito ? "Remover dos favoritos" : "Adicionar aos favoritos"}
    >
      {isFavorito ? "❤️" : "🤍"}
    </button>
  );
}