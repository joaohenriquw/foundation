import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function ConfiguraGatewayNyxpay({ user }) {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [modalAberto, setModalAberto] = useState(false);
  const [apiKey, setApiKey] = useState("");
  const [processando, setProcessando] = useState(false);
  const [mostrarChaves, setMostrarChaves] = useState(false);
  const [erroMsg, setErroMsg] = useState("");

  useEffect(() => {
    const init = async () => {
      const configs = await base44.entities.GatewayConfig.filter({ provider: "nyxpay" });
      if (configs.length > 0) {
        setConfig(configs[0]);
        setApiKey(configs[0].api_key || "");
      }
      setLoading(false);
    };
    init();
  }, []);

  const salvarConfig = async () => {
    if (!apiKey) {
      setErroMsg("⚠️ API Key é obrigatória");
      return;
    }
    setErroMsg("");
    setProcessando(true);

    if (config) {
      await base44.entities.GatewayConfig.update(config.id, {
        api_key: apiKey,
        ativo: true,
      });
      setConfig({ ...config, api_key: apiKey, ativo: true });
    } else {
      const novaConfig = await base44.entities.GatewayConfig.create({
        provider: "nyxpay",
        api_key: apiKey,
        webhook_url: `${window.location.origin}/api/v1/nyxpayWebhook`,
        ativo: true,
        admin_id: user.id,
        admin_email: user.email,
        data_configuracao: new Date().toISOString(),
      });
      setConfig(novaConfig);
    }

    setModalAberto(false);
    setProcessando(false);
  };

  const toggleAtivo = async () => {
    if (config) {
      await base44.entities.GatewayConfig.update(config.id, { ativo: !config.ativo });
      setConfig({ ...config, ativo: !config.ativo });
    }
  };

  const abrirModalEdicao = () => {
    setApiKey(config?.api_key || "");
    setErroMsg("");
    setModalAberto(true);
  };

  if (loading) return <div style={{ textAlign: "center", padding: 20 }}>Carregando...</div>;

  return (
    <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px 18px", marginBottom: 24 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213" }}>
          💳 Gateway de Pagamento (NyxPay)
        </div>
        {config && (
          <div style={{ fontSize: 10, fontWeight: 700, color: config.ativo ? "#00A893" : "#E21C3D" }}>
            {config.ativo ? "🟢 ATIVO" : "🔴 INATIVO"}
          </div>
        )}
      </div>

      {config ? (
        <div style={{ display: "grid", gap: 12 }}>
          <div style={{ background: "#F8FAFC", borderRadius: 10, padding: 12 }}>
            <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginBottom: 4 }}>API Key</div>
            <div style={{ fontSize: 11, color: "#101213", fontFamily: "monospace", fontWeight: 700, wordBreak: "break-all" }}>
              {mostrarChaves ? config.api_key : "••••••••••••••••••••••••"}
            </div>
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button onClick={() => setMostrarChaves(!mostrarChaves)}
              style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #170073", background: "#fff", color: "#170073", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif" }}>
              {mostrarChaves ? "🔒 Ocultar" : "👁️ Ver Chave"}
            </button>
            <button onClick={abrirModalEdicao}
              style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: "#170073", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif" }}>
              ✏️ Editar Chave
            </button>
            <button onClick={toggleAtivo}
              style={{ padding: "8px 12px", borderRadius: 8, border: "none", background: config.ativo ? "#E21C3D" : "#00A893", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif" }}>
              {config.ativo ? "🔴 Desativar" : "🟢 Ativar"}
            </button>
          </div>
        </div>
      ) : (
        <div style={{ textAlign: "center", padding: 20, color: "#57636C" }}>
          <div style={{ fontSize: 32, marginBottom: 10 }}>💳</div>
          <div style={{ fontWeight: 700, marginBottom: 12 }}>Gateway não configurado</div>
          <button onClick={abrirModalEdicao}
            style={{ padding: "8px 16px", borderRadius: 8, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12, fontFamily: "Montserrat,sans-serif" }}>
            ⚙️ Configurar Agora
          </button>
        </div>
      )}

      {modalAberto && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalAberto(false)}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
                💳 {config ? "Atualizar API Key" : "Registrar API Key"}
              </div>
              <button onClick={() => setModalAberto(false)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            {erroMsg && (
              <div style={{ background: "#FFEBEE", borderRadius: 8, padding: 10, marginBottom: 14, fontSize: 11, color: "#E21C3D", fontWeight: 700 }}>
                {erroMsg}
              </div>
            )}

            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>
                🔑 API Key
              </label>
              <input
                type="password"
                value={apiKey}
                onChange={e => setApiKey(e.target.value)}
                placeholder="sk_live_..."
                style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box", fontFamily: "monospace" }}
              />
              <div style={{ fontSize: 10, color: "#BDBDBD", marginTop: 4 }}>Começa com sk_live_ ou sk_test_</div>
            </div>

            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => setModalAberto(false)}
                style={{ flex: 1, padding: "12px", borderRadius: 10, border: "1.5px solid #E8ECF0", background: "#fff", color: "#57636C", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                ✕ Cancelar
              </button>
              <button onClick={salvarConfig} disabled={processando || !apiKey}
                style={{ flex: 1, padding: "12px", borderRadius: 10, border: "none", background: processando || !apiKey ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: processando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                {processando ? "Salvando..." : config ? "✅ Atualizar" : "✅ Registrar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}