import { useNavigate, useLocation } from "react-router-dom";
import { ChevronLeft } from "lucide-react";

export default function BackHeader({ 
  title = "", 
  showBackButton = true,
  rightAction = null,
  subtitle = ""
}) {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Root screens (show title/logo instead of back)
  const rootPaths = ["/", "/caderno-anilhas", "/perfil-usuario"];
  const isRootScreen = rootPaths.includes(location.pathname);

  const handleBack = () => {
    // Se voltar da Vitrine, vai para Home (limpar stack)
    if (location.pathname.includes('/vitrine')) {
      navigate("/", { replace: true });
    } else if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate("/");
    }
  };

  return (
    <div style={{
      position: "sticky",
      top: 0,
      background: "#0A0A0A",
      borderBottom: "1px solid #1C1C1E",
      paddingTop: "env(safe-area-inset-top, 44px)",
      paddingLeft: "env(safe-area-inset-left, 16px)",
      paddingRight: "env(safe-area-inset-right, 16px)",
      paddingBottom: 12,
      zIndex: 99,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      minHeight: 56,
    }}>
      {/* Left: Back button or logo */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1 }}>
        {showBackButton && !isRootScreen && (
          <button
            onClick={handleBack}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 44,
              height: 44,
              borderRadius: 10,
              border: "none",
              background: "#1C1C1E",
              cursor: "pointer",
              color: "#fff",
              transition: "all 0.15s",
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = "#2C2C2E"}
            onMouseLeave={(e) => e.currentTarget.style.background = "#1C1C1E"}
            aria-label="Voltar"
          >
            <ChevronLeft size={20} />
          </button>
        )}
        
        {isRootScreen && (
          <div style={{
            fontFamily: "Montserrat, sans-serif",
            fontSize: 20,
            fontWeight: 900,
            color: "#00C9B8",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
          }}>
            🐓 Galo
          </div>
        )}

        {/* Title */}
        {title && (
          <div>
            <div style={{
              fontFamily: "Montserrat, sans-serif",
              fontSize: 16,
              fontWeight: 800,
              color: "#fff",
              lineHeight: 1.2,
            }}>
              {title}
            </div>
            {subtitle && (
              <div style={{
                fontSize: 11,
                color: "#888",
                marginTop: 2,
              }}>
                {subtitle}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Right: Custom action */}
      {rightAction && (
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          {rightAction}
        </div>
      )}
    </div>
  );
}