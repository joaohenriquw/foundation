import { Link, useLocation, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

const TABS = [
  { path: "/",         emoji: "🏠", label: "Início"    },
  { path: "/leiloes", image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/e91391015_WhatsAppImage2026-04-04at000032.jpeg", label: "Leilões" },
  { path: "/plantel",  image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/34202ef59_5c11ff38-3230-4907-8326-8905539ffbcd.jpg", label: "Registros"  },
  { path: "/mapa-criadores",  image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/fc923f5cb_generated_image.png", label: "Criadores"   },
  { path: "/perfil-usuario",   emoji: "👤", label: "Perfil"    },
];

export default function BottomNav() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [lastTabPath, setLastTabPath] = useState(pathname);

  useEffect(() => {
    setLastTabPath(pathname);
  }, [pathname]);

  const handleTabClick = (path) => {
    // If clicking the same tab, reset its navigation stack
    const currentTabRoot = "/" + pathname.split("/")[1];
    const targetTabRoot = path;
    
    if (currentTabRoot === targetTabRoot && path !== pathname) {
      // Same tab but different sub-route: navigate to root
      navigate(path, { replace: true });
    } else if (currentTabRoot === targetTabRoot && path === pathname) {
      // Same tab, same route: reset to root
      navigate(path, { replace: true });
    } else {
      // Different tab: normal navigation
      navigate(path);
    }
  };

  return (
    <div style={{
      position: "fixed", bottom: 0, left: 0, right: 0,
      background: "#0A0A0A", borderTop: "1px solid #1C1C1E",
      display: "flex", zIndex: 100,
      paddingBottom: "env(safe-area-inset-bottom, 8px)",
      paddingLeft: "env(safe-area-inset-left)",
      paddingRight: "env(safe-area-inset-right)",
      overscrollBehavior: "none",
    }}>
      {TABS.map(t => {
      const ativo = pathname === t.path || (pathname.startsWith(t.path) && t.path !== "/");
      return (
        <button key={t.path} onClick={() => handleTabClick(t.path)} style={{
          flex: 1, display: "flex", flexDirection: "column", alignItems: "center",
          padding: "12px 4px 8px", background: "none", border: "none", cursor: "pointer",
          color: ativo ? "#00C9B8" : "#555", transition: ".15s",
          minHeight: "44px", justifyContent: "center",
          }} title={t.label}>
            {t.image ? (
              <img src={t.image} alt={t.label} style={{ width: 26, height: 26, objectFit: "cover", borderRadius: 5, opacity: ativo ? 1 : 0.5 }} />
            ) : (
              <span style={{ fontSize: 22 }}>{t.emoji}</span>
            )}
            <span style={{ fontSize: 11, fontWeight: ativo ? 800 : 500, fontFamily: "Montserrat,sans-serif", marginTop: 2 }}>{t.label}</span>
            {ativo && <span style={{ width: 4, height: 4, borderRadius: "50%", background: "#00C9B8", marginTop: 2 }} />}
          </button>
        );
      })}
    </div>
  );
}