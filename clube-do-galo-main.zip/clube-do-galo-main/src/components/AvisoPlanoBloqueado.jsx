import { Link } from 'react-router-dom';

export default function AvisoPlanoBloqueado({ validacao, titulo = "Acesso Bloqueado" }) {
  if (!validacao || validacao.tem_acesso !== false) return null;

  return (
    <div style={{
      background: '#FFEBEE',
      borderRadius: 14,
      padding: '16px 18px',
      border: '1.5px solid #FFCDD2',
      marginBottom: 16
    }}>
      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
        <span style={{ fontSize: 20, flexShrink: 0 }}>🔒</span>
        <div style={{ flex: 1 }}>
          <div style={{
            fontFamily: 'Montserrat,sans-serif',
            fontSize: 13,
            fontWeight: 800,
            color: '#C62828',
            marginBottom: 4
          }}>
            {titulo}
          </div>
          <div style={{
            fontSize: 12,
            color: '#D32F2F',
            lineHeight: 1.5,
            marginBottom: 10
          }}>
            {validacao.mensagem}
          </div>
          <Link to={validacao.link_upgrade || '/planos'}
            style={{
              display: 'inline-block',
              background: '#C62828',
              color: '#fff',
              padding: '8px 16px',
              borderRadius: 10,
              textDecoration: 'none',
              fontSize: 12,
              fontWeight: 700,
              fontFamily: 'Montserrat,sans-serif'
            }}>
            💎 Ver Planos
          </Link>
        </div>
      </div>
    </div>
  );
}