import { useState } from 'react';
import { base44 } from '@/api/base44Client';

const CARGOS = [
  { value: 'user', label: 'Usuário (sem permissões)', emoji: '👤', cor: '#57636C' },
  { value: 'advogado_civil', label: 'Advogado Civil', emoji: '⚖️', cor: '#1565C0' },
  { value: 'advogado_criminal', label: 'Advogado Criminal', emoji: '🔒', cor: '#C62828' },
  { value: 'veterinario', label: 'Veterinário', emoji: '🩺', cor: '#2E7D32' },
  { value: 'organizador_evento', label: 'Organizador de Eventos', emoji: '🎪', cor: '#00A893' },
  { value: 'admin', label: 'Admin (gerenciar planos, cargos, dados)', emoji: '🔑', cor: '#F0A500' },
  { value: 'master_admin', label: 'Master Admin (acesso total)', emoji: '👑', cor: '#170073' },
];

export default function ModalAtribuirCargo({ usuario, onClose, onCargoAtribuido }) {
  const [selecionado, setSelecionado] = useState(usuario?.role || 'user');
  const [atribuindo, setAtribuindo] = useState(false);

  const atribuir = async () => {
    if (!usuario || selecionado === usuario.role) return;
    
    setAtribuindo(true);
    try {
      await base44.entities.User.update(usuario.id, { role: selecionado });
      onCargoAtribuido(usuario.id, selecionado);
      onClose();
    } catch (e) {
      alert('Erro ao atribuir cargo: ' + e.message);
    } finally {
      setAtribuindo(false);
    }
  };

  const cargoAtual = CARGOS.find(c => c.value === usuario?.role) || CARGOS[0];

  return (
    <>
      <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.6)', zIndex: 998 }} />
      <div style={{
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        background: '#fff',
        borderRadius: '20px',
        padding: '20px',
        zIndex: 999,
        width: '90%',
        maxWidth: '420px',
        maxHeight: '90vh',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '0 20px 60px rgba(0,0,0,.3)',
      }} onClick={e => e.stopPropagation()}>
        
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 16, fontWeight: 900, color: '#170073' }}>
            👤 Atribuir Cargo
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: 24, cursor: 'pointer', color: '#57636C', padding: 0 }}>
            ✕
          </button>
        </div>

        {/* Usuário Info */}
        <div style={{ background: '#F8FAFC', borderRadius: 10, padding: '10px 12px', marginBottom: 12, border: '1px solid #E8ECF0', flexShrink: 0 }}>
          <div style={{ fontSize: 10, color: '#57636C' }}>
            {usuario?.email}
          </div>
          <div style={{ fontSize: 9, color: '#BDBDBD', marginTop: 4 }}>
            Cargo atual: <strong>{cargoAtual.label}</strong>
          </div>
        </div>

        {/* Lista de Cargos */}
        <div style={{ marginBottom: 12, flex: 1, overflowY: 'auto', paddingRight: 4 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#57636C', textTransform: 'uppercase', marginBottom: 8 }}>
            Selecione um cargo:
          </div>
          <div style={{ display: 'grid', gap: 6 }}>
            {CARGOS.map(cargo => (
              <button
                key={cargo.value}
                onClick={() => setSelecionado(cargo.value)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 14,
                  padding: '10px 12px',
                  borderRadius: 10,
                  border: `2px solid ${selecionado === cargo.value ? cargo.cor : '#E8ECF0'}`,
                  background: selecionado === cargo.value ? cargo.cor + '15' : '#fff',
                  cursor: 'pointer',
                  transition: '.15s',
                  textAlign: 'left',
                }}>
                
                {/* Radio */}
                <input
                  type="radio"
                  checked={selecionado === cargo.value}
                  onChange={() => setSelecionado(cargo.value)}
                  style={{
                    width: 16,
                    height: 16,
                    cursor: 'pointer',
                    flexShrink: 0,
                    accentColor: cargo.cor,
                  }}
                />

                {/* Emoji */}
                <span style={{ fontSize: 18, flexShrink: 0 }}>
                  {cargo.emoji}
                </span>

                {/* Label */}
                <div style={{ flex: 1 }}>
                  <div style={{
                    fontFamily: 'Montserrat,sans-serif',
                    fontSize: 11,
                    fontWeight: 800,
                    color: selecionado === cargo.value ? cargo.cor : '#101213',
                  }}>
                    {cargo.label}
                  </div>
                </div>

                {/* Check */}
                {selecionado === cargo.value && (
                  <span style={{ fontSize: 18, color: cargo.cor, fontWeight: 900 }}>✓</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Botões */}
        <div style={{ display: 'flex', gap: 8, flexShrink: 0, marginTop: 12, paddingTop: 12, borderTop: '1px solid #E8ECF0' }}>
          <button
            onClick={onClose}
            style={{
              flex: 1,
              padding: '10px 14px',
              borderRadius: 10,
              border: '1.5px solid #E8ECF0',
              background: '#fff',
              color: '#57636C',
              cursor: 'pointer',
              fontFamily: 'Montserrat,sans-serif',
              fontWeight: 700,
              fontSize: 12,
            }}>
            Cancelar
          </button>
          <button
            onClick={atribuir}
            disabled={atribuindo || selecionado === usuario?.role}
            style={{
              flex: 1,
              padding: '10px 14px',
              borderRadius: 10,
              border: 'none',
              background: atribuindo || selecionado === usuario?.role ? '#ddd' : 'linear-gradient(135deg, #170073, #00A893)',
              color: atribuindo || selecionado === usuario?.role ? '#999' : '#fff',
              cursor: atribuindo || selecionado === usuario?.role ? 'default' : 'pointer',
              fontFamily: 'Montserrat,sans-serif',
              fontWeight: 700,
              fontSize: 12,
              transition: '.15s',
            }}>
            {atribuindo ? '⏳ Atribuindo...' : '✅ Atribuir Cargo'}
          </button>
        </div>
      </div>
    </>
  );
}