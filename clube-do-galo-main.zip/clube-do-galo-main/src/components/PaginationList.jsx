import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function PaginationList({
  items = [],
  renderItem = () => null,
  itemsPerPage = 10,
  containerStyle = {},
  loadingComponent = null,
  emptyComponent = null,
  enableInfiniteScroll = false,
  onLoadMore = () => {},
}) {
  const [currentPage, setCurrentPage] = useState(0);
  const [displayedItems, setDisplayedItems] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  // Pagination logic
  useEffect(() => {
    if (enableInfiniteScroll) {
      setDisplayedItems(items);
    } else {
      const start = currentPage * itemsPerPage;
      const end = start + itemsPerPage;
      setDisplayedItems(items.slice(start, end));
    }
  }, [items, currentPage, itemsPerPage, enableInfiniteScroll]);

  const totalPages = Math.ceil(items.length / itemsPerPage);
  const hasNextPage = currentPage < totalPages - 1;
  const hasPrevPage = currentPage > 0;

  const handleNextPage = () => {
    if (hasNextPage) {
      setCurrentPage(currentPage + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handlePrevPage = () => {
    if (hasPrevPage) {
      setCurrentPage(currentPage - 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleLoadMore = async () => {
    setIsLoading(true);
    try {
      await onLoadMore?.();
    } finally {
      setIsLoading(false);
    }
  };

  if (displayedItems.length === 0) {
    return emptyComponent || (
      <div style={{
        textAlign: "center",
        padding: 40,
        color: "#57636C",
        fontSize: 14,
        ...containerStyle,
      }}>
        Nenhum item encontrado
      </div>
    );
  }

  return (
    <div style={containerStyle}>
      {/* Items */}
      <div style={{ display: "grid", gap: 12 }}>
        {displayedItems.map((item, idx) => (
          <div key={`${item.id || idx}`}>
            {renderItem(item, idx)}
          </div>
        ))}
      </div>

      {/* Infinite scroll trigger */}
      {enableInfiniteScroll && (
        <div
          style={{
            padding: "20px 16px",
            textAlign: "center",
          }}
          onVisible={() => handleLoadMore()}
        >
          {isLoading ? (
            <div style={{ color: "#57636C", fontSize: 12 }}>Carregando...</div>
          ) : items.length >= 50 ? (
            <button
              onClick={handleLoadMore}
              style={{
                padding: "10px 20px",
                borderRadius: 10,
                border: "none",
                background: "linear-gradient(135deg, #170073, #00A893)",
                color: "#fff",
                cursor: "pointer",
                fontWeight: 700,
                fontSize: 12,
                minHeight: 44,
              }}
            >
              Carregar mais
            </button>
          ) : null}
        </div>
      )}

      {/* Pagination controls (non-infinite scroll) */}
      {!enableInfiniteScroll && totalPages > 1 && (
        <div style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 12,
          marginTop: 20,
          paddingTop: 16,
          borderTop: "1px solid #E8ECF0",
        }}>
          <button
            onClick={handlePrevPage}
            disabled={!hasPrevPage}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 44,
              height: 44,
              borderRadius: 10,
              border: "1.5px solid #E8ECF0",
              background: "#fff",
              cursor: hasPrevPage ? "pointer" : "default",
              opacity: hasPrevPage ? 1 : 0.5,
              transition: "all 0.15s",
            }}
            onMouseEnter={(e) => hasPrevPage && (e.target.style.background = "#F8FAFC")}
            onMouseLeave={(e) => (e.target.style.background = "#fff")}
            aria-label="Página anterior"
          >
            <ChevronLeft size={18} color="#170073" />
          </button>

          <div style={{
            fontSize: 12,
            color: "#57636C",
            fontWeight: 600,
            minWidth: 80,
            textAlign: "center",
          }}>
            Página {currentPage + 1} de {totalPages}
          </div>

          <button
            onClick={handleNextPage}
            disabled={!hasNextPage}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              width: 44,
              height: 44,
              borderRadius: 10,
              border: "1.5px solid #E8ECF0",
              background: "#fff",
              cursor: hasNextPage ? "pointer" : "default",
              opacity: hasNextPage ? 1 : 0.5,
              transition: "all 0.15s",
            }}
            onMouseEnter={(e) => hasNextPage && (e.target.style.background = "#F8FAFC")}
            onMouseLeave={(e) => (e.target.style.background = "#fff")}
            aria-label="Próxima página"
          >
            <ChevronRight size={18} color="#170073" />
          </button>
        </div>
      )}
    </div>
  );
}