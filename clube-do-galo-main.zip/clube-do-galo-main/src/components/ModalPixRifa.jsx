import { useState } from "react";
import { base44 } from "@/api/base44Client";

export default function ModalPixRifa({ valor, user, onClose, onSucesso }) {
  const [etapa, setEtapa] = useState("cpf"); // cpf ou pix
  const [cpfInput, setCpfInput] = useState("");
  const [erro, setErro] = useState(null);
  const [gerando, setGerando] = useState(false);
  const [pixData, setPixData] = useState(null);
  const [copiado, setCopiado] = useState(false);

  const gerarPixComCpf = async () => {
    if (!cpfInput.replace(/\D/g, "") || cpfInput.replace(/\D/g, "").length !== 11) {
      setErro("CPF inválido. Use 11 dígitos.");
      return;
    }

    setErro(null);
    setGerando(true);
    setEtapa("pix");

    try {
      const res = await base44.functions.invoke("depositoPixNyxpay", {
        valor: valor,
        cpf: cpfInput.replace(/\D/g, ""),
        nome: user.full_name,
      });

      if (!res?.data) {
        throw new Error("Nenhum dado retornado da gateway");
      }

      const pixDataResponse = res.data.data || res.data;

      if (!pixDataResponse.qr_code && !pixDataResponse.pix_copia_cola) {
        throw new Error("QR Code ou chave PIX não gerados");
      }

      setPixData({
        qrCode: pixDataResponse.qr_code || pixDataResponse.pix_copia_cola || "",
        chave: pixDataResponse.pix_copia_cola || pixDataResponse.qr_code || "",
        txnId: pixDataResponse.transaction_id || "",
      });
    } catch (e) {
      setErro(e.message || "Erro ao gerar QR Code");
      setEtapa("cpf");
    } finally {
      setGerando(false);
    }
  };

  const copiarChave = () => {
    if (pixData?.chave) {
      navigator.clipboard.writeText(pixData.chave);
      setCopiado(true);
      setTimeout(() => setCopiado(false), 2000);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,.7)",
        zIndex: 2000,
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
      }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        style={{
          background: "#fff",
          borderRadius: "20px 20px 0 0",
          width: "100%",
          maxWidth: 500,
          maxHeight: "92vh",
          overflowY: "auto",
          padding: "20px 20px 40px",
        }}
      >
        {/* Header */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
            💳 Pagamento via PIX
          </div>
          <button
            onClick={onClose}
            style={{
              background: "none",
              border: "none",
              fontSize: 20,
              cursor: "pointer",
              color: "#57636C",
            }}
          >
            ✕
          </button>
        </div>

        {/* Resumo */}
        <div
          style={{
            background: "#F0F4FF",
            borderRadius: 12,
            padding: 14,
            marginBottom: 16,
            border: "1px solid #D0D8FF",
          }}
        >
          <div style={{ fontSize: 11, color: "#170073", fontWeight: 700, marginBottom: 6 }}>
            RESUMO DA COMPRA
          </div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span style={{ color: "#57636C", fontSize: 12 }}>Números da Rifa</span>
            <span style={{ fontWeight: 700, fontSize: 12, color: "#101213" }}>
              R$ {valor.toFixed(2)}
            </span>
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              borderTop: "1px solid #D0D8FF",
              paddingTop: 8,
              marginTop: 8,
            }}
          >
            <span style={{ color: "#101213", fontSize: 12, fontWeight: 700 }}>Total</span>
            <span
              style={{
                fontFamily: "Montserrat,sans-serif",
                fontSize: 16,
                fontWeight: 900,
                color: "#170073",
              }}
            >
              R$ {valor.toFixed(2)}
            </span>
          </div>
        </div>

        {/* ETAPA 1: Solicitar CPF */}
        {etapa === "cpf" && (
          <div>
            <div style={{ fontSize: 12, color: "#57636C", marginBottom: 16, lineHeight: 1.5 }}>
              Para processar o pagamento via PIX, precisamos do seu CPF para validação.
            </div>
            <label
              style={{
                fontSize: 11,
                fontWeight: 700,
                color: "#57636C",
                textTransform: "uppercase",
                display: "block",
                marginBottom: 8,
              }}
            >
              📋 CPF (11 dígitos)
            </label>
            <input
              type="text"
              value={cpfInput}
              onChange={(e) => {
                const valor = e.target.value.replace(/\D/g, "").slice(0, 11);
                setCpfInput(valor);
                setErro(null);
              }}
              placeholder="00000000000"
              maxLength="11"
              style={{
                width: "100%",
                padding: "11px 12px",
                borderRadius: 10,
                border: erro ? "1.5px solid #C62828" : "1.5px solid #E8ECF0",
                fontSize: 13,
                outline: "none",
                boxSizing: "border-box",
                marginBottom: erro ? 6 : 16,
                fontFamily: "monospace",
              }}
            />
            {erro && (
              <div style={{ fontSize: 11, color: "#C62828", marginBottom: 12, fontWeight: 700 }}>
                ⚠️ {erro}
              </div>
            )}
            <button
              onClick={gerarPixComCpf}
              disabled={cpfInput.length !== 11}
              style={{
                width: "100%",
                padding: "13px",
                borderRadius: 12,
                border: "none",
                cursor: cpfInput.length === 11 ? "pointer" : "default",
                background:
                  cpfInput.length === 11 ? "linear-gradient(135deg,#170073,#00A893)" : "#ccc",
                color: "#fff",
                fontFamily: "Montserrat,sans-serif",
                fontSize: 14,
                fontWeight: 900,
              }}
            >
              ✓ Confirmar CPF
            </button>
          </div>
        )}

        {/* ETAPA 2: Mostrar PIX */}
        {etapa === "pix" &&
          (gerando ? (
            <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>
              <div className="w-6 h-6 border-3 border-slate-200 border-t-slate-800 rounded-full animate-spin inline-block"></div>
              <div style={{ marginTop: 8, fontSize: 12 }}>Gerando QR Code...</div>
            </div>
          ) : erro ? (
            <div style={{ textAlign: "center", padding: 40 }}>
              <div style={{ fontSize: 48, marginBottom: 12 }}>❌</div>
              <div style={{ color: "#C62828", fontSize: 13, fontWeight: 700, marginBottom: 16 }}>
                {erro}
              </div>
              <button
                onClick={() => {
                  setEtapa("cpf");
                  setErro(null);
                  setPixData(null);
                }}
                style={{
                  padding: "10px 20px",
                  borderRadius: 10,
                  border: "none",
                  background: "#170073",
                  color: "#fff",
                  cursor: "pointer",
                  fontFamily: "Montserrat,sans-serif",
                  fontWeight: 700,
                }}
              >
                ← Voltar
              </button>
            </div>
          ) : pixData ? (
            <div>
              {/* Aviso para fechar apenas após pagar */}
              <div
                style={{
                  background: "#FFF8E1",
                  borderRadius: 12,
                  padding: 12,
                  marginBottom: 16,
                  border: "1px solid #F0A500",
                }}
              >
                <div style={{ fontSize: 11, fontWeight: 700, color: "#856404", marginBottom: 4 }}>
                  📱 Não feche este modal
                </div>
                <div style={{ fontSize: 10, color: "#856404" }}>
                  Deixe a janela aberta enquanto realiza o pagamento para receber a confirmação
                  automática.
                </div>
              </div>
              <div style={{ textAlign: "center", marginBottom: 20 }}>
                <div
                  style={{
                    background: "#fff",
                    border: "2px solid #E8ECF0",
                    borderRadius: 12,
                    padding: 16,
                    display: "inline-block",
                    marginBottom: 12,
                  }}
                >
                  <div
                    style={{
                      width: 180,
                      height: 180,
                      background: `url('https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
                        pixData.qrCode
                      )}') center/contain`,
                      backgroundRepeat: "no-repeat",
                    }}
                  />
                </div>
                <div style={{ fontSize: 10, color: "#57636C", marginBottom: 4 }}>
                  Aponte a câmera do seu celular para o QR Code
                </div>
                <div style={{ fontSize: 9, color: "#999", fontStyle: "italic" }}>
                  ou copie a chave PIX abaixo
                </div>
              </div>

              {/* Chave PIX */}
              <div
                style={{
                  background: "#F8FAFC",
                  borderRadius: 12,
                  padding: 14,
                  marginBottom: 12,
                  border: "1px solid #E8ECF0",
                }}
              >
                <div
                  style={{
                    fontSize: 10,
                    color: "#57636C",
                    fontWeight: 700,
                    marginBottom: 8,
                    textTransform: "uppercase",
                  }}
                >
                  Ou copie a chave PIX
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <input
                    type="text"
                    value={pixData.chave || ""}
                    readOnly
                    style={{
                      flex: 1,
                      padding: "10px 12px",
                      borderRadius: 8,
                      border: "1px solid #E8ECF0",
                      fontSize: 11,
                      fontFamily: "monospace",
                      outline: "none",
                      wordBreak: "break-all",
                    }}
                  />
                  <button
                    onClick={copiarChave}
                    style={{
                      padding: "10px 12px",
                      borderRadius: 8,
                      border: "1.5px solid #170073",
                      background: copiado ? "#E8F5E9" : "#fff",
                      color: copiado ? "#2E7D32" : "#170073",
                      cursor: "pointer",
                      fontWeight: 700,
                      fontSize: 11,
                    }}
                  >
                    {copiado ? "✓ Copiado" : "📋 Copiar"}
                  </button>
                </div>
              </div>

              {/* Instruções */}
              <div
                style={{
                  background: "#FFF8E1",
                  borderRadius: 12,
                  padding: 14,
                  marginBottom: 12,
                  border: "1px solid #F0A500",
                }}
              >
                <div style={{ fontSize: 11, fontWeight: 700, color: "#856404", marginBottom: 8 }}>
                  📱 Como fazer a transferência:
                </div>
                <ol
                  style={{
                    fontSize: 10,
                    color: "#856404",
                    paddingLeft: 16,
                    margin: 0,
                    lineHeight: 1.6,
                  }}
                >
                  <li>Abra o seu aplicativo bancário</li>
                  <li>Selecione a opção PIX</li>
                  <li>Escolha "Ler QR Code" ou "Copiar e Colar"</li>
                  <li>Confirme o pagamento</li>
                </ol>
              </div>

              {/* Info confirmação automática */}
              <div
                style={{
                  background: "#E8F5E9",
                  borderRadius: 12,
                  padding: 14,
                  border: "1px solid #00A893",
                }}
              >
                <div style={{ fontSize: 11, fontWeight: 700, color: "#2E7D32", marginBottom: 6 }}>
                  ✅ Confirmação Automática
                </div>
                <div style={{ fontSize: 10, color: "#2E7D32", lineHeight: 1.5 }}>
                  Sua compra será processada automaticamente assim que o pagamento for confirmado.
                </div>
              </div>
            </div>
          ) : null)}
      </div>
    </div>
  );
}