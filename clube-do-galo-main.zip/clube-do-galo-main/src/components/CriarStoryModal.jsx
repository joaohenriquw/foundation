import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";

export default function CriarStoryModal({ user, onClose, onConcluido }) {
  const [etapa, setEtapa] = useState("escolha"); // escolha | editor | enquete
  const [midia, setMidia] = useState(null);
  const [midiaType, setMidiaType] = useState("foto"); // foto | video
  const [texto, setTexto] = useState("");
  const [mostraTexto, setMostraTexto] = useState(false);
  const [mostraEnquete, setMostraEnquete] = useState(false);
  const [opcoes, setOpcoes] = useState(["", ""]);
  const [pergunta, setPergunta] = useState("");
  const [uploadando, setUploadando] = useState(false);
  const [saving, setSaving] = useState(false);

  const cameraRef = useRef(null);
  const galeriaRef = useRef(null);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadando(true);
    const res = await base44.integrations.Core.UploadFile({ file });
    setMidia(res.file_url);
    setMidiaType(file.type.startsWith("video") ? "video" : "foto");
    setUploadando(false);
    setEtapa("editor");
  };

  const salvar = async () => {
    setSaving(true);
    const dataExpiracao = new Date();
    dataExpiracao.setHours(dataExpiracao.getHours() + 24);

    const tipo = mostraEnquete ? "enquete" : midiaType;
    const opcoesEnquete = mostraEnquete
      ? opcoes.filter(o => o.trim()).map(o => ({ texto: o, votos: 0 }))
      : [];

    await base44.entities.Story.create({
      usuario_id: user?.id || user?.email,
      usuario_email: user?.email,
      usuario_nome: user?.full_name || user?.email,
      tipo,
      midia_url: midia,
      titulo: mostraEnquete ? pergunta : texto,
      descricao: texto,
      opcoes_enquete: opcoesEnquete,
      data_expiracao: dataExpiracao.toISOString(),
      ativo: true,
    });

    setSaving(false);
    onConcluido?.();
    onClose();
  };

  // Tela de escolha
  if (etapa === "escolha") {
    return (
      <div style={{ position: "fixed", inset: 0, background: "#000", zIndex: 3000, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <input ref={cameraRef} type="file" accept="image/*,video/*" capture="environment" onChange={handleFile} style={{ display: "none" }} />
        <input ref={galeriaRef} type="file" accept="image/*,video/*" onChange={handleFile} style={{ display: "none" }} />

        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 22, fontWeight: 900, color: "#fff", marginBottom: 8 }}>Novo Story</div>
        <div style={{ fontSize: 13, color: "rgba(255,255,255,.6)", marginBottom: 48 }}>Como quer compartilhar?</div>

        <div style={{ display: "flex", gap: 24, marginBottom: 40 }}>
          <button onClick={() => cameraRef.current?.click()}
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, background: "none", border: "none", cursor: "pointer" }}>
            <div style={{ width: 80, height: 80, borderRadius: "50%", background: "rgba(255,255,255,.15)", border: "2px solid rgba(255,255,255,.3)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36 }}>📷</div>
            <span style={{ color: "#fff", fontSize: 13, fontWeight: 700, fontFamily: "Montserrat,sans-serif" }}>Câmera</span>
          </button>

          <button onClick={() => galeriaRef.current?.click()}
            style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, background: "none", border: "none", cursor: "pointer" }}>
            <div style={{ width: 80, height: 80, borderRadius: "50%", background: "rgba(255,255,255,.15)", border: "2px solid rgba(255,255,255,.3)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36 }}>🖼️</div>
            <span style={{ color: "#fff", fontSize: 13, fontWeight: 700, fontFamily: "Montserrat,sans-serif" }}>Galeria</span>
          </button>
        </div>

        {uploadando && (
          <div style={{ color: "rgba(255,255,255,.7)", fontSize: 13 }}>⏳ Carregando...</div>
        )}

        <button onClick={onClose} style={{ color: "rgba(255,255,255,.5)", background: "none", border: "1px solid rgba(255,255,255,.2)", borderRadius: 20, padding: "8px 24px", cursor: "pointer", fontSize: 13 }}>
          Cancelar
        </button>
      </div>
    );
  }

  // Editor fullscreen estilo Instagram
  return (
    <div style={{ position: "fixed", inset: 0, background: "#000", zIndex: 3000, display: "flex", flexDirection: "column" }}>

      {/* Preview da mídia */}
      <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
        {midiaType === "video" ? (
          <video src={midia} autoPlay loop muted playsInline style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        ) : (
          <div style={{ width: "100%", height: "100%", background: `url(${midia}) center/cover no-repeat` }} />
        )}

        {/* Texto sobreposto na foto */}
        {mostraTexto && (
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
            <textarea
              autoFocus
              value={texto}
              onChange={e => setTexto(e.target.value)}
              placeholder="Escreva algo..."
              style={{
                background: "rgba(0,0,0,.45)",
                color: "#fff",
                border: "none",
                outline: "none",
                fontSize: 22,
                fontWeight: 700,
                fontFamily: "Montserrat,sans-serif",
                textAlign: "center",
                borderRadius: 12,
                padding: "12px 16px",
                width: "100%",
                resize: "none",
                backdropFilter: "blur(4px)",
                lineHeight: 1.4,
              }}
              rows={3}
            />
          </div>
        )}

        {/* Enquete sobreposta */}
        {mostraEnquete && (
          <div style={{ position: "absolute", bottom: 140, left: 16, right: 16 }}>
            <div style={{ background: "rgba(255,255,255,.95)", borderRadius: 16, padding: 16, backdropFilter: "blur(10px)" }}>
              <input
                value={pergunta}
                onChange={e => setPergunta(e.target.value)}
                placeholder="Faça uma pergunta..."
                autoFocus
                style={{ width: "100%", border: "none", borderBottom: "2px solid #170073", outline: "none", fontSize: 15, fontWeight: 700, color: "#101213", marginBottom: 12, padding: "4px 0", boxSizing: "border-box", background: "transparent" }}
              />
              <div style={{ display: "grid", gap: 8 }}>
                {opcoes.map((op, i) => (
                  <input
                    key={i}
                    value={op}
                    onChange={e => {
                      const nova = [...opcoes];
                      nova[i] = e.target.value;
                      setOpcoes(nova);
                    }}
                    placeholder={`Opção ${i + 1}`}
                    style={{ padding: "8px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", background: i === 0 ? "#EEF0FF" : "#FFF8E1", fontWeight: 600, color: "#101213" }}
                  />
                ))}
              </div>
              {opcoes.length < 4 && (
                <button onClick={() => setOpcoes([...opcoes, ""])}
                  style={{ marginTop: 8, fontSize: 12, color: "#170073", background: "none", border: "none", cursor: "pointer", fontWeight: 700 }}>
                  + Adicionar opção
                </button>
              )}
            </div>
          </div>
        )}

        {/* Botão fechar */}
        <button onClick={onClose} style={{ position: "absolute", top: 16, left: 16, background: "rgba(0,0,0,.4)", border: "none", borderRadius: "50%", width: 38, height: 38, color: "#fff", fontSize: 18, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>

        {/* Ferramentas (topo direito) */}
        <div style={{ position: "absolute", top: 16, right: 16, display: "flex", flexDirection: "column", gap: 10 }}>
          <button onClick={() => { setMostraTexto(!mostraTexto); setMostraEnquete(false); }}
            style={{ background: mostraTexto ? "#fff" : "rgba(0,0,0,.4)", border: "none", borderRadius: 10, width: 44, height: 44, color: mostraTexto ? "#170073" : "#fff", fontSize: 18, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900 }}>
            Aa
          </button>
          <button onClick={() => { setMostraEnquete(!mostraEnquete); setMostraTexto(false); }}
            style={{ background: mostraEnquete ? "#fff" : "rgba(0,0,0,.4)", border: "none", borderRadius: 10, width: 44, height: 44, color: mostraEnquete ? "#F0A500" : "#fff", fontSize: 20, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            🗳️
          </button>
        </div>
      </div>

      {/* Rodapé */}
      <div style={{ padding: "16px 20px 32px", background: "rgba(0,0,0,.8)", display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ width: 42, height: 42, borderRadius: "50%", background: "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 16, fontWeight: 900, fontFamily: "Montserrat,sans-serif", flexShrink: 0 }}>
          {user?.full_name?.[0] || "U"}
        </div>
        <div style={{ flex: 1, color: "rgba(255,255,255,.7)", fontSize: 13 }}>Seu story • 24h</div>
        <button onClick={salvar} disabled={saving}
          style={{ background: saving ? "#999" : "linear-gradient(135deg,#170073,#00A893)", border: "none", borderRadius: 22, padding: "11px 24px", color: "#fff", fontFamily: "Montserrat,sans-serif", fontWeight: 900, fontSize: 14, cursor: saving ? "default" : "pointer", display: "flex", alignItems: "center", gap: 8 }}>
          {saving ? "Publicando..." : "Publicar →"}
        </button>
      </div>
    </div>
  );
}