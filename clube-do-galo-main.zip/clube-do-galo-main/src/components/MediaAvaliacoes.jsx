import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";

export default function MediaAvaliacoes({ vendedorEmail }) {
  const [avaliacoes, setAvaliacoes] = useState([]);
  const [media, setMedia] = useState(0);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const carregar = async () => {
      const data = await base44.entities.Avaliacao.filter({ vendedor_email: vendedorEmail }, "-created_date", 100);
      setAvaliacoes(data);
      if (data.length > 0) {
        const soma = data.reduce((acc, a) => acc + (a.nota || 0), 0);
        setMedia(soma / data.length);
        setTotal(data.length);
      }
      setLoading(false);
    };
    carregar();

    const unsub = base44.entities.Avaliacao.subscribe((ev) => {
      if (ev.data?.vendedor_email === vendedorEmail) carregar();
    });
    return unsub;
  }, [vendedorEmail]);

  if (loading) return null;
  if (total === 0) return null;

  const estrelas = Math.round(media * 2) / 2;
  const porcentagens = [5, 4, 3, 2, 1].map(n => ({
    nota: n,
    qtd: avaliacoes.filter(a => a.nota === n).length,
    pct: (avaliacoes.filter(a => a.nota === n).length / total) * 100,
  }));

  return (
    <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px", marginBottom: 14 }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 4, marginBottom: 2 }}>
            <span style={{ fontSize: 24 }}>⭐</span>
            <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 20, fontWeight: 900, color: "#170073" }}>{estrelas.toFixed(1)}</span>
          </div>
          <div style={{ fontSize: 11, color: "#57636C" }}>{total} avaliação{total > 1 ? "ões" : ""}</div>
        </div>
      </div>

      {/* Distribuição */}
      {porcentagens.map(p => (
        <div key={p.nota} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: "#57636C", minWidth: 16 }}>{p.nota}</span>
          <span style={{ fontSize: 16 }}>⭐</span>
          <div style={{ flex: 1, height: 8, background: "#F1F4F8", borderRadius: 4, overflow: "hidden" }}>
            <div style={{ height: "100%", background: "#F0A500", width: `${p.pct}%`, transition: ".2s" }} />
          </div>
          <span style={{ fontSize: 11, color: "#57636C", minWidth: 30, textAlign: "right" }}>{p.qtd}</span>
        </div>
      ))}

      {/* Comentários */}
      {avaliacoes.filter(a => a.comentario?.trim()).length > 0 && (
        <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid #F1F4F8" }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: "#101213", marginBottom: 10 }}>📝 Avaliações recentes</div>
          {avaliacoes.filter(a => a.comentario?.trim()).slice(0, 3).map(a => (
            <div key={a.id} style={{ background: "#F8FAFC", borderRadius: 10, padding: "10px 12px", marginBottom: 8 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
                <div style={{ flex: 1 }}>
                  <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 800, color: "#101213" }}>{a.comprador_nome}</span>
                </div>
                <span style={{ fontSize: 12 }}>{"⭐".repeat(a.nota)}</span>
              </div>
              <div style={{ fontSize: 11, color: "#57636C", lineHeight: 1.4 }}>{a.comentario}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}