import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";

export default function ComentariosLeilao({ leilaoId, user }) {
  const [comentarios, setComentarios] = useState([]);
  const [texto, setTexto] = useState("");
  const [enviando, setEnviando] = useState(false);
  const bottomRef = useRef(null);

  const carregar = async () => {
    const data = await base44.entities.LeilaoComentario.filter({ leilao_id: leilaoId }, "created_date", 100);
    setComentarios(data);
  };

  useEffect(() => {
    carregar();
    const unsub = base44.entities.LeilaoComentario.subscribe((ev) => {
      if (ev.type === "create" && ev.data?.leilao_id === leilaoId) {
        setComentarios(prev => {
          // evitar duplicata se já existe
          if (prev.find(c => c.id === ev.data.id)) return prev;
          return [...prev, ev.data];
        });
      }
      if (ev.type === "delete") {
        setComentarios(prev => prev.filter(c => c.id !== ev.id));
      }
    });
    return unsub;
  }, [leilaoId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [comentarios]);

  const enviar = async () => {
    if (!texto.trim() || !user || enviando) return;
    setEnviando(true);
    await base44.entities.LeilaoComentario.create({
      leilao_id: leilaoId,
      autor_id: user.id || user.email,
      autor_nome: user.full_name || user.email,
      autor_email: user.email,
      texto: texto.trim(),
    });
    setTexto("");
    setEnviando(false);
  };

  const excluir = async (id) => {
    setComentarios(prev => prev.filter(c => c.id !== id));
    await base44.entities.LeilaoComentario.delete(id);
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); enviar(); }
  };

  const iniciais = (nome) => nome ? nome.split(" ").map(p => p[0]).slice(0, 2).join("").toUpperCase() : "?";

  return (
    <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E8ECF0", overflow: "hidden" }}>
      {/* Header */}
      <div style={{ padding: "14px 16px 10px", borderBottom: "1px solid #F1F4F8", display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 16 }}>💬</span>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>
          Comentários ({comentarios.length})
        </div>
      </div>

      {/* Lista */}
      <div style={{ maxHeight: 320, overflowY: "auto", padding: "8px 0" }}>
        {comentarios.length === 0 ? (
          <div style={{ padding: "24px 16px", textAlign: "center", color: "#57636C", fontSize: 12 }}>
            <div style={{ fontSize: 28, marginBottom: 6 }}>💬</div>
            Seja o primeiro a comentar!
          </div>
        ) : comentarios.map(c => (
          <div key={c.id} style={{ display: "flex", gap: 10, padding: "8px 16px", alignItems: "flex-start" }}>
            <div style={{
              width: 34, height: 34, borderRadius: "50%", flexShrink: 0,
              background: c.autor_email === user?.email ? "linear-gradient(135deg,#170073,#00A893)" : "linear-gradient(135deg,#F0A500,#E21C3D)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#fff",
            }}>
              {iniciais(c.autor_nome)}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
                <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213" }}>
                  {c.autor_nome}
                </span>
                <span style={{ fontSize: 10, color: "#BDBDBD" }}>
                  {new Date(c.created_date).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                </span>
                {(c.autor_email === user?.email || user?.role === "admin") && (
                  <button onClick={() => excluir(c.id)}
                    style={{ marginLeft: "auto", background: "none", border: "none", color: "#E21C3D", fontSize: 11, cursor: "pointer", padding: "0 4px" }}>
                    🗑️
                  </button>
                )}
              </div>
              <div style={{
                background: c.autor_email === user?.email ? "#F0F4FF" : "#F8FAFC",
                borderRadius: "0 12px 12px 12px", padding: "8px 12px",
                fontSize: 13, color: "#101213", lineHeight: 1.5, wordBreak: "break-word",
                border: c.autor_email === user?.email ? "1px solid #E0E8FF" : "1px solid #F1F4F8",
              }}>
                {c.texto}
              </div>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      {user ? (
        <div style={{ padding: "12px 16px", borderTop: "1px solid #F1F4F8", display: "flex", gap: 8, alignItems: "flex-end" }}>
          <div style={{ width: 32, height: 32, borderRadius: "50%", flexShrink: 0, background: "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 900, color: "#fff" }}>
            {iniciais(user.full_name || user.email)}
          </div>
          <textarea
            value={texto}
            onChange={e => setTexto(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Escreva um comentário... (Enter para enviar)"
            rows={1}
            style={{ flex: 1, padding: "9px 12px", borderRadius: 12, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", resize: "none", fontFamily: "DM Sans,sans-serif", lineHeight: 1.5 }}
          />
          <button onClick={enviar} disabled={!texto.trim() || enviando}
            style={{ padding: "9px 14px", borderRadius: 12, border: "none", background: !texto.trim() || enviando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: !texto.trim() || enviando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, whiteSpace: "nowrap" }}>
            {enviando ? "..." : "Enviar"}
          </button>
        </div>
      ) : (
        <div style={{ padding: "12px 16px", borderTop: "1px solid #F1F4F8", textAlign: "center", fontSize: 12, color: "#57636C" }}>
          Faça login para comentar
        </div>
      )}
    </div>
  );
}