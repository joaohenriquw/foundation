import { useEffect } from "react";
import { base44 } from "@/api/base44Client";

export function useNotificacoes(user) {
  useEffect(() => {
    if (!user?.email) return;

    // Monitor: Novos lances em leilões que estou participando
    const unsubLances = base44.entities.LeilaoLance.subscribe((event) => {
      if (event.type === "create" && event.data?.user_email !== user.email) {
        // Verificar se estou participando deste leilão
        base44.entities.LeilaoLance.filter({ leilao_id: event.data.leilao_id, user_email: user.email }).then(meus => {
          if (meus.length > 0) {
            // Buscar dados do leilão
            base44.entities.Leilao.filter({ id: event.data.leilao_id }).then(leiloes => {
              if (leiloes[0]) {
                const leilao = leiloes[0];
                base44.entities.Notificacao.create({
                  destinatario_email: user.email,
                  titulo: "💰 Novo lance!",
                  mensagem: `${event.data.user_nome} lançou R$ ${Number(event.data.valor).toLocaleString("pt-BR")} em "${leilao.animal_nome}"`,
                  tipo: "leilao",
                  icone: "💰",
                  link: `/leilao/${event.data.leilao_id}`,
                });
              }
            });
          }
        });
      }
    });

    // Monitor: Encerramento de leilões favoritos
    const unsubLeiloes = base44.entities.Leilao.subscribe((event) => {
      if (event.type === "update" && event.data?.status === "encerrado") {
        // Verificar se tenho este animal nos favoritos
        base44.entities.Favorito.filter({ usuario_email: user.email, animal_id: event.data.animal_id }).then(favs => {
          if (favs.length > 0) {
            base44.entities.Notificacao.create({
              destinatario_email: user.email,
              titulo: "🏆 Leilão encerrado!",
              mensagem: `O leilão de "${event.data.animal_nome}" foi encerrado. Ganhador: ${event.data.ganhador_nome}`,
              tipo: "leilao",
              icone: "🏆",
              link: `/leilao/${event.data.id}`,
            });
          }
        });
      }
    });

    // Monitor: Avisos de pagamento pendente
    const unsubTransacoes = base44.entities.Transacao.subscribe((event) => {
      if (event.type === "create" && event.data?.cliente_email === user.email) {
        if (event.data.status === "pending") {
          base44.entities.Notificacao.create({
            destinatario_email: user.email,
            titulo: "💳 Pagamento pendente",
            mensagem: `Sua parcela de R$ ${Number(event.data.valor).toLocaleString("pt-BR")} está aguardando confirmação`,
            tipo: "sistema",
            icone: "💳",
            link: "/perfil-usuario",
          });
        } else if (event.data.status === "approved") {
          base44.entities.Notificacao.create({
            destinatario_email: user.email,
            titulo: "✅ Pagamento confirmado!",
            mensagem: `Sua parcela de R$ ${Number(event.data.valor).toLocaleString("pt-BR")} foi confirmada`,
            tipo: "sistema",
            icone: "✅",
            link: "/perfil-usuario",
          });
        }
      }
    });

    // Monitor: Rifas finalizando e novas rifas lançadas
    const unsubRifas = base44.entities.Rifa.subscribe((event) => {
      if (event.type === "create" && event.data?.dono_email !== user.email) {
        // Nova rifa lançada - notifica apenas quem não é o dono
        base44.entities.Notificacao.create({
          destinatario_email: user.email,
          titulo: "🎰 Nova rifa lançada!",
          mensagem: `Rifa de "${event.data.animal_nome}" foi aberta. ${event.data.qtd_numeros} números disponíveis!`,
          tipo: "rifa",
          icone: "🎰",
          link: `/rifa/${event.data.id}`,
        });
      } else if (event.type === "update" && event.data?.status === "encerrada") {
        // Rifa finalizada - verificar se participei
        base44.entities.RifaBilhete.filter({ rifa_id: event.data.id, comprador_email: user.email }).then(bilhetes => {
          if (bilhetes.length > 0) {
            const venci = event.data.ganhador_email === user.email;
            base44.entities.Notificacao.create({
              destinatario_email: user.email,
              titulo: venci ? "🎉 Você ganhou a rifa!" : "🎰 Rifa finalizada",
              mensagem: venci 
                ? `Parabéns! Você venceu a rifa de "${event.data.animal_nome}"! Valor: R$ ${Number(event.data.ganhador_premio).toLocaleString("pt-BR")}`
                : `A rifa de "${event.data.animal_nome}" foi finalizada. Ganhador: ${event.data.ganhador_nome}`,
              tipo: "rifa",
              icone: venci ? "🎉" : "🎰",
              link: `/rifa/${event.data.id}`,
            });
          }
        });
      }
    });

    // Monitor: Stories de usuários (notificar apenas seguidores/interessados)
    const unsubStories = base44.entities.Story.subscribe((event) => {
      if (event.type === "create" && event.data?.ativo && event.data?.autor_id !== user.id) {
        // Notificar se é de um criador que o usuário segue ou tem favoritos
        base44.entities.Favorito.filter({ usuario_email: user.email }).then(favs => {
          const autoresComFavs = new Set(favs.map(f => f.proprietario_id));
          if (autoresComFavs.has(event.data.autor_id)) {
            base44.entities.Notificacao.create({
              destinatario_email: user.email,
              titulo: "📸 Novo story!",
              mensagem: `${event.data.autor_nome} postou um novo story${event.data.tipo_midia === "video" ? " em vídeo" : ""}`,
              tipo: "stories",
              icone: "📸",
              link: "/",
            });
          }
        });
      }
    });

    return () => {
      unsubLances();
      unsubLeiloes();
      unsubTransacoes();
      unsubRifas();
      unsubStories();
    };
  }, [user?.email, user?.id]);
}