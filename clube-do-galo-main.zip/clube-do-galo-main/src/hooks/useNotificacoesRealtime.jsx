import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export const useNotificacoesRealtime = (userEmail) => {
  useEffect(() => {
    if (!userEmail) return;

    // Subscribe a TODAS as notificações
    const unsubscribe = base44.entities.Notificacao.subscribe((event) => {
      // Apenas criar/atualizar (não deletar)
      if (event.type !== 'create') return;

      const notif = event.data;
      
      // Filtrar apenas notificações para este usuário
      if (notif.destinatario_email !== userEmail) return;

      // Mapear ícones/tipos
      const tipoConfig = {
        'leilao': { icone: '🏆', tempo: 6000 },
        'rifa': { icone: '🎟️', tempo: 6000 },
        'sistema': { icone: '📢', tempo: 4000 },
        'consultoria': { icone: '💬', tempo: 5000 },
        'vitrine': { icone: '🏪', tempo: 5000 },
        'stories': { icone: '📸', tempo: 4000 },
        'anilha': { icone: '📿', tempo: 5000 },
      };

      const config = tipoConfig[notif.tipo] || { icone: notif.icone || '📣', tempo: 4000 };

      // Toast customizado
      const toastId = toast.custom(
        (t) => (
          <div style={{
            background: '#fff',
            borderRadius: 12,
            padding: '14px 16px',
            boxShadow: '0 8px 24px rgba(0,0,0,.15)',
            display: 'flex',
            gap: 10,
            alignItems: 'flex-start',
            minWidth: 300,
            border: '1px solid #E8ECF0',
          }}>
            <span style={{ fontSize: 20, flexShrink: 0 }}>{config.icone}</span>
            <div style={{ flex: 1 }}>
              <div style={{
                fontFamily: 'Montserrat,sans-serif',
                fontSize: 13,
                fontWeight: 800,
                color: '#101213',
                marginBottom: 4,
              }}>
                {notif.titulo}
              </div>
              <div style={{
                fontSize: 12,
                color: '#57636C',
                lineHeight: 1.4,
              }}>
                {notif.mensagem}
              </div>
            </div>
            <button
              onClick={() => toast.dismiss(t)}
              style={{
                background: 'none',
                border: 'none',
                fontSize: 16,
                cursor: 'pointer',
                padding: 0,
                color: '#BDBDBD',
              }}
            >
              ✕
            </button>
          </div>
        ),
        {
          duration: config.tempo,
          position: 'top-right',
        }
      );

      // Marcar como lida após 2 segundos (dar tempo de ler)
      setTimeout(() => {
        base44.entities.Notificacao.update(notif.id, { lida: true }).catch(() => {});
      }, 2000);
    });

    return unsubscribe;
  }, [userEmail]);
};