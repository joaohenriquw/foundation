import { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export function useLanceNotificacoes(leilaoId, userEmail, meuMaiorLance) {
  const ultimoLanceRef = useRef(null);

  useEffect(() => {
    if (!leilaoId || !userEmail || !meuMaiorLance) return;

    ultimoLanceRef.current = meuMaiorLance;

    const unsubscribe = base44.entities.LeilaoLance.subscribe((event) => {
      if (event.data?.leilao_id !== leilaoId) return;

      const { valor, user_email, user_nome } = event.data;
      
      // Se foi o próprio usuário, não notifica
      if (user_email === userEmail) {
        ultimoLanceRef.current = valor;
        return;
      }

      // Se um novo lance superou o maior lance do usuário
      if (valor > ultimoLanceRef.current) {
        toast.error(`🚨 Seu lance foi superado!`, {
          description: `${user_nome} ofertou R$ ${Number(valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
          action: {
            label: '🔨 Dar novo lance',
            onClick: () => {
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          },
          duration: 8000,
        });
      }
    });

    return unsubscribe;
  }, [leilaoId, userEmail, meuMaiorLance]);
}