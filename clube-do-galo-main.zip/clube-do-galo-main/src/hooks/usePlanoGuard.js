import { useState } from 'react';
import { base44 } from '@/api/base44Client';

export const usePlanoGuard = () => {
  const [validacao, setValidacao] = useState(null);
  const [mostraModal, setMostraModal] = useState(false);
  const [carregando, setCarregando] = useState(false);

  const validar = async (tipo) => {
    setCarregando(true);
    try {
      const funcao = `validarAcesso${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`;
      const res = await base44.functions.invoke(funcao, {});

      if (!res.data.tem_acesso) {
        setValidacao(res.data);
        setMostraModal(true);
        return false;
      }

      setValidacao(res.data);
      return true;
    } catch (error) {
      console.error('Erro na validação:', error);
      return false;
    } finally {
      setCarregando(false);
    }
  };

  const fecharModal = () => {
    setMostraModal(false);
  };

  return {
    validar,
    validacao,
    mostraModal,
    carregando,
    fecharModal,
  };
};