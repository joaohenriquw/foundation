import { useState } from 'react';
import { base44 } from '@/api/base44Client';

export const useValidarAcesso = () => {
  const [validando, setValidando] = useState(false);
  const [erroValidacao, setErroValidacao] = useState(null);

  const validarLeilao = async () => {
    setValidando(true);
    setErroValidacao(null);
    try {
      const res = await base44.functions.invoke('validarAcessoCriarLeilao', {});
      setValidando(false);
      return res.data;
    } catch (e) {
      setErroValidacao(e.message);
      setValidando(false);
      return { tem_acesso: false, error: e.message };
    }
  };

  const validarRifa = async () => {
    setValidando(true);
    setErroValidacao(null);
    try {
      const res = await base44.functions.invoke('validarAcessoCriarRifa', {});
      setValidando(false);
      return res.data;
    } catch (e) {
      setErroValidacao(e.message);
      setValidando(false);
      return { tem_acesso: false, error: e.message };
    }
  };

  const validarVitrine = async () => {
    setValidando(true);
    setErroValidacao(null);
    try {
      const res = await base44.functions.invoke('validarAcessoVitrine', {});
      setValidando(false);
      return res.data;
    } catch (e) {
      setErroValidacao(e.message);
      setValidando(false);
      return { tem_acesso: false, error: e.message };
    }
  };

  const validarStories = async () => {
    setValidando(true);
    setErroValidacao(null);
    try {
      const res = await base44.functions.invoke('validarAcessoStories', {});
      setValidando(false);
      return res.data;
    } catch (e) {
      setErroValidacao(e.message);
      setValidando(false);
      return { tem_acesso: false, error: e.message };
    }
  };

  const validarConsultoria = async () => {
    setValidando(true);
    setErroValidacao(null);
    try {
      const res = await base44.functions.invoke('validarAcessoConsultoria', {});
      setValidando(false);
      return res.data;
    } catch (e) {
      setErroValidacao(e.message);
      setValidando(false);
      return { tem_acesso: false, error: e.message };
    }
  };

  return {
    validando,
    erroValidacao,
    validarLeilao,
    validarRifa,
    validarVitrine,
    validarStories,
    validarConsultoria
  };
};