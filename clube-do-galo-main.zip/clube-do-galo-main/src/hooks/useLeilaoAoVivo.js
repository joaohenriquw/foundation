import { useEffect, useState, useCallback } from 'react';

export function useLeilaoAoVivo(leilaoId) {
  const [lances, setLances] = useState([]);
  const [conectado, setConectado] = useState(false);
  const [status, setStatus] = useState('desconectado');
  const [encerrado, setEncerrado] = useState(false);
  const [ganhador, setGanhador] = useState(null);

  // Conectar ao SSE
  useEffect(() => {
    if (!leilaoId) return;

    const connectSSE = () => {
      const eventSource = new EventSource(
        `/api/v1/leilaoAoVivoSSE?leilao_id=${leilaoId}&action=connect`
      );

      eventSource.onopen = () => {
        setConectado(true);
        setStatus('conectado');
      };

      eventSource.onmessage = (event) => {
        try {
          const dados = JSON.parse(event.data);

          if (dados.tipo === 'lance') {
            setLances(prev => [dados, ...prev]);
            setStatus(`Lance: R$ ${dados.valor} por ${dados.lancador}`);
          } else if (dados.tipo === 'encerramento') {
            setEncerrado(true);
            setGanhador(dados.ganhador);
            setStatus(`✅ ${dados.mensagem}`);
            eventSource.close();
          }
        } catch (e) {
          console.error('Erro ao parsear evento:', e);
        }
      };

      eventSource.onerror = (error) => {
        console.error('Erro SSE:', error);
        setConectado(false);
        setStatus('desconectado');
        eventSource.close();
        setTimeout(connectSSE, 3000);
      };

      return eventSource;
    };

    const eventSource = connectSSE();

    return () => {
      eventSource.close();
      setConectado(false);
    };
  }, [leilaoId]);

  // Enviar novo lance
  const enviarLance = useCallback(async (valor, lancadorNome, lancadorEmail) => {
    try {
      const res = await fetch('/api/v1/leilaoAoVivoSSE?action=lance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leilao_id: leilaoId,
          lance_valor: valor,
          lancador_nome: lancadorNome,
          lancador_email: lancadorEmail,
        }),
      });
      return res.ok;
    } catch (error) {
      console.error('Erro ao enviar lance:', error);
      return false;
    }
  }, [leilaoId]);

  // Encerrar leilão
  const encerrarLeilao = useCallback(async (ganhadorNome, ganhadorEmail) => {
    try {
      const res = await fetch('/api/v1/leilaoAoVivoSSE?action=encerrar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leilao_id: leilaoId,
          ganhador_nome: ganhadorNome,
          ganhador_email: ganhadorEmail,
        }),
      });
      return res.ok;
    } catch (error) {
      console.error('Erro ao encerrar leilão:', error);
      return false;
    }
  }, [leilaoId]);

  return {
    lances,
    conectado,
    status,
    encerrado,
    ganhador,
    enviarLance,
    encerrarLeilao,
  };
}