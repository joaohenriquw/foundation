import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import BottomNav from "../components/BottomNav";
import ModalCriarDuelo from "../components/ModalCriarDuelo";
import SelectField from "../components/SelectField";

export default function Calendario() {
  const [user, setUser] = useState(null);
  const [eventos, setEventos] = useState([]);
  const [eventosDoUsuario, setEventosDoUsuario] = useState([]);
  const [mesSelecionado, setMesSelecionado] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [abaMostrada, setAbaMostrada] = useState("calendario");
  const [modalAberto, setModalAberto] = useState(false);
  const [modalDueloAberto, setModalDueloAberto] = useState(false);
  const [eventoSelecionado, setEventoSelecionado] = useState(null);
  const [formulario, setFormulario] = useState({ titulo: "", tipo: "exposicao", data_inicio: "", data_fim: "", local: "", cidade: "", estado: "", taxa_inscricao: 0 });
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      if (!me) { setLoading(false); return; }
      const [ev, evUser] = await Promise.all([
        base44.entities.Evento.list("-created_date", 200),
        base44.entities.Evento.filter({ organizador_email: me.email }, "-created_date", 100),
      ]);
      setEventos(ev);
      setEventosDoUsuario(evUser);
      setLoading(false);
    };
    init();
  }, []);

  const criarEvento = async () => {
    if (!formulario.titulo || !formulario.data_inicio) return;
    setSalvando(true);
    await base44.entities.Evento.create({
      ...formulario,
      organizador_id: user.id,
      organizador_nome: user.full_name,
      organizador_email: user.email,
    });
    const updated = await base44.entities.Evento.filter({ organizador_email: user.email });
    setEventosDoUsuario(updated);
    setFormulario({ titulo: "", tipo: "exposicao", data_inicio: "", data_fim: "", local: "", cidade: "", estado: "", taxa_inscricao: 0 });
    setModalAberto(false);
    setSalvando(false);
  };

  const diasDoMes = () => {
    const ano = mesSelecionado.getFullYear();
    const mes = mesSelecionado.getMonth();
    const primeiro = new Date(ano, mes, 1);
    const ultimo = new Date(ano, mes + 1, 0);
    const dias = [];
    
    for (let i = primeiro.getDate(); i <= ultimo.getDate(); i++) {
      dias.push(new Date(ano, mes, i));
    }
    return dias;
  };

  const eventosDoDia = (data) => {
    const dataStr = data.toISOString().split("T")[0];
    return eventos.filter(e => e.data_inicio?.startsWith(dataStr));
  };

  const podeOrganizar = user && (user.role === "organizador_evento" || user.role === "admin" || user.role === "master_admin");

  const abrirModalDuelo = (evento) => {
    if (!podeOrganizar) return;
    setEventoSelecionado(evento);
    setModalDueloAberto(true);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px 20px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
          <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>📅 Calendário de Eventos</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Exposições e competições ornitológicas</div>
          </div>
        </div>

        {/* Abas */}
        <div style={{ display: "flex", gap: 0, borderBottom: "1px solid rgba(255,255,255,.2)" }}>
          <button onClick={() => setAbaMostrada("calendario")}
            style={{ padding: "12px 14px", background: "none", border: "none", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: abaMostrada === "calendario" ? "#fff" : "rgba(255,255,255,.55)", borderBottom: abaMostrada === "calendario" ? "3px solid #fff" : "none" }}>
            📅 Calendário
          </button>
          {podeOrganizar && (
            <button onClick={() => setAbaMostrada("meus-eventos")}
              style={{ padding: "12px 14px", background: "none", border: "none", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: abaMostrada === "meus-eventos" ? "#fff" : "rgba(255,255,255,.55)", borderBottom: abaMostrada === "meus-eventos" ? "3px solid #fff" : "none" }}>
              🏆 Meus Eventos
            </button>
          )}
          <button onClick={() => setAbaMostrada("inscritos")}
            style={{ padding: "12px 14px", background: "none", border: "none", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: abaMostrada === "inscritos" ? "#fff" : "rgba(255,255,255,.55)", borderBottom: abaMostrada === "inscritos" ? "3px solid #fff" : "none" }}>
            ✅ Minhas Inscrições
          </button>
        </div>
      </div>

      <div style={{ padding: "16px", maxWidth: 800, margin: "0 auto" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 60, color: "#57636C" }}>⏳ Carregando...</div>
        ) : (
          <>
            {/* ===== CALENDÁRIO ===== */}
            {abaMostrada === "calendario" && (
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                  <button onClick={() => setMesSelecionado(new Date(mesSelecionado.getFullYear(), mesSelecionado.getMonth() - 1))}
                    style={{ background: "#fff", border: "1px solid #E8ECF0", borderRadius: 10, padding: "6px 12px", cursor: "pointer", fontWeight: 700 }}>←</button>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213" }}>
                    {mesSelecionado.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}
                  </div>
                  <button onClick={() => setMesSelecionado(new Date(mesSelecionado.getFullYear(), mesSelecionado.getMonth() + 1))}
                    style={{ background: "#fff", border: "1px solid #E8ECF0", borderRadius: 10, padding: "6px 12px", cursor: "pointer", fontWeight: 700 }}>→</button>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4, marginBottom: 14 }}>
                  {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"].map(d => (
                    <div key={d} style={{ textAlign: "center", fontSize: 11, fontWeight: 800, color: "#57636C", padding: 8 }}>{d}</div>
                  ))}
                  {diasDoMes().map((dia, i) => {
                    const temEventos = eventosDoDia(dia).length;
                    return (
                      <div key={i} style={{
                        background: "#fff", borderRadius: 10, padding: 8, border: temEventos > 0 ? "2px solid #170073" : "1px solid #E8ECF0", textAlign: "center", minHeight: 60, display: "flex", flexDirection: "column", cursor: "pointer"
                      }}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 2 }}>{dia.getDate()}</div>
                        {temEventos > 0 && (
                          <div style={{ fontSize: 9, color: "#170073", fontWeight: 700 }}>🎪 {temEventos} evento{temEventos > 1 ? "s" : ""}</div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Próximos eventos */}
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213", marginBottom: 8 }}>📌 Próximos Eventos</div>
                {eventos.length === 0 ? (
                  <div style={{ background: "#fff", borderRadius: 12, padding: 20, textAlign: "center", color: "#57636C" }}>
                    Nenhum evento disponível no momento
                  </div>
                ) : eventos.slice(0, 5).map(e => (
                  <div key={e.id} style={{ background: "#fff", borderRadius: 12, padding: "12px 14px", marginBottom: 8, border: "1px solid #E8ECF0" }}>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213" }}>{e.titulo}</div>
                        <div style={{ fontSize: 11, color: "#57636C" }}>📍 {e.local} · {e.cidade}, {e.estado}</div>
                        <div style={{ fontSize: 10, color: "#57636C", marginTop: 2 }}>
                          📅 {new Date(e.data_inicio).toLocaleDateString("pt-BR")} a {new Date(e.data_fim).toLocaleDateString("pt-BR")}
                        </div>
                        <div style={{ fontSize: 10, color: "#57636C" }}>👤 {e.organizador_nome}</div>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontSize: 11, fontWeight: 800, background: "#170073", color: "#fff", borderRadius: 8, padding: "4px 10px", display: "inline-block" }}>
                          {e.tipo}
                        </div>
                        <div style={{ fontSize: 10, color: "#00A893", fontWeight: 700, marginTop: 6 }}>👥 {e.total_inscritos || 0} inscritos</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== MEUS EVENTOS ===== */}
            {abaMostrada === "meus-eventos" && podeOrganizar && (
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>🏆 Meus Eventos ({eventosDoUsuario.length})</div>
                  <button onClick={() => setModalAberto(true)}
                    style={{ background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", border: "none", borderRadius: 10, padding: "8px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
                    + Criar Evento
                  </button>
                </div>

                {eventosDoUsuario.length === 0 ? (
                  <div style={{ background: "#fff", borderRadius: 12, padding: 20, textAlign: "center", color: "#57636C" }}>
                    <div style={{ fontSize: 32, marginBottom: 8 }}>🎪</div>
                    Você não criou nenhum evento ainda
                  </div>
                ) : eventosDoUsuario.map(e => (
                  <div key={e.id} style={{ background: "#fff", borderRadius: 12, padding: "14px", marginBottom: 10, border: "1px solid #E8ECF0" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                      <div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213" }}>{e.titulo}</div>
                        <div style={{ fontSize: 11, color: "#57636C" }}>{e.local} · {e.cidade}, {e.estado}</div>
                      </div>
                      <div style={{ fontSize: 11, fontWeight: 800, background: e.status === "aberto" ? "#E8F5E9" : e.status === "iniciado" ? "#FFF8E1" : "#F1F4F8", color: e.status === "aberto" ? "#2E7D32" : e.status === "iniciado" ? "#F0A500" : "#57636C", borderRadius: 8, padding: "3px 8px" }}>
                        {e.status}
                      </div>
                    </div>

                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 10 }}>
                      <div style={{ background: "#F8FAFC", borderRadius: 8, padding: 8, textAlign: "center" }}>
                        <div style={{ fontSize: 14, fontWeight: 900, color: "#170073" }}>{e.total_inscritos || 0}</div>
                        <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>Inscritos</div>
                      </div>
                      <div style={{ background: "#F8FAFC", borderRadius: 8, padding: 8, textAlign: "center" }}>
                        <div style={{ fontSize: 14, fontWeight: 900, color: "#170073" }}>0</div>
                        <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>Duelos</div>
                      </div>
                      <div style={{ background: "#F8FAFC", borderRadius: 8, padding: 8, textAlign: "center" }}>
                        <div style={{ fontSize: 12, fontWeight: 900, color: "#00A893" }}>R$ {Number(e.taxa_inscricao || 0).toFixed(2).replace(".", ",")}</div>
                        <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700 }}>Taxa</div>
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: 6 }}>
                      <button onClick={() => abrirModalDuelo(e)} style={{ flex: 1, padding: "8px", borderRadius: 8, background: "#170073", color: "#fff", border: "none", fontWeight: 700, fontSize: 11, cursor: "pointer" }}>
                        ⚔️ Criar Duelo
                      </button>
                      <button style={{ flex: 1, padding: "8px", borderRadius: 8, background: "#E8ECF0", color: "#101213", border: "none", fontWeight: 700, fontSize: 11, cursor: "pointer" }}>
                        👥 Ver Inscrições
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== MINHAS INSCRIÇÕES ===== */}
            {abaMostrada === "inscritos" && (
              <div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213", marginBottom: 8 }}>✅ Minhas Inscrições</div>
                <div style={{ background: "#fff", borderRadius: 12, padding: 20, textAlign: "center", color: "#57636C" }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>📝</div>
                  Você ainda não se inscreveu em nenhum evento
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Modal Criar Duelo */}
      {modalDueloAberto && eventoSelecionado && (
        <ModalCriarDuelo 
          eventoId={eventoSelecionado.id} 
          onClose={() => setModalDueloAberto(false)}
          onDueloCriado={() => {
            // Atualizar eventos aqui se necessário
          }}
        />
      )}

      {/* Modal Criar Evento - Bloqueado */}
      {!podeOrganizar && modalAberto && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center" }}
          onClick={() => setModalAberto(false)}>
          <div style={{ background: "#fff", borderRadius: 16, padding: "24px 20px", textAlign: "center", maxWidth: 300 }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>🔒</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 6 }}>Acesso Restrito</div>
            <div style={{ fontSize: 12, color: "#57636C", marginBottom: 16 }}>Apenas organizadores de eventos podem criar eventos</div>
            <button onClick={() => setModalAberto(false)} style={{ padding: "10px 20px", background: "#170073", color: "#fff", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 700 }}>Entendi</button>
          </div>
        </div>
      )}

      {/* Modal Criar Evento */}
      {modalAberto && podeOrganizar && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2000, display: "flex", alignItems: "flex-end" }}
          onClick={e => e.target === e.currentTarget && setModalAberto(false)}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px", maxHeight: "90vh", overflowY: "auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🎪 Criar Evento</div>
              <button onClick={() => setModalAberto(false)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            <div style={{ display: "grid", gap: 12 }}>
              <input type="text" placeholder="Título do evento *" value={formulario.titulo}
                onChange={e => setFormulario(f => ({ ...f, titulo: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

              <SelectField
                value={formulario.tipo}
                onChange={e => setFormulario(f => ({ ...f, tipo: e.target.value }))}
                options={[
                  { value: "exposicao", label: "Exposição" },
                  { value: "competicao", label: "Competição" },
                  { value: "campeonato", label: "Campeonato" }
                ]}
              />

              <input type="date" placeholder="Data de início *" value={formulario.data_inicio}
                onChange={e => setFormulario(f => ({ ...f, data_inicio: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

              <input type="date" placeholder="Data de término" value={formulario.data_fim}
                onChange={e => setFormulario(f => ({ ...f, data_fim: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

              <input type="text" placeholder="Local *" value={formulario.local}
                onChange={e => setFormulario(f => ({ ...f, local: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

              <input type="text" placeholder="Cidade" value={formulario.cidade}
                onChange={e => setFormulario(f => ({ ...f, cidade: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

              <input type="text" placeholder="Estado" value={formulario.estado}
                onChange={e => setFormulario(f => ({ ...f, estado: e.target.value }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

              <input type="number" placeholder="Taxa de inscrição (R$)" value={formulario.taxa_inscricao}
                onChange={e => setFormulario(f => ({ ...f, taxa_inscricao: parseFloat(e.target.value) || 0 }))}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />

              <button onClick={criarEvento} disabled={salvando || !formulario.titulo || !formulario.data_inicio}
                style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", marginTop: 8, cursor: salvando ? "default" : "pointer",
                  background: salvando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
                {salvando ? "Criando..." : "✅ Criar Evento"}
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}