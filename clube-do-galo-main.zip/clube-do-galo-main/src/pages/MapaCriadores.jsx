import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import { base44 } from "@/api/base44Client";
import NotificacoesSino from "../components/NotificacoesSino";
import BottomNav from "../components/BottomNav";

// Coordenadas aproximadas de principais cidades brasileiras
const COORDENADAS_CIDADES = {
  "São Paulo": [-23.5505, -46.6333],
  "Rio de Janeiro": [-22.9068, -43.1729],
  "Minas Gerais": [-19.9191, -43.9386],
  "Bahia": [-13.0039, -38.5816],
  "Rio Grande do Sul": [-30.0346, -51.2177],
  "Paraná": [-25.4195, -49.2646],
  "Santa Catarina": [-27.5969, -49.2827],
  "Pernambuco": [-8.0476, -34.8770],
  "Ceará": [-3.7319, -38.5269],
  "Goiás": [-15.8267, -48.9385],
  "Espírito Santo": [-20.3155, -40.3128],
  "Brasília": [-15.7942, -47.8822],
};

// Ícone customizado para marcadores
const criarIcone = (cor = "#170073") => {
  return L.icon({
    iconUrl: `data:image/svg+xml;base64,${btoa(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="32" height="32"><circle cx="12" cy="12" r="10" fill="${cor}"/><text x="12" y="14" font-size="16" font-weight="bold" fill="white" text-anchor="middle">🐓</text></svg>`)}`,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
  });
};

export default function MapaCriadores() {
  const [criadores, setCriadores] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [buscaLocal, setBuscaLocal] = useState("");
  const [agrupados, setAgrupados] = useState({});

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);

      // Buscar todos os usuários (criadores) com cidade/estado
      const usuarios = await base44.entities.User.list("-created_date", 500);
      
      // Filtrar usuários que têm cidade e agrupar por localização
      const comLocalizacao = usuarios.filter(u => u.cidade || u.estado);
      
      const agrupado = {};
      for (const criad of comLocalizacao) {
        const chave = `${criad.cidade || "—"}, ${criad.estado || "—"}`;
        if (!agrupado[chave]) {
          agrupado[chave] = {
            local: chave,
            cidade: criad.cidade,
            estado: criad.estado,
            criadores: [],
            coordenadas: COORDENADAS_CIDADES[criad.estado] || [-15, -51],
          };
        }
        agrupado[chave].criadores.push(criad);
      }

      setCriadores(comLocalizacao);
      setAgrupados(agrupado);
      setLoading(false);
    };
    init();
  }, []);

  const locaisFiltrados = Object.values(agrupados).filter(local => {
    const termo = buscaLocal.toLowerCase();
    return (
      local.local.toLowerCase().includes(termo) ||
      local.criadores.some(c => c.full_name?.toLowerCase().includes(termo))
    );
  });

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "16px 16px", position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: 800, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 20, textDecoration: "none" }}>←</Link>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff" }}>🗺️ Mapa de Criadores</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,.75)" }}>{criadores.length} criadores cadastrados</div>
            </div>
          </div>
          {user && <NotificacoesSino userEmail={user.email} />}
        </div>
      </div>

      <div style={{ padding: "12px 12px", maxWidth: 800, margin: "0 auto" }}>
        {/* Input de busca */}
        <div style={{ marginBottom: 12 }}>
          <input
            type="text"
            placeholder="Buscar por cidade, estado ou criador..."
            value={buscaLocal}
            onChange={e => setBuscaLocal(e.target.value)}
            style={{
              width: "100%",
              padding: "10px 14px",
              borderRadius: 10,
              border: "1.5px solid #E8ECF0",
              fontSize: 13,
              outline: "none",
              fontFamily: "'DM Sans', sans-serif",
            }}
          />
        </div>

        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>Carregando mapa...</div>
        ) : locaisFiltrados.length === 0 ? (
          <div style={{ textAlign: "center", padding: 48 }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🗺️</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "#101213" }}>Nenhum criador encontrado</div>
            <div style={{ fontSize: 12, color: "#57636C", marginTop: 6 }}>Tente buscar por outra localização</div>
          </div>
        ) : (
          <>
            {/* Mapa */}
            <div style={{ borderRadius: 14, overflow: "hidden", marginBottom: 14, height: 400, border: "1px solid #E8ECF0" }}>
              <MapContainer center={[-15, -51]} zoom={4} style={{ height: "100%", width: "100%" }}>
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; OpenStreetMap contributors'
                />
                {locaisFiltrados.map(local => (
                  <Marker key={local.local} position={local.coordenadas} icon={criarIcone()}>
                    <Popup>
                      <div style={{ fontFamily: "'DM Sans', sans-serif", width: 180 }}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#170073", marginBottom: 8 }}>
                          📍 {local.local}
                        </div>
                        <div style={{ fontSize: 11, color: "#57636C", marginBottom: 8 }}>
                          {local.criadores.length} criador{local.criadores.length > 1 ? "es" : ""}
                        </div>
                        <div style={{ fontSize: 10, borderTop: "1px solid #E8ECF0", paddingTop: 8 }}>
                          {local.criadores.map(c => (
                            <div key={c.id} style={{ marginBottom: 6, color: "#101213", fontWeight: 600 }}>
                              🐓 {c.full_name}
                              {c.email && <div style={{ fontSize: 9, color: "#57636C", marginTop: 2 }}>{c.email}</div>}
                            </div>
                          ))}
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </div>

            {/* Lista de localizações */}
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#101213", marginBottom: 10 }}>
                📍 Localidades ({locaisFiltrados.length})
              </div>
              <div style={{ display: "grid", gap: 10 }}>
                {locaisFiltrados.map(local => (
                  <div key={local.local} style={{ background: "#fff", borderRadius: 12, border: "1px solid #E8ECF0", padding: 12 }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#170073", marginBottom: 8 }}>
                      📍 {local.local}
                    </div>
                    <div style={{ display: "grid", gap: 8 }}>
                      {local.criadores.map(c => (
                        <div key={c.id} style={{ background: "#F8FAFC", borderRadius: 8, padding: "8px 10px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 700, color: "#101213" }}>
                              🐓 {c.full_name}
                            </div>
                            {c.email && <div style={{ fontSize: 9, color: "#57636C", marginTop: 2 }}>{c.email}</div>}
                          </div>
                          {c.role === "admin" && (
                            <span style={{ background: "#170073", color: "#fff", borderRadius: 4, padding: "2px 6px", fontSize: 9, fontWeight: 700, marginLeft: 8 }}>
                              Admin
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      <BottomNav />
    </div>
  );
}