import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import BotaoFavorito from "../components/BotaoFavorito";
import BottomNav from "../components/BottomNav";
import NotificacoesSino from "../components/NotificacoesSino";

const fmt = (v) => v != null ? "R$ " + Number(v).toFixed(2).replace(".", ",") : "—";

export default function MeusFavoritos() {
  const [favoritos, setFavoritos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [recomendacoes, setRecomendacoes] = useState([]);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);

      if (!me) {
        setLoading(false);
        return;
      }

      // Buscar favoritos do usuário
      const favs = await base44.entities.Favorito.filter(
        { usuario_email: me.email },
        "-created_date",
        100
      );
      setFavoritos(favs);

      // Calcular recomendações baseadas em espécie/criatório mais acessado
      const especiesMap = {};
      const criatorriosMap = {};

      favs.forEach((f) => {
        if (f.animal_especie) {
          especiesMap[f.animal_especie] = (especiesMap[f.animal_especie] || 0) + 1;
        }
        if (f.proprietario_id) {
          criatorriosMap[f.proprietario_id] = {
            id: f.proprietario_id,
            nome: f.proprietario_nome,
            count: (criatorriosMap[f.proprietario_id]?.count || 0) + 1,
          };
        }
      });

      // Top espécie e criatório
      const topEspecie = Object.entries(especiesMap).sort((a, b) => b[1] - a[1])[0]?.[0];
      const topCriatorio = Object.entries(criatorriosMap).sort(
        (a, b) => b[1].count - a[1].count
      )[0]?.[1];

      // Buscar recomendações
      let recomend = [];
      if (topEspecie || topCriatorio) {
        const allVitrine = await base44.entities.VitrineExposicao.filter(
          { ativa: true },
          "-created_date",
          200
        );

        const hoje = new Date().toISOString().split("T")[0];
        const ativas = allVitrine.filter((v) => v.data_expiracao >= hoje);

        recomend = ativas
          .filter((v) => {
            const naoEhFavorito = !favs.some((f) => f.animal_id === v.animal_id);
            const matchEspecie = topEspecie && v.animal_especie === topEspecie;
            const matchCriatorio = topCriatorio && v.proprietario_id === topCriatorio.id;
            return naoEhFavorito && (matchEspecie || matchCriatorio);
          })
          .slice(0, 6);
      }

      setRecomendacoes(recomend);
      setLoading(false);
    };

    init();

    const unsub = base44.entities.Favorito.subscribe(() => {
      init();
    });
    return unsub;
  }, []);

  const recarregar = async () => {
    const me = await base44.auth.me().catch(() => null);
    if (me) {
      const favs = await base44.entities.Favorito.filter(
        { usuario_email: me.email },
        "-created_date",
        100
      );
      setFavoritos(favs);
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 80, color: "#fff" }}>
      <div style={{ background: "#0A0A0A", padding: "52px 20px 16px", borderBottom: "1px solid #1C1C1E" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={() => navigate(-1)} style={{ background: "#1C1C1E", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", fontSize: 18, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#00C9B8" }}>❤️ Meus Favoritos</div>
              <div style={{ fontSize: 11, color: "#888" }}>{favoritos.length} animais salvos</div>
            </div>
          </div>
          {user && <NotificacoesSino userEmail={user.email} />}
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 800, margin: "0 auto" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#555" }}>Carregando...</div>
        ) : favoritos.length === 0 ? (
          <div style={{ textAlign: "center", padding: 48 }}>
            <div style={{ fontSize: 52, marginBottom: 12 }}>🤍</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "#fff" }}>Nenhum favorito ainda</div>
            <div style={{ fontSize: 12, color: "#888", marginTop: 6 }}>Clique no ❤️ para salvar animais</div>
            <Link to="/vitrine" style={{ display: "inline-block", marginTop: 16, padding: "10px 16px", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", borderRadius: 10, textDecoration: "none", fontWeight: 700, fontSize: 12 }}>
              Explorar Vitrine
            </Link>
          </div>
        ) : (
          <>
            {/* Favoritos */}
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff", marginBottom: 12 }}>Seus Favoritos</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
                {favoritos.map((f) => (
                  <div key={f.id} style={{ background: "#1C1C1E", borderRadius: 14, border: "1px solid #333", overflow: "hidden" }}>
                    <div style={{ height: 120, background: f.animal_foto_url ? `url(${f.animal_foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                      {!f.animal_foto_url && <span style={{ fontSize: 48 }}>🐓</span>}
                      <div style={{ position: "absolute", top: 8, right: 8 }}>
                        <BotaoFavorito animal={f} user={user} onFavoritoChange={recarregar} />
                      </div>
                    </div>

                    <div style={{ padding: "12px 14px" }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff", marginBottom: 4 }}>
                      {f.animal_nome}
                      </div>
                      <div style={{ fontSize: 11, color: "#888", marginBottom: 2 }}>🏷️ {f.animal_anilha}</div>
                      {f.animal_especie && <div style={{ fontSize: 11, color: "#888", marginBottom: 2 }}>🐓 {f.animal_especie}</div>}
                      {f.proprietario_nome && <div style={{ fontSize: 11, color: "#888", marginBottom: 8 }}>👤 {f.proprietario_nome}</div>}
                      {f.animal_valor && <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#170073", marginBottom: 8 }}>{fmt(f.animal_valor)}</div>}
                      <button style={{ width: "100%", padding: "8px", borderRadius: 8, border: "1.5px solid #E8ECF0", background: "#fff", color: "#170073", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                        Ver Detalhes
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recomendações */}
            {recomendacoes.length > 0 && (
              <div style={{ marginTop: 32 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 12 }}>
                  ✨ Recomendados para Você
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
                  {recomendacoes.map((r) => (
                    <div key={r.id} style={{ background: "#1C1C1E", borderRadius: 14, border: "1px solid #333", overflow: "hidden" }}>
                      <div style={{ height: 120, background: r.animal_foto_url ? `url(${r.animal_foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                        {!r.animal_foto_url && <span style={{ fontSize: 48 }}>🐓</span>}
                        <div style={{ position: "absolute", top: 8, right: 8 }}>
                          <BotaoFavorito animal={r} user={user} onFavoritoChange={recarregar} />
                        </div>
                      </div>

                      <div style={{ padding: "12px 14px" }}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 4 }}>
                          {r.animal_nome}
                        </div>
                        <div style={{ fontSize: 11, color: "#57636C", marginBottom: 2 }}>🏷️ {r.animal_anilha}</div>
                        {r.animal_especie && <div style={{ fontSize: 11, color: "#57636C", marginBottom: 2 }}>🐓 {r.animal_especie}</div>}
                        {r.proprietario_nome && <div style={{ fontSize: 11, color: "#57636C", marginBottom: 8 }}>👤 {r.proprietario_nome}</div>}
                        {r.animal_valor && <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#170073", marginBottom: 8 }}>{fmt(r.animal_valor)}</div>}
                        <button style={{ width: "100%", padding: "8px", borderRadius: 8, border: "1.5px solid #E8ECF0", background: "#fff", color: "#00A893", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                          Ver Detalhes
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <BottomNav />
    </div>
  );
}