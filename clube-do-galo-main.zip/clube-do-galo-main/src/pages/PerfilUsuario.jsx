import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import jsPDF from "jspdf";
import NotificacoesSino from "../components/NotificacoesSino";
import BottomNav from "../components/BottomNav";
import { getPlano, getPlanoBundles } from "../lib/planos";
import CarteiraCaixa from "../components/CarteiraCaixa";
import CarteiraPix from "../components/CarteiraPix";
import CarteirinhaDigital from "../components/CarteirinhaDigital";
import CriarStoryModal from "../components/CriarStoryModal";
import ModalPagamentoPlan from "../components/ModalPagamentoPlan";
import ModalDeletarConta from "../components/ModalDeletarConta";
import ModalTrocaSenha from "../components/ModalTrocaSenha";

const MESES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

export default function PerfilUsuario() {
  const [user, setUser] = useState(null);
  const [userMeta, setUserMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [abaMostrada, setAbaMostrada] = useState("carteira");
  const [dataInicio, setDataInicio] = useState("");
  const [dataFim, setDataFim] = useState("");
  const [gerandoPDF, setGerandoPDF] = useState(false);
  const [consultoriasMensagens, setConsultoriasMensagens] = useState([]);
  const [consultoriaAberta, setConsultoriaAberta] = useState(null);
  const [anilhasCount, setAnilhasCount] = useState(0);
  const [mostraCriarStory, setMostraCriarStory] = useState(false);
  const [formDados, setFormDados] = useState(null);
  const [salvandoDados, setSalvandoDados] = useState(false);
  const [modalPlano, setModalPlano] = useState(null);
  const [modalPreco, setModalPreco] = useState(null);
  const [mostraDeletarConta, setMostraDeletarConta] = useState(false);
  const [mostraTrocaSenha, setMostraTrocaSenha] = useState(false);
  const [uploadandoFoto, setUploadandoFoto] = useState(false);
  const [fotoPerfil, setFotoPerfil] = useState(null);
  const fotoRef = useRef(null);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me();
      setUser(me);
      setUserMeta({ ...me, role: me.role, plano: me.plano || "iniciante" });
      setFotoPerfil(me.foto_perfil || null);
      if (me) {
        const anilhas = await base44.entities.AnilhaFilha.filter({ usuario_email: me.email });
        setAnilhasCount(anilhas.length);
      }
      if (me) {
        const conversas = await base44.entities.ChatConversa.filter({ usuario_email: me.email }, "-updated_date", 50);
        setConsultoriasMensagens(conversas);
      }
      setLoading(false);
    };
    init();
    const unsub = base44.entities.ChatConversa.subscribe(() => { init(); });
    return unsub;
  }, []);

  const handleUploadFoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadandoFoto(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file });
      await base44.auth.updateMe({ foto_perfil: res.file_url });
      setFotoPerfil(res.file_url);
      setUser(prev => ({ ...prev, foto_perfil: res.file_url }));
    } catch (e) {
      alert("Erro ao fazer upload: " + e.message);
    } finally {
      setUploadandoFoto(false);
    }
  };

  const gerarRelatorioFinanceiro = async () => {
    if (!dataInicio || !dataFim) { alert("Selecione o período!"); return; }
    setGerandoPDF(true);
    const doc = new jsPDF();
    const hoje = new Date().toLocaleDateString("pt-BR");
    doc.setFillColor(23, 0, 115);
    doc.rect(0, 0, 210, 30, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text("RELATÓRIO FINANCEIRO", 15, 18);
    doc.setTextColor(23, 0, 115);
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    doc.text(`Período: ${dataInicio} a ${dataFim}`, 15, 40);
    doc.text(`Gerado em: ${hoje}`, 15, 48);
    doc.text(`Criatório: ${userMeta?.nome_criatório || user?.full_name}`, 15, 56);
    let yPos = 70;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text("📊 RESUMO FINANCEIRO", 15, yPos);
    yPos += 10;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text(`Saldo Atual: ${fmt(userMeta?.saldo || 0)}`, 20, yPos); yPos += 8;
    doc.text(`Comissões Ganhas (Leilões): ${fmt(0)}`, 20, yPos); yPos += 8;
    doc.text(`Ganhos (Rifas): ${fmt(0)}`, 20, yPos); yPos += 8;
    doc.text(`Despesas (Compras): ${fmt(0)}`, 20, yPos); yPos += 8;
    doc.text(`Saques: ${fmt(0)}`, 20, yPos); yPos += 8;
    doc.text(`Depósitos: ${fmt(0)}`, 20, yPos); yPos += 15;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text("📋 TRANSAÇÕES", 15, yPos); yPos += 8;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.text("Data", 20, yPos); doc.text("Tipo", 60, yPos); doc.text("Descrição", 100, yPos); doc.text("Valor", 170, yPos); yPos += 6;
    doc.setDrawColor(200, 200, 200);
    doc.line(15, yPos, 195, yPos); yPos += 5;
    const transacoes = [];
    if (transacoes.length === 0) doc.text("Nenhuma transação no período", 20, yPos);
    yPos += 10;
    doc.setFont("helvetica", "italic");
    doc.setFontSize(8);
    doc.text("Este é um relatório automático gerado pelo Clube do Galo", 15, yPos);
    doc.save(`relatorio_financeiro_${dataInicio}_${dataFim}.pdf`);
    setGerandoPDF(false);
  };

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", color: "#57636C" }}>
        Carregando...
      </div>
    );
  }

  const planoKey = getPlanoBundles(userMeta?.role || user?.role, userMeta?.plano || "iniciante");
  const planoAtual = getPlano(planoKey);
  const consultoriasNaoLidas = consultoriasMensagens.filter(c => c.status === "aguardando").length;

  const ABAS = [
    { id: "carteira", label: "💰 Carteira" },
    { id: "carteirinha", label: "🎫 Carteirinha" },
    { id: "dados", label: "📋 Dados" },
    { id: "relatorio", label: "📊 Financeiro" },
    { id: "planos", label: "💎 Planos" },
    { id: "consultoria", label: consultoriasNaoLidas > 0 ? `💬 Consulta (${consultoriasNaoLidas})` : "💬 Consulta" },
  ];

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 90, color: "#fff", paddingLeft: "env(safe-area-inset-left)", paddingRight: "env(safe-area-inset-right)" }}>
      {/* Header */}
      <div style={{ background: "#0A0A0A", padding: "52px 20px 16px", borderBottom: "1px solid #1C1C1E" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Link to="/" style={{ color: "#888", fontSize: 22, textDecoration: "none" }}>←</Link>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 20, fontWeight: 700, color: "#00C9B8" }}>Perfil</div>
          <NotificacoesSino userEmail={user?.email} />
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 800, margin: "0 auto" }}>
        {/* Foto de Perfil */}
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <input ref={fotoRef} type="file" accept="image/*" onChange={handleUploadFoto} style={{ display: "none" }} />
          <div style={{ position: "relative", width: 80, height: 80, margin: "0 auto", marginBottom: 10 }}>
            <div style={{ width: "100%", height: "100%", borderRadius: "50%", background: fotoPerfil ? `url(${fotoPerfil}) center/cover` : "#1C1C1E", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, border: "2px solid #00C9B8", cursor: "pointer", transition: "opacity 0.2s" }} onClick={() => fotoRef.current?.click()} onMouseEnter={e => e.currentTarget.style.opacity = "0.8"} onMouseLeave={e => e.currentTarget.style.opacity = "1"}>
              {!fotoPerfil && "👤"}
            </div>
            <div style={{ position: "absolute", bottom: 0, right: 0, width: 26, height: 26, borderRadius: "50%", background: "#00C9B8", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, cursor: "pointer", color: "#000" }} onClick={() => fotoRef.current?.click()} title="Alterar foto">
              📷
            </div>
          </div>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 700, color: "#fff" }}>{user?.full_name || "—"}</div>
          <div style={{ fontSize: 12, color: "#888" }}>{userMeta?.nome_criatorio || ""}</div>
          <div style={{ fontSize: 12, color: "#00C9B8", marginTop: 4 }}>{user?.email}</div>
        </div>

        {/* Abas */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 16, paddingBottom: 6, borderBottom: "1px solid #1C1C1E" }}>
          {ABAS.map(t => (
            <button key={t.id} onClick={() => setAbaMostrada(t.id)}
              style={{
                padding: "8px 12px", borderRadius: 10, border: "none", cursor: "pointer",
                fontSize: 11, fontFamily: "Montserrat,sans-serif", fontWeight: 700,
                background: abaMostrada === t.id ? "#7C3AED" : "#1C1C1E",
                color: abaMostrada === t.id ? "#fff" : "#888",
                whiteSpace: "nowrap",
              }}>
              {t.label}
            </button>
          ))}
        </div>

        {/* ABA: Carteira */}
        {abaMostrada === "carteira" && user && (
          <CarteiraPix user={user} />
        )}

        {/* ABA: Carteirinha */}
        {abaMostrada === "carteirinha" && user && (
          <CarteirinhaDigital user={user} userMeta={userMeta} />
        )}

        {/* ABA: Relatório Financeiro */}
        {abaMostrada === "relatorio" && (
          <div style={{ display: "grid", gap: 12 }}>
            <div style={{ background: "#1C1C1E", borderRadius: 12, padding: 14 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#fff", marginBottom: 12 }}>📅 Período do Relatório</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>De</label>
                  <input type="date" value={dataInicio} onChange={e => setDataInicio(e.target.value)}
                    style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "none", background: "#2C2C2E", color: "#fff", fontSize: 12, boxSizing: "border-box", colorScheme: "dark" }} />
                </div>
                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>Até</label>
                  <input type="date" value={dataFim} onChange={e => setDataFim(e.target.value)}
                    style={{ width: "100%", padding: "8px 10px", borderRadius: 8, border: "none", background: "#2C2C2E", color: "#fff", fontSize: 12, boxSizing: "border-box", colorScheme: "dark" }} />
                </div>
              </div>
              <button onClick={gerarRelatorioFinanceiro} disabled={gerandoPDF || !dataInicio || !dataFim}
                style={{ width: "100%", padding: "10px", borderRadius: 10, border: "none", background: gerandoPDF ? "#333" : "linear-gradient(135deg,#7C3AED,#5B2BE0)", color: gerandoPDF ? "#666" : "#fff", cursor: gerandoPDF ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700, fontSize: 12 }}>
                {gerandoPDF ? "Gerando..." : "📄 Gerar PDF"}
              </button>
            </div>
          </div>
        )}

        {/* ABA: Planos */}
        {abaMostrada === "planos" && (
          <div style={{ display: "grid", gap: 12 }}>
            <div style={{ background: "#fff", borderRadius: 12, padding: 14, border: "1px solid #E8ECF0" }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#101213", marginBottom: 10 }}>
                Seu Plano Atual: <span style={{ color: planoAtual.cor }}>{planoAtual.label}</span>
              </div>
              <div style={{ background: planoAtual.bg, borderRadius: 10, padding: 12, marginBottom: 10, fontSize: 14, color: planoAtual.cor, fontWeight: 800, fontFamily: "Montserrat,sans-serif" }}>
                ✅ {planoAtual.label}
              </div>
            </div>
            <div style={{ fontSize: 16, fontFamily: "Montserrat,sans-serif", fontWeight: 900, color: "#101213", marginBottom: 16 }}>💎 Escolha seu Plano Ideal</div>
            {[
              { nome: "Iniciante", nivel: 0, cor: "#57636C", bg: "#F1F4F8", preco: "Grátis", badge: null, descricao: "Comece agora sem custos", features: [{ icon: "📿", text: "50 anilhas grátis" }, { icon: "📸", text: "1 story por dia" }, { icon: "🛒", text: "Acesso liberado a compra" }, { icon: "🚫", text: "Sem permissão na vitrine" }] },
              { nome: "Standard", nivel: 1, cor: "#1565C0", bg: "#E3F2FD", preco: "R$ 29,90", periodo: "/mês", badge: null, descricao: "Para criadores ativos", features: [{ icon: "📿", text: "500 anilhas" }, { icon: "📸", text: "3 stories por dia" }, { icon: "🏪", text: "1 animal na vitrine a cada 15 dias" }, { icon: "🛒", text: "Acesso a compra liberado" }] },
              { nome: "Gold", nivel: 2, cor: "#F0A500", bg: "#FFF8E1", preco: "R$ 49,90", periodo: "/mês", badge: "⭐ MAIS POPULAR", descricao: "Melhor custo-benefício", features: [{ icon: "📿", text: "Anilhas ilimitadas" }, { icon: "📸", text: "4 stories por dia" }, { icon: "🏪", text: "1 anúncio na vitrine por semana" }, { icon: "🎓", text: "Acesso curso ilimitado" }, { icon: "🛒", text: "Acesso compra ilimitado" }] },
              { nome: "Premium", nivel: 3, cor: "#E21C3D", bg: "#FFEBEE", preco: "R$ 69,90", periodo: "/mês ou R$ 598,80/ano", badge: "👑 COMPLETO", descricao: "Tudo desbloqueado + suporte VIP", features: [{ icon: "📿", text: "Anilhas ilimitadas" }, { icon: "📸", text: "Stories ilimitados" }, { icon: "🏪", text: "Vitrine ilimitada" }, { icon: "🔨", text: "Criar rifas e leilões" }, { icon: "🎓", text: "Curso ilimitado" }, { icon: "⚖️", text: "Consultoria jurídica e veterinária" }] },
            ].map(p => (
              <div key={p.nome} style={{ background: p.bg, borderRadius: 16, padding: "16px 18px", border: `2.5px solid ${p.cor}`, position: "relative", transform: p.badge ? "scale(1.03)" : "scale(1)", boxShadow: p.badge ? `0 8px 24px ${p.cor}30` : "0 2px 8px rgba(0,0,0,.08)" }}>
                {userMeta?.plano === p.nome.toLowerCase() && (
                  <div style={{ position: "absolute", top: -12, left: 16, background: p.cor, color: "#fff", padding: "4px 12px", borderRadius: 20, fontSize: 10, fontWeight: 900, fontFamily: "Montserrat,sans-serif" }}>✅ SEU PLANO ATUAL</div>
                )}
                {p.badge && (
                  <div style={{ position: "absolute", top: -12, right: 16, background: p.cor, color: "#fff", padding: "4px 12px", borderRadius: 20, fontSize: 10, fontWeight: 900, fontFamily: "Montserrat,sans-serif" }}>{p.badge}</div>
                )}
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 900, fontSize: 18, color: p.cor, marginBottom: 2 }}>{p.nome}</div>
                  <div style={{ fontSize: 12, color: p.cor, fontWeight: 700, opacity: 0.8 }}>{p.descricao}</div>
                </div>
                <div style={{ marginBottom: 14, paddingBottom: 14, borderBottom: `1px solid ${p.cor}30` }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: p.cor }}>
                    {p.preco}
                    {p.periodo && <span style={{ fontSize: 12, fontWeight: 700, opacity: 0.8 }}>{p.periodo}</span>}
                  </div>
                </div>
                <div style={{ marginBottom: 14 }}>
                  {p.features.map((f, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, fontSize: 12, color: p.cor, fontWeight: 600 }}>
                      <span style={{ fontSize: 16 }}>{f.icon}</span>
                      <span>{f.text}</span>
                    </div>
                  ))}
                </div>
                {userMeta?.plano !== p.nome.toLowerCase() && (
                  <button onClick={() => { setModalPlano(p.nome.toLowerCase()); setModalPreco(p.preco === "Grátis" ? 0 : parseFloat(p.preco.replace('R$ ', '').replace(',', '.'))); }}
                    style={{ width: "100%", padding: "12px", borderRadius: 12, border: "none", background: p.cor, color: "#fff", cursor: "pointer", fontWeight: 900, fontSize: 13, fontFamily: "Montserrat,sans-serif" }}
                    onMouseEnter={e => e.target.style.transform = "translateY(-2px)"}
                    onMouseLeave={e => e.target.style.transform = "translateY(0)"}>
                    🛒 Comprar Plano
                  </button>
                )}
              </div>
            ))}
          </div>
        )}

        {/* ABA: Dados Pessoais */}
        {abaMostrada === "dados" && (
          <div style={{ display: "grid", gap: 14 }}>
            {(user?.role === "admin" || user?.role === "master_admin") && (
              <Link to="/admin-dashboard" style={{ textDecoration: "none" }}>
                <div style={{ background: "linear-gradient(135deg,#FF6B35,#FF8C42)", borderRadius: 14, padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", cursor: "pointer" }}>
                  <div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#fff" }}>⚙️ Painel de Administrador</div>
                    <div style={{ fontSize: 11, color: "rgba(255,255,255,.8)", marginTop: 2 }}>Gerenciar usuários, relatórios e configurações</div>
                  </div>
                  <span style={{ fontSize: 18 }}>→</span>
                </div>
              </Link>
            )}
            <div style={{ background: "linear-gradient(135deg,#7C3AED,#00C9B8)", borderRadius: 16, padding: 20, color: "#fff" }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 4 }}>👤 {user?.full_name || "—"}</div>
                  <div style={{ fontSize: 11, opacity: 0.9 }}>ID: {user?.id?.substring(0, 12).toUpperCase() || "—"}</div>
                </div>
                <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 12, padding: "8px 12px", fontSize: 11, fontWeight: 700 }}>
                  {userMeta?.role?.toUpperCase() || "USER"}
                </div>
              </div>
              <div style={{ fontSize: 12, opacity: 0.9, fontFamily: "monospace" }}>{user?.email}</div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {[
                { icon: "🏠", label: "Criatório", value: userMeta?.nome_criatorio || "—", cor: "#00C9B8" },
                { icon: "💎", label: "Plano Atual", value: planoAtual.label, cor: planoAtual.cor },
                { icon: "🗓️", label: "Membro Desde", value: user?.created_date ? new Date(user.created_date).toLocaleDateString("pt-BR") : "—", cor: "#7C3AED" },
                { icon: "📿", label: "Anilhas", value: anilhasCount, cor: "#F0A500" },
              ].map((item, idx) => (
                <div key={idx} style={{ background: "#1C1C1E", borderRadius: 12, padding: 14 }}>
                  <div style={{ fontSize: 12, color: item.cor, fontWeight: 700, marginBottom: 6 }}>{item.icon} {item.label}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#fff" }}>{item.value}</div>
                </div>
              ))}
            </div>

            <div style={{ background: "#1C1C1E", borderRadius: 12, padding: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "#888", textTransform: "uppercase", marginBottom: 10 }}>📊 Resumo da Conta</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div style={{ background: "#2C2C2E", borderRadius: 10, padding: "10px 12px" }}>
                  <div style={{ fontSize: 10, color: "#888", marginBottom: 4 }}>Status da Conta</div>
                  <div style={{ fontSize: 12, fontWeight: 800, color: "#00C9B8", display: "flex", alignItems: "center", gap: 4 }}>
                    <span style={{ fontSize: 14 }}>✅</span> Ativa
                  </div>
                </div>
                <div style={{ background: "#2C2C2E", borderRadius: 10, padding: "10px 12px" }}>
                  <div style={{ fontSize: 10, color: "#888", marginBottom: 4 }}>E-mail</div>
                  <div style={{ fontSize: 12, fontWeight: 800, color: "#00C9B8", display: "flex", alignItems: "center", gap: 4 }}>
                    <span style={{ fontSize: 14 }}>✅</span> Verificado
                  </div>
                </div>
              </div>
            </div>

            {!formDados && (
              <button onClick={() => setFormDados({ cpf: userMeta?.cpf || "", nome_criatorio: userMeta?.nome_criatorio || "", whatsapp: userMeta?.whatsapp || "", cidade: userMeta?.cidade || "", estado: userMeta?.estado || "" })}
                style={{ width: "100%", padding: "14px", borderRadius: 14, border: "none", background: "#1C1C1E", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700, fontSize: 14, textAlign: "left" }}>
                ✏️  Editar perfil
              </button>
            )}
            {formDados && (
              <div style={{ background: "#1C1C1E", borderRadius: 12, padding: 16, display: "grid", gap: 12 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213", marginBottom: 4 }}>✏️ Editar Dados</div>
                {[
                   { key: "cpf", label: "CPF", placeholder: "Ex: 123.456.789-10" },
                   { key: "nome_criatorio", label: "Nome do Criatório", placeholder: "Ex: Criatório São João" },
                   { key: "whatsapp", label: "WhatsApp", placeholder: "Ex: 11999999999" },
                   { key: "cidade", label: "Cidade", placeholder: "Ex: São Paulo" },
                   { key: "estado", label: "Estado", placeholder: "Ex: SP" },
                 ].map(f => (
                  <div key={f.key}>
                    <label style={{ fontSize: 10, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>{f.label}</label>
                    <input value={formDados[f.key] || ""} placeholder={f.placeholder}
                      onChange={e => setFormDados(p => ({ ...p, [f.key]: e.target.value }))}
                      style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: "#2C2C2E", color: "#fff", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
                  </div>
                ))}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <button onClick={() => setFormDados(null)}
                    style={{ padding: "10px", borderRadius: 10, border: "none", background: "#2C2C2E", color: "#888", cursor: "pointer", fontWeight: 700, fontSize: 12 }}>Cancelar</button>
                  <button onClick={async () => { setSalvandoDados(true); await base44.auth.updateMe(formDados); setUserMeta(p => ({ ...p, ...formDados })); setFormDados(null); setSalvandoDados(false); }} disabled={salvandoDados}
                    style={{ padding: "10px", borderRadius: 10, border: "none", background: "linear-gradient(135deg,#7C3AED,#5B2BE0)", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12 }}>{salvandoDados ? "Salvando..." : "💾 Salvar"}</button>
                </div>
              </div>
            )}

            <div style={{ display: "grid", gap: 8 }}>
               {[
                 { label: "🔒 Segurança", action: () => setMostraTrocaSenha(true) },
                 { label: "📢 Anunciar", action: null, path: "/anunciar-banner" },
                 { label: "Sair", action: () => { if (confirm("Deseja sair?")) base44.auth.logout("/"); }, color: "#888" },
                 { label: "🗑️ Deletar Conta", action: () => setMostraDeletarConta(true), color: "#FF453A" },
              ].map((item, i) => (
                item.path ? (
                  <Link key={i} to={item.path} style={{ textDecoration: "none" }}>
                    <button
                      style={{ width: "100%", padding: "16px", background: "#1C1C1E", border: "none", borderRadius: 14, color: item.color || "#fff", fontSize: 15, fontWeight: 600, textAlign: "left", cursor: "pointer", fontFamily: "inherit" }}>
                      {item.label}
                    </button>
                  </Link>
                ) : (
                  <button key={i} onClick={item.action}
                    style={{ width: "100%", padding: "16px", background: "#1C1C1E", border: "none", borderRadius: 14, color: item.color || "#fff", fontSize: 15, fontWeight: 600, textAlign: "left", cursor: item.action ? "pointer" : "default", fontFamily: "inherit" }}>
                    {item.label}
                  </button>
                  )
                  ))}
                  </div>
          </div>
        )}

        {/* ABA: Consultoria */}
        {abaMostrada === "consultoria" && (
          <div style={{ display: "grid", gap: 12 }}>
            {consultoriasMensagens.length === 0 ? (
              <div style={{ textAlign: "center", padding: 40, color: "#888" }}>
                <div style={{ fontSize: 48, marginBottom: 10 }}>💬</div>
                <div style={{ fontWeight: 700 }}>Nenhuma consultoria iniciada</div>
              </div>
            ) : (
              consultoriasMensagens.map(c => (
                <div key={c.id} onClick={() => setConsultoriaAberta(c)}
                  style={{ background: "#1C1C1E", borderRadius: 12, padding: 14, cursor: "pointer", border: c.status === "aguardando" ? "1px solid #7C3AED" : "1px solid #333" }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                    <div style={{ fontWeight: 700, color: "#fff" }}>{c.tipo.split("_").join(" ").toUpperCase()}</div>
                    <div style={{ fontSize: 10, color: c.status === "aguardando" ? "#FF453A" : "#00C9B8", fontWeight: 700 }}>
                      {c.status === "aguardando" ? "⏳ Aguardando" : "✅ Ativa"}
                    </div>
                  </div>
                  <div style={{ fontSize: 11, color: "#888" }}>Profissional: {c.profissional_nome || "—"}</div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {mostraCriarStory && (
        <CriarStoryModal user={user} onClose={() => setMostraCriarStory(false)} onConcluido={() => setMostraCriarStory(false)} />
      )}

      {modalPlano && (
        <ModalPagamentoPlan
          plano={modalPlano}
          planoPreco={modalPreco}
          user={user}
          onClose={() => setModalPlano(null)}
          onConcluido={() => { setModalPlano(null); window.location.reload(); }}
        />
      )}

      {mostraDeletarConta && user && (
        <ModalDeletarConta
          user={user}
          onClose={() => setMostraDeletarConta(false)}
          onSucesso={() => setMostraDeletarConta(false)}
        />
      )}

      {mostraTrocaSenha && user && (
        <ModalTrocaSenha
          user={user}
          onClose={() => setMostraTrocaSenha(false)}
        />
      )}

      <BottomNav />
    </div>
  );
}