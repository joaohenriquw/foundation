import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import BottomNav from "../components/BottomNav";
import NotificacoesSino from "../components/NotificacoesSino";
import AnimacaoVendido from "../components/AnimacaoVendido";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");
const diasRestantes = (data) => {
  const agora = new Date();
  const fim = new Date(data);
  const diff = Math.ceil((fim - agora) / (1000 * 60 * 60 * 24));
  return diff > 0 ? diff : 0;
};

export default function MeusLeiloes() {
  const [leiloes, setLeiloes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [filtro, setFiltro] = useState("todos");
  const [leilaoSelecionado, setLeilaoSelecionado] = useState(null);
  const [lances, setLances] = useState([]);
  const [modalAberto, setModalAberto] = useState(null);
  const [mostraAnimacaoVendido, setMostraAnimacaoVendido] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);

      if (!me) {
        setLoading(false);
        return;
      }

      // Buscar leilões do criador
      const leiloes = await base44.entities.Leilao.filter(
        { dono_email: me.email },
        "-created_date",
        100
      );
      setLeiloes(leiloes);
      setLoading(false);
    };

    init();

    const unsub = base44.entities.Leilao.subscribe(() => {
      init();
    });
    return unsub;
  }, []);

  const abrirDetalhes = async (leilao) => {
    setLeilaoSelecionado(leilao);
    const lancesData = await base44.entities.LeilaoLance.filter({ leilao_id: leilao.id }, "-created_date", 100);
    setLances(lancesData);
    setModalAberto('detalhes');
  };

  const cancelarLeilao = async (leilaoId) => {
    if (!confirm('Tem certeza que quer cancelar este leilão?')) return;
    await base44.entities.Leilao.update(leilaoId, { status: 'cancelado' });
    setModalAberto(null);
  };

  const encerrarLeilao = async (leilaoId) => {
    if (!confirm('Encerrar o leilão? O ganhador será notificado.')) return;
    const leilaoAtualizado = await base44.entities.Leilao.update(leilaoId, { status: 'encerrado' });
    if (leilaoAtualizado.ganhador_nome) {
      setMostraAnimacaoVendido(true);
    }
    setModalAberto(null);
  };

  const leiloesFiltrados = leiloes.filter((l) => {
    if (filtro === "ativos") return l.status === "ativo" || l.status === "agendado";
    if (filtro === "encerrados") return l.status === "encerrado";
    if (filtro === "cancelados") return l.status === "cancelado";
    return true;
  });

  const stats = {
    ativos: leiloes.filter((l) => l.status === "ativo" || l.status === "agendado").length,
    encerrados: leiloes.filter((l) => l.status === "encerrado").length,
    lances: leiloes.reduce((sum, l) => sum + (l.maior_lance || 0), 0),
  };

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 80, color: "#fff" }}>
      <div style={{ background: "#0A0A0A", padding: "52px 20px 16px", borderBottom: "1px solid #1C1C1E" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={() => navigate(-1)} style={{ background: "#1C1C1E", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", fontSize: 18, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#00C9B8" }}>🔨 Meus Leilões</div>
              <div style={{ fontSize: 11, color: "#888" }}>{leiloes.length} leilões no total</div>
            </div>
          </div>
          {user && <NotificacoesSino userEmail={user.email} />}
        </div>

        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginTop: 14 }}>
          {[
            { label: "Ativos", valor: stats.ativos, emoji: "🟢" },
            { label: "Encerrados", valor: stats.encerrados, emoji: "⚫" },
            { label: "Maior Lance", valor: fmt(stats.lances), emoji: "💰" },
          ].map((s, i) => (
            <div key={i} style={{ background: "rgba(255,255,255,.15)", borderRadius: 10, padding: "8px 6px", textAlign: "center" }}>
              <div style={{ fontSize: 16, fontWeight: 900, color: "#fff", fontFamily: "Montserrat,sans-serif" }}>{s.valor}</div>
              <div style={{ fontSize: 8, color: "rgba(255,255,255,.8)", fontWeight: 700, textTransform: "uppercase" }}>{s.emoji} {s.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 800, margin: "0 auto" }}>
        {/* Filtros */}
        <div style={{ display: "flex", gap: 6, marginBottom: 14, overflowX: "auto", paddingBottom: 2 }}>
          {[
            { id: "todos", label: "🐓 Todos" },
            { id: "ativos", label: "🟢 Ativos" },
            { id: "encerrados", label: "⚫ Encerrados" },
            { id: "cancelados", label: "❌ Cancelados" },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFiltro(f.id)}
              style={{
                padding: "6px 14px",
                borderRadius: 20,
                border: "1.5px solid",
                cursor: "pointer",
                fontFamily: "Montserrat,sans-serif",
                fontSize: 11,
                fontWeight: 700,
                whiteSpace: "nowrap",
                borderColor: filtro === f.id ? "#7C3AED" : "#333",
                background: filtro === f.id ? "#7C3AED" : "transparent",
                color: filtro === f.id ? "#fff" : "#888",
              }}
            >
              {f.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#555" }}>Carregando...</div>
        ) : leiloesFiltrados.length === 0 ? (
          <div style={{ textAlign: "center", padding: 48 }}>
            <div style={{ fontSize: 52, marginBottom: 12 }}>🔨</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "#fff" }}>Nenhum leilão encontrado</div>
            <Link to="/plantel" style={{ display: "inline-block", marginTop: 16, padding: "10px 16px", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", borderRadius: 10, textDecoration: "none", fontWeight: 700, fontSize: 12 }}>
              Criar Leilão
            </Link>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 12 }}>
            {leiloesFiltrados.map((l) => (
              <div key={l.id} style={{ textDecoration: "none" }}>
                <div
                  onClick={() => abrirDetalhes(l)}
                  onMouseEnter={(e) => e.currentTarget.style.boxShadow = "0 8px 24px rgba(23,0,115,.15)"}
                  onMouseLeave={(e) => e.currentTarget.style.boxShadow = "none"}
                  style={{ background: "#1C1C1E", borderRadius: 14, border: "1px solid #333", overflow: "hidden", cursor: "pointer", transition: ".2s" }}>
                  
                  {/* Foto */}
                  <div style={{ height: 140, background: l.animal_foto_url ? `url(${l.animal_foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                    {!l.animal_foto_url && <span style={{ fontSize: 48 }}>🐓</span>}
                    <div style={{ position: "absolute", top: 8, right: 8, background: l.status === "ativo" ? "#2E7D32" : l.status === "encerrado" ? "#57636C" : "#E21C3D", color: "#fff", borderRadius: 8, padding: "4px 10px", fontSize: 10, fontWeight: 800 }}>
                      {l.status === "ativo" ? "🟢 ATIVO" : l.status === "encerrado" ? "⚫ ENCERRADO" : "❌ CANCELADO"}
                    </div>
                  </div>

                  <div style={{ padding: "14px 16px" }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff", marginBottom: 4 }}>
                      {l.animal_nome}
                    </div>
                    <div style={{ fontSize: 11, color: "#888", marginBottom: 8 }}>
                      {l.animal_anilha} · {l.animal_especie || "—"}
                    </div>

                    {/* Lances e Tempo */}
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
                      <div>
                        <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>Maior Lance</div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#170073" }}>
                          {fmt(l.maior_lance || l.lance_minimo)}
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>Termina</div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: diasRestantes(l.data_fim) <= 1 ? "#E21C3D" : "#00A893" }}>
                          {diasRestantes(l.data_fim)}d
                        </div>
                      </div>
                    </div>

                    <button onClick={(e) => { e.stopPropagation(); abrirDetalhes(l); }} style={{ width: "100%", padding: "8px", borderRadius: 8, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12 }}>
                      Ver Detalhes →
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal Detalhes */}
      {modalAberto === 'detalhes' && leilaoSelecionado && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 1000, display: "flex", alignItems: "flex-end" }}>
          <div style={{ background: "#1C1C1E", borderRadius: "20px 20px 0 0", width: "100%", maxHeight: "85vh", overflowY: "auto", padding: "20px", maxWidth: 600, margin: "0 auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>Detalhes do Leilão</div>
              <button onClick={() => setModalAberto(null)} style={{ background: "none", border: "none", fontSize: 24, cursor: "pointer" }}>✕</button>
            </div>

            {/* Foto e Info */}
            <div style={{ height: 160, background: leilaoSelecionado.animal_foto_url ? `url(${leilaoSelecionado.animal_foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", borderRadius: 12, marginBottom: 14, display: "flex", alignItems: "center", justifyContent: "center" }}>
              {!leilaoSelecionado.animal_foto_url && <span style={{ fontSize: 52 }}>🐓</span>}
            </div>

            <div style={{ marginBottom: 16 }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#fff", marginBottom: 4 }}>{leilaoSelecionado.animal_nome}</div>
            <div style={{ fontSize: 12, color: "#888" }}>Anilha: {leilaoSelecionado.animal_anilha}</div>
            <div style={{ fontSize: 12, color: "#888", marginBottom: 8 }}>{leilaoSelecionado.animal_especie}</div>
              <div style={{ background: leilaoSelecionado.status === "ativo" ? "#E8F5E9" : "#EEEEEE", borderRadius: 8, padding: "6px 10px", display: "inline-block", fontSize: 11, fontWeight: 700, color: leilaoSelecionado.status === "ativo" ? "#2E7D32" : "#57636C" }}>
                {leilaoSelecionado.status === "ativo" ? "🟢 ATIVO" : leilaoSelecionado.status === "encerrado" ? "⚫ ENCERRADO" : "❌ CANCELADO"}
              </div>
            </div>

            {/* Valores */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>  
            <div style={{ background: "#2C2C2E", borderRadius: 10, padding: 10 }}>
                <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginBottom: 4 }}>Lance Mínimo</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>{fmt(leilaoSelecionado.lance_minimo)}</div>
              </div>
              <div style={{ background: "#F5F5F5", borderRadius: 10, padding: 10 }}>
                <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginBottom: 4 }}>Maior Lance</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#2E7D32" }}>{fmt(leilaoSelecionado.maior_lance || leilaoSelecionado.lance_minimo)}</div>
              </div>
            </div>

            {/* Lances */}
            {lances.length > 0 && (
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#101213", marginBottom: 8 }}>Histórico de Lances ({lances.length})</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 6, maxHeight: 200, overflowY: "auto" }}>
                  {lances.map((l, i) => (
                    <div key={i} style={{ background: "#F8FAFC", borderRadius: 8, padding: "8px 10px", display: "flex", justifyContent: "space-between", alignItems: "center", borderLeft: i === 0 ? "3px solid #2E7D32" : "3px solid #E8ECF0" }}>
                      <div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 800, color: "#101213" }}>{l.user_nome}</div>
                        <div style={{ fontSize: 10, color: "#57636C" }}>{l.parcelas}x de {fmt(l.valor_parcela)}</div>
                      </div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: i === 0 ? "#2E7D32" : "#170073" }}>{fmt(l.valor)}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Ganhador */}
            {leilaoSelecionado.status === "encerrado" && leilaoSelecionado.ganhador_nome && (
              <div style={{ background: "#E8F5E9", borderRadius: 10, padding: 12, marginBottom: 16 }}>
                <div style={{ fontWeight: 700, color: "#2E7D32", marginBottom: 6 }}>🏆 Ganhador</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#101213" }}>{leilaoSelecionado.ganhador_nome}</div>
                <div style={{ fontSize: 11, color: "#57636C" }}>{leilaoSelecionado.ganhador_email}</div>
              </div>
            )}

            {/* Botões de Ação */}
            <div style={{ display: "flex", gap: 10, flexDirection: leilaoSelecionado.status === "ativo" ? "row" : "column" }}>
              {leilaoSelecionado.status === "ativo" && (
                <>
                  <button onClick={() => navigate(`/leilao-ao-vivo/${leilaoSelecionado.id}`)} style={{ flex: 1, padding: "12px", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                    Ver ao Vivo
                  </button>
                  <button onClick={() => encerrarLeilao(leilaoSelecionado.id)} style={{ flex: 1, padding: "12px", background: "#FFC107", color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                    Encerrar
                  </button>
                  <button onClick={() => cancelarLeilao(leilaoSelecionado.id)} style={{ flex: 1, padding: "12px", background: "#E21C3D", color: "#fff", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                    Cancelar
                  </button>
                </>
              )}
              <button onClick={() => setModalAberto(null)} style={{ flex: 1, padding: "12px", background: "#E8ECF0", color: "#101213", border: "none", borderRadius: 10, fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Animação Vendido */}
      <AnimacaoVendido
        visible={mostraAnimacaoVendido}
        ganhadorNome={leilaoSelecionado?.ganhador_nome || ""}
        donoNome={leilaoSelecionado?.dono_nome || ""}
        onClose={() => setMostraAnimacaoVendido(false)}
      />

      <BottomNav />
    </div>
  );
}