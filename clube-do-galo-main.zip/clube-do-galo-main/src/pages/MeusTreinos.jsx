import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import SelectField from "../components/SelectField";
import NotificacoesSino from "../components/NotificacoesSino";
import BottomNav from "../components/BottomNav";
import BackHeader from "../components/BackHeader";

export default function MeusTreinos() {
  const [user, setUser] = useState(null);
  const [treinos, setTreinos] = useState([]);
  const [cursos, setCursos] = useState([]);
  const [animais, setAnimais] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalAberto, setModalAberto] = useState(false);
  const [formData, setFormData] = useState({
    animal_id: "",
    curso_id: "",
    data_treino: new Date().toISOString().split("T")[0],
    duracao_minutos: 30,
    desempenho: "bom",
    saude_animal: "excelente",
    observacoes: "",
    peso_pos_treino: 0,
    oponente_tipo: "padrao",
    oponente_nome: "Topador",
    oponente_manual: "",
  });
  const [processando, setProcessando] = useState(false);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      if (!me) { setLoading(false); return; }

      const [treinosData, cursosData, animaisData] = await Promise.all([
        base44.entities.Treino.filter({ usuario_email: me.email }, "-created_date", 200),
        base44.entities.Curso.filter({ ativo: true }, "-created_date", 200),
        base44.entities.Animal.filter({ proprietario_email: me.email }, "-created_date", 200),
      ]);

      setTreinos(treinosData);
      setCursos(cursosData);
      setAnimais(animaisData);
      setLoading(false);
    };
    init();

    const unsub = base44.entities.Treino.subscribe(() => {
      init();
    });
    return unsub;
  }, []);

  const registrarTreino = async () => {
    if (!formData.animal_id || !formData.curso_id) {
      alert("Selecione o animal e o curso!");
      return;
    }
    setProcessando(true);

    const animalSelecionado = animais.find(a => a.id === formData.animal_id);
    const cursoSelecionado = cursos.find(c => c.id === formData.curso_id);

    const nomeOponente = formData.oponente_tipo === "padrao" ? formData.oponente_nome : formData.oponente_tipo === "plantel" ? animais.find(a => a.id === formData.oponente_nome)?.nome : formData.oponente_manual;
    
    await base44.entities.Treino.create({
      usuario_id: user.id,
      usuario_email: user.email,
      animal_id: animalSelecionado.id,
      animal_nome: animalSelecionado.nome,
      animal_anilha: animalSelecionado.anilha,
      curso_id: cursoSelecionado.id,
      curso_titulo: cursoSelecionado.titulo,
      data_treino: formData.data_treino,
      duracao_minutos: formData.duracao_minutos,
      desempenho: formData.desempenho,
      saude_animal: formData.saude_animal,
      observacoes: formData.observacoes,
      peso_pos_treino: formData.peso_pos_treino > 0 ? formData.peso_pos_treino : null,
      oponente_nome: nomeOponente,
    });

    // Incrementar visualizações do curso
    await base44.entities.Curso.update(formData.curso_id, {
      visualizacoes: (cursoSelecionado.visualizacoes || 0) + 1,
    });

    setFormData({
      animal_id: "",
      curso_id: "",
      data_treino: new Date().toISOString().split("T")[0],
      duracao_minutos: 30,
      desempenho: "bom",
      saude_animal: "excelente",
      observacoes: "",
      peso_pos_treino: 0,
      oponente_tipo: "padrao",
      oponente_nome: "Topador",
      oponente_manual: "",
    });
    setModalAberto(false);
    setProcessando(false);
  };

  const deletarTreino = async (id) => {
    if (confirm("Deletar este treino?")) {
      await base44.entities.Treino.delete(id);
    }
  };

  if (loading) return <div style={{ textAlign: "center", padding: 20 }}>Carregando...</div>;

  const diasSemTreino = Math.floor((Date.now() - new Date(treinos[0]?.created_date || Date.now()).getTime()) / (1000 * 60 * 60 * 24));
  const mediaDesempenho = treinos.length > 0 ? ((treinos.filter(t => t.desempenho === "excelente").length / treinos.length) * 100).toFixed(0) : 0;

  return (
    <div style={{ minHeight: "100vh", background: "#000", paddingBottom: 80, color: "#fff", fontFamily: "'DM Sans', -apple-system, sans-serif" }}>
      <BackHeader
        title="🏋️ Meus Treinos"
        subtitle="Monitore o progresso dos seus animais"
        rightAction={user && <NotificacoesSino userEmail={user.email} />}
      />

      <div style={{ padding: "14px 14px 40px", maxWidth: 900, margin: "0 auto" }}>
        {/* KPIs */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 10, marginBottom: 20 }}>
          <div style={{ background: "#1C1C1E", borderRadius: 12, padding: 12, border: "1px solid #333", textAlign: "center" }}>
            <div style={{ fontSize: 24, marginBottom: 4 }}>🏋️</div>
            <div style={{ fontSize: 11, color: "#888" }}>Treinos Registrados</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#00C9B8" }}>{treinos.length}</div>
          </div>
          <div style={{ background: "#1C1C1E", borderRadius: 12, padding: 12, border: "1px solid #333", textAlign: "center" }}>
            <div style={{ fontSize: 24, marginBottom: 4 }}>⭐</div>
            <div style={{ fontSize: 11, color: "#888" }}>Desempenho</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#F0A500" }}>{mediaDesempenho}%</div>
          </div>
          <div style={{ background: "#1C1C1E", borderRadius: 12, padding: 12, border: "1px solid #333", textAlign: "center" }}>
            <div style={{ fontSize: 24, marginBottom: 4 }}>📚</div>
            <div style={{ fontSize: 11, color: "#888" }}>Cursos Abertos</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#7C3AED" }}>{cursos.length}</div>
          </div>
        </div>

        <button onClick={() => setModalAberto(true)}
          style={{ width: "100%", padding: "12px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 900, marginBottom: 20, fontSize: 14 }}>
          ➕ Registrar Treino
        </button>

        {/* Treinos */}
        <div style={{ display: "grid", gap: 12 }}>
          {treinos.length === 0 ? (
            <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>
              <div style={{ fontSize: 32, marginBottom: 10 }}>🏋️</div>
              <div style={{ fontWeight: 700, marginBottom: 8 }}>Nenhum treino registrado</div>
              <button onClick={() => setModalAberto(true)} style={{ padding: "8px 16px", borderRadius: 10, border: "none", background: "#170073", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12 }}>
                Registre seu primeiro treino
              </button>
            </div>
          ) : (
            treinos.map(t => (
              <div key={t.id} style={{ background: "#1C1C1E", borderRadius: 14, padding: 14, border: "1px solid #333" }}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 10 }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#fff", marginBottom: 4 }}>
                      🐓 {t.animal_nome} ({t.animal_anilha})
                    </div>
                    <div style={{ fontSize: 11, color: "#888", marginBottom: 6 }}>
                      📚 {t.curso_titulo}
                    </div>
                  </div>
                  <button onClick={() => deletarTreino(t.id)} style={{ background: "#FFE0E6", border: "none", color: "#E21C3D", padding: "4px 8px", borderRadius: 6, cursor: "pointer", fontWeight: 700, fontSize: 10 }}>
                    🗑️
                  </button>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(100px, 1fr))", gap: 8, marginBottom: 10 }}>
                  <div style={{ background: "#2C2C2E", borderRadius: 8, padding: 8, textAlign: "center" }}>
                    <div style={{ fontSize: 10, color: "#170073", fontWeight: 700 }}>📅 Data</div>
                    <div style={{ fontSize: 11, color: "#170073", fontWeight: 900 }}>{new Date(t.data_treino).toLocaleDateString("pt-BR")}</div>
                  </div>
                  <div style={{ background: "#2C2C2E", borderRadius: 8, padding: 8, textAlign: "center" }}>
                    <div style={{ fontSize: 10, color: "#F0A500", fontWeight: 700 }}>⏱️ Duração</div>
                    <div style={{ fontSize: 11, color: "#F0A500", fontWeight: 900 }}>{t.duracao_minutos}min</div>
                  </div>
                  <div style={{ background: "#2C2C2E", borderRadius: 8, padding: 8, textAlign: "center" }}>
                    <div style={{ fontSize: 10, color: "#2E7D32", fontWeight: 700 }}>✨ Desempenho</div>
                    <div style={{ fontSize: 11, color: "#2E7D32", fontWeight: 900 }}>{t.desempenho.toUpperCase()}</div>
                  </div>
                </div>

                <div style={{ fontSize: 11, color: "#aaa", background: "#2C2C2E", padding: 8, borderRadius: 6, marginBottom: 8 }}>
                  {t.oponente_nome && <div><strong>⚔️ Treinou Contra:</strong> {t.oponente_nome}</div>}
                  {t.observacoes && <div><strong>📝 Observações:</strong> {t.observacoes}</div>}
                </div>

                <div style={{ fontSize: 9, color: "#BDBDBD", textAlign: "right" }}>
                  {t.saude_animal && `Saúde: ${t.saude_animal}`}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Modal Registrar Treino */}
      {modalAberto && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalAberto(false)}>
          <div style={{ background: "#1C1C1E", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px", maxHeight: "90vh", overflowY: "auto" }} onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 20 }}>🏋️ Registrar Treino</div>

            <div style={{ display: "grid", gap: 14 }}>
              <div>
                <SelectField
                  label="Animal"
                  value={formData.animal_id}
                  onChange={(e) => setFormData({ ...formData, animal_id: e.target.value })}
                  options={animais.map(a => ({ value: a.id, label: `${a.nome} (${a.anilha})` }))}
                  placeholder="Selecione um animal"
                  required
                />
              </div>

              <div>
                <SelectField
                  label="Curso"
                  value={formData.curso_id}
                  onChange={(e) => setFormData({ ...formData, curso_id: e.target.value })}
                  options={cursos.map(c => ({ value: c.id, label: c.titulo }))}
                  placeholder="Selecione um curso"
                  required
                />
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Data do Treino</label>
                <input type="date" value={formData.data_treino} onChange={e => setFormData({ ...formData, data_treino: e.target.value })}
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Duração (min)</label>
                  <input type="number" value={formData.duracao_minutos} onChange={e => setFormData({ ...formData, duracao_minutos: Number(e.target.value) })}
                    style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Peso Pós-Treino (g)</label>
                  <input type="number" value={formData.peso_pos_treino} onChange={e => setFormData({ ...formData, peso_pos_treino: Number(e.target.value) })}
                    style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <SelectField
                    label="Desempenho"
                    value={formData.desempenho}
                    onChange={(e) => setFormData({ ...formData, desempenho: e.target.value })}
                    options={['Excelente', 'Bom', 'Regular', 'Ruim'].map(o => ({ value: o.toLowerCase(), label: o }))}
                  />
                </div>
                <div>
                  <SelectField
                    label="Saúde Animal"
                    value={formData.saude_animal}
                    onChange={(e) => setFormData({ ...formData, saude_animal: e.target.value })}
                    options={['Excelente', 'Bom', 'Regular', 'Cansado'].map(o => ({ value: o.toLowerCase(), label: o }))}
                  />
                </div>
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>⚔️ Treinou Contra</label>
                <div style={{ display: "grid", gap: 10 }}>
                  <div>
                    <SelectField
                      label="Tipo de Oponente"
                      value={formData.oponente_tipo}
                      onChange={(e) => setFormData({ ...formData, oponente_tipo: e.target.value, oponente_nome: e.target.value === "padrao" ? "Topador" : "", oponente_manual: "" })}
                      options={[
                        { value: 'padrao', label: '📌 Opções Padrão' },
                        { value: 'plantel', label: '🐓 Do Plantel' },
                        { value: 'manual', label: '✍️ Entrada Manual' }
                      ]}
                    />
                  </div>
                  {formData.oponente_tipo === "padrao" && (
                    <div>
                      <SelectField
                        label="Selecione o Auxiliar"
                        value={formData.oponente_nome}
                        onChange={(e) => setFormData({ ...formData, oponente_nome: e.target.value })}
                        options={['Topador', 'Palhaço', 'Escoveiro'].map(o => ({ value: o, label: o }))}
                      />
                    </div>
                  )}
                  {formData.oponente_tipo === "plantel" && (
                    <div>
                      <SelectField
                        label="Selecione do Plantel"
                        value={formData.oponente_nome}
                        onChange={(e) => setFormData({ ...formData, oponente_nome: e.target.value })}
                        options={animais.filter(a => a.id !== formData.animal_id).map(a => ({ value: a.id, label: `${a.nome} (${a.anilha})` }))}
                        placeholder="Selecione um galo"
                      />
                    </div>
                  )}
                  {formData.oponente_tipo === "manual" && (
                    <div>
                      <label style={{ fontSize: 10, color: "#57636C", display: "block", marginBottom: 4 }}>Nome do Animal</label>
                      <input type="text" value={formData.oponente_manual} onChange={e => setFormData({ ...formData, oponente_manual: e.target.value })} placeholder="Ex: Galo Vermelho"
                        style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Observações</label>
                <textarea value={formData.observacoes} onChange={e => setFormData({ ...formData, observacoes: e.target.value })} placeholder="Notas sobre o desempenho do animal..."
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box", minHeight: 60, fontFamily: "inherit" }} />
              </div>

              <button onClick={registrarTreino} disabled={processando || !formData.animal_id || !formData.curso_id}
                style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: processando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: processando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                {processando ? "Registrando..." : "✅ Registrar Treino"}
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}