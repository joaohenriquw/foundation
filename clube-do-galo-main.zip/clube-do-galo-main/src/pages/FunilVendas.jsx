import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { jsPDF } from "jspdf";

const STATUS_CONFIG = {
  pendente:       { label: "Pendente",        cor: "#F0A500", bg: "#FFF8E1", emoji: "⏳" },
  em_negociacao:  { label: "Em Negociação",   cor: "#1565C0", bg: "#E3F2FD", emoji: "🤝" },
  concluido:      { label: "Concluído",       cor: "#2E7D32", bg: "#E8F5E9", emoji: "✅" },
  cancelado:      { label: "Cancelado",       cor: "#C62828", bg: "#FFEBEE", emoji: "❌" },
};

const PAGAMENTO_LABEL = { pix: "PIX", dinheiro: "Dinheiro", transferencia: "Transferência", parcelado: "Parcelado" };

const fmt = (v) => v != null ? "R$ " + Number(v).toFixed(2).replace(".", ",") : "—";
const empty = { animal_id: "", animal_nome: "", animal_anilha: "", comprador_nome: "", comprador_whatsapp: "", valor_proposta: "", valor_final: "", status: "pendente", observacoes: "", data_contato: "", forma_pagamento: "pix" };

function gerarPDF(venda) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const cor = [23, 0, 115];

  doc.setFillColor(...cor);
  doc.rect(0, 0, 210, 30, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20); doc.setFont(undefined, "bold");
  doc.text("CLUBE DO GALO", 14, 13);
  doc.setFontSize(10); doc.setFont(undefined, "normal");
  doc.text("Recibo de Negociação", 14, 21);
  doc.text(`Data: ${new Date().toLocaleDateString("pt-BR")}`, 160, 21);

  doc.setTextColor(0, 0, 0);
  doc.setFontSize(13); doc.setFont(undefined, "bold");
  doc.text("Dados da Venda", 14, 42);

  const linhas = [
    ["Animal", venda.animal_nome + (venda.animal_anilha ? ` (Anilha: ${venda.animal_anilha})` : "")],
    ["Comprador", venda.comprador_nome],
    ["WhatsApp", venda.comprador_whatsapp || "—"],
    ["Forma de Pagamento", PAGAMENTO_LABEL[venda.forma_pagamento] || "—"],
    ["Valor da Proposta", fmt(venda.valor_proposta)],
    ["Valor Final", fmt(venda.valor_final || venda.valor_proposta)],
    ["Status", STATUS_CONFIG[venda.status]?.label || venda.status],
    ["Data do Contato", venda.data_contato || "—"],
    ["Observações", venda.observacoes || "—"],
  ];

  let y = 52;
  doc.setFontSize(10);
  linhas.forEach(([key, val]) => {
    doc.setFont(undefined, "bold"); doc.text(key + ":", 14, y);
    doc.setFont(undefined, "normal"); doc.text(String(val), 65, y);
    y += 9;
  });

  doc.setFillColor(...cor);
  doc.rect(14, y + 6, 182, 0.5, "F");
  doc.setFontSize(9); doc.setTextColor(100, 100, 100);
  doc.text("Este recibo confirma a negociação realizada via WhatsApp fora do ambiente do aplicativo.", 14, y + 18);
  doc.text("Clube do Galo — Gestão de Aves de Alto Padrão", 14, y + 25);

  doc.save(`recibo-${venda.animal_nome.replace(/ /g, "-")}-${Date.now()}.pdf`);
}

export default function FunilVendas() {
  const [vendas, setVendas] = useState([]);
  const [animais, setAnimais] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(null);
  const [filtroStatus, setFiltroStatus] = useState("todos");
  const [saving, setSaving] = useState(false);

  // Lê parâmetros vindos do Plantel (botão "Negociar")
  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    if (p.get("animal_nome")) {
      setForm({
        ...empty,
        animal_id: p.get("animal_id") || "",
        animal_nome: p.get("animal_nome") || "",
        animal_anilha: p.get("animal_anilha") || "",
        valor_proposta: p.get("valor") || "",
      });
    }
  }, []);

  const carregar = async () => {
    setLoading(true);
    const me = await base44.auth.me().catch(() => null);
    const [data, adata] = await Promise.all([
      base44.entities.FunilVendas.list("-created_date", 100),
      me ? base44.entities.Animal.filter({ proprietario_email: me.email }, "nome", 200) : [],
    ]);
    setVendas(data);
    setAnimais(adata);
    setLoading(false);
  };

  useEffect(() => { carregar(); }, []);

  const salvar = async () => {
    setSaving(true);
    const payload = { ...form, valor_proposta: Number(form.valor_proposta), valor_final: form.valor_final ? Number(form.valor_final) : null };
    if (form.id) {
      await base44.entities.FunilVendas.update(form.id, payload);
    } else {
      await base44.entities.FunilVendas.create(payload);
    }
    setSaving(false);
    setForm(null);
    carregar();
  };

  const atualizarStatus = async (id, status) => {
    await base44.entities.FunilVendas.update(id, { status });
    setVendas(prev => prev.map(v => v.id === id ? { ...v, status } : v));
  };

  const excluir = async (id) => {
    if (!confirm("Excluir esta negociação?")) return;
    await base44.entities.FunilVendas.delete(id);
    setVendas(prev => prev.filter(v => v.id !== id));
  };

  const vendasFiltradas = vendas.filter(v => filtroStatus === "todos" || v.status === filtroStatus);

  const contadores = Object.fromEntries(Object.keys(STATUS_CONFIG).map(s => [s, vendas.filter(v => v.status === s).length]));
  const totalConcluido = vendas.filter(v => v.status === "concluido").reduce((s, v) => s + (v.valor_final || v.valor_proposta || 0), 0);

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", color: "#fff" }}>
      {/* Header */}
      <div style={{ background: "#0A0A0A", padding: "52px 20px 16px", borderBottom: "1px solid #1C1C1E" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={() => navigate(-1)} style={{ background: "#1C1C1E", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", fontSize: 18, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#00C9B8" }}>Funil de Vendas</div>
              <div style={{ fontSize: 11, color: "#888" }}>Negociações via WhatsApp</div>
            </div>
          </div>
          <button onClick={() => setForm({ ...empty })}
            style={{ background: "#fff", color: "#170073", border: "none", borderRadius: 12, padding: "9px 16px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
            + Nova Proposta
          </button>
        </div>

        {/* KPIs */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginTop: 16 }}>
          {Object.entries(STATUS_CONFIG).map(([key, cfg]) => (
            <div key={key} style={{ background: "rgba(255,255,255,.15)", borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
              <div style={{ fontSize: 18, fontWeight: 900, color: "#fff", fontFamily: "Montserrat,sans-serif" }}>{contadores[key] || 0}</div>
              <div style={{ fontSize: 9, color: "rgba(255,255,255,.8)", fontWeight: 700, textTransform: "uppercase" }}>{cfg.label}</div>
            </div>
          ))}
        </div>

        <div style={{ background: "rgba(255,255,255,.1)", borderRadius: 10, padding: "10px 14px", marginTop: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 11, color: "rgba(255,255,255,.8)" }}>💰 Total em vendas concluídas</span>
          <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#fff" }}>{fmt(totalConcluido)}</span>
        </div>
      </div>

      <div style={{ padding: "14px 16px 40px", maxWidth: 700, margin: "0 auto" }}>
        {/* Filtro status */}
        <div style={{ display: "flex", gap: 7, marginBottom: 14, overflowX: "auto", paddingBottom: 2 }}>
          {[["todos","Todas"], ...Object.entries(STATUS_CONFIG).map(([k,c])=>[k, c.emoji+" "+c.label])].map(([k,label]) => (
            <button key={k} onClick={() => setFiltroStatus(k)}
              style={{ padding: "6px 14px", borderRadius: 20, border: "1.5px solid", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap", transition: ".2s",
                borderColor: filtroStatus === k ? "#7C3AED" : "#333",
                background: filtroStatus === k ? "#7C3AED" : "transparent",
                color: filtroStatus === k ? "#fff" : "#888" }}>
              {label}
            </button>
          ))}
        </div>

        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#555" }}>Carregando...</div>
        ) : vendasFiltradas.length === 0 ? (
          <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>
            <div style={{ fontSize: 40, marginBottom: 10 }}>🤝</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>Nenhuma negociação aqui</div>
            <div style={{ fontSize: 12, marginTop: 6 }}>Registre uma proposta recebida pelo WhatsApp</div>
          </div>
        ) : vendasFiltradas.map(v => {
          const cfg = STATUS_CONFIG[v.status] || STATUS_CONFIG.pendente;
          return (
            <div key={v.id} style={{ background: "#1C1C1E", borderRadius: 14, border: "1px solid #333", marginBottom: 12, overflow: "hidden" }}>
              {/* Topo colorido */}
              <div style={{ background: cfg.bg, borderBottom: `2px solid ${cfg.cor}30`, padding: "10px 14px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 16 }}>{cfg.emoji}</span>
                  <div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#fff" }}>{v.animal_nome}</div>
                    {v.animal_anilha && <div style={{ fontSize: 10, color: "#888" }}>Anilha: {v.animal_anilha}</div>}
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 15, fontWeight: 900, color: cfg.cor }}>{fmt(v.valor_final || v.valor_proposta)}</div>
                  <div style={{ fontSize: 9, color: "#57636C" }}>Proposta: {fmt(v.valor_proposta)}</div>
                </div>
              </div>

              <div style={{ padding: "10px 14px" }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 10 }}>
                  <div>
                    <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700, textTransform: "uppercase" }}>Comprador</div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: "#101213" }}>{v.comprador_nome}</div>
                    {v.comprador_whatsapp && <div style={{ fontSize: 11, color: "#00A893" }}>📱 {v.comprador_whatsapp}</div>}
                  </div>
                  <div>
                    <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700, textTransform: "uppercase" }}>Pagamento</div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: "#101213" }}>{PAGAMENTO_LABEL[v.forma_pagamento] || "—"}</div>
                    {v.data_contato && <div style={{ fontSize: 11, color: "#57636C" }}>📅 {v.data_contato}</div>}
                  </div>
                </div>

                {v.observacoes && (
                  <div style={{ background: "#2C2C2E", borderRadius: 8, padding: "6px 10px", marginBottom: 10, fontSize: 11, color: "#aaa" }}>
                    📝 {v.observacoes}
                  </div>
                )}

                {/* Ações de status */}
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
                  {Object.entries(STATUS_CONFIG).filter(([k]) => k !== v.status).map(([k, c]) => (
                    <button key={k} onClick={() => atualizarStatus(v.id, k)}
                      style={{ padding: "4px 10px", borderRadius: 8, border: `1px solid ${c.cor}50`, background: c.bg, color: c.cor, cursor: "pointer", fontSize: 10, fontWeight: 700 }}>
                      {c.emoji} {c.label}
                    </button>
                  ))}
                </div>

                <div style={{ display: "flex", gap: 7, borderTop: "1px solid #F8FAFC", paddingTop: 8 }}>
                  <button onClick={() => setForm({ ...v })}
                    style={{ flex: 1, padding: "7px", borderRadius: 8, border: "1.5px solid #E8ECF0", background: "#fff", color: "#57636C", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                    ✏️ Editar
                  </button>
                  {v.status === "concluido" && (
                    <button onClick={() => gerarPDF(v)}
                      style={{ flex: 1, padding: "7px", borderRadius: 8, border: "none", background: "#170073", color: "#fff", cursor: "pointer", fontSize: 11, fontWeight: 700, fontFamily: "Montserrat,sans-serif" }}>
                      📄 Gerar Recibo PDF
                    </button>
                  )}
                  <button onClick={() => excluir(v.id)}
                    style={{ padding: "7px 12px", borderRadius: 8, border: "1.5px solid #fee2e2", background: "#fff", color: "#E21C3D", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                    🗑️
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal Form */}
      {form && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
          onClick={(e) => e.target === e.currentTarget && setForm(null)}>
          <div style={{ background: "#1C1C1E", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 600, maxHeight: "90vh", overflowY: "auto", padding: "20px 20px 40px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
                {form.id ? "Editar Proposta" : "Nova Proposta"}
              </div>
              <button onClick={() => setForm(null)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            <div style={{ display: "grid", gap: 12 }}>
              {/* Seletor de animal do plantel */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: .5, display: "block", marginBottom: 4 }}>🐓 Animal do Plantel</label>
                <select value={form.animal_id || ""}
                  onChange={e => {
                    const animal = animais.find(a => a.id === e.target.value);
                    if (animal) {
                      setForm(p => ({ ...p, animal_id: animal.id, animal_nome: animal.nome, animal_anilha: animal.anilha || "", valor_proposta: p.valor_proposta || animal.valor_estimado || "" }));
                    } else {
                      setForm(p => ({ ...p, animal_id: "", animal_nome: "", animal_anilha: "" }));
                    }
                  }}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", background: "#fff" }}>
                  <option value="">-- Selecione ou preencha manualmente abaixo --</option>
                  {animais.filter(a => a.status_vitrine === "disponivel" || a.id === form.animal_id).map(a => (
                    <option key={a.id} value={a.id}>{a.nome} · {a.anilha}{a.valor_estimado ? ` · R$ ${Number(a.valor_estimado).toFixed(2)}` : ""}</option>
                  ))}
                </select>
              </div>
              {[
                { key: "animal_nome", label: "🐓 Nome do Animal *", type: "text", placeholder: "Ou digite manualmente" },
                { key: "animal_anilha", label: "🏷️ Anilha", type: "text", placeholder: "Ex: GG-2024-001" },
                { key: "comprador_nome", label: "👤 Comprador *", type: "text", placeholder: "Nome completo" },
                { key: "comprador_whatsapp", label: "📱 WhatsApp", type: "text", placeholder: "(99) 99999-9999" },
                { key: "valor_proposta", label: "💬 Valor da Proposta (R$) *", type: "number", placeholder: "0,00" },
                { key: "valor_final", label: "✅ Valor Final Acordado (R$)", type: "number", placeholder: "Deixe vazio se ainda não fechou" },
                { key: "data_contato", label: "📅 Data do Contato", type: "date" },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: .5, display: "block", marginBottom: 4 }}>{f.label}</label>
                  <input type={f.type} value={form[f.key] || ""} placeholder={f.placeholder}
                    onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))}
                    style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
                </div>
              ))}

              {/* Status */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: .5, display: "block", marginBottom: 4 }}>Status</label>
                <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
                  {Object.entries(STATUS_CONFIG).map(([k, c]) => (
                    <button key={k} onClick={() => setForm(p => ({ ...p, status: k }))}
                      style={{ padding: "6px 12px", borderRadius: 10, border: `1.5px solid ${form.status === k ? c.cor : "#E8ECF0"}`, background: form.status === k ? c.bg : "#fff", color: form.status === k ? c.cor : "#57636C", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                      {c.emoji} {c.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Forma pagamento */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: .5, display: "block", marginBottom: 4 }}>Forma de Pagamento</label>
                <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
                  {Object.entries(PAGAMENTO_LABEL).map(([k, label]) => (
                    <button key={k} onClick={() => setForm(p => ({ ...p, forma_pagamento: k }))}
                      style={{ padding: "6px 12px", borderRadius: 10, border: `1.5px solid ${form.forma_pagamento === k ? "#170073" : "#E8ECF0"}`, background: form.forma_pagamento === k ? "#170073" : "#fff", color: form.forma_pagamento === k ? "#fff" : "#57636C", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Observações */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: .5, display: "block", marginBottom: 4 }}>Observações</label>
                <textarea value={form.observacoes || ""} placeholder="Ex: Negociação via zap, pagamento em 2x..."
                  onChange={e => setForm(p => ({ ...p, observacoes: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", height: 70, resize: "none" }} />
              </div>
            </div>

            <button onClick={salvar} disabled={saving || !form.animal_nome || !form.comprador_nome || !form.valor_proposta}
              style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", background: saving ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: saving ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, marginTop: 16 }}>
              {saving ? "Salvando..." : form.id ? "Atualizar Proposta" : "Registrar Proposta"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}