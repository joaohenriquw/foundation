import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import ConfigurarNyxpay from "../components/ConfiguraGatewayNyxpay";
import GestaoSocios from "../components/GestaoSocios";
import GerenciamentoDados from "../components/GerenciamentoDados";
import SuporteAoUsuario from "../components/SuporteAoUsuario";
import GestaoPlanos from "../components/GestaoPlanos";
import GestaoConsultorias from "../components/GestaoConsultorias";
import AdminFiltros from "../components/AdminFiltros";
import AdminExportacao from "../components/AdminExportacao";
import AdminAuditoria from "../components/AdminAuditoria";
import ModalAtribuirCargo from "../components/ModalAtribuirCargo";

const CARGOS = [
  { value: "user",              label: "Usuário",             emoji: "👤", cor: "#57636C" },
  { value: "advogado_civil",    label: "Advogado Civil",      emoji: "⚖️", cor: "#170073" },
  { value: "advogado_criminal", label: "Advogado Criminal",   emoji: "🔒", cor: "#C62828" },
  { value: "veterinario",       label: "Veterinário",         emoji: "🩺", cor: "#2E7D32" },
  { value: "organizador_evento",label: "Org. de Eventos",     emoji: "🎪", cor: "#00A893" },
  { value: "admin",             label: "Administrador",       emoji: "👑", cor: "#F0A500" },
  { value: "master_admin",      label: "Master Admin",        emoji: "🛡️", cor: "#170073" },
];

export default function AdminPanel() {
  const [user, setUser]     = useState(null);
  const [users, setUsers]   = useState([]);
  const [rifas, setRifas]   = useState([]);
  const [busca, setBusca]   = useState("");
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(null);
  const [abaMostrada, setAbaMostrada] = useState("usuarios");
  const [filtrosUsuarios, setFiltrosUsuarios] = useState({});
  const [filtrosRifas, setFiltrosRifas] = useState({});
  const [rifaSelecionada, setRifaSelecionada] = useState(null);
  const [modalRifaAberto, setModalRifaAberto] = useState(false);
  const [editandoRifa, setEditandoRifa] = useState(null);
  const [formRifa, setFormRifa] = useState({});
  const [processandoRifa, setProcessandoRifa] = useState(false);
  const [modalCargoAberto, setModalCargoAberto] = useState(false);
  const [usuarioParaEditar, setUsuarioParaEditar] = useState(null);
  const [usuarioParaPlano, setUsuarioParaPlano] = useState(null);
  const [planoSelecionado, setPlanoSelecionado] = useState(null);

  const PLANOS = [
    { id: 'iniciante', label: 'Iniciante', cor: '#57636C' },
    { id: 'standard', label: 'Standard', cor: '#1565C0' },
    { id: 'gold', label: 'Gold', cor: '#F0A500' },
    { id: 'premium', label: 'Premium', cor: '#170073' },
  ];

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      if (!me) return;
      const [lista, rifasData] = await Promise.all([
        base44.entities.User.list("-created_date", 200),
        base44.entities.Rifa.list("-created_date", 500),
      ]);
      setUsers(lista);
      setRifas(rifasData);
      setLoading(false);
    };
    init();
  }, []);

  const alterarCargo = async (userId, novoRole) => {
    setSalvando(userId);
    await base44.entities.User.update(userId, { role: novoRole });
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: novoRole } : u));
    setSalvando(null);
  };

  const abrirModalRifa = (rifa) => {
    setRifaSelecionada(rifa);
    setEditandoRifa(rifa.id);
    setFormRifa({ titulo: rifa.titulo || "", valor_por_numero: rifa.valor_por_numero || 0, valor_arrecadar: rifa.valor_arrecadar || 0, qtd_numeros: rifa.qtd_numeros || 0, data_sorteio: rifa.data_sorteio || "" });
    setModalRifaAberto(true);
  };

  const salvarEdicaoRifa = async () => {
    if (!editandoRifa) return;
    setProcessandoRifa(true);
    await base44.entities.Rifa.update(editandoRifa, formRifa);
    const updated = await base44.entities.Rifa.list("-created_date", 500);
    setRifas(updated);
    setModalRifaAberto(false);
    setProcessandoRifa(false);
  };

  const deletarRifa = async (id) => {
    if (confirm("Deletar esta rifa?")) {
      await base44.entities.Rifa.delete(id);
      setRifas(rifas.filter(r => r.id !== id));
    }
  };

  // Aplicar filtros avançados de usuários
  const usuariosFiltrados = users.filter(u => {
    const matchBusca = !filtrosUsuarios.busca || `${u.full_name || ""} ${u.email || ""}`.toLowerCase().includes(filtrosUsuarios.busca.toLowerCase());
    const matchRole = !filtrosUsuarios.role || u.role === filtrosUsuarios.role;
    const matchPlano = !filtrosUsuarios.plano || u.plano === filtrosUsuarios.plano;
    const matchData = !filtrosUsuarios.data_criacao || (u.created_date && new Date(u.created_date).toISOString().split("T")[0] >= filtrosUsuarios.data_criacao);
    return matchBusca && matchRole && matchPlano && matchData;
  });

  // Aplicar filtros avançados de rifas
  const rifasFiltradas = rifas.filter(r => {
    const matchBusca = !filtrosRifas.busca || `${r.titulo || ""} ${r.animal_nome || ""}`.toLowerCase().includes(filtrosRifas.busca.toLowerCase());
    const matchStatus = !filtrosRifas.status || r.status === filtrosRifas.status;
    const matchDono = !filtrosRifas.dono || r.dono_email?.toLowerCase().includes(filtrosRifas.dono.toLowerCase());
    const matchValorMin = !filtrosRifas.valor_minimo || (r.valor_arrecadar || 0) >= parseFloat(filtrosRifas.valor_minimo);
    const matchValorMax = !filtrosRifas.valor_maximo || (r.valor_arrecadar || 0) <= parseFloat(filtrosRifas.valor_maximo);
    return matchBusca && matchStatus && matchDono && matchValorMin && matchValorMax;
  });

  if (!user) return null;

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
          <div style={{ flex: 1, textAlign: "center" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 20, fontWeight: 900, color: "#00C9B8" }}>CLUBE DO GALO</div>
          </div>
          <div style={{ width: 22 }} />
        </div>
        <div style={{ fontSize: 12, color: "rgba(255,255,255,.8)", textAlign: "center" }}>Gerenciar cargos e configurações</div>
      </div>

      <div style={{ padding: "20px", maxWidth: 900, margin: "0 auto" }}>
        {/* Menu Grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(100px, 1fr))", gap: 12, marginBottom: 20 }}>
          {[
            { id: "usuarios", label: "👤 Usuários", icon: "👤" },
            { id: "rifas", label: "🎰 Rifas", icon: "🎰" },
            { id: "gateway", label: "💳 NyxPay", icon: "💳", admin: true },
            { id: "socios", label: "👥 Sócios", icon: "👥", admin: true },
            { id: "auditoria", label: "📋 Auditoria", icon: "📋", admin: true },
            { id: "dados", label: "📊 Dados", icon: "📊", admin: true },
            { id: "suporte", label: "💬 Suporte", icon: "💬", admin: true },
            { id: "consultorias", label: "💬 Consultorias", icon: "💬", admin: true },
            { id: "saques", label: "💰 Saques", icon: "💰", admin: true },
          ].filter(item => !item.admin || user?.role === "admin" || user?.role === "master_admin").map(item => (
            <button key={item.id} onClick={() => setAbaMostrada(item.id)}
              style={{
                padding: "14px 10px",
                borderRadius: 12,
                border: abaMostrada === item.id ? "2px solid #170073" : "1px solid #E8ECF0",
                background: abaMostrada === item.id ? "#EEF0FF" : "#fff",
                cursor: "pointer",
                fontWeight: 700,
                fontSize: 11,
                fontFamily: "Montserrat,sans-serif",
                color: abaMostrada === item.id ? "#170073" : "#101213",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 6,
                textAlign: "center",
              }}>
              <span style={{ fontSize: 20 }}>{item.icon}</span>
              {item.label.split(' ')[1]}
            </button>
          ))}
        </div>

        {/* Aba: Usuários */}
        {abaMostrada === "usuarios" && (
          <>
            {/* Legenda de cargos */}
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
              {CARGOS.map(c => (
                <div key={c.value} style={{ display: "flex", alignItems: "center", gap: 5, background: "#fff", borderRadius: 10, padding: "5px 10px", border: `1.5px solid ${c.cor}30`, fontSize: 11, fontWeight: 700, color: c.cor }}>
                  {c.emoji} {c.label}
                </div>
              ))}
            </div>

            {/* Filtros avançados */}
            <AdminFiltros tipo="usuarios" filtros={filtrosUsuarios} onFiltrosChange={setFiltrosUsuarios} />

            {/* Exportação */}
            <div style={{ marginBottom: 12 }}>
              <AdminExportacao dados={usuariosFiltrados} tipo="usuarios" nome="usuarios" />
            </div>

            {loading ? (
              <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>Carregando...</div>
            ) : usuariosFiltrados.map(u => {
              const cargo = CARGOS.find(c => c.value === u.role) || CARGOS[0];
              return (
                <div key={u.id} style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", marginBottom: 10, border: "1px solid #E8ECF0" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
                    <div style={{ width: 40, height: 40, borderRadius: "50%", background: "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, color: "#fff", fontWeight: 900, fontFamily: "Montserrat,sans-serif", flexShrink: 0 }}>
                      {(u.full_name?.[0] || u.email?.[0] || "U").toUpperCase()}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213" }}>{u.full_name || "—"}</div>
                      <div style={{ fontSize: 11, color: "#57636C", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.email}</div>
                    </div>
                    <div style={{ fontSize: 10, fontWeight: 700, background: cargo.cor + "15", color: cargo.cor, padding: "4px 8px", borderRadius: 8 }}>
                      {cargo.emoji} {cargo.label}
                    </div>
                  </div>

                  {/* Botões Editar Cargo e Plano */}
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => { setUsuarioParaEditar(u); setModalCargoAberto(true); }}
                      style={{ padding: "8px 14px", borderRadius: 10, border: "none", background: "#170073", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif" }}>
                      ✏️ Cargo
                    </button>
                    <button onClick={() => { setUsuarioParaPlano(u); setPlanoSelecionado(u.plano || 'iniciante'); }}
                      style={{ padding: "8px 14px", borderRadius: 10, border: "none", background: "#00A893", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif" }}>
                      👑 Plano
                    </button>
                  </div>
                </div>
              );
            })}
          </>
        )}

        {/* Aba: Gateway - Apenas Master Admin */}
        {abaMostrada === "gateway" && user?.role === "master_admin" && (
          <ConfigurarNyxpay user={user} />
        )}
        {abaMostrada === "gateway" && user?.role !== "master_admin" && (
          <div style={{ background: "#FFF8E1", borderRadius: 14, padding: "14px 16px", border: "1px solid #F0A500", textAlign: "center", color: "#856404" }}>
            ⚠️ Apenas Master Admin pode configurar o gateway de pagamento
          </div>
        )}

        {/* Aba: Sócios */}
        {abaMostrada === "socios" && user?.role === "master_admin" && (
          <GestaoSocios user={user} />
        )}
        {abaMostrada === "socios" && user?.role !== "master_admin" && (
          <div style={{ background: "#FFF8E1", borderRadius: 14, padding: "14px 16px", border: "1px solid #F0A500", textAlign: "center", color: "#856404" }}>
            ⚠️ Apenas Master Admin pode gerenciar sócios
          </div>
        )}

        {/* Aba: Gerenciamento de Dados */}
        {abaMostrada === "dados" && user?.role === "master_admin" && (
          <GerenciamentoDados user={user} />
        )}
        {abaMostrada === "dados" && user?.role !== "master_admin" && (
          <div style={{ background: "#FFF8E1", borderRadius: 14, padding: "14px 16px", border: "1px solid #F0A500", textAlign: "center", color: "#856404" }}>
            ⚠️ Apenas Master Admin pode gerenciar dados
          </div>
        )}

        {/* Aba: Suporte */}
        {abaMostrada === "suporte" && (user?.role === "admin" || user?.role === "master_admin") && (
          <SuporteAoUsuario user={user} />
        )}



        {/* Aba: Auditoria */}
        {abaMostrada === "auditoria" && (user?.role === "admin" || user?.role === "master_admin") && (
         <AdminAuditoria />
        )}

        {/* Aba: Consultorias */}
        {abaMostrada === "consultorias" && (user?.role === "admin" || user?.role === "master_admin") && (
         <GestaoConsultorias />
        )}

        {/* Aba: Saques */}
        {abaMostrada === "saques" && (user?.role === "admin" || user?.role === "master_admin") && (
          <div style={{ textAlign: "center", padding: 20 }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>💰</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 8 }}>Gestão de Saques</div>
            <div style={{ fontSize: 13, color: "#57636C", marginBottom: 20 }}>Gerencie aprovações, recusas e o modo de saque (automático/manual).</div>
            <Link to="/admin-saques"
              style={{ display: "inline-block", padding: "14px 28px", borderRadius: 12, background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontFamily: "Montserrat,sans-serif", fontWeight: 900, fontSize: 14, textDecoration: "none" }}>
              Abrir Painel de Saques →
            </Link>
          </div>
        )}

        {/* Aba: Rifas */}
        {abaMostrada === "rifas" && (
          <div>
            {/* Filtros avançados */}
            <AdminFiltros tipo="rifas" filtros={filtrosRifas} onFiltrosChange={setFiltrosRifas} />

            {/* Exportação */}
            <div style={{ marginBottom: 12 }}>
              <AdminExportacao dados={rifasFiltradas} tipo="rifas" nome="rifas" />
            </div>

            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C", marginBottom: 12 }}>{rifasFiltradas.length} de {rifas.length} rifas</div>
            {rifasFiltradas.map(r => {
              const percentualVenda = r.qtd_numeros > 0 ? ((r.numeros_vendidos || 0) / r.qtd_numeros) * 100 : 0;
              const percentualMeta = r.valor_arrecadar > 0 ? ((r.total_arrecadado || 0) / r.valor_arrecadar) * 100 : 0;
              return (
                <div key={r.id} style={{ background: "#fff", borderRadius: 12, padding: "14px", marginBottom: 10, border: "1px solid #E8ECF0" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800 }}>{r.titulo || r.animal_nome}</div>
                      <div style={{ fontSize: 11, color: "#57636C" }}>Dono: {r.dono_nome}</div>
                      <div style={{ fontSize: 11, color: "#57636C" }}>Animal: {r.animal_nome} (Anilha: {r.animal_anilha})</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 10, fontWeight: 800, borderRadius: 8, padding: "3px 8px", background: r.status === "ativa" ? "#E8F5E9" : r.status === "encerrada" ? "#F1F4F8" : "#FFF8E1", color: r.status === "ativa" ? "#2E7D32" : r.status === "encerrada" ? "#57636C" : "#F0A500" }}>{r.status}</div>
                      <div style={{ fontSize: 10, color: "#BDBDBD", marginTop: 4 }}>🗓️ {new Date(r.data_sorteio).toLocaleDateString("pt-BR")}</div>
                    </div>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 8, marginBottom: 10 }}>
                    <div style={{ background: "#F8FAFC", borderRadius: 8, padding: 8 }}>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>💰 Arrecadado</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#170073" }}>R$ {Number(r.total_arrecadado || 0).toFixed(2)}</div>
                      <div style={{ fontSize: 9, color: "#00A893" }}>{percentualMeta.toFixed(0)}% da meta</div>
                    </div>
                    <div style={{ background: "#F8FAFC", borderRadius: 8, padding: 8 }}>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>🎟️ Números</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#170073" }}>{r.numeros_vendidos || 0}/{r.qtd_numeros}</div>
                      <div style={{ fontSize: 9, color: "#00A893" }}>{percentualVenda.toFixed(0)}% vendidos</div>
                    </div>
                    <div style={{ background: "#F8FAFC", borderRadius: 8, padding: 8 }}>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>💵 Por Número</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#170073" }}>R$ {Number(r.valor_por_numero || 0).toFixed(2)}</div>
                    </div>
                    <div style={{ background: "#F8FAFC", borderRadius: 8, padding: 8 }}>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>🎯 Meta</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#170073" }}>R$ {Number(r.valor_arrecadar || 0).toFixed(2)}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button onClick={() => abrirModalRifa(r)} style={{ padding: "6px 12px", borderRadius: 8, background: "#170073", color: "#fff", border: "none", fontWeight: 700, fontSize: 11, cursor: "pointer" }}>✏️ Editar</button>
                    <button onClick={() => deletarRifa(r.id)} style={{ padding: "6px 12px", borderRadius: 8, background: "#FFE0E6", color: "#E21C3D", border: "none", fontWeight: 700, fontSize: 11, cursor: "pointer" }}>🗑️ Deletar</button>
                    {r.ganhador_id && <div style={{ padding: "6px 12px", borderRadius: 8, background: "#E8F5E9", color: "#2E7D32", fontSize: 11, fontWeight: 700 }}>🏆 Ganhador: {r.ganhador_nome}</div>}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Modal Atribuir Cargo */}
        {modalCargoAberto && usuarioParaEditar && (
          <ModalAtribuirCargo
            usuario={usuarioParaEditar}
            onClose={() => setModalCargoAberto(false)}
            onCargoAtribuido={(userId, novoRole) => {
              setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: novoRole } : u));
            }}
          />
        )}

        {/* Modal Atribuir Plano */}
        {usuarioParaPlano && (
          <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 999, display: "flex", alignItems: "center", justifyContent: "center" }} onClick={() => setUsuarioParaPlano(null)}>
            <div style={{ background: "#fff", borderRadius: "20px", padding: "24px 20px", zIndex: 1000, width: "90%", maxWidth: "360px", boxShadow: "0 20px 60px rgba(0,0,0,.3)" }} onClick={e => e.stopPropagation()}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>👑 Atribuir Plano</div>
                <button onClick={() => setUsuarioParaPlano(null)} style={{ background: "none", border: "none", fontSize: 24, cursor: "pointer", color: "#57636C", padding: 0 }}>✕</button>
              </div>

              <div style={{ background: "#F8FAFC", borderRadius: 10, padding: "10px 12px", marginBottom: 12, border: "1px solid #E8ECF0" }}>
                <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>{usuarioParaPlano.email}</div>
                <div style={{ fontSize: 9, color: "#BDBDBD", marginTop: 4 }}>Plano atual: <strong>{PLANOS.find(p => p.id === usuarioParaPlano.plano)?.label || 'Iniciante'}</strong></div>
              </div>

              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 8 }}>Selecione um plano:</div>
                <div style={{ display: "grid", gap: 6 }}>
                  {PLANOS.map(plano => (
                    <button key={plano.id} onClick={() => setPlanoSelecionado(plano.id)}
                      style={{
                        padding: "12px",
                        borderRadius: 10,
                        border: `2px solid ${planoSelecionado === plano.id ? plano.cor : "#E8ECF0"}`,
                        background: planoSelecionado === plano.id ? plano.cor + "15" : "#fff",
                        color: plano.cor,
                        cursor: "pointer",
                        fontWeight: 700,
                        fontSize: 12,
                        fontFamily: "Montserrat,sans-serif",
                      }}>
                      {planoSelecionado === plano.id ? "✓" : "○"} {plano.label}
                    </button>
                  ))}
                </div>
              </div>

              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={() => setUsuarioParaPlano(null)}
                  style={{ flex: 1, padding: "10px", borderRadius: 10, border: "1.5px solid #E8ECF0", background: "#fff", color: "#57636C", cursor: "pointer", fontWeight: 700, fontSize: 12, fontFamily: "Montserrat,sans-serif" }}>
                  Cancelar
                </button>
                <button onClick={async () => {
                  if (usuarioParaPlano && planoSelecionado) {
                    await base44.entities.User.update(usuarioParaPlano.id, { plano: planoSelecionado });
                    setUsers(prev => prev.map(u => u.id === usuarioParaPlano.id ? { ...u, plano: planoSelecionado } : u));
                    setUsuarioParaPlano(null);
                  }
                }}
                  style={{ flex: 1, padding: "10px", borderRadius: 10, border: "none", background: "linear-gradient(135deg, #170073, #00A893)", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 12, fontFamily: "Montserrat,sans-serif" }}>
                  ✅ Atribuir
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Editar Rifa */}
        {modalRifaAberto && rifaSelecionada && (
          <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalRifaAberto(false)}>
            <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 16 }}>✏️ Editar Rifa</div>
              <div style={{ display: "grid", gap: 12, marginBottom: 16 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Título</label>
                  <input type="text" value={formRifa.titulo || ""} onChange={e => setFormRifa({ ...formRifa, titulo: e.target.value })} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <div>
                    <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Valor/Número</label>
                    <input type="number" value={formRifa.valor_por_numero || 0} onChange={e => setFormRifa({ ...formRifa, valor_por_numero: parseFloat(e.target.value) || 0 })} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                  </div>
                  <div>
                    <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Meta (R$)</label>
                    <input type="number" value={formRifa.valor_arrecadar || 0} onChange={e => setFormRifa({ ...formRifa, valor_arrecadar: parseFloat(e.target.value) || 0 })} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                  </div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <div>
                    <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Qtd de Números</label>
                    <input type="number" value={formRifa.qtd_numeros || 0} onChange={e => setFormRifa({ ...formRifa, qtd_numeros: parseInt(e.target.value) || 0 })} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                  </div>
                  <div>
                    <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Data Sorteio</label>
                    <input type="date" value={formRifa.data_sorteio || ""} onChange={e => setFormRifa({ ...formRifa, data_sorteio: e.target.value })} style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                  </div>
                </div>
              </div>
              <button onClick={salvarEdicaoRifa} disabled={processandoRifa} style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: processandoRifa ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: processandoRifa ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>{processandoRifa ? "Salvando..." : "✅ Salvar Alterações"}</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}