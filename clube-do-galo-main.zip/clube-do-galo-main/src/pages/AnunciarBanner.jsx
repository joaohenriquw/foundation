import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import NotificacoesSino from "../components/NotificacoesSino";
import BottomNav from "../components/BottomNav";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

const PLANOS_BANNER = [
  { id: "semanal", label: "1 Semana", dias: 7, preco: 49.90, descricao: "Exibição por 7 dias" },
  { id: "quinzena", label: "2 Semanas", dias: 14, preco: 89.90, descricao: "Exibição por 14 dias" },
  { id: "mensal", label: "1 Mês", dias: 30, preco: 149.90, descricao: "Exibição por 30 dias" },
  { id: "trimestral", label: "3 Meses", dias: 90, preco: 399.90, descricao: "Exibição por 90 dias" },
];

export default function AnunciarBanner() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [step, setStep] = useState(1); // 1: seleção | 2: dados | 3: pagamento
  const [planoSelecionado, setPlanoSelecionado] = useState(null);
  const [titulo, setTitulo] = useState("");
  const [link, setLink] = useState("");
  const [imagem, setImagem] = useState(null);
  const [processando, setProcessando] = useState(false);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      if (!me) {
        navigate("/");
        return;
      }
      setUser(me);
    };
    init();
  }, [navigate]);

  const handleUploadImagem = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProcessando(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setImagem(file_url);
    } finally {
      setProcessando(false);
    }
  };

  const handleCriarBanner = async () => {
    if (!planoSelecionado || !titulo || !imagem) {
      alert("Preencha todos os campos!");
      return;
    }

    setProcessando(true);
    try {
      const plano = PLANOS_BANNER.find(p => p.id === planoSelecionado);
      const dataFim = new Date();
      dataFim.setDate(dataFim.getDate() + plano.dias);

      const anuncio = await base44.entities.Anuncio.create({
        titulo,
        imagem_url: imagem,
        link_destino: link,
        anunciante: user.full_name,
        anunciante_email: user.email,
        data_inicio: new Date().toISOString(),
        data_fim: dataFim.toISOString(),
        ativo: true,
        valor_pago: plano.preco,
      });

      alert("✅ Banner criado com sucesso! Será exibido em breve.");
      navigate("/");
    } catch (error) {
      alert("Erro ao criar banner: " + error.message);
    } finally {
      setProcessando(false);
    }
  };

  if (!user) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", color: "#57636C" }}>
        Carregando...
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#fff", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: 800, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Link to="/perfil-usuario" style={{ color: "#fff", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>📢 Anunciar Banner</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Divulgue seu negócio</div>
            </div>
          </div>
          <NotificacoesSino userEmail={user.email} />
        </div>
      </div>

      <div style={{ padding: "20px", maxWidth: 800, margin: "0 auto" }}>
        {/* Step 1: Seleção de Plano */}
        {step === 1 && (
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, marginBottom: 20, color: "#000" }}>
             Escolha a Duração do Seu Banner
            </div>
            <div style={{ display: "grid", gap: 12, marginBottom: 20 }}>
              {PLANOS_BANNER.map(p => (
                <button
                  key={p.id}
                  onClick={() => { setPlanoSelecionado(p.id); setStep(2); }}
                  style={{
                    padding: "16px",
                    borderRadius: 12,
                    border: "2px solid #E8ECF0",
                    background: "#fff",
                    cursor: "pointer",
                    textAlign: "left",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}>
                  <div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 4 }}>
                      {p.label}
                    </div>
                    <div style={{ fontSize: 12, color: "#57636C" }}>{p.descricao}</div>
                  </div>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
                    {fmt(p.preco)}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Dados do Banner */}
        {step === 2 && (
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, marginBottom: 20, color: "#000" }}>
              Dados do Banner
            </div>
            <div style={{ display: "grid", gap: 14, marginBottom: 20 }}>
              <div>
                <label style={{ fontSize: 12, fontWeight: 700, color: "#000", display: "block", marginBottom: 6 }}>
                  Título do Banner
                </label>
                <input
                  type="text"
                  value={titulo}
                  onChange={e => setTitulo(e.target.value)}
                  placeholder="Ex: Descubra nossos novos produtos"
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: 10,
                    border: "1.5px solid #E8ECF0",
                    fontSize: 13,
                    boxSizing: "border-box",
                    color: "#101213",
                    backgroundColor: "#fff",
                    outline: "none",
                  }}
                />
              </div>

              <div>
                <label style={{ fontSize: 12, fontWeight: 700, color: "#000", display: "block", marginBottom: 6 }}>
                  Link de Destino (opcional)
                </label>
                <input
                  type="url"
                  value={link}
                  onChange={e => setLink(e.target.value)}
                  placeholder="https://seu-site.com"
                  style={{
                    width: "100%",
                    padding: "12px",
                    borderRadius: 10,
                    border: "1.5px solid #E8ECF0",
                    fontSize: 13,
                    boxSizing: "border-box",
                    color: "#101213",
                    backgroundColor: "#fff",
                    outline: "none",
                  }}
                />
              </div>

              <div>
                <label style={{ fontSize: 12, fontWeight: 700, color: "#000", display: "block", marginBottom: 6 }}>
                  Imagem do Banner (recomendado: 1200x300px)
                </label>
                {imagem ? (
                  <div style={{ marginBottom: 10 }}>
                    <img src={imagem} alt="preview" style={{ width: "100%", borderRadius: 10, maxHeight: 150, objectFit: "cover" }} />
                    <button
                      onClick={() => setImagem(null)}
                      style={{
                        marginTop: 8,
                        padding: "8px 12px",
                        borderRadius: 8,
                        border: "none",
                        background: "#FF453A",
                        color: "#fff",
                        cursor: "pointer",
                        fontSize: 12,
                        fontWeight: 700,
                      }}>
                      Remover Imagem
                    </button>
                  </div>
                ) : (
                  <label
                    style={{
                      display: "block",
                      padding: "20px",
                      borderRadius: 10,
                      border: "2px dashed #170073",
                      textAlign: "center",
                      cursor: "pointer",
                      background: "#f5f0ff",
                    }}>
                    <input type="file" accept="image/*" onChange={handleUploadImagem} style={{ display: "none" }} />
                    <div style={{ fontSize: 14, fontWeight: 700, color: "#170073" }}>📷 Clique para fazer upload</div>
                    <div style={{ fontSize: 11, color: "#000", marginTop: 4 }}>Formatos: JPG, PNG, WebP</div>
                  </label>
                )}
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <button
                onClick={() => setStep(1)}
                style={{
                  padding: "12px",
                  borderRadius: 10,
                  border: "1.5px solid #E8ECF0",
                  background: "#fff",
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  color: "#101213",
                }}
              >
                ← Voltar
              </button>
              <button
                onClick={() => setStep(3)}
                disabled={!titulo || !imagem || processando}
                style={{
                  padding: "12px",
                  borderRadius: 10,
                  border: "none",
                  background: !titulo || !imagem ? "#999" : "linear-gradient(135deg,#170073,#00A893)",
                  color: "#fff",
                  cursor: !titulo || !imagem ? "default" : "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  fontFamily: "Montserrat,sans-serif",
                }}>
                Próximo →
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Confirmação */}
        {step === 3 && (
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, marginBottom: 20, color: "#000" }}>
              Revisar e Confirmar
            </div>
            <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: 20, marginBottom: 20 }}>
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 12, color: "#000", marginBottom: 4, fontWeight: 700 }}>Imagem</div>
                <img src={imagem} alt="banner" style={{ width: "100%", borderRadius: 10, maxHeight: 150, objectFit: "cover" }} />
              </div>
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 12, color: "#000", marginBottom: 4, fontWeight: 700 }}>Título</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 800, color: "#000" }}>{titulo}</div>
              </div>
              <div>
                <div style={{ fontSize: 12, color: "#000", marginBottom: 4, fontWeight: 700 }}>Duração</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 800, color: "#000" }}>
                  {PLANOS_BANNER.find(p => p.id === planoSelecionado)?.label} - {fmt(PLANOS_BANNER.find(p => p.id === planoSelecionado)?.preco)}
                </div>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <button
                onClick={() => setStep(2)}
                style={{
                  padding: "12px",
                  borderRadius: 10,
                  border: "1.5px solid #E8ECF0",
                  background: "#fff",
                  cursor: "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  color: "#101213",
                }}
              >
                ← Voltar
              </button>
              <button
                onClick={handleCriarBanner}
                disabled={processando}
                style={{
                  padding: "12px",
                  borderRadius: 10,
                  border: "none",
                  background: processando ? "#999" : "linear-gradient(135deg,#170073,#00A893)",
                  color: "#fff",
                  cursor: processando ? "default" : "pointer",
                  fontWeight: 700,
                  fontSize: 13,
                  fontFamily: "Montserrat,sans-serif",
                }}
              >
                {processando ? "⏳ Processando..." : "✅ Confirmar e Publicar"}
              </button>
            </div>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}