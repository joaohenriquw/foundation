import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import BottomNav from "../components/BottomNav";

const CORES_ANILHA = {
  azul_escuro:  { label: "Azul Escuro",  bg: "#dbeafe", cor: "#0c3a78" },
  preto:        { label: "Preto",        bg: "#e5e7eb", cor: "#000000" },
  verde:        { label: "Verde",        bg: "#dcfce7", cor: "#15803d" },
  amarelo:      { label: "Amarelo",      bg: "#fef3c7", cor: "#ca8a04" },
  laranja:      { label: "Laranja",      bg: "#fed7aa", cor: "#c2410c" },
  roxo:         { label: "Roxo",         bg: "#ede9fe", cor: "#6d28d9" },
  rosa:         { label: "Rosa",         bg: "#fbcfe8", cor: "#be185d" },
  branco:       { label: "Branco",       bg: "#f3f4f6", cor: "#ffffff", borda: "#333" },
};

const STATS_STATUS = {
  incubando:        { label: "Incubando",        cor: "#eab308", emoji: "🥚" },
  pronto_para_troca: { label: "Pronto p/ Troca", cor: "#8b5cf6", emoji: "✅" },
  convertida:       { label: "Convertida",       cor: "#10b981", emoji: "🐓" },
};

export default function CadernoAnilhas() {
  const [aba, setAba] = useState("compradas");
  const [anilhasCompradas, setAnilhasCompradas] = useState([]);
  const [anilhasFilhas, setAnilhasFilhas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [busca, setBusca] = useState("");
  const [filtroStatus, setFiltroStatus] = useState("todos");
  const [formComprada, setFormComprada] = useState(null);
  const [formFilha, setFormFilha] = useState(null);
  const [animais, setAnimais] = useState([]);
  const [sugestoesPai, setSugestoesPai] = useState([]);
  const [sugestoesMae, setSugestoesMae] = useState([]);

  const carregar = async () => {
    setLoading(true);
    const me = await base44.auth.me().catch(() => null);
    setUser(me);

    if (me) {
      const [todasAnilhas, animaisData] = await Promise.all([
        base44.entities.AnilhaFilha.filter({ usuario_email: me.email }, "-created_date", 200),
        base44.entities.Animal.filter({ proprietario_email: me.email }, "nome", 200),
      ]);
      setAnilhasCompradas(todasAnilhas.filter(a => a.tipo === "comprada" || !a.tipo));
      setAnilhasFilhas(todasAnilhas.filter(a => a.tipo === "filha"));
      setAnimais(animaisData);
    }
    setLoading(false);
  };

  const filtrarAnimais = (texto) => {
    if (!texto) return [];
    return animais.filter(a => a.nome?.toLowerCase().includes(texto.toLowerCase())).slice(0, 5);
  };

  useEffect(() => {
    carregar();
    const unsub = base44.entities.AnilhaFilha.subscribe(() => carregar());
    return unsub;
  }, []);

  const salvarAnilhaComprada = async () => {
     const hoje = new Date().toISOString().split('T')[0];
     for (let i = 0; i < formComprada.quantidade; i++) {
       await base44.entities.AnilhaFilha.create({
         usuario_email: user.email,
         tipo: "comprada",
         animal_pai_id: formComprada.animal_pai_id || "",
         animal_pai_nome: formComprada.animal_pai_nome,
         animal_mae_id: formComprada.animal_mae_id || "",
         animal_mae_nome: formComprada.animal_mae_nome,
         anilha_numero: `GG-${hoje.split('-').join('')}-${String(i + 1).padStart(4, '0')}`,
         cor_anilha_definitiva: formComprada.cor,
         data_criacao: hoje,
         data_troca_definitiva: formComprada.data_troca,
         status: "incubando",
       });
     }
     setFormComprada(null);
     carregar();
   };

  const excluir = async (id) => {
    if (!confirm("Excluir esta anilha?")) return;
    await base44.entities.AnilhaFilha.delete(id);
    carregar();
  };

  let itemsFiltrados = aba === "compradas" ? anilhasCompradas : anilhasFilhas;

  if (filtroStatus !== "todos") {
    itemsFiltrados = itemsFiltrados.filter(a => a.status === filtroStatus);
  }

  if (busca) {
    itemsFiltrados = itemsFiltrados.filter(a =>
      `${a.anilha_numero} ${a.animal_pai_nome || ""} ${a.animal_mae_nome || ""}`.toLowerCase().includes(busca.toLowerCase())
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 80, color: "#fff" }}>
      {/* Header */}
      <div style={{ background: "#0A0A0A", padding: "52px 20px 16px", borderBottom: "1px solid #1C1C1E" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={() => { const nav = window.history.length > 1 ? -1 : '/'; window.history.length > 1 ? window.history.back() : window.location.href = '/'; }} style={{ background: "#1C1C1E", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", fontSize: 18, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#00C9B8", display: "flex", alignItems: "center", gap: 8 }}><img src="https://media.base44.com/images/public/69cf34a8fab4925b6658841a/007f8b306_WhatsAppImage2026-04-03at235723.jpg" alt="Anilhas" style={{ width: 24, height: 24 }} /> Caderno de Anilhas</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Gestão centralizada · Clube do Galo</div>
          </div>
        </div>
      </div>

      <div style={{ padding: "16px 16px 20px", maxWidth: 800, margin: "0 auto" }}>
        {/* Forma Simplificada - Genealogia + Cores + Datas + Anilhas */}
        <div style={{ background: "#1C1C1E", borderRadius: 16, padding: 16, border: "1px solid #333" }}>
          {/* Genealogia */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
            <div>
              <label style={{ fontSize: 10, fontWeight: 700, color: "#888", textTransform: "uppercase", display: "block", marginBottom: 6 }}>PAI</label>
              <input type="text" placeholder="Filiais" value={formFilha?.animal_pai_nome || ""}
                onChange={e => setFormFilha(p => ({ ...p, animal_pai_nome: e.target.value }))}
                style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid #333", background: "#fff", color: "#000", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div>
              <label style={{ fontSize: 10, fontWeight: 700, color: "#888", textTransform: "uppercase", display: "block", marginBottom: 6 }}>MÃE</label>
              <input type="text" placeholder="Rojem" value={formFilha?.animal_mae_nome || ""}
                onChange={e => setFormFilha(p => ({ ...p, animal_mae_nome: e.target.value }))}
                style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid #333", background: "#fff", color: "#000", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
            </div>
          </div>

          {/* Cores */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#888", textTransform: "uppercase", display: "block", marginBottom: 10 }}>🎨 COR DA ANILHA DEFINITIVA</label>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {Object.entries(CORES_ANILHA).map(([k, c]) => (
                <button key={k} onClick={() => setFormFilha(p => ({ ...p, cor: k }))}
                  style={{ width: 50, height: 50, borderRadius: 12, border: formFilha?.cor === k ? "3px solid #00C9B8" : "2px solid #555", background: c.cor, cursor: "pointer" }} />
              ))}
            </div>
          </div>

          {/* Datas */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
            <div>
              <label style={{ fontSize: 10, fontWeight: 700, color: "#888", textTransform: "uppercase", display: "block", marginBottom: 6 }}>📅 DATA DE CRIAÇÃO</label>
              <input type="date" value={formFilha?.data_criacao || ""}
                onChange={e => setFormFilha(p => ({ ...p, data_criacao: e.target.value }))}
                style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid #333", background: "#fff", color: "#000", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
            </div>
            <div>
              <label style={{ fontSize: 10, fontWeight: 700, color: "#888", textTransform: "uppercase", display: "block", marginBottom: 6 }}>📅 DATA DA TROCA</label>
              <input type="date" value={formFilha?.data_troca || ""}
                onChange={e => setFormFilha(p => ({ ...p, data_troca: e.target.value }))}
                style={{ width: "100%", padding: "10px", borderRadius: 8, border: "1px solid #333", background: "#fff", color: "#000", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
            </div>
          </div>

          {/* Anilhas */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 10, fontWeight: 700, color: "#888", textTransform: "uppercase", display: "block", marginBottom: 12 }}>🎨 NÚMEROS DAS ANILHAS</label>
            <div style={{ display: "grid", gap: 8 }}>
              {[1, 2].map(i => (
                <div key={i} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <div style={{ width: 24, height: 24, borderRadius: 6, background: "#00A893", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 12 }}>●</div>
                  <input type="text" placeholder={`Anilha ${i}`}
                    style={{ flex: 1, padding: "10px", borderRadius: 8, border: "1px solid #333", background: "#fff", color: "#000", fontSize: 12, outline: "none", boxSizing: "border-box" }} />
                  <button style={{ padding: "8px 12px", borderRadius: 6, border: "none", background: "#E21C3D", color: "#fff", cursor: "pointer", fontWeight: 700 }}>✕</button>
                </div>
              ))}
            </div>
            <button style={{ width: "100%", marginTop: 12, padding: "10px", borderRadius: 8, border: "1px dashed #00C9B8", background: "transparent", color: "#00C9B8", cursor: "pointer", fontWeight: 700, fontSize: 12 }}>+ Adicionar</button>
          </div>

          {/* Botão Salvar */}
          <button onClick={() => { /* save */ }} style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontWeight: 900, fontFamily: "Montserrat,sans-serif", cursor: "pointer" }}>Chat to Expert</button>
        </div>

        {/* Lista de Anilhas Registradas */}
        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>Carregando...</div>
        ) : itemsFiltrados.length === 0 ? (
          <div style={{ textAlign: "center", padding: 40 }}>
            <div style={{ fontSize: 48, marginBottom: 10 }}>🔍</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>Nenhuma anilha encontrada</div>
          </div>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {(() => {
              // Agrupar anilhas por genealogia (pai + mãe)
              const grupos = {};
              itemsFiltrados.forEach(item => {
                const chave = `${item.animal_pai_nome || "?"}|${item.animal_mae_nome || "?"}`;
                if (!grupos[chave]) {
                  grupos[chave] = { paiNome: item.animal_pai_nome, maeNome: item.animal_mae_nome, anilhas: [] };
                }
                grupos[chave].anilhas.push(item);
              });
              return Object.entries(grupos).map(([chave, grupo]) => (
                <div key={chave} style={{ background: "#1C1C1E", borderRadius: 14, border: "1px solid #333", overflow: "hidden" }}>
                  {/* Header do lote - Pai e Mãe pequeno */}
                  <div style={{ padding: "8px 14px", background: "#2C2C2E", borderBottom: "1px solid #333" }}>
                    <div style={{ fontSize: 10, color: "#888", fontWeight: 700, lineHeight: 1.4 }}>
                      {grupo.paiNome && <div>♂️ {grupo.paiNome}</div>}
                      {grupo.maeNome && <div>♀️ {grupo.maeNome}</div>}
                    </div>
                  </div>

                  {/* Grid de anilhas do lote */}
                  <div style={{ padding: "12px", display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(100px, 1fr))", gap: 8 }}>
                    {grupo.anilhas.map(item => {
                      const corCfg = CORES_ANILHA[item.cor_anilha_definitiva] || CORES_ANILHA.amarelo;
                      const statusCfg = STATS_STATUS[item.status] || STATS_STATUS.incubando;
                      const diasRestantes = item.data_troca_definitiva ? Math.ceil((new Date(item.data_troca_definitiva + "T23:59") - new Date()) / (1000 * 60 * 60 * 24)) : null;
                      return (
                        <div
                          key={item.id}
                          style={{
                            background: corCfg.bg,
                            borderRadius: 10,
                            border: `2px solid ${corCfg.cor}`,
                            padding: "10px 8px",
                            textAlign: "center",
                            position: "relative",
                          }}
                          onContextMenu={e => { e.preventDefault(); excluir(item.id); }}
                          title="Clique direito para excluir"
                        >
                          {/* Número ou status */}
                          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: corCfg.cor, marginBottom: 3 }}>
                            {item.anilha_numero || statusCfg.emoji}
                          </div>

                          {/* Prazo pequeno */}
                          {diasRestantes !== null && (
                            <div style={{ fontSize: 9, color: diasRestantes < 30 ? "#e74c3c" : "#888", fontWeight: 700 }}>
                              {diasRestantes > 0 ? `${diasRestantes}d` : "Vencido"}
                            </div>
                          )}

                          {/* Badge status pequeno */}
                          <div style={{ fontSize: 8, color: statusCfg.cor, fontWeight: 700, marginTop: 2 }}>
                            {statusCfg.label}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Resumo do lote */}
                  <div style={{ padding: "8px 14px", borderTop: "1px solid #333", fontSize: 10, color: "#555", textAlign: "center" }}>
                    {grupo.anilhas.length} anilha{grupo.anilhas.length !== 1 ? "s" : ""} · {grupo.anilhas.filter(a => a.status === "incubando").length} 🥚 {grupo.anilhas.filter(a => a.status === "convertida").length} 🐓
                  </div>
                </div>
              ));
            })()}
          </div>
        )}
      </div>

      {/* Modal Anilhas Filhas (fase 1: cor + pai + mãe) */}
      {formFilha && !formFilha.data_troca_definida && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
          onClick={e => e.target === e.currentTarget && setFormFilha(null)}
        >
          <div style={{ background: "#1C1C1E", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 600, maxHeight: "92vh", overflowY: "auto", padding: "20px 20px 40px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🐣 Registrar Ninhada</div>
              <button onClick={() => setFormFilha(null)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            <div style={{ display: "grid", gap: 12 }}>
              {/* Pai */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>♂️ Pai</label>
                <input
                  type="text"
                  placeholder="Digite o nome do pai"
                  value={formFilha.animal_pai_nome}
                  onChange={e => {
                    setFormFilha(p => ({ ...p, animal_pai_nome: e.target.value }));
                    setSugestoesPai(filtrarAnimais(e.target.value));
                  }}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", background: "#1C1C1E", color: "#FFFFFF" }}
                />
                {sugestoesPai.length > 0 && (
                  <div style={{ marginTop: 4, display: "flex", flexDirection: "column", gap: 4 }}>
                    {sugestoesPai.map(a => (
                      <button
                        key={a.id}
                        onClick={() => {
                          setFormFilha(p => ({ ...p, animal_pai_nome: a.nome, animal_pai_id: a.id }));
                          setSugestoesPai([]);
                        }}
                        style={{ textAlign: "left", padding: "8px", borderRadius: 8, border: "1px solid #E8ECF0", background: "#f8f9fa", cursor: "pointer", fontSize: 12 }}
                      >
                        {a.nome} ({a.anilha})
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Mãe */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>♀️ Mãe</label>
                <input
                  type="text"
                  placeholder="Digite o nome da mãe"
                  value={formFilha.animal_mae_nome}
                  onChange={e => {
                    setFormFilha(p => ({ ...p, animal_mae_nome: e.target.value }));
                    setSugestoesMae(filtrarAnimais(e.target.value));
                  }}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", background: "#1C1C1E", color: "#FFFFFF" }}
                />
                {sugestoesMae.length > 0 && (
                  <div style={{ marginTop: 4, display: "flex", flexDirection: "column", gap: 4 }}>
                    {sugestoesMae.map(a => (
                      <button
                        key={a.id}
                        onClick={() => {
                          setFormFilha(p => ({ ...p, animal_mae_nome: a.nome, animal_mae_id: a.id }));
                          setSugestoesMae([]);
                        }}
                        style={{ textAlign: "left", padding: "8px", borderRadius: 8, border: "1px solid #E8ECF0", background: "#f8f9fa", cursor: "pointer", fontSize: 12 }}
                      >
                        {a.nome} ({a.anilha})
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Cor */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>🎨 Cor da Anilha Definitiva</label>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {Object.entries(CORES_ANILHA).map(([k, c]) => (
                    <button
                      key={k}
                      onClick={() => setFormFilha(p => ({ ...p, cor: k }))}
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 10,
                        border: formFilha.cor === k ? `3px solid #170073` : `2px solid ${c.cor}`,
                        background: c.cor,
                        cursor: "pointer",
                        boxShadow: formFilha.cor === k ? `0 0 0 3px rgba(23,0,115,.3)` : "none",
                      }}
                      title={c.label}
                    />
                  ))}
                </div>
              </div>

              {/* Data da Troca */}
              <div>
                <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>🔄 Data da Troca</label>
                <input
                  type="date"
                  value={formFilha.data_troca}
                  onChange={e => setFormFilha(p => ({ ...p, data_troca: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", background: "#1C1C1E", color: "#FFFFFF" }}
                />
              </div>

              <button
               onClick={() => setFormFilha(p => ({ ...p, data_troca_definida: true }))}
               disabled={!formFilha.animal_pai_nome || !formFilha.animal_mae_nome}
                style={{
                  width: "100%",
                  padding: "14px",
                  borderRadius: 12,
                  border: "none",
                  background: !formFilha.animal_pai_nome || !formFilha.animal_mae_nome || !formFilha.data_troca ? "#ccc" : "linear-gradient(135deg,#8b5cf6,#6d28d9)",
                  color: "#fff",
                  cursor: !formFilha.animal_pai_nome || !formFilha.animal_mae_nome || !formFilha.data_troca ? "default" : "pointer",
                  fontFamily: "Montserrat,sans-serif",
                  fontSize: 14,
                  fontWeight: 900,
                  marginTop: 10,
                }}
              >
                Próximo: Números das Anilhas
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Anilhas Filhas (fase 2: quantidade) */}
      {formFilha && formFilha.data_troca_definida && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
          onClick={e => e.target === e.currentTarget && setFormFilha(null)}
        >
          <div style={{ background: "#1C1C1E", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 600, maxHeight: "92vh", overflowY: "auto", padding: "20px 20px 40px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🐣 Anilhas Filhas</div>
              <button onClick={() => setFormFilha(null)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>
            <div style={{ background: "#f0f4ff", borderRadius: 10, padding: "10px 12px", marginBottom: 16, fontSize: 12, color: "#170073", fontWeight: 700 }}>
              ♂️ {formFilha.animal_pai_nome} × ♀️ {formFilha.animal_mae_nome}
            </div>

            <div style={{ display: "grid", gap: 16 }}>
              {/* Resumo da data de troca */}
              <div style={{ background: "#f8fafc", borderRadius: 10, padding: "10px 12px" }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: "#57636C", marginBottom: 4 }}>🔄 Data da Troca</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>
                  {formFilha.data_troca ? new Date(formFilha.data_troca + "T12:00:00").toLocaleDateString("pt-BR") : "—"}
                </div>
              </div>

              {/* Cor */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 8 }}>🎨 Cor</label>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {Object.entries(CORES_ANILHA).map(([k, c]) => {
                    const corCfg = CORES_ANILHA[formFilha.cor] || CORES_ANILHA.amarelo;
                    const isSelected = formFilha.cor === k;
                    return (
                      <button
                        key={k}
                        onClick={() => setFormFilha(p => ({ ...p, cor: k }))}
                        style={{
                          width: 40,
                          height: 40,
                          borderRadius: 10,
                          border: isSelected ? `3px solid #170073` : `2px solid ${c.cor}`,
                          background: c.cor,
                          cursor: "pointer",
                          boxShadow: isSelected ? `0 0 0 3px rgba(23,0,115,.3)` : "none",
                        }}
                        title={c.label}
                      />
                    );
                  })}
                </div>
              </div>

              {/* Anilhas geradas - só com cor */}
              <div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase" }}>🎨 Anilhas Geradas</label>
                  <span style={{ fontSize: 11, color: "#00A893", fontWeight: 700, fontFamily: "Montserrat,sans-serif", background: "#E8F5E9", padding: "4px 10px", borderRadius: 20 }}>{formFilha.quantidade}</span>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(60px, 1fr))", gap: 8, marginBottom: 12 }}>
                  {Array.from({ length: formFilha.quantidade }).map((_, idx) => {
                    const corCfg = CORES_ANILHA[formFilha.cor] || CORES_ANILHA.amarelo;
                    return (
                      <div key={idx} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                        <div style={{ width: 50, height: 50, borderRadius: 10, background: corCfg.cor, border: corCfg.borda ? `2px solid ${corCfg.borda}` : `2px solid ${corCfg.cor}`, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: corCfg.cor === "#ffffff" ? "#57636C" : "rgba(255,255,255,0.8)" }} />
                        <span style={{ fontSize: 10, fontWeight: 700, color: "#57636C" }}>#{idx + 1}</span>
                      </div>
                    );
                  })}
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    onClick={() => setFormFilha(p => ({ ...p, quantidade: Math.max(1, p.quantidade - 1) }))}
                    disabled={formFilha.quantidade <= 1}
                    style={{ flex: 1, padding: "10px", borderRadius: 8, border: "1.5px solid #fee2e2", background: formFilha.quantidade <= 1 ? "#f3f4f6" : "#fff", color: formFilha.quantidade <= 1 ? "#ccc" : "#E21C3D", cursor: formFilha.quantidade <= 1 ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700, fontSize: 12 }}
                  >
                    − Remover
                  </button>
                  <button
                    onClick={() => setFormFilha(p => ({ ...p, quantidade: p.quantidade + 1 }))}
                    style={{ flex: 1, padding: "10px", borderRadius: 8, border: "1.5px solid #170073", background: "linear-gradient(135deg,#8b5cf6,#6d28d9)", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700, fontSize: 12 }}
                  >
                    + Adicionar
                  </button>
                </div>
              </div>

              <button
               onClick={async () => {
                  const hoje = new Date().toISOString().split('T')[0];
                  for (let i = 0; i < formFilha.quantidade; i++) {
                   await base44.entities.AnilhaFilha.create({
                     usuario_email: user.email,
                     tipo: "filha",
                     animal_pai_id: formFilha.animal_pai_id || "",
                     animal_pai_nome: formFilha.animal_pai_nome,
                     animal_mae_id: formFilha.animal_mae_id || "",
                     animal_mae_nome: formFilha.animal_mae_nome,
                     anilha_numero: `GG-${hoje.split('-').join('')}-${String(i + 1).padStart(4, '0')}`,
                     cor_anilha_definitiva: formFilha.cor,
                     data_criacao: hoje,
                     data_troca_definitiva: formFilha.data_troca,
                     status: "incubando",
                   });
                  }
                  setFormFilha(null);
                  carregar();
                }}
                disabled={formFilha.quantidade < 1}
                style={{
                  width: "100%",
                  padding: "14px",
                  borderRadius: 12,
                  border: "none",
                  background: formFilha.quantidade < 1 ? "#ccc" : "linear-gradient(135deg,#8b5cf6,#6d28d9)",
                  color: "#fff",
                  cursor: formFilha.quantidade < 1 ? "default" : "pointer",
                  fontFamily: "Montserrat,sans-serif",
                  fontSize: 14,
                  fontWeight: 900,
                  marginTop: 10,
                }}
              >
                💾 Registrar {formFilha.quantidade} Anilha{formFilha.quantidade !== 1 ? "s" : ""}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Anilhas Compradas (fase 1: cor + pai + mãe) */}
      {formComprada && !formComprada.data_troca_definida && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
          onClick={e => e.target === e.currentTarget && setFormComprada(null)}
        >
          <div style={{ background: "#1C1C1E", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 600, maxHeight: "92vh", overflowY: "auto", padding: "20px 20px 40px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>📿 Registrar Anilhas Compradas</div>
              <button onClick={() => setFormComprada(null)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            <div style={{ display: "grid", gap: 12 }}>
              {/* Genealogia */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>♂️ Pai</label>
                <input
                  type="text"
                  placeholder="Nome do pai"
                  value={formComprada.animal_pai_nome}
                  onChange={e => setFormComprada(p => ({ ...p, animal_pai_nome: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", background: "#1C1C1E", color: "#FFFFFF" }}
                />
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>♀️ Mãe</label>
                <input
                  type="text"
                  placeholder="Nome da mãe"
                  value={formComprada.animal_mae_nome}
                  onChange={e => setFormComprada(p => ({ ...p, animal_mae_nome: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", background: "#1C1C1E", color: "#FFFFFF" }}
                />
              </div>

              {/* Cores e Datas */}
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>🎨 Cor da Anilha Definitiva</label>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  {Object.entries(CORES_ANILHA).map(([k, c]) => (
                    <button
                      key={k}
                      onClick={() => setFormComprada(p => ({ ...p, cor: k }))}
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 10,
                        border: formComprada.cor === k ? `3px solid #170073` : `2px solid ${c.cor}`,
                        background: c.cor,
                        cursor: "pointer",
                        boxShadow: formComprada.cor === k ? `0 0 0 3px rgba(23,0,115,.3)` : "none",
                      }}
                      title={c.label}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>🔄 Data da Troca</label>
                <input
                  type="date"
                  value={formComprada.data_troca}
                  onChange={e => setFormComprada(p => ({ ...p, data_troca: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", background: "#1C1C1E", color: "#FFFFFF" }}
                />
              </div>

              {/* Anilhas geradas - só com cor */}
              <div>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase" }}>🎨 Anilhas Geradas</label>
                  <span style={{ fontSize: 11, color: "#00A893", fontWeight: 700, fontFamily: "Montserrat,sans-serif", background: "#E8F5E9", padding: "4px 10px", borderRadius: 20 }}>{formComprada.quantidade}</span>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(60px, 1fr))", gap: 8, marginBottom: 12 }}>
                  {Array.from({ length: formComprada.quantidade }).map((_, idx) => {
                    const corCfg = CORES_ANILHA[formComprada.cor] || CORES_ANILHA.amarelo;
                    return (
                      <div key={idx} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                        <div style={{ width: 50, height: 50, borderRadius: 10, background: corCfg.cor, border: corCfg.borda ? `2px solid ${corCfg.borda}` : `2px solid ${corCfg.cor}`, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: corCfg.cor === "#ffffff" ? "#57636C" : "rgba(255,255,255,0.8)" }} />
                        <span style={{ fontSize: 10, fontWeight: 700, color: "#57636C" }}>#{idx + 1}</span>
                      </div>
                    );
                  })}
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    onClick={() => setFormComprada(p => ({ ...p, quantidade: Math.max(1, p.quantidade - 1) }))}
                    disabled={formComprada.quantidade <= 1}
                    style={{ flex: 1, padding: "10px", borderRadius: 8, border: "1.5px solid #fee2e2", background: formComprada.quantidade <= 1 ? "#f3f4f6" : "#fff", color: formComprada.quantidade <= 1 ? "#ccc" : "#E21C3D", cursor: formComprada.quantidade <= 1 ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700, fontSize: 12 }}
                  >
                    − Remover
                  </button>
                  <button
                    onClick={() => setFormComprada(p => ({ ...p, quantidade: p.quantidade + 1 }))}
                    style={{ flex: 1, padding: "10px", borderRadius: 8, border: "1.5px solid #170073", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700, fontSize: 12 }}
                  >
                    + Adicionar
                  </button>
                </div>
              </div>

              <button
                onClick={salvarAnilhaComprada}
                style={{
                  width: "100%",
                  padding: "14px",
                  borderRadius: 12,
                  border: "none",
                  background: "linear-gradient(135deg,#170073,#00A893)",
                  color: "#fff",
                  cursor: "pointer",
                  fontFamily: "Montserrat,sans-serif",
                  fontSize: 14,
                  fontWeight: 900,
                  marginTop: 10,
                }}
              >
                💾 Registrar {formComprada.quantidade} Anilha{formComprada.quantidade !== 1 ? "s" : ""}
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}