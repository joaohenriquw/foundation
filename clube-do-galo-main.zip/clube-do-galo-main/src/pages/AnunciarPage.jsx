import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";

const PLANOS_AD = [
  { id: "semanal",  label: "Semanal",  preco: "R$ 49,90",  dias: 7,  cor: "#1565C0", desc: "7 dias de exposição no banner principal" },
  { id: "mensal",   label: "Mensal",   preco: "R$ 149,90", dias: 30, cor: "#170073", desc: "30 dias · Melhor custo-benefício" },
  { id: "trimestral", label: "Trimestral", preco: "R$ 349,90", dias: 90, cor: "#F0A500", desc: "90 dias · Máxima visibilidade" },
];

export default function AnunciarPage() {
  const [plano, setPlano]       = useState(null);
  const [form, setForm]         = useState({ titulo: "", anunciante: "", email: "", link_destino: "" });
  const [salvando, setSalvando] = useState(false);
  const [enviado, setEnviado]   = useState(false);
  const [pagando, setPagando]   = useState(false);
  const navigate = useNavigate();

  const enviar = () => {
    if (!plano || !form.titulo || !form.anunciante || !form.email) return;
    setPagando(true);
  };

  const confirmarPagamento = async () => {
    setSalvando(true);
    try {
      const inicio = new Date();
      const fim = new Date();
      fim.setDate(fim.getDate() + plano.dias);
      await base44.entities.Anuncio.create({
        titulo: form.titulo,
        anunciante: form.anunciante,
        anunciante_email: form.email,
        link_destino: form.link_destino,
        data_inicio: inicio.toISOString().split("T")[0],
        data_fim: fim.toISOString().split("T")[0],
        ativo: true, // ativado após pagamento
        valor_pago: parseFloat(plano.preco.match(/\d+[.,]?\d*/)[0].replace(',', '.')),
      });
      await base44.integrations.Core.SendEmail({
        to: form.email,
        subject: "Clube do Galo — Anúncio Ativado! 🎉",
        body: `<h2>Parabéns, ${form.anunciante}!</h2><p>Seu anúncio <strong>${form.titulo}</strong> foi ativado com sucesso (${plano.label})!</p><p>Seu banner já está aparecendo na página inicial. Obrigado!</p>`,
      });
      setPagando(false);
      setEnviado(true);
    } catch (e) {
      alert('Erro ao ativar anúncio: ' + e.message);
      setSalvando(false);
      setPagando(false);
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif" }}>
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px 20px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>📢 Anuncie no Clube do Galo</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Alcance milhares de criadores</div>
          </div>
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 560, margin: "0 auto" }}>
        {enviado ? (
          <div style={{ textAlign: "center", padding: 40 }}>
            <div style={{ fontSize: 52, marginBottom: 16 }}>✅</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#2E7D32" }}>Solicitação enviada!</div>
            <div style={{ fontSize: 13, color: "#57636C", marginTop: 8, marginBottom: 24 }}>Nossa equipe entrará em contato para confirmar o pagamento e ativar seu anúncio.</div>
            <Link to="/" style={{ padding: "12px 28px", borderRadius: 12, background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", textDecoration: "none", fontFamily: "Montserrat,sans-serif", fontWeight: 800 }}>Voltar ao início</Link>
          </div>
        ) : (
          <>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213", marginBottom: 10 }}>Escolha um plano</div>
            {PLANOS_AD.map(p => (
              <div key={p.id} onClick={() => setPlano(p)}
                style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", marginBottom: 10, border: `2px solid ${plano?.id === p.id ? p.cor : "#E8ECF0"}`, cursor: "pointer" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213" }}>{p.label}</div>
                    <div style={{ fontSize: 12, color: "#57636C" }}>{p.desc}</div>
                  </div>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: p.cor }}>{p.preco}</div>
                </div>
              </div>
            ))}

            <div style={{ background: "#fff", borderRadius: 14, padding: 16, border: "1px solid #E8ECF0", marginTop: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213", marginBottom: 12 }}>Dados do anúncio</div>
              {[
                { key: "titulo",       label: "Título do Anúncio *", placeholder: "Ex: Ração Premium AviGold" },
                { key: "anunciante",   label: "Nome do Anunciante *", placeholder: "Ex: Granja Boa Vista" },
                { key: "email",        label: "E-mail de contato *",  placeholder: "contato@empresa.com" },
                { key: "link_destino", label: "Link (site ou WhatsApp)", placeholder: "https://..." },
              ].map(f => (
                <div key={f.key} style={{ marginBottom: 12 }}>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>{f.label}</label>
                  <input value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder}
                    style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
                </div>
              ))}
            </div>

            <button onClick={enviar} disabled={!plano || !form.titulo || !form.anunciante || !form.email || salvando}
              style={{ width: "100%", padding: 14, borderRadius: 12, border: "none", background: (!plano || !form.titulo || !form.anunciante || !form.email) ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, marginTop: 16 }}>
              {salvando ? "Processando..." : "💳 Ir para Pagamento"}
            </button>
          </>
        )}
      </div>

      {pagando && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div style={{ background: "#fff", borderRadius: 16, padding: "32px 24px", maxWidth: 400, textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>💳</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#101213", marginBottom: 8 }}>Confirmar Pagamento</div>
            <div style={{ fontSize: 13, color: "#57636C", marginBottom: 20 }}>
              Você está prestes a pagar <strong>{plano.preco}</strong> pelo plano <strong>{plano.label}</strong>
            </div>
            <div style={{ background: "#F8FAFC", borderRadius: 12, padding: "12px 16px", marginBottom: 20, fontSize: 12, color: "#57636C" }}>
              ✅ Seu anúncio será ativado imediatamente após o pagamento
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => setPagando(false)} disabled={salvando}
                style={{ flex: 1, padding: 12, borderRadius: 10, border: "1.5px solid #E8ECF0", background: "#fff", color: "#57636C", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                ❌ Cancelar
              </button>
              <button onClick={confirmarPagamento} disabled={salvando}
                style={{ flex: 1, padding: 12, borderRadius: 10, border: "none", background: salvando ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                {salvando ? "Processando..." : "✅ Confirmar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}