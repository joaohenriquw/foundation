import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import NotificacoesSino from "../components/NotificacoesSino";
import BackHeader from "../components/BackHeader";

const fmt = (v) => v != null ? "R$ " + Number(v).toFixed(2).replace(".", ",") : "—";

export default function Vitrine() {
  const [criatories, setCriatories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [busca, setBusca] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      
      // Fetch exposições ativas e não expiradas
      const hoje = new Date().toISOString().split('T')[0];
      const allExposicoes = await base44.entities.VitrineExposicao.filter({ ativa: true }, "-created_date", 500);
      
      // Filtrar expiradas
      const exposicoes = allExposicoes.filter(e => e.data_expiracao >= hoje);
      
      // Agrupar por proprietário
      const agrupado = {};
      for (const exp of exposicoes) {
        const propId = exp.proprietario_id;
        if (!agrupado[propId]) {
          agrupado[propId] = {
            proprietario_id: exp.proprietario_id,
            proprietario_nome: exp.proprietario_nome,
            animais: [],
          };
        }
        agrupado[propId].animais.push(exp);
      }
      
      setCriatories(Object.values(agrupado));
      setLoading(false);
    };
    init();

    const unsub = base44.entities.VitrineExposicao.subscribe(() => {
      init();
    });
    return unsub;
  }, []);

  return (
    <div style={{ minHeight: "100vh", background: "hsl(var(--background))", fontFamily: "'DM Sans', -apple-system, sans-serif", color: "hsl(var(--foreground))", paddingBottom: 100 }}>
      <BackHeader title="Vitrine" />
      <div style={{ padding: "14px 14px", maxWidth: 900, margin: "0 auto" }}>
        {/* Barra de busca */}
        <div style={{ position: "relative", marginBottom: 16 }}>
          <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 16, pointerEvents: "none" }}>🔍</span>
          <input
            type="text"
            placeholder="Buscar por animal, espécie ou criatório..."
            value={busca}
            onChange={e => setBusca(e.target.value)}
            style={{ width: "100%", boxSizing: "border-box", padding: "12px 16px 12px 40px", borderRadius: 12, border: "none", fontSize: 13, fontFamily: "'DM Sans',sans-serif", outline: "none", background: "hsl(var(--input))", color: "hsl(var(--foreground))" }}
          />
          {busca && (
            <button onClick={() => setBusca("")}
              style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", fontSize: 18, cursor: "pointer", color: "hsl(var(--muted-foreground))", lineHeight: 1 }}>×</button>
          )}
        </div>
        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "hsl(var(--muted-foreground))" }}>Carregando...</div>
        ) : criatories.length === 0 ? (
          <div style={{ textAlign: "center", padding: 48 }}>
            <div style={{ fontSize: 52, marginBottom: 12 }}>🏪</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "hsl(var(--foreground))" }}>Vitrine vazia</div>
            <div style={{ fontSize: 12, color: "hsl(var(--muted-foreground))", marginTop: 6 }}>Nenhum criatório com animais expostos no momento</div>
          </div>
        ) : (() => {
          const termo = busca.toLowerCase().trim();
          const filtrados = !termo ? criatories : criatories
            .map(c => ({
              ...c,
              animais: c.animais.filter(a =>
                a.animal_nome?.toLowerCase().includes(termo) ||
                a.animal_especie?.toLowerCase().includes(termo) ||
                c.proprietario_nome?.toLowerCase().includes(termo)
              )
            }))
            .filter(c => c.animais.length > 0 || c.proprietario_nome?.toLowerCase().includes(termo));

          return filtrados.length === 0 ? (
            <div style={{ textAlign: "center", padding: 40 }}>
              <div style={{ fontSize: 40, marginBottom: 10 }}>🔍</div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "hsl(var(--foreground))" }}>Nenhum resultado</div>
              <div style={{ fontSize: 12, color: "hsl(var(--muted-foreground))", marginTop: 4 }}>Tente outro nome, espécie ou criatório</div>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
              {filtrados.map(c => (
                <div key={c.proprietario_id} onClick={() => navigate(`/vitrine-criatorio/${c.proprietario_id}`)}
                style={{ background: "hsl(var(--background))", borderRadius: 14, border: `1px solid hsl(var(--border))`, overflow: "hidden", cursor: "pointer", transition: ".2s" }}
                onMouseEnter={(e) => e.currentTarget.style.boxShadow = "0 8px 24px rgba(23,0,115,.15)"}
                onMouseLeave={(e) => e.currentTarget.style.boxShadow = "none"}>
                
                {/* Primeiro animal como capa */}
                <div style={{ height: 160, background: c.animais[0]?.animal_foto_url ? `url(${c.animais[0].animal_foto_url}) center/cover` : "linear-gradient(135deg,hsl(var(--primary)),#00A893)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                  {!c.animais[0]?.animal_foto_url && <span style={{ fontSize: 52 }}>🐓</span>}
                  <div style={{ position: "absolute", top: 8, right: 8, background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))", borderRadius: 10, padding: "4px 12px", fontSize: 12, fontWeight: 800, fontFamily: "Montserrat,sans-serif" }}>
                    {c.animais.length} animal{c.animais.length > 1 ? "is" : ""}
                  </div>
                </div>

                <div style={{ padding: "14px 16px" }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "hsl(var(--foreground))", marginBottom: 2 }}>
                    🐓 Criatório {c.proprietario_nome}
                  </div>
                  <div style={{ fontSize: 12, color: "hsl(var(--muted-foreground))", marginBottom: 10 }}>
                    {c.animais.length} animal{c.animais.length > 1 ? "is" : ""} em exposição
                  </div>

                  {/* Mini preview dos animais */}
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 6, marginBottom: 10 }}>
                    {c.animais.slice(0, 3).map((a, i) => (
                      <div key={i} style={{ background: "hsl(var(--muted))", borderRadius: 8, padding: "6px", textAlign: "center", fontSize: 10, color: "hsl(var(--muted-foreground))" }}>
                        <div style={{ fontWeight: 700 }}>{a.animal_nome.split(" ")[0]}</div>
                        <div style={{ fontSize: 9, marginTop: 2 }}>{a.animal_especie || "—"}</div>
                      </div>
                    ))}
                  </div>

                  <button style={{ width: "100%", padding: "10px", borderRadius: 10, border: "none", background: "linear-gradient(135deg,hsl(var(--primary)),#00A893)", color: "hsl(var(--primary-foreground))", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800 }}>
                    Ver criatório completo →
                  </button>
                </div>
              </div>
            ))}
            </div>
          );
        })()}
      </div>
    </div>
  );
}