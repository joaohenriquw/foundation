import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import NotificacoesSino from "../components/NotificacoesSino";
import BottomNav from "../components/BottomNav";
import SelectField from "../components/SelectField";

const CATEGORIAS = {
  tecnica_criacao: { label: "Técnica de Criação", emoji: "🐓" },
  saude_animal: { label: "Saúde do Animal", emoji: "🏥" },
  nutricao: { label: "Nutrição", emoji: "🥗" },
  genetica: { label: "Genética", emoji: "🧬" },
  comportamento: { label: "Comportamento", emoji: "🧠" },
  negociacao: { label: "Negociação", emoji: "💼" },
};

export default function CursosAdmin() {
  const [user, setUser] = useState(null);
  const [cursos, setCursos] = useState([]);
  const [aulas, setAulas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalAberto, setModalAberto] = useState(false);
  const [modalAulasAberto, setModalAulasAberto] = useState(false);
  const [cursoSelecionado, setCursoSelecionado] = useState(null);
  const [formData, setFormData] = useState({
    titulo: "",
    descricao: "",
    categoria: "tecnica_criacao",
    video_url: "",
    duracao_minutos: 0,
    nivel: "iniciante",
  });
  const [processando, setProcessando] = useState(false);
  const [formAula, setFormAula] = useState({
    titulo: "",
    descricao: "",
    video_url: "",
    duracao_minutos: 0,
  });
  const [processandoAula, setProcessandoAula] = useState(false);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me();
      if (me?.role !== "admin") {
        window.location.href = "/";
        return;
      }
      setUser(me);

      const cursosData = await base44.entities.Curso.filter({}, "-created_date", 200);
      const aulasData = await base44.entities.Aula.list("-created_date", 500);
      setCursos(cursosData);
      setAulas(aulasData);
      setLoading(false);
    };
    init();

    const unsubCurso = base44.entities.Curso.subscribe(() => init());
    const unsubAula = base44.entities.Aula.subscribe(() => init());
    return () => { unsubCurso(); unsubAula(); };
  }, []);

  const criarCurso = async () => {
    if (!formData.titulo || !formData.video_url) {
      alert("Preencha título e URL do vídeo!");
      return;
    }
    setProcessando(true);

    await base44.entities.Curso.create({
      ...formData,
      admin_id: user.id,
      admin_email: user.email,
      ativo: true,
    });

    setFormData({
      titulo: "",
      descricao: "",
      categoria: "tecnica_criacao",
      video_url: "",
      duracao_minutos: 0,
      nivel: "iniciante",
    });
    setModalAberto(false);
    setProcessando(false);
  };

  const deletarCurso = async (id) => {
    if (confirm("Deletar este curso?")) {
      await base44.entities.Curso.delete(id);
    }
  };

  const toggleAtivo = async (curso) => {
    await base44.entities.Curso.update(curso.id, { ativo: !curso.ativo });
  };

  const abrirModalAulas = (curso) => {
    setCursoSelecionado(curso);
    setFormAula({ titulo: "", descricao: "", video_url: "", duracao_minutos: 0 });
    setModalAulasAberto(true);
  };

  const criarAula = async () => {
    if (!formAula.titulo || !formAula.video_url || !cursoSelecionado) return;
    setProcessandoAula(true);

    const proximaOrdem = (aulas.filter(a => a.curso_id === cursoSelecionado.id).length) + 1;

    await base44.entities.Aula.create({
      ...formAula,
      curso_id: cursoSelecionado.id,
      curso_titulo: cursoSelecionado.titulo,
      ordem: proximaOrdem,
      admin_id: user.id,
      admin_email: user.email,
      ativo: true,
    });

    setFormAula({ titulo: "", descricao: "", video_url: "", duracao_minutos: 0 });
    setProcessandoAula(false);
  };

  const deletarAula = async (id) => {
    if (confirm("Deletar esta aula?")) {
      await base44.entities.Aula.delete(id);
    }
  };

  const aulasDosCurso = cursoSelecionado ? aulas.filter(a => a.curso_id === cursoSelecionado.id).sort((a, b) => a.ordem - b.ordem) : [];

  if (loading) return <div style={{ textAlign: "center", padding: 20 }}>Carregando...</div>;

  return (
    <div style={{ minHeight: "100vh", background: "hsl(var(--background))", paddingBottom: 80 }}>
      <div style={{ background: "linear-gradient(135deg,hsl(var(--primary)),#00A893)", padding: "20px 24px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Link to="/admin" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none" }}>←</Link>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>📚 Gerenciar Cursos</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Total: {cursos.length} cursos</div>
            </div>
          </div>
          <NotificacoesSino userEmail={user?.email} />
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 900, margin: "0 auto" }}>
        <button onClick={() => setModalAberto(true)}
          style={{ width: "100%", padding: "12px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,hsl(var(--primary)),#00A893)", color: "hsl(var(--primary-foreground))", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 900, marginBottom: 20, fontSize: 14 }}>
          ➕ Novo Curso
        </button>

        <div style={{ display: "grid", gap: 12 }}>
          {cursos.map(c => (
            <div key={c.id} style={{ background: c.ativo ? "hsl(var(--background))" : "hsl(var(--muted))", borderRadius: 14, padding: 16, border: `1.5px solid ${c.ativo ? "hsl(var(--border))" : "hsl(var(--input))"}`, opacity: c.ativo ? 1 : 0.6 }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "hsl(var(--foreground))", marginBottom: 4 }}>
                    {CATEGORIAS[c.categoria]?.emoji} {c.titulo}
                  </div>
                  <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", marginBottom: 8, lineHeight: 1.5 }}>
                    {c.descricao}
                  </div>
                  <div style={{ display: "flex", gap: 10, flexWrap: "wrap", fontSize: 10, fontWeight: 700 }}>
                    <span style={{ background: 'hsl(var(--primary)/.1)', color: "hsl(var(--primary))", padding: "3px 8px", borderRadius: 6 }}>
                      {CATEGORIAS[c.categoria]?.label}
                    </span>
                    <span style={{ background: 'hsl(var(--secondary)/.2)', color: "hsl(var(--foreground))", padding: "3px 8px", borderRadius: 6 }}>
                      {c.nivel.toUpperCase()}
                    </span>
                    <span style={{ background: 'hsl(var(--primary)/.05)', color: "hsl(var(--muted-foreground))", padding: "3px 8px", borderRadius: 6 }}>
                      ⏱️ {c.duracao_minutos}min
                    </span>
                    <span style={{ background: 'hsl(var(--secondary)/.1)', color: "hsl(var(--foreground))", padding: "3px 8px", borderRadius: 6 }}>
                      👁️ {c.visualizacoes} views
                    </span>
                  </div>
                </div>
              </div>

              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <button onClick={() => toggleAtivo(c)}
                  style={{ padding: "6px 12px", borderRadius: 8, border: "none", background: c.ativo ? "hsl(var(--destructive))" : "#00A893", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif" }}>
                  {c.ativo ? "🔴 Desativar" : "🟢 Ativar"}
                </button>
                <button onClick={() => abrirModalAulas(c)}
                  style={{ padding: "6px 12px", borderRadius: 8, border: `1px solid hsl(var(--primary))`, background: "hsl(var(--background))", color: "hsl(var(--primary))", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif" }}>
                  📝 Aulas ({aulas.filter(a => a.curso_id === c.id).length})
                </button>
                <a href={c.video_url} target="_blank" rel="noopener noreferrer"
                  style={{ padding: "6px 12px", borderRadius: 8, border: `1px solid hsl(var(--primary))`, background: "hsl(var(--background))", color: "hsl(var(--primary))", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif", textDecoration: "none" }}>
                  🎥 Ver Vídeo
                </a>
                <button onClick={() => deletarCurso(c.id)}
                  style={{ padding: "6px 12px", borderRadius: 8, border: "none", background: 'hsl(var(--destructive)/.1)', color: "hsl(var(--destructive))", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif" }}>
                  🗑️ Deletar
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal Gerenciar Aulas */}
      {modalAulasAberto && cursoSelecionado && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalAulasAberto(false)}>
          <div style={{ background: "hsl(var(--background))", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px", maxHeight: "90vh", overflowY: "auto" }} onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "hsl(var(--primary))", marginBottom: 4 }}>📝 {cursoSelecionado.titulo}</div>
            <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", marginBottom: 16 }}>{aulasDosCurso.length} aula{aulasDosCurso.length !== 1 ? "s" : ""}</div>

            {/* Aulas existentes */}
            {aulasDosCurso.length > 0 && (
              <div style={{ marginBottom: 20, paddingBottom: 16, borderBottom: `1px solid hsl(var(--border))` }}>
                {aulasDosCurso.map((a, i) => (
                  <div key={a.id} style={{ background: "hsl(var(--muted))", borderRadius: 10, padding: 12, marginBottom: 8, display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "hsl(var(--foreground))" }}>{i + 1}. {a.titulo}</div>
                      {a.descricao && <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginTop: 2 }}>{a.descricao}</div>}
                      <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginTop: 4 }}>⏱️ {a.duracao_minutos}min</div>
                    </div>
                    <button onClick={() => deletarAula(a.id)}
                      style={{ background: 'hsl(var(--destructive)/.1)', color: "hsl(var(--destructive))", border: "none", borderRadius: 6, padding: "4px 8px", fontSize: 11, fontWeight: 700, cursor: "pointer", marginLeft: 8 }}>
                      🗑️
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Novo Aula */}
            <div style={{ display: "grid", gap: 12 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Título da Aula</label>
                <input type="text" value={formAula.titulo} onChange={e => setFormAula({ ...formAula, titulo: e.target.value })} placeholder="Ex: Introdução"
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: `1.5px solid hsl(var(--border))`, fontSize: 12, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Descrição (opcional)</label>
                <textarea value={formAula.descricao} onChange={e => setFormAula({ ...formAula, descricao: e.target.value })} placeholder="Descreva o conteúdo desta aula"
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: `1.5px solid hsl(var(--border))`, fontSize: 12, outline: "none", boxSizing: "border-box", minHeight: 60, fontFamily: "inherit", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>URL Vídeo</label>
                  <input type="url" value={formAula.video_url} onChange={e => setFormAula({ ...formAula, video_url: e.target.value })} placeholder="https://youtube.com/..."
                    style={{ width: "100%", padding: "10px", borderRadius: 8, border: `1.5px solid hsl(var(--border))`, fontSize: 12, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Duração (min)</label>
                  <input type="number" value={formAula.duracao_minutos} onChange={e => setFormAula({ ...formAula, duracao_minutos: Number(e.target.value) })} placeholder="15"
                    style={{ width: "100%", padding: "10px", borderRadius: 8, border: `1.5px solid hsl(var(--border))`, fontSize: 12, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
                </div>
              </div>

              <button onClick={criarAula} disabled={processandoAula || !formAula.titulo || !formAula.video_url}
                style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: processandoAula ? "hsl(var(--muted))" : "linear-gradient(135deg,hsl(var(--primary)),#00A893)", color: processandoAula ? "hsl(var(--muted-foreground))" : "hsl(var(--primary-foreground))", cursor: processandoAula ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                {processandoAula ? "Criando..." : "✅ Adicionar Aula"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Novo Curso */}
      {modalAberto && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalAberto(false)}>
          <div style={{ background: "hsl(var(--background))", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "hsl(var(--primary))", marginBottom: 20 }}>📚 Novo Curso</div>

            <div style={{ display: "grid", gap: 14 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Título</label>
                <input type="text" value={formData.titulo} onChange={e => setFormData({ ...formData, titulo: e.target.value })} placeholder="Ex: Técnicas de Criação"
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: `1.5px solid hsl(var(--border))`, fontSize: 12, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Descrição</label>
                <textarea value={formData.descricao} onChange={e => setFormData({ ...formData, descricao: e.target.value })} placeholder="Descreva o conteúdo do curso..."
                  style={{ width: "100%", padding: "10px", borderRadius: 8, border: `1.5px solid hsl(var(--border))`, fontSize: 12, outline: "none", boxSizing: "border-box", minHeight: 80, fontFamily: "inherit", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Categoria</label>
                  <SelectField
                    value={formData.categoria}
                    onChange={e => setFormData({ ...formData, categoria: e.target.value })}
                    options={Object.entries(CATEGORIAS).map(([k, v]) => ({ value: k, label: v.label }))}
                  />
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Nível</label>
                  <SelectField
                    value={formData.nivel}
                    onChange={e => setFormData({ ...formData, nivel: e.target.value })}
                    options={[
                      { value: "iniciante", label: "Iniciante" },
                      { value: "intermediario", label: "Intermediário" },
                      { value: "avancado", label: "Avançado" }
                    ]}
                  />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Duração (min)</label>
                  <input type="number" value={formData.duracao_minutos} onChange={e => setFormData({ ...formData, duracao_minutos: Number(e.target.value) })} placeholder="30"
                    style={{ width: "100%", padding: "10px", borderRadius: 8, border: `1.5px solid hsl(var(--border))`, fontSize: 12, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>URL do Vídeo</label>
                  <input type="url" value={formData.video_url} onChange={e => setFormData({ ...formData, video_url: e.target.value })} placeholder="https://youtube.com/..."
                    style={{ width: "100%", padding: "10px", borderRadius: 8, border: `1.5px solid hsl(var(--border))`, fontSize: 12, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }} />
                </div>
              </div>

              <button onClick={criarCurso} disabled={processando || !formData.titulo}
                style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: processando || !formData.titulo ? "hsl(var(--muted))" : "linear-gradient(135deg,hsl(var(--primary)),#00A893)", color: processando ? "hsl(var(--muted-foreground))" : "hsl(var(--primary-foreground))", cursor: processando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>
                {processando ? "Criando..." : "✅ Criar Curso"}
              </button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}