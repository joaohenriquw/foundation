import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useLanceNotificacoes } from "../hooks/useLanceNotificacoes";
import BackHeader from "../components/BackHeader";
import ComentariosLeilao from "../components/ComentariosLeilao";
import AvaliacaoModal from "../components/AvaliacaoModal";
import ChatLeilao from "../components/ChatLeilao";
import BottomNav from "../components/BottomNav";
import CheckoutModalNew from "../components/CheckoutModal";

const PIX_KEY = "clube@galomura.com";
const PARCELAS = [1, 2, 3, 6, 12];

/* ── Timer badge ─────────────────────────────────────────── */
function TimerBadge({ dataFim, onEncerrado }) {
  const [txt, setTxt] = useState("...");
  const [urgente, setUrgente] = useState(false);
  const [done, setDone] = useState(false);
  useEffect(() => {
    const tick = () => {
      const diff = new Date(dataFim) - new Date();
      if (diff <= 0) { setTxt("Encerrado"); setDone(true); onEncerrado?.(); return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setUrgente(diff < 3600000);
      setTxt(`${h > 0 ? h + "h " : ""}${String(m).padStart(2,"0")}m ${String(s).padStart(2,"0")}s`);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [dataFim]);
  return (
    <div style={{ background: done ? "#E21C3D" : urgente ? "#E21C3D" : "#2E7D32", borderRadius: 20, padding: "5px 11px", display: "flex", alignItems: "center", gap: 5, flexShrink: 0 }}>
      <span style={{ fontSize: 11 }}>⏱</span>
      <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 900, color: "#fff", whiteSpace: "nowrap" }}>{txt}</span>
    </div>
  );
}

/* ── QR Code visual ──────────────────────────────────────── */
function QRVisual() {
  const p = useRef(Array.from({ length: 49 }, () => Math.random() > 0.45)).current;
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 3, width: 110, margin: "0 auto" }}>
      {p.map((b, i) => <div key={i} style={{ width: "100%", aspectRatio: "1", background: b ? "#101213" : "#fff", borderRadius: 2 }} />)}
    </div>
  );
}



/* ── Principal ───────────────────────────────────────────── */
export default function LeilaoDetalhe() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [leilao, setLeilao] = useState(null);
  const [lances, setLances] = useState([]);
  const [user, setUser] = useState(null);
  const [parcelas, setParcelas] = useState(2);
  const [dando, setDando] = useState(false);
  const [encerrado, setEncerrado] = useState(false);
  const [euVenci, setEuVenci] = useState(false);
  const [loading, setLoading] = useState(true);
  const [mostraAvaliacao, setMostraAvaliacao] = useState(false);
  const [jaAvaliou, setJaAvaliou] = useState(false);
  const [validacaoPlano, setValidacaoPlano] = useState(null);
  const [mostraCheckout, setMostraCheckout] = useState(false);

  const meuMaiorLance = lances.find(l => l.user_email === user?.email)?.valor || 0;
  useLanceNotificacoes(id, user?.email, meuMaiorLance);

  useEffect(() => {
    const init = async () => {
      const [me, ls] = await Promise.all([
        base44.auth.me().catch(() => null),
        base44.entities.LeilaoLance.filter({ leilao_id: id }, "-created_date", 50),
      ]);
      const lList = await base44.entities.Leilao.filter({ id });
      const lData = Array.isArray(lList) ? lList[0] : lList;
      setUser(me);
      setLeilao(lData);
      setLances(ls);
      setLoading(false);
      if (lData && me && lData.ganhador_email === me.email) setEuVenci(true);
      if (lData?.status === "encerrado") setEncerrado(true);
      if (me && lData?.status === "encerrado" && me.email === lData.ganhador_email) {
        const aval = await base44.entities.Avaliacao.filter({ tipo: "leilao", referencia_id: id, comprador_email: me.email });
        setJaAvaliou(aval.length > 0);
        if (aval.length === 0) setMostraAvaliacao(true);
      }
      if (me) {
        const res = await base44.functions.invoke("validarAcessoLeilao", {}).catch(() => null);
        if (res?.data) setValidacaoPlano(res.data);
      }
    };
    init();

    const unsub = base44.entities.LeilaoLance.subscribe((ev) => {
      if (ev.data?.leilao_id === id && ev.type === "create") {
        setLances(prev => prev.find(l => l.id === ev.data.id) ? prev : [ev.data, ...prev]);
      }
    });
    const unsubL = base44.entities.Leilao.subscribe((ev) => {
      if (ev.data?.id === id) {
        setLeilao(ev.data);
        if (ev.data?.status === "encerrado") setEncerrado(true);
      }
    });
    return () => { unsub(); unsubL(); };
  }, [id]);

  const encerrarLeilao = async () => {
    if (!leilao?.maior_lance_user_email) return;
    const lg = lances.find(l => l.user_email === leilao.maior_lance_user_email);
    await base44.entities.Leilao.update(id, {
      status: "encerrado",
      ganhador_id: leilao.maior_lance_user_id,
      ganhador_nome: leilao.maior_lance_user_nome,
      ganhador_email: leilao.maior_lance_user_email,
      ganhador_parcelas: lg?.parcelas || 1,
    });
    await base44.entities.Notificacao.create({
      destinatario_id: leilao.maior_lance_user_id,
      destinatario_email: leilao.maior_lance_user_email,
      titulo: "🏆 Você venceu o leilão!",
      mensagem: `Parabéns! Arrematou "${leilao.animal_nome}" por R$ ${Number(leilao.maior_lance).toFixed(2)}. Acesse para pagar via PIX.`,
      tipo: "leilao", lida: false, icone: "🏆",
    });
    setEncerrado(true);
    if (user?.email === leilao.maior_lance_user_email) setEuVenci(true);
  };

  const darLance = async () => {
    if (!user || !leilao) return;
    if (validacaoPlano && !validacaoPlano.tem_acesso) { alert(validacaoPlano.mensagem); return; }
    const maiorLance = leilao.maior_lance || leilao.lance_minimo;
    const lanceMin = maiorLance + Math.max(50, Math.ceil(maiorLance * 0.02));
    setDando(true);
    await base44.entities.LeilaoLance.create({
      leilao_id: id,
      user_id: user.id || user.email,
      user_nome: user.full_name || user.email,
      user_email: user.email,
      valor: lanceMin,
      parcelas,
      valor_parcela: lanceMin / parcelas,
    });
    await base44.entities.Leilao.update(id, {
      maior_lance: lanceMin,
      maior_lance_user_id: user.id || user.email,
      maior_lance_user_nome: user.full_name || user.email,
      maior_lance_user_email: user.email,
    });
    base44.functions.invoke("notificarLeilao", { leilao_id: id, tipo: "novo_lance", user_id: user?.id || user?.email }).catch(() => {});
    setDando(false);
  };

  const abrirWhatsApp = () => {
    if (!leilao || !user) return;
    const p = lanceAtualUser?.parcelas || leilao.ganhador_parcelas || 1;
    const vTotal = Number(leilao.maior_lance).toFixed(2).replace(".", ",");
    const vParcela = (leilao.maior_lance / p).toFixed(2).replace(".", ",");
    const msg = encodeURIComponent(
      `Olá ${leilao.dono_nome}! Sou ${user.full_name || user.email}.\n\nGanhei seu leilão do animal *${leilao.animal_nome}* (Anilha: ${leilao.animal_anilha}) pelo valor de *R$ ${vTotal}*.\n\n✅ Parcelamento: *${p}x de R$ ${vParcela}*\n✅ 1ª parcela já paga e confirmada via PIX.\n\nAguardo seu contato para as demais parcelas!`
    );
    const numero = leilao.dono_whatsapp?.replace(/\D/g, "");
    window.open(`https://wa.me/55${numero}?text=${msg}`, "_blank");
  };

  if (loading) return <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "100vh", fontSize: 40 }}>🔨</div>;
  if (!leilao) return <div style={{ textAlign: "center", padding: 48 }}>Leilão não encontrado</div>;

  const maiorLance = leilao.maior_lance || leilao.lance_minimo;
  const lanceMin = maiorLance + Math.max(50, Math.ceil(maiorLance * 0.02));
  const ehDono = user?.email === leilao.dono_email;
  const lanceAtualUser = lances.find(l => l.user_email === user?.email);
  const parcelasGanhou = lanceAtualUser?.parcelas || leilao.ganhador_parcelas || 1;
  const vpGanhou = ((leilao.maior_lance || 0) / parcelasGanhou).toFixed(2).replace(".", ",");

  return (
    <div style={{ minHeight: "100vh", background: "#F1F4F8", fontFamily: "'DM Sans', sans-serif", paddingBottom: 100 }}>
      <BackHeader title="Leilão de Animais" showBackButton={true} />

      <div style={{ padding: "14px", maxWidth: 520, margin: "0 auto", background: "#F1F4F8" }}>

        {/* ═══════ CARD LEILÃO ATIVO ═══════ */}
        {!encerrado && (
          <div style={{ background: "#fff", borderRadius: 16, overflow: "hidden", marginBottom: 14, boxShadow: "0 2px 12px rgba(0,0,0,.08)" }}>

            {/* Header amarelo/dourado */}
            <div style={{ background: "linear-gradient(135deg,#F0A500,#E6920A)", padding: "14px 16px", display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ width: 46, height: 46, borderRadius: "50%", background: "rgba(255,255,255,.25)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, flexShrink: 0 }}>🏆</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {leilao.titulo || leilao.animal_nome}
                </div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,.9)", marginTop: 1 }}>
                  {leilao.dono_nome}
                  {leilao.plano_dono && <span style={{ marginLeft: 6, background: "rgba(255,255,255,.25)", borderRadius: 6, padding: "1px 7px", fontSize: 10, fontWeight: 800 }}>{leilao.plano_dono}</span>}
                </div>
              </div>
              <TimerBadge dataFim={leilao.data_fim} onEncerrado={() => leilao.status === "ativo" && encerrarLeilao()} />
            </div>

            {/* Dados */}
            <div style={{ padding: "16px 16px 0" }}>
              {[
                { label: "Lance atual",  val: `R$ ${Number(maiorLance).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, cor: "#170073" },
                { label: "Lance mínimo", val: `R$ ${Number(lanceMin).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, cor: "#170073" },
                { label: "Lances dados", val: lances.length, cor: "#101213" },
              ].map((r, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingBottom: 9, marginBottom: 9, borderBottom: i < 2 ? "1px solid #F1F4F8" : "none" }}>
                  <span style={{ fontSize: 13, color: "#57636C" }}>{r.label}</span>
                  <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: r.cor }}>{r.val}</span>
                </div>
              ))}

              {/* Info pagamento */}
              <div style={{ background: "#E8F5E9", borderRadius: 10, padding: "10px 12px", marginBottom: 16, display: "flex", gap: 8, alignItems: "flex-start" }}>
                <span style={{ fontSize: 14, flexShrink: 0 }}>📍</span>
                <div style={{ fontSize: 11, color: "#2E7D32", lineHeight: 1.55 }}>
                  <strong>Pagamento apenas ao final do leilão.</strong> Se você for o maior lance ao encerrar, pagará a 1ª parcela via PIX. O dono entra em contato para as demais.
                </div>
              </div>
            </div>

            {/* Parcelas + botão para não-donos */}
            {!ehDono && (
              <div style={{ padding: "0 16px 18px" }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: "#57636C", marginBottom: 10 }}>Escolha as parcelas:</div>

                {/* Grid wrap de chips igual ao print */}
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 16 }}>
                  {PARCELAS.map(p => {
                    const vp = (lanceMin / p).toFixed(0);
                    const sel = parcelas === p;
                    return (
                      <button key={p} onClick={() => setParcelas(p)}
                        style={{
                          padding: "9px 16px", borderRadius: 22,
                          border: sel ? "2px solid #170073" : "1.5px solid #D8DCE5",
                          background: sel ? "#170073" : "#F8FAFC",
                          color: sel ? "#fff" : "#101213",
                          fontFamily: "Montserrat,sans-serif", fontWeight: 800, fontSize: 13,
                          cursor: "pointer", transition: "all .15s",
                          boxShadow: sel ? "0 4px 12px rgba(23,0,115,.25)" : "none",
                        }}>
                        {p}x R${Number(vp).toLocaleString("pt-BR")}
                      </button>
                    );
                  })}
                </div>

                {validacaoPlano && !validacaoPlano.tem_acesso && (
                  <div style={{ background: "#FFF3E0", borderRadius: 10, padding: "8px 12px", marginBottom: 10, fontSize: 11, color: "#E65100", fontWeight: 700 }}>🔒 {validacaoPlano.mensagem}</div>
                )}

                <button
                  onClick={darLance}
                  disabled={dando || (validacaoPlano && !validacaoPlano.tem_acesso)}
                  style={{ width: "100%", padding: "15px", borderRadius: 12, border: "none", background: dando ? "#aaa" : "linear-gradient(135deg,#170073,#1A0090)", color: "#fff", cursor: dando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, letterSpacing: 0.3, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                  {dando ? "⏳ Registrando..." : "🔨 Dar Lance — Pagar ao Encerrar"}
                </button>
              </div>
            )}
          </div>
        )}

        {/* ═══════ CARD VENCEDOR ═══════ */}
        {encerrado && euVenci && (
          <div style={{ background: "#fff", borderRadius: 16, overflow: "hidden", marginBottom: 14, boxShadow: "0 2px 12px rgba(0,0,0,.08)" }}>

            {/* Header laranja/vermelho igual ao print */}
            <div style={{ background: "linear-gradient(135deg,#F0A500,#E21C3D)", padding: "14px 16px", display: "flex", alignItems: "center", gap: 12 }}>
              {leilao.animal_foto_url ? (
                <div style={{ width: 46, height: 46, borderRadius: "50%", background: `url(${leilao.animal_foto_url}) center/cover`, flexShrink: 0, border: "2px solid rgba(255,255,255,.4)" }} />
              ) : (
                <div style={{ width: 46, height: 46, borderRadius: "50%", background: "rgba(255,255,255,.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>🐓</div>
              )}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                  {leilao.titulo || leilao.animal_nome}
                </div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,.9)", marginTop: 1 }}>ENCERRADO · Você foi o vencedor!</div>
              </div>
              <div style={{ background: "#fff", color: "#E21C3D", borderRadius: 20, padding: "5px 13px", fontSize: 12, fontWeight: 900, fontFamily: "Montserrat,sans-serif", flexShrink: 0 }}>GANHOU</div>
            </div>

            {/* Resumo valores */}
            <div style={{ padding: "16px 16px 0" }}>
              {[
                { label: "Seu lance vencedor", val: `R$ ${Number(leilao.maior_lance).toFixed(2).replace(".", ",")}` },
                { label: "Opção escolhida",    val: `${parcelasGanhou}x R$ ${vpGanhou}` },
                { label: "1ª parcela (agora)", val: `R$ ${vpGanhou}`, cor: "#170073", bold: true },
              ].map((r, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingBottom: 10, marginBottom: 10, borderBottom: i < 2 ? "1px solid #F1F4F8" : "none" }}>
                  <span style={{ fontSize: 13, color: "#57636C" }}>{r.label}</span>
                  <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: r.bold ? 15 : 14, fontWeight: 900, color: r.cor || "#101213" }}>{r.val}</span>
                </div>
              ))}

              {/* Info verde */}
              <div style={{ background: "#E8F5E9", borderRadius: 10, padding: "10px 12px", marginBottom: 16, display: "flex", gap: 8, alignItems: "flex-start" }}>
                <span style={{ fontSize: 14, flexShrink: 0 }}>✅</span>
                <div style={{ fontSize: 11, color: "#2E7D32", lineHeight: 1.55 }}>
                  Pague a 1ª parcela agora via PIX. As demais parcelas serão tratadas diretamente com o criador.
                </div>
              </div>
            </div>

            {/* Botões */}
            <div style={{ padding: "0 16px 18px" }}>
              {!leilao.pagamento_confirmado && (
                <button onClick={() => setMostraCheckout(true)}
                  style={{ width: "100%", padding: 15, borderRadius: 12, border: "none", background: "linear-gradient(135deg,#170073,#1A0090)", color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, cursor: "pointer", marginBottom: 10, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                  💳 Pagar 1ª Parcela — R$ {vpGanhou} PIX
                </button>
              )}

              {leilao.pagamento_confirmado ? (
                <button onClick={abrirWhatsApp}
                  style={{ width: "100%", padding: 14, borderRadius: 12, border: "none", background: "#25D366", color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                  📱 Falar com Vendedor no WhatsApp
                </button>
              ) : (
                <div style={{ textAlign: "center", fontSize: 11, color: "#BDBDBD", padding: "4px 0" }}>
                  📵 Contato do vendedor liberado após confirmação do PIX
                </div>
              )}
            </div>
          </div>
        )}

        {/* Encerrado e não venci */}
        {encerrado && !euVenci && (
          <div style={{ background: "#fff", borderRadius: 16, padding: 20, marginBottom: 14, textAlign: "center", boxShadow: "0 2px 8px rgba(0,0,0,.07)" }}>
            <div style={{ fontSize: 36 }}>🔨</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 15, fontWeight: 900, color: "#101213", marginTop: 8 }}>Leilão Encerrado</div>
            <div style={{ fontSize: 12, color: "#57636C", marginTop: 4 }}>Vencedor: <strong>{leilao.ganhador_nome || "—"}</strong> · R$ {Number(leilao.maior_lance || 0).toFixed(2).replace(".", ",")}</div>
          </div>
        )}

        {/* ── Histórico ── */}
        <div style={{ background: "#fff", borderRadius: 16, overflow: "hidden", marginBottom: 14, boxShadow: "0 1px 6px rgba(0,0,0,.06)" }}>
          <div style={{ padding: "14px 16px 10px", borderBottom: "1px solid #F1F4F8" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>📊 Histórico de lances ({lances.length})</div>
          </div>
          {lances.length === 0 ? (
            <div style={{ padding: 24, textAlign: "center", color: "#57636C", fontSize: 12 }}>Nenhum lance ainda. Seja o primeiro!</div>
          ) : lances.map((l, i) => (
            <div key={l.id || i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 16px", borderBottom: "1px solid #F8FAFC", background: l.user_email === user?.email ? "#F0F4FF" : "#fff" }}>
              <div style={{ width: 36, height: 36, borderRadius: "50%", background: i === 0 ? "linear-gradient(135deg,#F0A500,#E21C3D)" : "#F1F4F8", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16, flexShrink: 0 }}>
                {i === 0 ? "🏆" : "🔨"}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213" }}>{l.user_nome}</div>
                <div style={{ fontSize: 11, color: "#57636C" }}>{l.parcelas}x de R$ {Number(l.valor_parcela || l.valor / l.parcelas).toFixed(2)}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: i === 0 ? "#2E7D32" : "#170073" }}>
                  R$ {Number(l.valor).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </div>
                <div style={{ fontSize: 9, color: "#BDBDBD" }}>{new Date(l.created_date).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</div>
              </div>
            </div>
          ))}
        </div>

        {!ehDono && user && !encerrado && (
          <ChatLeilao leilaoId={id} user={user} donoNome={leilao.dono_nome} donoEmail={leilao.dono_email} />
        )}

        <ComentariosLeilao leilaoId={id} user={user} />

        {encerrado && euVenci && !jaAvaliou && (
          <div style={{ background: "#FFF8E1", borderRadius: 14, padding: "14px 16px", marginTop: 14, border: "1px solid #F0A500", textAlign: "center" }}>
            <div style={{ fontSize: 12, color: "#856404", marginBottom: 10 }}>⭐ <strong>Avalie sua experiência</strong> com {leilao.dono_nome}</div>
            <button onClick={() => setMostraAvaliacao(true)}
              style={{ background: "#F0A500", color: "#fff", border: "none", borderRadius: 10, padding: "8px 18px", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800 }}>
              ⭐ Avaliar
            </button>
          </div>
        )}
      </div>

      {mostraCheckout && leilao && (
        <CheckoutModalNew
          leilao={leilao}
          parcelas={parcelasGanhou}
          onPago={() => setLeilao(prev => ({ ...prev, pagamento_confirmado: true }))}
          onClose={() => setMostraCheckout(false)}
        />
      )}

      {mostraAvaliacao && user && leilao && (
        <AvaliacaoModal
          tipo="leilao"
          referenciaId={id}
          vendedorEmail={leilao.dono_email}
          vendedorNome={leilao.dono_nome}
          animalNome={leilao.animal_nome}
          compradorUser={user}
          onClose={() => setMostraAvaliacao(false)}
          onAvaliado={() => setJaAvaliou(true)}
        />
      )}

      <BottomNav />
    </div>
  );
}