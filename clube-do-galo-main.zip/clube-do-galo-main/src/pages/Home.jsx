import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import NotificacoesSino from "../components/NotificacoesSino";
import MinhaVitrine from "../components/MinhaVitrine";
import BottomNav from "../components/BottomNav";
import StoriesFeed from "../components/StoriesFeed";
import CriarStoryModal from "../components/CriarStoryModal";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

const ACESSO_RAPIDO = [
  { image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/34202ef59_5c11ff38-3230-4907-8326-8905539ffbcd.jpg", label: "Registros", path: "/plantel" },
  { image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/e91391015_WhatsAppImage2026-04-04at000032.jpeg", label: "Leilão",     path: "/leiloes"    },
  { emoji: "🎰", label: "Rifas",      path: "/rifas"      },
  { image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/fc923f5cb_generated_image.png", label: "Vitrine",    path: "/vitrine"    },
  { emoji: "🎓", label: "Cursos",     path: "/cursos"     },
  { emoji: "🏢", label: "Adv/Vet",     path: "/consultoria"},
];

export default function Home() {
  const [user, setUser]         = useState(null);
  const [userMeta, setUserMeta] = useState(null);
  const [stories, setStories]   = useState([]);
  const [animais, setAnimais]   = useState([]);
  const [vitrineItens, setVitrineItens] = useState([]);
  const [anuncios, setAnuncios] = useState([]);
  const [anuncioAtual, setAnuncioAtual] = useState(0);
  const [dadosFaltando, setDadosFaltando] = useState([]);
  const [storyAtivo, setStoryAtivo] = useState(null);
  const [mostraModalStory, setMostraModalStory] = useState(false);
  const [mostraModalAnuncio, setMostraModalAnuncio] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      const [storiesData, animaisData, vitrineData, anunciosData] = await Promise.all([
        base44.entities.Story.filter({ ativo: true }, "-created_date", 10),
        me ? base44.entities.Animal.filter({ proprietario_email: me.email }, "nome", 200) : [],
        base44.entities.VitrineExposicao.filter({ ativa: true }, "-created_date", 6),
        base44.entities.Anuncio.filter({ ativo: true }, "-created_date", 20),
      ]);
      if (me) {
        setUserMeta(me);
      }
      setStories(storiesData);
      setAnimais(animaisData);
      setVitrineItens(vitrineData);
      setAnuncios(anunciosData);
      setAnuncioAtual(0);
    };
    init();
  }, []);

  useEffect(() => {
    if (anuncios.length === 0) return;
    const timer = setTimeout(() => {
      setAnuncioAtual(prev => (prev + 1) % anuncios.length);
    }, 10000);
    return () => clearTimeout(timer);
  }, [anuncioAtual, anuncios.length]);

  useEffect(() => {
    const verificarDados = async () => {
      if (!user) return;
      const dadosObrigatorios = ['cpf', 'whatsapp', 'nome_criatorio'];
      const faltando = dadosObrigatorios.filter(campo => !userMeta?.[campo]);
      setDadosFaltando(faltando);
    };
    verificarDados();
  }, [user, userMeta]);

  const planoLabel = { iniciante: "Iniciante", standard: "Standard", gold: "Gold", premium: "Premium" };
  const planoCor   = { iniciante: "#57636C", standard: "#1565C0", gold: "#F0A500", premium: "#170073" };
  const plano = userMeta?.plano || "iniciante";
  const vitrineCount = animais.filter(a => a.status_vitrine === "disponivel" || a.status_vitrine === "em_negociacao").length;

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 90, color: "#fff" }}>
      {/* Header */}
      <div style={{ background: "#0A0A0A", padding: "52px 20px 10px", borderBottom: "1px solid #1C1C1E" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
          <button onClick={() => navigate("/perfil-usuario")} style={{ background: "#1C1C1E", borderRadius: 20, padding: "6px 14px", display: "flex", alignItems: "center", gap: 6, border: "none", cursor: "pointer" }}>
            <span style={{ fontSize: 14 }}>💰</span>
            <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#00C9B8" }}>{fmt(userMeta?.saldo)}</span>
          </button>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {user && (user.role === "admin" || user.role === "master_admin") && (
              <button onClick={() => navigate("/admin")} style={{ background: "#170073", borderRadius: 10, padding: "6px 10px", border: "none", cursor: "pointer", fontSize: 14, fontWeight: 700, color: "#fff" }}>👑</button>
            )}
            {user && <NotificacoesSino userEmail={user.email} />}
          </div>
        </div>

        {/* Stories */}
        <div style={{ display: "flex", gap: 12, overflowX: "auto", paddingBottom: 10, scrollbarWidth: "none" }}>
          {user && (
            <div onClick={() => setMostraModalStory(true)} style={{ flexShrink: 0, textAlign: "center", cursor: "pointer" }}>
              <div style={{ position: "relative", width: 58, height: 58 }}>
                <div style={{ width: 58, height: 58, borderRadius: "50%", background: userMeta?.avatar_url ? `url(${userMeta.avatar_url}) center/cover` : "#1C1C1E", border: "2px solid #00C9B8", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, color: "#fff", fontWeight: 900 }}>
                  {!userMeta?.avatar_url && (user.full_name?.[0] || "U")}
                </div>
                <div style={{ position: "absolute", bottom: -2, right: -2, width: 20, height: 20, borderRadius: "50%", background: "#7C3AED", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 900, color: "#fff" }}>+</div>
              </div>
              <div style={{ fontSize: 9, color: "#888", marginTop: 4, maxWidth: 58, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>Seu story</div>
            </div>
          )}
          {stories.map(s => (
            <div key={s.id} onClick={() => setStoryAtivo(s)} style={{ flexShrink: 0, textAlign: "center", cursor: "pointer" }}>
              <div style={{ width: 58, height: 58, borderRadius: "50%", background: s.midia_url ? `url(${s.midia_url}) center/cover` : "#1C1C1E", border: "2px solid #00C9B8", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {!s.midia_url && <span style={{ fontSize: 22 }}>🐓</span>}
              </div>
              <div style={{ fontSize: 9, color: "#888", marginTop: 4, maxWidth: 58, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.usuario_nome?.split(" ")[0]}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: "14px 14px", maxWidth: 600, margin: "0 auto" }}>


        {/* Card do usuário */}
        {user && (
          <div style={{ background: "#1C1C1E", borderRadius: 16, padding: "14px 16px", marginBottom: 14, display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={() => setMostraModalStory(true)} style={{ width: 56, height: 56, borderRadius: "50%", background: userMeta?.avatar_url ? `url(${userMeta.avatar_url}) center/cover` : "#2C2C2E", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, color: "#fff", flexShrink: 0, border: "2px solid #00C9B8", cursor: "pointer" }}>
              {!userMeta?.avatar_url && (user.full_name?.[0] || "U")}
            </button>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff" }}>{user.full_name || user.email}</div>
              {(userMeta?.cidade || userMeta?.estado) && (
                <div style={{ fontSize: 11, color: "#888" }}>📍 {[userMeta.cidade, userMeta.estado].filter(Boolean).join(", ")}</div>
              )}
              <div style={{ display: "inline-block", background: "#00C9B820", color: "#00C9B8", borderRadius: 6, padding: "2px 8px", fontSize: 10, fontWeight: 800, marginTop: 3 }}>
                {planoLabel[plano]}
              </div>
            </div>
            <div style={{ display: "flex", gap: 14 }}>
              {[
                { val: animais.length, label: "Animais" },
                { val: vitrineCount, label: "Vitrine" },
              ].map((s, i) => (
                <div key={i} style={{ textAlign: "center" }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#00C9B8" }}>{s.val}</div>
                  <div style={{ fontSize: 9, color: "#888", fontWeight: 700 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Carrossel de Anúncios */}
        {anuncios.length > 0 ? (
          <div style={{ position: 'relative', marginBottom: 14 }}>
            <div onClick={() => setMostraModalAnuncio(true)}
              style={{ borderRadius: 14, overflow: 'hidden', cursor: 'pointer', height: 90, background: anuncios[anuncioAtual].imagem_url ? `url(${anuncios[anuncioAtual].imagem_url}) center/cover` : 'linear-gradient(135deg,#00C9B8,#7C3AED)', position: 'relative' }}>
              <div style={{ position: 'absolute', top: 8, left: 8, background: 'rgba(0,0,0,.6)', borderRadius: 6, padding: '2px 8px', fontSize: 9, color: '#fff', fontWeight: 700 }}>PATROCINADO</div>
              {!anuncios[anuncioAtual].imagem_url && (
                <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: 16 }}>
                  <div style={{ fontSize: 14, fontWeight: 900, color: '#fff' }}>{anuncios[anuncioAtual].titulo}</div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,.85)' }}>{anuncios[anuncioAtual].anunciante}</div>
                </div>
              )}
            </div>
            {anuncios.length > 1 && (
              <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginTop: 10 }}>
                {anuncios.map((_, i) => (
                  <button key={i} onClick={() => setAnuncioAtual(i)}
                    style={{ width: 8, height: 8, borderRadius: '50%', border: 'none', background: i === anuncioAtual ? '#00C9B8' : '#D0D0D0', cursor: 'pointer' }} />
                ))}
              </div>
            )}
          </div>
        ) : (
          <Link to="/anunciar" style={{ textDecoration: "none" }}>
            <div style={{ borderRadius: 14, background: "linear-gradient(135deg,#00C9B8,#7C3AED)", marginBottom: 14, padding: "16px 20px", display: "flex", flexDirection: "column", gap: 4, cursor: "pointer" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#fff" }}>Agora você pode anunciar aqui!</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.8)" }}>Anuncie seus produtos e divulgue sua marca</div>
              <div style={{ fontSize: 11, color: "#fff", fontWeight: 700 }}>Clique aqui para anunciar</div>
            </div>
          </Link>
        )}



        {/* Acesso Rápido */}
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 700, color: "#00C9B8", marginBottom: 10 }}>Acesso Rápido</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
            {ACESSO_RAPIDO.map(item => (
              <Link key={item.label} to={item.path} style={{ textDecoration: "none" }}>
                <div style={{ background: "#1C1C1E", borderRadius: 12, padding: "10px 6px", textAlign: "center", border: "1px solid #222" }}>
                  <div style={{ fontSize: 22, marginBottom: 4, height: 28, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {item.image ? (
                      <img src={item.image} alt={item.label} style={{ height: 32, width: 32, objectFit: "cover", borderRadius: 6 }} />
                    ) : (
                      <span>{item.emoji}</span>
                    )}
                  </div>
                  <div style={{ fontSize: 9, fontWeight: 700, color: "#aaa" }}>{item.label}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>


      </div>

      {/* Modal Anúncio */}
      {mostraModalAnuncio && anuncios.length > 0 && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.7)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setMostraModalAnuncio(false)}>
          <div style={{ background: "#1C1C1E", borderRadius: "20px 20px 0 0", width: "100%", padding: 24, display: "grid", gap: 12 }} onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 15, fontWeight: 900, color: "#fff", marginBottom: 4 }}>{anuncios[anuncioAtual].titulo}</div>
            <div style={{ fontSize: 12, color: "#888", marginBottom: 8 }}>Anunciante: {anuncios[anuncioAtual].anunciante}</div>
            {anuncios[anuncioAtual].link_destino && (
              <button onClick={() => { window.open(anuncios[anuncioAtual].link_destino, '_blank'); setMostraModalAnuncio(false); }}
                style={{ width: "100%", padding: "12px", borderRadius: 12, border: "none", background: "linear-gradient(135deg,#00C9B8,#7C3AED)", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>
                🔗 Visitar site
              </button>
            )}
            <Link to="/anunciar-banner" style={{ textDecoration: "none" }}>
              <button onClick={() => setMostraModalAnuncio(false)}
                style={{ width: "100%", padding: "12px", borderRadius: 12, border: "none", background: "#00C9B8", color: "#000", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>
                📢 Anunciar
              </button>
            </Link>
            <button onClick={() => setMostraModalAnuncio(false)}
              style={{ width: "100%", padding: "10px", borderRadius: 12, border: "none", background: "#2C2C2E", color: "#888", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>
              Fechar
            </button>
          </div>
        </div>
      )}

      {mostraModalStory && (
        <CriarStoryModal user={user} onClose={() => setMostraModalStory(false)} onConcluido={() => setMostraModalStory(false)} />
      )}

      {storyAtivo && (
        <div style={{ position: "fixed", inset: 0, background: "#000", zIndex: 2000 }} onClick={() => setStoryAtivo(null)}>
          <div style={{ width: "100%", height: "100%", background: `url(${storyAtivo.midia_url}) center/contain no-repeat`, position: "relative" }}>
            <div style={{ position: "absolute", top: 20, left: 16, right: 16, display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#1C1C1E", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🐓</div>
              <div style={{ fontSize: 13, fontWeight: 800, color: "#fff" }}>{storyAtivo.autor_nome}</div>
              <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
                {user?.email === storyAtivo?.usuario_email && (
                  <button onClick={async (e) => {
                    e.stopPropagation();
                    if (!confirm("Apagar este story?")) return;
                    await base44.entities.Story.delete(storyAtivo.id);
                    setStoryAtivo(null);
                  }}
                    style={{ background: "rgba(226,28,61,.3)", border: "none", borderRadius: "50%", width: 36, height: 36, color: "#ff6b81", fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>🗑️</button>
                )}
                <button onClick={() => setStoryAtivo(null)} style={{ background: "none", border: "none", color: "#fff", fontSize: 24, cursor: "pointer" }}>✕</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}