import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BottomNav from "../components/BottomNav";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

export default function AdminFinanceiro() {
  const [user, setUser] = useState(null);
  const [aba, setAba] = useState("Cursos");
  const [loading, setLoading] = useState(true);

  // Transações
  const [transacoes, setTransacoes] = useState([]);
  const [depositos, setDepositos] = useState([]);
  const [saques, setSaques] = useState([]);

  // Cursos e Aulas
  const [cursos, setCursos] = useState([]);
  const [aulas, setAulas] = useState([]);
  const [novaAula, setNovaAula] = useState({ titulo: "", descricao: "", conteudo: "", duracao_minutos: 30, video_url: "" });
  const [salvandoAula, setSalvandoAula] = useState(false);

  // Gateway Config
  const [gatewayCfg, setGatewayCfg] = useState(null);
  const [apiKey, setApiKey] = useState("");
  const [webhookSecret, setWebhookSecret] = useState("");
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    const init = async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);

        // Verificar se é admin
        if (me?.role !== "admin" && me?.role !== "master_admin") {
          return;
        }

        // Carregar dados
        const [dep, saq, cfg, cur, aul] = await Promise.all([
          base44.entities.Deposito.list("-created_date", 100),
          base44.entities.Saque.list("-created_date", 100),
          base44.entities.GatewayConfig.filter({ provider: "nyxpay" }),
          base44.entities.Curso.list("-created_date", 50).catch(() => []),
          base44.entities.Aula.list("-created_date", 100).catch(() => []),
        ]);

        setDepositos(dep);
        setSaques(saq);
        setCursos(cur);
        setAulas(aul);
        
        if (cfg.length > 0) {
          setGatewayCfg(cfg[0]);
          setApiKey(cfg[0].api_key || "");
          setWebhookSecret(cfg[0].webhook_secret || "");
        }

        // Combinar transações
        const todas = [
          ...dep.map(d => ({ ...d, tipo: "Depósito", sinal: "+" })),
          ...saq.map(s => ({ ...s, tipo: "Saque", sinal: "-" })),
        ].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

        setTransacoes(todas);
      } catch (e) {
        console.error("Erro:", e);
      }
      setLoading(false);
    };
    init();
  }, []);

  const salvarGateway = async () => {
    if (!apiKey || !webhookSecret) {
      alert("Preencha API Key e Webhook Secret");
      return;
    }
    setSalvando(true);

    try {
      if (gatewayCfg) {
        await base44.entities.GatewayConfig.update(gatewayCfg.id, {
          api_key: apiKey,
          webhook_secret: webhookSecret,
        });
      } else {
        await base44.entities.GatewayConfig.create({
          provider: "nyxpay",
          api_key: apiKey,
          webhook_secret: webhookSecret,
          ativo: true,
        });
      }
      alert("✅ Configuração salva!");
    } catch (e) {
      alert("❌ Erro ao salvar: " + e.message);
    }
    setSalvando(false);
  };



  const isAdmin = user && (user.role === "admin" || user.role === "master_admin");

  if (loading) {
    return <div style={{ padding: 20, textAlign: "center" }}>⏳ Carregando...</div>;
  }

  if (!user || !isAdmin) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 12 }}>
        <div style={{ fontSize: 48 }}>🔒</div>
        <div style={{ fontSize: 16, fontWeight: 800, color: "#170073" }}>Acesso restrito</div>
        <Link to="/" style={{ color: "#00A893", fontSize: 13 }}>← Voltar</Link>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#F0F2F8", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
          <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>💰 Financeiro</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Gerenciar transações e saques</div>
          </div>
        </div>

        {/* Abas */}
        <div style={{ display: "flex", gap: 0, overflowX: "auto", borderBottom: "2px solid rgba(255,255,255,.15)", scrollBehavior: "smooth" }}>
          {["Cursos"].map(a => (
            <button
              key={a}
              onClick={() => setAba(a)}
              style={{
                padding: "14px 20px",
                background: "none",
                border: "none",
                cursor: "pointer",
                fontFamily: "Montserrat,sans-serif",
                fontSize: 13,
                fontWeight: 600,
                whiteSpace: "nowrap",
                color: aba === a ? "#fff" : "rgba(255,255,255,.6)",
                borderBottom: aba === a ? "3px solid #fff" : "3px solid transparent",
                transition: "all .2s ease",
                flexShrink: 0,
              }}
            >
              {a}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "16px", maxWidth: 900, margin: "0 auto" }}>
        {/* ===== CURSOS ===== */}
        {aba === "Cursos" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
              {[
                { emoji: "📚", label: "Cursos", val: cursos.length },
                { emoji: "🎓", label: "Aulas", val: aulas.length },
              ].map((k, i) => (
                <div key={i} style={{ background: "#fff", borderRadius: 12, padding: "14px 16px", border: "1px solid #E8ECF0", textAlign: "center" }}>
                  <div style={{ fontSize: 24, marginBottom: 6 }}>{k.emoji}</div>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#170073" }}>{k.val}</div>
                  <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>{k.label}</div>
                </div>
              ))}
            </div>

            {/* Formulário Nova Aula */}
            <div style={{ background: "#fff", borderRadius: 14, padding: "16px", border: "1px solid #E8ECF0", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213", marginBottom: 12 }}>
                ➕ Criar Nova Aula
              </div>

              <div style={{ display: "grid", gap: 10 }}>

                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Título da Aula</label>
                  <input
                    type="text"
                    value={novaAula.titulo}
                    onChange={e => setNovaAula(p => ({ ...p, titulo: e.target.value }))}
                    placeholder="Ex: Introdução ao Treinamento"
                    style={{ width: "100%", padding: "8px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Descrição</label>
                  <textarea
                    value={novaAula.descricao}
                    onChange={e => setNovaAula(p => ({ ...p, descricao: e.target.value }))}
                    placeholder="Descreva o conteúdo da aula..."
                    style={{ width: "100%", padding: "8px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box", minHeight: 80, fontFamily: "'DM Sans', sans-serif" }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Conteúdo (opcional)</label>
                  <textarea
                    value={novaAula.conteudo}
                    onChange={e => setNovaAula(p => ({ ...p, conteudo: e.target.value }))}
                    placeholder="Links, materiais, observações..."
                    style={{ width: "100%", padding: "8px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box", minHeight: 60, fontFamily: "'DM Sans', sans-serif" }}
                  />
                </div>

                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>URL do Vídeo</label>
                  <input
                    type="text"
                    value={novaAula.video_url}
                    onChange={e => setNovaAula(p => ({ ...p, video_url: e.target.value }))}
                    placeholder="Ex: https://youtube.com/watch?v=..."
                    style={{ width: "100%", padding: "8px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                  />
                </div>

                {novaAula.video_url && (
                  <div style={{ borderRadius: 10, overflow: "hidden", background: "#000" }}>
                    <iframe
                      src={novaAula.video_url.includes("youtube.com") || novaAula.video_url.includes("youtu.be") 
                        ? `https://www.youtube.com/embed/${novaAula.video_url.split("v=")[1] || novaAula.video_url.split("/").pop()}` 
                        : novaAula.video_url}
                      width="100%"
                      height="300"
                      frameBorder="0"
                      allowFullScreen
                      style={{ borderRadius: 10 }}
                    />
                  </div>
                )}

                <div>
                  <label style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Duração (minutos)</label>
                  <input
                    type="number"
                    value={novaAula.duracao_minutos}
                    onChange={e => setNovaAula(p => ({ ...p, duracao_minutos: Number(e.target.value) }))}
                    min="1"
                    style={{ width: "100%", padding: "8px", borderRadius: 8, border: "1.5px solid #E8ECF0", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                  />
                </div>

                <button
                  onClick={async () => {
                    if (!novaAula.titulo || !novaAula.video_url) {
                      alert("Preencha título e URL do vídeo");
                      return;
                    }
                    setSalvandoAula(true);
                    try {
                      await base44.entities.Aula.create({
                        titulo: novaAula.titulo,
                        descricao: novaAula.descricao,
                        conteudo: novaAula.conteudo,
                        duracao_minutos: novaAula.duracao_minutos,
                        video_url: novaAula.video_url,
                        usuario_email: user.email,
                      });
                      const aul = await base44.entities.Aula.list("-created_date", 100);
                      setAulas(aul);
                      setNovaAula({ titulo: "", descricao: "", conteudo: "", duracao_minutos: 30, video_url: "" });
                      alert("✅ Aula criada!");
                    } catch (e) {
                      alert("❌ Erro: " + e.message);
                    }
                    setSalvandoAula(false);
                  }}
                  disabled={salvandoAula}
                  style={{
                    width: "100%",
                    padding: "10px",
                    borderRadius: 10,
                    border: "none",
                    background: salvandoAula ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
                    color: "#fff",
                    cursor: salvandoAula ? "default" : "pointer",
                    fontFamily: "Montserrat,sans-serif",
                    fontWeight: 700,
                    fontSize: 12,
                  }}
                >
                  {salvandoAula ? "Criando..." : "✅ Criar Aula"}
                </button>
              </div>
            </div>

            {/* Lista de Aulas */}
            {aulas.length > 0 && (
              <div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C", marginBottom: 8 }}>
                  📋 Aulas Criadas ({aulas.length})
                </div>
                {aulas.map(a => (
                  <div key={a.id} style={{ background: "#fff", borderRadius: 12, padding: "12px 14px", marginBottom: 8, border: "1px solid #E8ECF0" }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213" }}>
                      {a.titulo}
                    </div>
                    <div style={{ fontSize: 10, color: "#57636C", marginTop: 4 }}>
                      {a.descricao}
                    </div>
                    <div style={{ fontSize: 9, color: "#BDBDBD", marginTop: 6 }}>
                      ⏱️ {a.duracao_minutos}min · {new Date(a.created_date).toLocaleDateString("pt-BR")}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>



      <BottomNav />
    </div>
  );
}