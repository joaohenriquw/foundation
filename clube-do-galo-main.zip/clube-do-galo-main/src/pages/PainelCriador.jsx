import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import BottomNav from "../components/BottomNav";
import NotificacoesSino from "../components/NotificacoesSino";
import RelatoriosExportacao from "../components/RelatoriosExportacao";
import ConquistasPanel from "../components/ConquistasPanel";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

export default function PainelCriador() {
  const [user, setUser] = useState(null);
  const [userMeta, setUserMeta] = useState(null);
  const [leiloes, setLeiloes] = useState([]);
  const [animais, setAnimais] = useState([]);
  const [rifas, setRifas] = useState([]);
  const [avaliacoes, setAvaliacoes] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);

      if (!me) {
        navigate("/");
        return;
      }

      const [leiloesData, animaisData, rifasData, avaliacoesData, users] = await Promise.all([
        base44.entities.Leilao.filter({ dono_email: me.email }, "-created_date", 200),
        base44.entities.Animal.filter({ proprietario_email: me.email }, "-created_date", 200),
        base44.entities.Rifa.filter({ dono_email: me.email }, "-created_date", 200),
        base44.entities.Avaliacao.filter({ vendedor_email: me.email }, "-created_date", 200),
        base44.entities.User.filter({ email: me.email }),
      ]);

      setLeiloes(leiloesData);
      setAnimais(animaisData);
      setRifas(rifasData);
      setAvaliacoes(avaliacoesData);
      setUserMeta(users[0] || null);
      setLoading(false);
    };

    init();
  }, [navigate]);

  // Calcular stats
  const totalLeiloes = leiloes.length;
  const leiloesEncerrados = leiloes.filter(l => l.status === "encerrado").length;
  const taxaConversao = totalLeiloes > 0 ? ((leiloesEncerrados / totalLeiloes) * 100).toFixed(1) : 0;

  const totalArrecadado = leiloes.reduce((sum, l) => sum + (l.maior_lance || 0), 0);
  const mediaValorLeiloes = leiloesEncerrados > 0 ? totalArrecadado / leiloesEncerrados : 0;

  // Dados por espécie
  const dadosPorEspecie = {};
  leiloes.forEach(l => {
    if (!l.animal_especie) return;
    if (!dadosPorEspecie[l.animal_especie]) {
      dadosPorEspecie[l.animal_especie] = { especie: l.animal_especie, total: 0, quantidade: 0, valor_medio: 0 };
    }
    dadosPorEspecie[l.animal_especie].total += l.maior_lance || 0;
    dadosPorEspecie[l.animal_especie].quantidade += 1;
  });

  Object.keys(dadosPorEspecie).forEach(key => {
    dadosPorEspecie[key].valor_medio = dadosPorEspecie[key].total / dadosPorEspecie[key].quantidade;
  });

  const graficoEspecies = Object.values(dadosPorEspecie).sort((a, b) => b.total - a.total);

  // Timeline mensal
  const timelineMensal = {};
  leiloes.forEach(l => {
    const mes = new Date(l.created_date).toLocaleDateString("pt-BR", { month: "2-digit", year: "2-digit" });
    if (!timelineMensal[mes]) {
      timelineMensal[mes] = { mes, total: 0, quantidade: 0 };
    }
    timelineMensal[mes].total += l.maior_lance || 0;
    timelineMensal[mes].quantidade += 1;
  });

  const graficoTimeline = Object.values(timelineMensal).sort((a, b) => new Date(a.mes) - new Date(b.mes));

  // Status dos animais
  const statusAnimais = {
    disponivel: animais.filter(a => a.status_vitrine === "disponivel").length,
    em_negociacao: animais.filter(a => a.status_vitrine === "em_negociacao").length,
    vendido: animais.filter(a => a.status_vitrine === "vendido").length,
    reservado: animais.filter(a => a.status_vitrine === "reservado").length,
  };

  const graficoStatus = [
    { name: "Disponível", value: statusAnimais.disponivel, fill: "#2E7D32" },
    { name: "Em Negociação", value: statusAnimais.em_negociacao, fill: "#1565C0" },
    { name: "Reservado", value: statusAnimais.reservado, fill: "#F0A500" },
    { name: "Vendido", value: statusAnimais.vendido, fill: "#57636C" },
  ].filter(s => s.value > 0);

  // Performance por animal (top 5)
  const performanceAnimal = [];
  leiloes.forEach(l => {
    const existing = performanceAnimal.find(p => p.animal_id === l.animal_id);
    if (existing) {
      existing.valor_total += l.maior_lance || 0;
      existing.leiloes += 1;
    } else {
      performanceAnimal.push({
        animal_id: l.animal_id,
        animal_nome: l.animal_nome,
        valor_total: l.maior_lance || 0,
        leiloes: 1,
      });
    }
  });

  const top5Animais = performanceAnimal
    .sort((a, b) => b.valor_total - a.valor_total)
    .slice(0, 5)
    .map(a => ({ name: a.animal_nome.substring(0, 10), value: a.valor_total }));

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif", paddingBottom: 100 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px 24px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={() => navigate(-1)} style={{ background: "#1C1C1E", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", fontSize: 18, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>📊 Painel do Criador</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Desempenho e análise detalhada</div>
            </div>
          </div>
          {user && <NotificacoesSino userEmail={user.email} />}
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 1000, margin: "0 auto" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>Carregando dados...</div>
        ) : (
          <>
            {/* Conquistase Medalhas */}
            {user && <ConquistasPanel user={user} leiloes={leiloes} rifas={rifas} avaliacoes={avaliacoes} />}

            {/* Exportar Relatórios */}
            <RelatoriosExportacao user={user} />

            {/* KPIs Principais */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 12, marginBottom: 24 }}>
              {[
                { emoji: "🐓", label: "Animais", valor: animais.length, cor: "#170073" },
                { emoji: "🔨", label: "Leilões Total", valor: totalLeiloes, cor: "#00A893" },
                { emoji: "✅", label: "Encerrados", valor: leiloesEncerrados, cor: "#2E7D32" },
                { emoji: "📈", label: "Taxa Conversão", valor: taxaConversao + "%", cor: "#F0A500" },
                { emoji: "💰", label: "Total Arrecadado", valor: fmt(totalArrecadado), cor: "#170073" },
                { emoji: "📊", label: "Média por Leilão", valor: fmt(mediaValorLeiloes), cor: "#1565C0" },
              ].map((kpi, i) => (
                <div key={i} style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "14px 16px" }}>
                  <div style={{ fontSize: 24, marginBottom: 6 }}>{kpi.emoji}</div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 4 }}>
                    {kpi.label}
                  </div>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: kpi.cor }}>
                    {kpi.valor}
                  </div>
                </div>
              ))}
            </div>

            {/* Status dos Animais - Pizza */}
            {graficoStatus.length > 0 && (
              <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px", marginBottom: 24 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 14 }}>
                  📦 Status dos Animais
                </div>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie data={graficoStatus} cx="50%" cy="50%" labelLine={false} label={({ name, value }) => `${name}: ${value}`} outerRadius={80} fill="#170073" dataKey="value">
                      {graficoStatus.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Timeline Mensal */}
            {graficoTimeline.length > 0 && (
              <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px", marginBottom: 24 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 14 }}>
                  📈 Faturamento Mensal
                </div>
                <ResponsiveContainer width="100%" height={250}>
                  <LineChart data={graficoTimeline} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="mes" />
                    <YAxis />
                    <Tooltip formatter={(value) => fmt(value)} />
                    <Legend />
                    <Line type="monotone" dataKey="total" stroke="#170073" strokeWidth={2} name="Total (R$)" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Performance por Espécie */}
            {graficoEspecies.length > 0 && (
              <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px", marginBottom: 24 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 14 }}>
                  🐓 Performance por Espécie
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={graficoEspecies} margin={{ top: 20, right: 30, left: 0, bottom: 60 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="especie" angle={-45} textAnchor="end" height={80} />
                    <YAxis />
                    <Tooltip formatter={(value) => fmt(value)} />
                    <Legend />
                    <Bar dataKey="valor_medio" fill="#170073" name="Valor Médio (R$)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Top 5 Animais */}
            {top5Animais.length > 0 && (
              <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px", marginBottom: 24 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 14 }}>
                  ⭐ Top 5 Animais por Valor Arrecadado
                </div>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={top5Animais} layout="vertical" margin={{ top: 5, right: 30, left: 120, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={110} />
                    <Tooltip formatter={(value) => fmt(value)} />
                    <Bar dataKey="value" fill="#00A893" name="Valor Total (R$)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}

            {/* Tabela Detalhada de Leilões */}
            <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px", marginBottom: 24 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 14 }}>
                📋 Últimos 10 Leilões
              </div>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", fontSize: 12, borderCollapse: "collapse" }}>
                  <thead>
                    <tr style={{ borderBottom: "2px solid #E8ECF0", background: "#F8FAFC" }}>
                      <th style={{ padding: "10px", textAlign: "left", fontWeight: 700, color: "#57636C" }}>Animal</th>
                      <th style={{ padding: "10px", textAlign: "left", fontWeight: 700, color: "#57636C" }}>Espécie</th>
                      <th style={{ padding: "10px", textAlign: "left", fontWeight: 700, color: "#57636C" }}>Lance Mín.</th>
                      <th style={{ padding: "10px", textAlign: "left", fontWeight: 700, color: "#57636C" }}>Maior Lance</th>
                      <th style={{ padding: "10px", textAlign: "left", fontWeight: 700, color: "#57636C" }}>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {leiloes.slice(0, 10).map(l => (
                      <tr key={l.id} style={{ borderBottom: "1px solid #E8ECF0" }}>
                        <td style={{ padding: "10px", color: "#101213", fontWeight: 700 }}>{l.animal_nome}</td>
                        <td style={{ padding: "10px", color: "#57636C" }}>{l.animal_especie || "—"}</td>
                        <td style={{ padding: "10px", color: "#57636C" }}>{fmt(l.lance_minimo)}</td>
                        <td style={{ padding: "10px", color: "#170073", fontWeight: 700 }}>{fmt(l.maior_lance || l.lance_minimo)}</td>
                        <td style={{ padding: "10px" }}>
                          <span style={{
                            padding: "2px 8px",
                            borderRadius: 6,
                            fontSize: 10,
                            fontWeight: 700,
                            background: l.status === "ativo" ? "#2E7D3220" : l.status === "encerrado" ? "#57636C20" : "#E21C3D20",
                            color: l.status === "ativo" ? "#2E7D32" : l.status === "encerrado" ? "#57636C" : "#E21C3D",
                          }}>
                            {l.status === "ativo" ? "🟢" : l.status === "encerrado" ? "⚫" : "❌"} {l.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>

      <BottomNav />
    </div>
  );
}