import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BottomNav from "../components/BottomNav";
import ModalPagamentoPlan from "../components/ModalPagamentoPlan";

const PLANOS = [
  {
    id: "iniciante",
    nome: "Iniciante",
    cor: "#57636C",
    bg: "#F1F4F8",
    preco: "Grátis",
    precoNum: 0,
    descricao: "Comece sem custos e explore as funcionalidades básicas.",
    destaque: false,
    features: ["📿 50 anilhas grátis", "📸 1 story por dia", "🛒 Acesso a compra liberado"],
  },
  {
    id: "standard",
    nome: "Standard",
    cor: "#1565C0",
    bg: "#E3F2FD",
    preco: "R$ 29,90/mês",
    precoNum: 29.90,
    descricao: "Para criadores ativos que querem mais espaço e visibilidade.",
    destaque: false,
    features: ["📿 500 anilhas", "📸 3 stories por dia", "🏪 1 animal na vitrine a cada 15 dias", "🛒 Acesso a compra liberado"],
  },
  {
    id: "gold",
    nome: "Gold",
    cor: "#F0A500",
    bg: "#FFF8E1",
    preco: "R$ 49,90/mês",
    precoNum: 49.90,
    descricao: "Melhor custo-benefício. Crie rifas e leilões!",
    destaque: true,
    features: ["📿 Anilhas ilimitadas", "📸 4 stories por dia", "🏪 1 vitrine por semana", "🔨 Criar rifas e leilões", "🎓 Cursos ilimitados"],
  },
  {
    id: "premium",
    nome: "Premium",
    cor: "#E21C3D",
    bg: "#FFEBEE",
    preco: "R$ 69,90/mês",
    precoNum: 69.90,
    periodo: "ou R$ 598,80/ano",
    descricao: "Tudo desbloqueado + consultoria jurídica e veterinária.",
    destaque: false,
    features: ["📿 Anilhas ilimitadas", "📸 Stories ilimitados", "🏪 Vitrine ilimitada", "🔨 Criar rifas e leilões", "🎓 Cursos ilimitados", "⚖️ Consultoria jurídica e veterinária"],
  },
];

const BENEFICIOS = [
  "📿 Caderno de Anilhas",
  "🔨 Rifas e Leilões (Gold+)",
  "🏪 Vitrine de Animais",
  "⚖️ Consultoria Especializada (Premium)",
];

export default function Planos() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
   const [assinatura, setAssinatura] = useState(null);
   const [loading, setLoading] = useState(true);
   const [processando, setProcessando] = useState(null);
   const [modalPlano, setModalPlano] = useState(null);
   const [modalPreco, setModalPreco] = useState(null);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      if (!me) {
        navigate("/");
        return;
      }
      setUser(me);

      const assinaturas = await base44.entities.Mensalidade.filter(
        { usuario_email: me.email, status: "ativa" },
        "-created_date",
        1
      );
      if (assinaturas.length > 0) {
        setAssinatura(assinaturas[0]);
      }
      setLoading(false);
    };
    init();
  }, [navigate]);

  const abrirModalPagamento = (planoId, preco) => {
     setModalPlano(planoId);
     setModalPreco(preco);
   };

   const ao_concluir_pagamento = async () => {
     setModalPlano(null);
     setModalPreco(null);
     // Recarregar dados
     const me = await base44.auth.me();
     setUser(me);
     const assinaturas = await base44.entities.Mensalidade.filter(
       { usuario_email: me.email, status: "ativa" },
       "-created_date",
       1
     );
     if (assinaturas.length > 0) {
       setAssinatura(assinaturas[0]);
     }
   };

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 80, color: "#fff" }}>
      {/* Header */}
      <div style={{ background: "#0A0A0A", padding: "52px 20px 20px", borderBottom: "1px solid #1C1C1E" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
          <button onClick={() => navigate(-1)} style={{ background: "#1C1C1E", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", fontSize: 18, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>
            ←
          </button>
        </div>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 22, fontWeight: 900, marginBottom: 6, color: "#00C9B8" }}>
          💎 Planos Premium
        </div>
        <div style={{ fontSize: 13, color: "#888" }}>
          Desbloqueie acesso ilimitado a todos os recursos
        </div>
      </div>

      <div style={{ padding: "20px 16px", maxWidth: 900, margin: "0 auto" }}>
        {/* Status atual */}
        {assinatura && (
          <div style={{ background: "#1C1C1E", borderRadius: 14, padding: "14px 16px", marginBottom: 20, border: "1.5px solid #00C9B8" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#00C9B8", marginBottom: 4 }}>
              ✅ Você possui uma assinatura ativa
            </div>
            <div style={{ fontSize: 11, color: "#00C9B8" }}>
              Plano {assinatura.plano} - Válido até {new Date(assinatura.data_vencimento).toLocaleDateString("pt-BR")}
            </div>
          </div>
        )}

        {/* Benefícios */}
        <div style={{ background: "#1C1C1E", borderRadius: 14, padding: "16px 18px", marginBottom: 20, border: "1px solid #333" }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#fff", marginBottom: 12 }}>
          Benefícios Inclusos
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {BENEFICIOS.map((beneficio, idx) => (
              <div key={idx} style={{ fontSize: 12, color: "#aaa", display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 14 }}>{beneficio.split(" ")[0]}</span>
                {beneficio.split(" ").slice(1).join(" ")}
              </div>
            ))}
          </div>
        </div>

        {/* Planos */}
        <div style={{ display: "grid", gap: 16 }}>
          {PLANOS.map(plano => (
            <div
              key={plano.id}
              style={{
                background: plano.bg,
                borderRadius: 14,
                border: plano.destaque ? `2px solid ${plano.cor}` : `1px solid ${plano.cor}40`,
                overflow: "hidden",
                position: "relative",
              }}
            >
              {plano.destaque && (
                <div style={{ background: plano.cor, color: "#fff", padding: "6px 12px", textAlign: "center", fontSize: 11, fontWeight: 900, fontFamily: "Montserrat,sans-serif" }}>
                  ⭐ MAIS POPULAR
                </div>
              )}

              <div style={{ padding: "18px 16px" }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: plano.cor, marginBottom: 2 }}>
                  {plano.nome}
                </div>
                <div style={{ fontSize: 11, color: plano.cor, opacity: 0.8, marginBottom: 12, fontWeight: 600 }}>{plano.descricao}</div>

                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 22, fontWeight: 900, color: plano.cor }}>
                    {plano.preco}
                  </div>
                  {plano.periodo && <div style={{ fontSize: 11, color: plano.cor, opacity: 0.7, fontWeight: 600 }}>{plano.periodo}</div>}
                </div>

                <div style={{ marginBottom: 16 }}>
                  {plano.features.map((f, i) => (
                    <div key={i} style={{ fontSize: 12, color: plano.cor, fontWeight: 600, marginBottom: 6, display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 15 }}>{f.split(" ")[0]}</span>
                      {f.split(" ").slice(1).join(" ")}
                    </div>
                  ))}
                </div>

                {plano.precoNum > 0 && (
                  <button
                    onClick={() => abrirModalPagamento(plano.id, plano.precoNum)}
                    disabled={assinatura && assinatura.plano === plano.id}
                    style={{
                      width: "100%", padding: "12px", borderRadius: 10, border: "none",
                      background: assinatura && assinatura.plano === plano.id ? "#E8ECF0" : plano.cor,
                      color: assinatura && assinatura.plano === plano.id ? "#BDBDBD" : "#fff",
                      cursor: assinatura && assinatura.plano === plano.id ? "default" : "pointer",
                      fontFamily: "Montserrat,sans-serif", fontWeight: 900, fontSize: 13,
                    }}
                  >
                    {assinatura && assinatura.plano === plano.id ? "✓ Plano Atual" : "💳 Assinar Agora"}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Informações */}
        <div style={{ background: "#1C1C1E", borderRadius: 14, padding: "16px 18px", marginTop: 20, border: "1px solid #333" }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#00C9B8", marginBottom: 10 }}>
            🔒 Segurança Garantida
          </div>
          <div style={{ fontSize: 11, color: "#aaa", lineHeight: 1.6 }}>
            Todos os pagamentos são processados de forma segura através da plataforma <strong>NyxPay</strong>. Suas informações de pagamento nunca são armazenadas em nossos servidores.
          </div>
        </div>
      </div>

      {/* Modal Pagamento */}
       {modalPlano && (
         <ModalPagamentoPlan
           plano={modalPlano}
           planoPreco={modalPreco}
           user={user}
           onClose={() => setModalPlano(null)}
           onConcluido={ao_concluir_pagamento}
         />
       )}

       <BottomNav />
      </div>
      );
      }