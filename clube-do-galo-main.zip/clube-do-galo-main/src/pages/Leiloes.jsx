import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BottomNav from "../components/BottomNav";
import BackHeader from "../components/BackHeader";
import PaginationList from "../components/PaginationList";
import NotificacoesSino from "../components/NotificacoesSino";
import CriarLeilaoModal from "../components/CriarLeilaoModal";
import PlanoGuard from "../components/PlanoGuard";
import { getPlano, getPlanoBundles } from "../lib/planos";

function Countdown({ dataFim }) {
  const [restante, setRestante] = useState("");
  const [urgente, setUrgente]   = useState(false);

  useEffect(() => {
    const calc = () => {
      const diff = new Date(dataFim) - new Date();
      if (diff <= 0) { setRestante("Encerrado"); return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setUrgente(diff < 3600000);
      setRestante(`${h > 0 ? h+"h " : ""}${String(m).padStart(2,"0")}m ${String(s).padStart(2,"0")}s`);
    };
    calc();
    const t = setInterval(calc, 1000);
    return () => clearInterval(t);
  }, [dataFim]);

  return (
    <span style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 900, color: urgente ? "#E21C3D" : "#2E7D32", fontSize: 13 }}>
      ⏱️ {restante}
    </span>
  );
}

export default function Leiloes() {
  const [leiloes, setLeiloes]   = useState([]);
  const [meusLeiloes, setMeusLeiloes] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [user, setUser]         = useState(null);
  const [userMeta, setUserMeta] = useState(null);
  const [criando, setCriando]   = useState(false);
  const [aba, setAba]           = useState('todos');
  const [loadingMeta, setLoadingMeta] = useState(true);
  const navigate = useNavigate();

  const carregar = async () => {
    setLoading(true);
    setLoadingMeta(true);
    try {
      const [me, data] = await Promise.all([
        base44.auth.me().catch(() => null),
        base44.entities.Leilao.list("-created_date", 50).catch(() => []),
      ]);
      setUser(me);
      if (me) {
        const [users, meus] = await Promise.all([
          base44.entities.User.filter({ email: me.email }).catch(() => []),
          base44.entities.Leilao.filter({ dono_email: me.email }, "-created_date", 50).catch(() => []),
        ]);
        setUserMeta(users[0] || null);
        setMeusLeiloes(meus);
      }
      setLeiloes(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setLoadingMeta(false);
    }
  };

  useEffect(() => {
    carregar();
  }, []);

  // Recarrega dados ao voltar à página
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        carregar();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  const planoBundles = getPlanoBundles(user?.role, userMeta?.plano);
  const plano = getPlano(planoBundles);
  const dados = aba === 'todos' ? leiloes.filter(l => ['ativo', 'agendado', 'encerrado'].includes(l.status)) : meusLeiloes;
  const dadosFaltando = ['cpf', 'whatsapp', 'nome_criatorio'].filter(campo => !userMeta?.[campo]);

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 80, color: "#fff" }}>
      <BackHeader 
        title="Leilões"
        showBackButton={true}
        rightAction={
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {user && <NotificacoesSino userEmail={user.email} />}
            {loadingMeta ? (
              <button disabled style={{ background: "#ccc", color: "#fff", border: "none", borderRadius: 10, padding: "8px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, minHeight: 44, cursor: "wait" }}>...</button>
            ) : plano.pode_rifa_leilao ? (
              <button onClick={() => setCriando(true)}
                style={{ background: "#170073", color: "#fff", border: "none", borderRadius: 10, padding: "8px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer", minHeight: 44, display: "flex", alignItems: "center" }}>
                + Criar
              </button>
            ) : (
              <button onClick={() => navigate("/planos")}
                style={{ background: "rgba(23,0,115,.2)", color: "#170073", border: "none", borderRadius: 10, padding: "8px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer", minHeight: 44 }}>
                + Criar 🔒
              </button>
            )}
          </div>
        }
      />
      
      {/* Tabs */}
      <div style={{ display: "flex", gap: 0, borderBottom: "1px solid #1C1C1E", background: "#0A0A0A" }}>
        {[{key: 'todos', label: '📋 Todos'}, {key: 'meus', label: '👤 Meus'}].map(t => (
          <button key={t.key} onClick={() => setAba(t.key)}
            style={{ flex: 1, padding: "14px", background: "none", border: "none", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, minHeight: 44,
              color: aba === t.key ? "#00C9B8" : "#555",
              borderBottom: aba === t.key ? "3px solid #00C9B8" : "3px solid transparent",
              transition: "all .2s" }}>
            {t.label}
          </button>
        ))}
      </div>



      <div style={{ padding: "14px 14px 20px", maxWidth: 700, margin: "0 auto" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#555" }}>Carregando...</div>
        ) : (
          <PaginationList
            items={dados}
            itemsPerPage={10}
            renderItem={(l) => (
              <div onClick={() => navigate(l.status === 'ativo' ? `/leilao-ao-vivo/${l.id}` : `/leilao/${l.id}`)}
                style={{ background: "#1C1C1E", borderRadius: 16, border: "1px solid #333", overflow: "hidden", cursor: "pointer", minHeight: 44, display: "flex", alignItems: "center" }}>
                <div style={{ display: "flex", gap: 0, width: "100%" }}>
                  <div style={{ width: 100, minWidth: 100, background: "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", height: 100 }}>
                    {l.animal_foto_url ? (
                      <img src={l.animal_foto_url} alt={l.animal_nome} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                    ) : (
                      <span style={{ fontSize: 40 }}>🐓</span>
                    )}
                  </div>
                  <div style={{ flex: 1, padding: "12px 14px", display: "flex", flexDirection: "column", justifyContent: "center" }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff", marginBottom: 2 }}>{l.titulo}</div>
                    <div style={{ fontSize: 11, color: "#888", marginBottom: 4 }}>{l.animal_nome}</div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                      <Countdown dataFim={l.data_fim} />
                      <div style={{ fontSize: 10, color: "#2E7D32", fontWeight: 700 }}>R$ {Number(l.maior_lance || l.lance_minimo).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
                    </div>
                  </div>
                </div>
              </div>
            )
            }
            emptyComponent={
              <div style={{ textAlign: "center", padding: 48 }}>
                <div style={{ fontSize: 52, marginBottom: 12 }}>🔨</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "#fff" }}>Nenhum leilão ativo</div>
                <div style={{ fontSize: 12, color: "#888", marginTop: 6 }}>Seja o primeiro a criar um leilão</div>
              </div>
            }
          />
        )}

      </div>

      {criando && <CriarLeilaoModal user={user} onClose={() => setCriando(false)} onCriado={carregar} />}
      <BottomNav />
      </div>
      );
      }