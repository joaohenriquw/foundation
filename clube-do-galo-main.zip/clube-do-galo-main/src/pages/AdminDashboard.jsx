import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BottomNav from "../components/BottomNav";
import ConfigurarNyxpay from "../components/ConfiguraGatewayNyxpay";

// ================================================================
// SOCIOS E DIVISÃO DE LUCROS
// ================================================================
const SOCIOS = [
  { nome: "Jéder",  pct_leilao: 50, pct_rifa: 50, pct_mensalidade: 50 },
  { nome: "João",   pct_leilao: 20, pct_rifa: 20, pct_mensalidade: 20 },
  { nome: "Álvaro", pct_leilao: 20, pct_rifa: 20, pct_mensalidade: 20 },
  { nome: "Lucas",  pct_leilao: 10, pct_rifa: 10, pct_mensalidade: 10 },
];

const ADMINS_NOMES = ["Luan", "Jéder", "Álvaro", "Lucas"];

const TAXA_ADMIN  = 0.10; // 10% do leilão/rifa vai para os sócios
const TAXA_GATEWAY = 0.38; // R$ 0,38 por transação

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

const ABAS = ["Resumo", "Leilões", "Rifas", "Trocas de Posse", "Anilhas", "Vitrine", "Planos Gratuitos", "Cursos", "Usuários", "Sócios", "Configurações"];

const STATUS_BADGE = (status, mapCor = {}) => {
  const cfg = mapCor[status] || { bg: "#F1F4F8", cor: "#57636C" };
  return (
    <div style={{ fontSize: 10, fontWeight: 800, borderRadius: 8, padding: "3px 8px", background: cfg.bg, color: cfg.cor, display: "inline-block" }}>
      {status}
    </div>
  );
};

const LEILAO_COR = {
  ativo:     { bg: "#E8F5E9", cor: "#2E7D32" },
  encerrado: { bg: "#F1F4F8", cor: "#57636C" },
  agendado:  { bg: "#FFF8E1", cor: "#F0A500" },
  cancelado: { bg: "#FFEBEE", cor: "#C62828" },
};

const TROCA_COR = {
  concluida:      { bg: "#E8F5E9", cor: "#2E7D32" },
  pendente_aceite:{ bg: "#FFF8E1", cor: "#F0A500" },
  cancelada:      { bg: "#FFEBEE", cor: "#C62828" },
};

export default function AdminDashboard() {
  const [user, setUser]       = useState(null);
  const [userMeta, setUserMeta] = useState(null);
  const [aba, setAba]         = useState("Resumo");
  const [loading, setLoading] = useState(true);
  const [leiloes, setLeiloes] = useState([]);
  const [trocas, setTrocas]   = useState([]);
  const [anilhas, setAnilhas] = useState([]);
  const [vitrine, setVitrine] = useState([]);
  const [animais, setAnimais] = useState([]);
  const [usuarios, setUsuarios] = useState([]);
  const [planosGratuitos, setPlanosGratuitos] = useState([]);
  const [rifas, setRifas] = useState([]);
  const [bilhetes, setBilhetes] = useState([]);
  const [cursos, setCursos] = useState([]);
  const [aulas, setAulas] = useState([]);
  const [historicoAberto, setHistoricoAberto] = useState(false);
  const [filtroDataInicio, setFiltroDataInicio] = useState("");
  const [filtroDataFim, setFiltroDataFim] = useState("");
  const [filtroValorMin, setFiltroValorMin] = useState("");
  const [filtroValorMax, setFiltroValorMax] = useState("");

  // Modal concessão de plano
  const [modalPlano, setModalPlano] = useState(false);
  const [planoForm, setPlanoForm]   = useState({ usuario_email: "", plano: "premium", motivo: "Influenciador", validade: "" });
  const [salvandoPlano, setSalvandoPlano] = useState(false);

  // Modal atribuição de cargo
  const [modalCargo, setModalCargo] = useState(false);
  const [cargoForm, setCargoForm] = useState({ usuario_id: "", usuario_email: "", novo_cargo: "user" });
  const [salvandoCargo, setSalvandoCargo] = useState(false);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      if (!me) return;
      const [l, t, an, v, anim, u, pg, r, b, c, a] = await Promise.all([
        base44.entities.Leilao.list("-created_date", 500),
        base44.entities.TrocaPosse.list("-created_date", 500),
        base44.entities.AnilhaFilha.list("-created_date", 500),
        base44.entities.VitrineExposicao.list("-created_date", 500),
        base44.entities.Animal.list("-created_date", 500),
        base44.entities.User.list("-created_date", 500),
        base44.entities.PlanoGratuito.list("-created_date", 200),
        base44.entities.Rifa.list("-created_date", 500),
        base44.entities.RifaBilhete.list("-created_date", 1000),
        base44.entities.Curso.list("-created_date", 50),
        base44.entities.Aula.list("-created_date", 100),
      ]);
      setLeiloes(l);
      setTrocas(t);
      setAnilhas(an);
      setVitrine(v);
      setAnimais(anim);
      setUsuarios(u);
      setPlanosGratuitos(pg);
      setRifas(r);
      setBilhetes(b);
      setCursos(c);
      setAulas(a);
      const uMeta = u.find(x => x.email === me.email) || null;
      setUserMeta(uMeta);
      console.log('Rifas carregadas:', r.length, 'Bilhetes:', b.length);
      setLoading(false);
    };
    init();
  }, []);

  const concederPlano = async () => {
    if (!planoForm.usuario_email) return;
    setSalvandoPlano(true);
    // Registra log
    await base44.entities.PlanoGratuito.create({
      admin_id: user.id,
      admin_nome: user.full_name,
      admin_email: user.email,
      usuario_email: planoForm.usuario_email,
      plano: planoForm.plano,
      motivo: planoForm.motivo,
      validade: planoForm.validade,
    });
    // Atualiza o plano do usuário
    const target = usuarios.find(u => u.email === planoForm.usuario_email);
    if (target) {
      await base44.entities.User.update(target.id, { plano: planoForm.plano, plano_expiracao: planoForm.validade });
    }
    setPlanosGratuitos(prev => [{ ...planoForm, admin_nome: user.full_name, admin_email: user.email, created_date: new Date().toISOString() }, ...prev]);
    setSalvandoPlano(false);
    setModalPlano(false);
    setPlanoForm({ usuario_email: "", plano: "premium", motivo: "Influenciador", validade: "" });
  };

  const atribuirCargo = async () => {
    if (!cargoForm.usuario_id) return;
    setSalvandoCargo(true);
    // Atualiza o cargo do usuário
    await base44.entities.User.update(cargoForm.usuario_id, { role: cargoForm.novo_cargo });
    // Atualiza a lista local de usuários
    setUsuarios(prev => prev.map(u => u.id === cargoForm.usuario_id ? { ...u, role: cargoForm.novo_cargo } : u));
    setSalvandoCargo(false);
    setModalCargo(false);
    setCargoForm({ usuario_id: "", usuario_email: "", novo_cargo: "user" });
  };

  // KPIs financeiros
  const leiloesConfirmados = leiloes.filter(l => l.pagamento_confirmado);
  const totalLeiloesArrecadado = leiloesConfirmados.reduce((s, l) => s + (l.maior_lance || 0), 0);
  const taxaAdminLeilao = totalLeiloesArrecadado * TAXA_ADMIN;
  const gatewayLeilao   = leiloesConfirmados.length * TAXA_GATEWAY;

  const trocasConcluidas = trocas.filter(t => t.status === "concluida");
  const valorTrocas = trocasConcluidas.reduce((s, t) => s + (t.valor || 0), 0);

  const totalUsuarios   = usuarios.length;
  const totalAnimais    = animais.length;
  const vitrineAtiva    = vitrine.filter(v => v.ativa).length;
  const totalAnilhas    = anilhas.length;

  const isAdmin = user && (user.role === "admin" || user.role === "master_admin");
  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ textAlign: "center", color: "#57636C" }}>⏳ Carregando...</div>
    </div>
  );
  if (!user || !isAdmin) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Montserrat,sans-serif", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 48 }}>🔒</div>
      <div style={{ fontSize: 16, fontWeight: 800, color: "#170073" }}>Acesso restrito</div>
      <Link to="/" style={{ color: "#00A893", fontSize: 13 }}>← Voltar ao início</Link>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "#F0F2F8", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px 20px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
          <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>🛡️ Painel Administrativo</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>{user.full_name} · {user.role}</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 0, overflowX: "auto", borderBottom: "2px solid rgba(255,255,255,.15)", scrollBehavior: "smooth" }}>
          {ABAS.map(a => (
            <button key={a} onClick={() => setAba(a)}
              style={{ padding: "14px 20px", background: "none", border: "none", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 600, whiteSpace: "nowrap",
                color: aba === a ? "#fff" : "rgba(255,255,255,.6)",
                borderBottom: aba === a ? "3px solid #fff" : "3px solid transparent",
                transition: "all .2s ease",
                position: "relative",
                flexShrink: 0 }}
              onMouseEnter={e => aba !== a && (e.target.style.color = "rgba(255,255,255,.8)")}
              onMouseLeave={e => (e.target.style.color = aba === a ? "#fff" : "rgba(255,255,255,.6)")}
              title={a}>
              {a}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "16px", maxWidth: 800, margin: "0 auto" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 60, color: "#57636C" }}>⏳ Carregando dados...</div>
        ) : (
          <>
            {/* ===== RESUMO ===== */}
            {aba === "Resumo" && (
              <div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
                  {[
                    { emoji: "👤", label: "Usuários",       val: totalUsuarios, aba: "Usuários" },
                    { image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/34202ef59_5c11ff38-3230-4907-8326-8905539ffbcd.jpg", label: "Animais",        val: totalAnimais, aba: null },
                    { image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/e91391015_WhatsAppImage2026-04-04at000032.jpeg", label: "Leilões",        val: leiloes.length, aba: "Leilões" },
                    { emoji: "🔄", label: "Trocas de Posse",val: trocas.length, aba: "Trocas de Posse" },
                    { image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/007f8b306_WhatsAppImage2026-04-03at235723.jpg", label: "Anilhas",        val: totalAnilhas, aba: "Anilhas" },
                    { emoji: "🎰", label: "Rifas",        val: rifas.length, aba: "Rifas" },
                    { image: "https://media.base44.com/images/public/69cf34a8fab4925b6658841a/fc923f5cb_generated_image.png", label: "Vitrine ativa",  val: vitrineAtiva, aba: "Vitrine" },
                  ].map((k, i) => (
                    <button key={i} onClick={() => k.aba && setAba(k.aba)}
                      style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", border: "1px solid #E8ECF0", display: "flex", alignItems: "center", gap: 12, cursor: k.aba ? "pointer" : "default", transition: ".2s", textAlign: "left" }}
                      onMouseEnter={e => k.aba && (e.currentTarget.style.borderColor = "#170073")}
                      onMouseLeave={e => k.aba && (e.currentTarget.style.borderColor = "#E8ECF0")}>
                      {k.image ? (
                        <img src={k.image} alt={k.label} style={{ width: 32, height: 32, objectFit: "cover", borderRadius: 6 }} />
                      ) : (
                        <span style={{ fontSize: 26 }}>{k.emoji}</span>
                      )}
                      <div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 22, fontWeight: 900, color: "#170073" }}>{k.val}</div>
                        <div style={{ fontSize: 11, color: "#57636C", fontWeight: 700 }}>{k.label}</div>
                      </div>
                    </button>
                  ))}
                </div>

                {/* Financeiro Leilões */}
                <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", borderRadius: 16, padding: "18px 20px", color: "#fff", marginBottom: 14 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, marginBottom: 10 }}>🔨 Financeiro — Leilões</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, textAlign: "center" }}>
                    {[
                      { label: "Total transacionado", val: fmt(totalLeiloesArrecadado) },
                      { label: "Taxa admin (10%)", val: fmt(taxaAdminLeilao) },
                      { label: "Gateway (R$0,38/tx)", val: fmt(gatewayLeilao) },
                    ].map((k, i) => (
                      <div key={i}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>{k.val}</div>
                        <div style={{ fontSize: 9, opacity: .8 }}>{k.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Trocas */}
                <div style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", border: "1px solid #E8ECF0", marginBottom: 14 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, marginBottom: 8, color: "#101213" }}>🔄 Trocas de Posse</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, textAlign: "center" }}>
                    {[
                      { label: "Total", val: trocas.length },
                      { label: "Concluídas", val: trocasConcluidas.length },
                      { label: "Valor total", val: fmt(valorTrocas) },
                    ].map((k, i) => (
                      <div key={i} style={{ background: "#F8FAFC", borderRadius: 10, padding: 10 }}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>{k.val}</div>
                        <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>{k.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Botão Gestão de Saques */}
                <Link to="/admin-saques"
                  style={{ display: "flex", alignItems: "center", gap: 12, background: "#fff", borderRadius: 14, padding: "14px 16px", border: "1px solid #E8ECF0", textDecoration: "none", marginBottom: 14 }}>
                  <span style={{ fontSize: 26 }}>💰</span>
                  <div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>Gestão de Saques</div>
                    <div style={{ fontSize: 11, color: "#57636C", fontWeight: 600 }}>Aprovar ou recusar solicitações</div>
                  </div>
                  <span style={{ marginLeft: "auto", fontSize: 18, color: "#170073" }}>→</span>
                </Link>

                {/* Planos gratuitos recentes */}
                {planosGratuitos.length > 0 && (
                  <div style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", border: "1px solid #E8ECF0" }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, marginBottom: 8, color: "#101213" }}>🎁 Planos Gratuitos Recentes</div>
                    {planosGratuitos.slice(0, 5).map((p, i) => (
                      <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 0", borderBottom: "1px solid #F8FAFC" }}>
                        <div>
                          <div style={{ fontSize: 12, fontWeight: 700, color: "#101213" }}>{p.usuario_email}</div>
                          <div style={{ fontSize: 10, color: "#57636C" }}>Por {p.admin_nome} · {p.motivo}</div>
                        </div>
                        <div style={{ fontSize: 10, fontWeight: 800, background: "#170073", color: "#fff", borderRadius: 8, padding: "3px 8px" }}>{p.plano}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ===== LEILÕES ===== */}
            {aba === "Leilões" && (
              <div>
                <div style={{ background: "#fff", borderRadius: 12, padding: "12px 16px", marginBottom: 12, border: "1px solid #E8ECF0" }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#101213", marginBottom: 6 }}>📊 Taxas por transação</div>
                  <div style={{ fontSize: 11, color: "#57636C", lineHeight: 1.6 }}>
                    • <strong>R$ 0,38</strong> por transação (gateway de pagamento)<br/>
                    • <strong>10%</strong> de taxa administrativa (leiloeiro)<br/>
                    • O restante vai direto para a conta do dono do animal
                  </div>
                </div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C", marginBottom: 8 }}>{leiloes.length} leilões registrados</div>
                {leiloes.map(l => (
                  <div key={l.id} style={{ background: "#fff", borderRadius: 12, padding: "12px 14px", marginBottom: 8, border: "1px solid #E8ECF0" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800 }}>{l.animal_nome || "Animal"}</div>
                        <div style={{ fontSize: 11, color: "#57636C" }}>Dono: {l.dono_nome || l.dono_email}</div>
                        <div style={{ fontSize: 11, color: "#57636C" }}>Lance mín: {fmt(l.lance_minimo)}</div>
                        {l.maior_lance > 0 && (
                          <div style={{ fontSize: 11, color: "#2E7D32", fontWeight: 700 }}>
                            Maior lance: {fmt(l.maior_lance)} · {l.maior_lance_user_nome}
                          </div>
                        )}
                        {l.pagamento_confirmado && (
                          <div style={{ fontSize: 10, color: "#2E7D32", fontWeight: 700, marginTop: 2 }}>
                            💰 Taxa admin: {fmt((l.maior_lance || 0) * 0.10)} · Gateway: R$ 0,38
                          </div>
                        )}
                      </div>
                      <div style={{ textAlign: "right" }}>
                        {STATUS_BADGE(l.status, LEILAO_COR)}
                        {l.pagamento_confirmado && <div style={{ fontSize: 10, color: "#2E7D32", fontWeight: 700, marginTop: 4 }}>✅ Pago</div>}
                        <div style={{ fontSize: 10, color: "#BDBDBD", marginTop: 4 }}>{new Date(l.data_fim).toLocaleDateString("pt-BR")}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== RIFAS ===== */}
            {aba === "Rifas" && (
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, flex: 1 }}>
                    {[
                      { label: "Total", val: rifas.length },
                      { label: "Ativas", val: rifas.filter(r => r.status === "ativa").length },
                      { label: "Arrecadado", val: fmt(rifas.filter(r => r.status !== "cancelada").reduce((s, r) => s + (r.total_arrecadado || 0), 0)) },
                    ].map((k, i) => (
                      <div key={i} style={{ background: "#fff", borderRadius: 12, padding: "14px 16px", border: "1px solid #E8ECF0", textAlign: "center" }}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#170073" }}>{k.val}</div>
                        <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginTop: 4 }}>{k.label}</div>
                      </div>
                    ))}
                  </div>
                  <button onClick={() => setHistoricoAberto(!historicoAberto)}
                    style={{ background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", border: "none", borderRadius: 10, padding: "8px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer", marginLeft: 10, whiteSpace: "nowrap" }}>
                    📊 Histórico de Ganhadores
                  </button>
                </div>

                {historicoAberto && (
                  <div style={{ background: "#F8FAFC", borderRadius: 14, padding: "12px", marginBottom: 14, border: "1px solid #E8ECF0", maxHeight: 350, overflowY: "auto" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, position: "sticky", top: 0, background: "#F8FAFC", paddingBottom: 8 }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#101213" }}>📊 Histórico de Ganhadores</div>
                      <button onClick={() => setHistoricoAberto(false)} style={{ background: "none", border: "none", fontSize: 16, cursor: "pointer", color: "#57636C" }}>✕</button>
                    </div>

                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 6, marginBottom: 10 }}>
                      <input type="date" value={filtroDataInicio} onChange={e => setFiltroDataInicio(e.target.value)} style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid #E8ECF0", fontSize: 11 }} />
                      <input type="date" value={filtroDataFim} onChange={e => setFiltroDataFim(e.target.value)} style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid #E8ECF0", fontSize: 11 }} />
                      <input type="number" value={filtroValorMin} placeholder="Mín" onChange={e => setFiltroValorMin(e.target.value)} style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid #E8ECF0", fontSize: 11 }} />
                      <input type="number" value={filtroValorMax} placeholder="Máx" onChange={e => setFiltroValorMax(e.target.value)} style={{ padding: "6px 8px", borderRadius: 6, border: "1px solid #E8ECF0", fontSize: 11 }} />
                    </div>

                    {(() => {
                      const ganhadores = rifas.filter(r => r.ganhador_id && r.status === "encerrada").filter(r => {
                        if (filtroDataInicio && new Date(r.data_sorteio) < new Date(filtroDataInicio)) return false;
                        if (filtroDataFim && new Date(r.data_sorteio) > new Date(filtroDataFim)) return false;
                        if (filtroValorMin && (r.total_arrecadado || 0) < Number(filtroValorMin)) return false;
                        if (filtroValorMax && (r.total_arrecadado || 0) > Number(filtroValorMax)) return false;
                        return true;
                      }).sort((a, b) => new Date(b.data_sorteio) - new Date(a.data_sorteio));

                      return (
                        <div>
                          {ganhadores.length === 0 ? (
                            <div style={{ textAlign: "center", padding: 12, color: "#BDBDBD", fontSize: 11 }}>Nenhum sorteio</div>
                          ) : ganhadores.slice(0, 10).map(r => (
                            <div key={r.id} style={{ background: "#fff", borderRadius: 8, padding: "8px", marginBottom: 6, border: "1px solid #E8ECF0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                              <div>
                                <div style={{ fontSize: 11, fontWeight: 700, color: "#101213" }}>{r.ganhador_nome}</div>
                                <div style={{ fontSize: 9, color: "#57636C" }}>Rifa: {r.animal_nome}</div>
                              </div>
                              <div style={{ fontSize: 9, color: "#BDBDBD" }}>{new Date(r.data_sorteio).toLocaleDateString("pt-BR")}</div>
                            </div>
                          ))}
                        </div>
                      );
                    })()}
                  </div>
                )}

                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C", marginBottom: 8 }}>{rifas.length} rifas registradas</div>
                {rifas.map(r => {
                  const bilhete = bilhetes.filter(b => b.rifa_id === r.id && b.status === "pago");
                  return (
                    <div key={r.id} style={{ background: "#fff", borderRadius: 12, padding: "12px 14px", marginBottom: 8, border: "1px solid #E8ECF0" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                        <div>
                          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800 }}>{r.animal_nome || "Animal"}</div>
                          <div style={{ fontSize: 11, color: "#57636C" }}>Dono: {r.dono_nome || r.dono_email}</div>
                          <div style={{ fontSize: 11, color: "#57636C" }}>Meta: {fmt(r.valor_arrecadar)} · {r.qtd_numeros} números</div>
                          <div style={{ fontSize: 11, color: "#2E7D32", fontWeight: 700, marginTop: 2 }}
                            >Arrecadado: {fmt(r.total_arrecadado || 0)} ({bilhete.length}/{r.qtd_numeros} vendidos)
                          </div>
                          {r.ganhador_nome && (
                            <div style={{ fontSize: 10, color: "#170073", fontWeight: 700, marginTop: 2 }}>✅ Ganhador: {r.ganhador_nome}</div>
                          )}
                        </div>
                        <div style={{ textAlign: "right" }}>
                          {STATUS_BADGE(r.status, { ativa: { bg: "#E8F5E9", cor: "#2E7D32" }, encerrada: { bg: "#F1F4F8", cor: "#57636C" }, cancelada: { bg: "#FFEBEE", cor: "#C62828" } })}
                          <div style={{ fontSize: 10, color: "#BDBDBD", marginTop: 4 }}>{new Date(r.data_sorteio).toLocaleDateString("pt-BR")}</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* ===== TROCAS ===== */}
            {aba === "Trocas de Posse" && (
              <div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C", marginBottom: 8 }}>{trocas.length} trocas registradas</div>
                {trocas.map(t => (
                  <div key={t.id} style={{ background: "#fff", borderRadius: 12, padding: "12px 14px", marginBottom: 8, border: "1px solid #E8ECF0" }}>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800 }}>{t.animal_nome} · {t.animal_anilha}</div>
                        <div style={{ fontSize: 11, color: "#57636C" }}>De: {t.cedente_nome || t.cedente_email}</div>
                        <div style={{ fontSize: 11, color: "#57636C" }}>Para: {t.cessionario_nome || t.cessionario_email}</div>
                        <div style={{ fontSize: 10, color: "#57636C", marginTop: 2 }}>Modalidade: {t.modalidade} · {t.data_transferencia}</div>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>{fmt(t.valor)}</div>
                        <div style={{ marginTop: 4 }}>{STATUS_BADGE(t.status, TROCA_COR)}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== ANILHAS ===== */}
            {aba === "Anilhas" && (
              <div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 14 }}>
                  {[
                    { label: "Total", val: totalAnilhas },
                    { label: "Trocadas", val: anilhas.filter(a => a.status === "trocada").length },
                    { label: "Pendentes", val: anilhas.filter(a => a.status === "aguardando_troca").length },
                  ].map((k, i) => (
                    <div key={i} style={{ background: "#fff", borderRadius: 12, padding: 12, textAlign: "center", border: "1px solid #E8ECF0" }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 20, fontWeight: 900, color: "#170073" }}>{k.val}</div>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>{k.label}</div>
                    </div>
                  ))}
                </div>
                {anilhas.map(a => (
                  <div key={a.id} style={{ background: "#fff", borderRadius: 12, padding: "10px 14px", marginBottom: 6, border: "1px solid #E8ECF0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800 }}>#{a.numero_anilha} · {a.cor_anilha}</div>
                      <div style={{ fontSize: 11, color: "#57636C" }}>{a.nome_filhote || "Filhote"} · Troca: {a.data_prevista_troca}</div>
                    </div>
                    <div style={{ fontSize: 10, fontWeight: 800, borderRadius: 8, padding: "3px 8px",
                      background: a.status === "trocada" ? "#E8F5E9" : a.status === "cadastrada" ? "#E3F2FD" : "#FFF8E1",
                      color: a.status === "trocada" ? "#2E7D32" : a.status === "cadastrada" ? "#1565C0" : "#F0A500" }}>
                      {a.status}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== VITRINE ===== */}
            {aba === "Vitrine" && (
              <div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C", marginBottom: 8 }}>
                  {vitrineAtiva} ativos de {vitrine.length} registros
                </div>
                {vitrine.map(v => (
                  <div key={v.id} style={{ background: "#fff", borderRadius: 12, padding: "10px 14px", marginBottom: 6, border: "1px solid #E8ECF0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800 }}>{v.animal_nome} · {v.animal_anilha}</div>
                      <div style={{ fontSize: 11, color: "#57636C" }}>Expositor: {v.proprietario_nome}</div>
                      <div style={{ fontSize: 10, color: "#57636C" }}>Expira: {v.data_expiracao ? new Date(v.data_expiracao).toLocaleDateString("pt-BR") : "—"}</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>{fmt(v.animal_valor)}</div>
                      <div style={{ fontSize: 10, fontWeight: 700, color: v.ativa ? "#2E7D32" : "#C62828", marginTop: 4 }}>{v.ativa ? "✅ Ativo" : "❌ Inativo"}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== CURSOS ===== */}
            {aba === "Cursos" && (
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, flex: 1 }}>
                  {[
                    { emoji: "📚", label: "Cursos", val: cursos.length },
                    { emoji: "🎓", label: "Aulas", val: aulas.length },
                  ].map((k, i) => (
                    <div key={i} style={{ background: "#fff", borderRadius: 12, padding: "14px 16px", border: "1px solid #E8ECF0", textAlign: "center" }}>
                      <div style={{ fontSize: 24, marginBottom: 6 }}>{k.emoji}</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#170073" }}>{k.val}</div>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>{k.label}</div>
                    </div>
                  ))}
                  </div>
                  <Link to="/admin-financeiro" style={{ background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", border: "none", borderRadius: 10, padding: "10px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer", whiteSpace: "nowrap", textDecoration: "none", display: "inline-block" }}>➕ Adicionar Aulas</Link>
                </div>

                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C", marginBottom: 8 }}>
                  📚 Cursos ({cursos.length})
                </div>

                {cursos.length === 0 ? (
                  <div style={{ textAlign: "center", padding: 40, color: "#57636C", background: "#fff", borderRadius: 12, border: "1px solid #E8ECF0" }}>
                    <div style={{ fontSize: 36, marginBottom: 8 }}>📚</div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>Nenhum curso criado ainda</div>
                  </div>
                ) : (
                  cursos.map(c => (
                    <div key={c.id} style={{ background: "#fff", borderRadius: 12, padding: "12px 14px", marginBottom: 8, border: "1px solid #E8ECF0" }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213" }}>
                        {c.titulo}
                      </div>
                      <div style={{ fontSize: 11, color: "#57636C", marginTop: 4 }}>
                        {c.descricao}
                      </div>
                      <div style={{ fontSize: 10, color: "#BDBDBD", marginTop: 6 }}>
                        {new Date(c.created_date).toLocaleDateString("pt-BR")}
                      </div>
                    </div>
                  ))
                )}

                {aulas.length > 0 && (
                  <div style={{ marginTop: 20 }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C", marginBottom: 8 }}>
                      🎓 Aulas ({aulas.length})
                    </div>
                    {aulas.slice(0, 10).map(aula => (
                      <div key={aula.id} style={{ background: "#fff", borderRadius: 12, padding: "10px 14px", marginBottom: 6, border: "1px solid #E8ECF0" }}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213" }}>
                          {aula.titulo}
                        </div>
                        <div style={{ fontSize: 10, color: "#57636C", marginTop: 2 }}>
                          {aula.descricao}
                        </div>
                        <div style={{ fontSize: 9, color: "#BDBDBD", marginTop: 4 }}>
                          ⏱️ {aula.duracao_minutos}min
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ===== PLANOS GRATUITOS ===== */}
            {aba === "Planos Gratuitos" && (
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>
                    🎁 {planosGratuitos.length} planos concedidos
                  </div>
                  <button onClick={() => setModalPlano(true)}
                    style={{ background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", border: "none", borderRadius: 10, padding: "8px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
                    + Conceder Plano
                  </button>
                </div>

                {planosGratuitos.length === 0 ? (
                  <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>
                    <div style={{ fontSize: 36, marginBottom: 8 }}>🎁</div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700 }}>Nenhum plano gratuito concedido ainda</div>
                  </div>
                ) : planosGratuitos.map((p, i) => (
                  <div key={i} style={{ background: "#fff", borderRadius: 12, padding: "12px 14px", marginBottom: 8, border: "1px solid #E8ECF0" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                      <div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213" }}>{p.usuario_email}</div>
                        {p.usuario_nome && <div style={{ fontSize: 11, color: "#57636C" }}>{p.usuario_nome}</div>}
                        <div style={{ fontSize: 11, color: "#57636C", marginTop: 2 }}>
                          Concedido por: <strong>{p.admin_nome || p.admin_email}</strong>
                        </div>
                        <div style={{ fontSize: 10, color: "#57636C" }}>Motivo: {p.motivo || "—"}</div>
                        {p.validade && <div style={{ fontSize: 10, color: "#F0A500", fontWeight: 700 }}>Válido até: {p.validade}</div>}
                      </div>
                      <div style={{ fontSize: 12, fontWeight: 900, background: "#170073", color: "#fff", borderRadius: 10, padding: "4px 12px" }}>
                        {p.plano}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== USUÁRIOS ===== */}
            {aba === "Usuários" && (
              <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "#57636C" }}>{totalUsuarios} usuários cadastrados</div>
                  <button onClick={() => setModalCargo(true)}
                    style={{ background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", border: "none", borderRadius: 10, padding: "8px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
                    + Atribuir Cargo
                  </button>
                </div>
                {usuarios.map(u => (
                  <div key={u.id} style={{ background: "#fff", borderRadius: 12, padding: "12px 14px", marginBottom: 6, border: "1px solid #E8ECF0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213" }}>{u.full_name || "—"}</div>
                      <div style={{ fontSize: 11, color: "#57636C" }}>{u.email}</div>
                    </div>
                    <div style={{ textAlign: "right", display: "flex", alignItems: "center", gap: 10 }}>
                      <div>
                        <div style={{ fontSize: 10, fontWeight: 800, borderRadius: 8, padding: "3px 8px",
                          background: (u.role === "admin" || u.role === "master_admin") ? "#FFF8E1" : "#F1F4F8",
                          color: (u.role === "admin" || u.role === "master_admin") ? "#F0A500" : "#57636C" }}>
                          {u.role || "user"}
                        </div>
                        {u.plano && <div style={{ fontSize: 10, color: "#170073", fontWeight: 700, marginTop: 4 }}>{u.plano}</div>}
                      </div>
                      <button onClick={() => {
                        setCargoForm({ usuario_id: u.id, usuario_email: u.email, novo_cargo: u.role || "user" });
                        setModalCargo(true);
                      }}
                        style={{ background: "rgba(23,0,115,.1)", color: "#170073", border: "1px solid #E8ECF0", borderRadius: 8, padding: "4px 10px", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                        ✏️ Editar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* ===== CONFIGURAÇÕES ===== */}
            {aba === "Configurações" && (
              <div>
                <ConfigurarNyxpay user={user} />
              </div>
            )}

            {/* ===== SÓCIOS ===== */}
            {aba === "Sócios" && (
              <div>
                {/* Info taxas */}
                <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", borderRadius: 16, padding: "16px 20px", color: "#fff", marginBottom: 14 }}>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, marginBottom: 8 }}>💼 Estrutura de Divisão</div>
                  {[
                    { icone: "🔨", label: "Leilão",      base: fmt(taxaAdminLeilao),  desc: `10% de ${fmt(totalLeiloesArrecadado)} + R$0,38/tx` },
                    { icone: "🎰", label: "Rifa",        base: "—",                    desc: "10% de arrecadado + R$0,38/tx" },
                    { icone: "💳", label: "Mensalidades", base: "—",                    desc: "100% dividido entre os sócios" },
                  ].map((t, i) => (
                    <div key={i} style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: 11 }}>
                      <span>{t.icone} {t.label}: <span style={{ opacity: .8 }}>{t.desc}</span></span>
                      <strong>{t.base}</strong>
                    </div>
                  ))}
                </div>

                {/* Cards sócios */}
                {SOCIOS.map((s, i) => (
                  <div key={i} style={{ background: "#fff", borderRadius: 14, padding: "16px 18px", marginBottom: 10, border: "1px solid #E8ECF0" }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                        <div style={{ width: 44, height: 44, borderRadius: "50%", background: "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Montserrat,sans-serif", fontSize: 20, fontWeight: 900, color: "#fff" }}>
                          {s.nome[0]}
                        </div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 15, fontWeight: 900, color: "#101213" }}>{s.nome}</div>
                      </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
                      {[
                        { label: "🔨 Leilão",      pct: s.pct_leilao,      base: taxaAdminLeilao },
                        { label: "🎰 Rifa",         pct: s.pct_rifa,        base: 0 },
                        { label: "💳 Mensalidades", pct: s.pct_mensalidade, base: 0 },
                      ].map((k, j) => (
                        <div key={j} style={{ background: "#F8FAFC", borderRadius: 10, padding: "8px 10px", textAlign: "center" }}>
                          <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700, marginBottom: 2 }}>{k.label}</div>
                          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>{k.pct}%</div>
                          {k.base > 0 && <div style={{ fontSize: 9, color: "#2E7D32", fontWeight: 700 }}>{fmt(k.base * k.pct / 100)}</div>}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}

                <div style={{ background: "#F8FAFC", borderRadius: 12, padding: "12px 16px", border: "1px dashed #E8ECF0", textAlign: "center", marginTop: 4 }}>
                  <div style={{ fontSize: 11, color: "#57636C", fontWeight: 700 }}>
                    👑 Master Admin — Acesso geral a todos os dados, sem participação nos lucros
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Modal Atribuir Cargo */}
      {modalCargo && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
          onClick={e => e.target === e.currentTarget && setModalCargo(false)}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>👤 Atribuir Cargo</div>
              <button onClick={() => setModalCargo(false)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            <div style={{ display: "grid", gap: 12, marginBottom: 16 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Usuário</label>
                <div style={{ padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", background: "#F8FAFC", fontSize: 13, color: "#101213", fontWeight: 600 }}>
                  {cargoForm.usuario_email}
                </div>
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Novo Cargo</label>
                <div style={{ display: "flex", gap: 8, flexDirection: "column" }}>
                  {["user", "admin", "master_admin"].map(r => (
                    <button key={r} onClick={() => setCargoForm(f => ({ ...f, novo_cargo: r }))}
                      style={{ padding: "12px", borderRadius: 10, cursor: "pointer", fontSize: 12, fontWeight: 700, fontFamily: "Montserrat,sans-serif",
                        border: `1.5px solid ${cargoForm.novo_cargo === r ? "#170073" : "#E8ECF0"}`,
                        background: cargoForm.novo_cargo === r ? "#170073" : "#fff",
                        color: cargoForm.novo_cargo === r ? "#fff" : "#57636C",
                        textAlign: "left" }}>
                      {r === "user" && "👤 Usuário (sem permissões)"}                      {r === "admin" && "🔑 Admin (gerenciar planos, cargos, dados)"}
                      {r === "master_admin" && "👑 Master Admin (acesso total)"}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button onClick={atribuirCargo} disabled={salvandoCargo}
              style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", cursor: salvandoCargo ? "default" : "pointer",
                background: salvandoCargo ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff",
                fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
              {salvandoCargo ? "Salvando..." : "✅ Atribuir Cargo"}
            </button>
          </div>
        </div>
      )}

      {/* Modal Conceder Plano */}
      {modalPlano && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}
          onClick={e => e.target === e.currentTarget && setModalPlano(false)}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>🎁 Conceder Plano Gratuito</div>
              <button onClick={() => setModalPlano(false)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "#57636C" }}>✕</button>
            </div>

            <div style={{ display: "grid", gap: 12 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>E-mail do usuário *</label>
                <input type="email" value={planoForm.usuario_email} placeholder="email@exemplo.com"
                  onChange={e => setPlanoForm(p => ({ ...p, usuario_email: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Plano</label>
                <div style={{ display: "flex", gap: 8 }}>
                  {["standard", "gold", "premium"].map(p => (
                    <button key={p} onClick={() => setPlanoForm(f => ({ ...f, plano: p }))}
                      style={{ flex: 1, padding: "8px", borderRadius: 10, cursor: "pointer", fontSize: 12, fontWeight: 800, fontFamily: "Montserrat,sans-serif",
                        border: `1.5px solid ${planoForm.plano === p ? "#170073" : "#E8ECF0"}`,
                        background: planoForm.plano === p ? "#170073" : "#fff",
                        color: planoForm.plano === p ? "#fff" : "#57636C" }}>
                      {p.charAt(0).toUpperCase() + p.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Motivo</label>
                <input type="text" value={planoForm.motivo} placeholder="Ex: Influenciador, parceiro..."
                  onChange={e => setPlanoForm(p => ({ ...p, motivo: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
              </div>

              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Válido até (opcional)</label>
                <input type="date" value={planoForm.validade}
                  onChange={e => setPlanoForm(p => ({ ...p, validade: e.target.value }))}
                  style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
              </div>
            </div>

            <button onClick={concederPlano} disabled={salvandoPlano || !planoForm.usuario_email}
              style={{ width: "100%", padding: "14px", borderRadius: 12, border: "none", marginTop: 16, cursor: salvandoPlano ? "default" : "pointer",
                background: salvandoPlano ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff",
                fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
              {salvandoPlano ? "Salvando..." : "✅ Conceder Plano"}
            </button>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}