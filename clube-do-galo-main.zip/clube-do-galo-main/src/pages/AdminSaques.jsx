import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

export default function AdminSaques() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [saques, setSaques] = useState([]);
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [modalRecusa, setModalRecusa] = useState(null);
  const [motivoRecusa, setMotivoRecusa] = useState("");
  const [processando, setProcessando] = useState(null);
  const [filtro, setFiltro] = useState("pendente");

  useEffect(() => {
    base44.auth.me().then(u => {
      if (u?.role !== "admin" && u?.role !== "master_admin") { navigate("/"); return; }
      setUser(u);
      carregar();
    });
  }, []);

  const carregar = async () => {
    setLoading(true);
    const [s, c] = await Promise.all([
      base44.entities.Saque.list("-created_date", 100),
      base44.entities.GatewayConfig.list("-created_date", 1),
    ]);
    setSaques(s);
    setConfig(c[0] || null);
    setLoading(false);
  };

  const toggleModoSaque = async () => {
    if (!config) return;
    const novoModo = config.modo_saque === "automatico" ? "manual" : "automatico";
    await base44.entities.GatewayConfig.update(config.id, { modo_saque: novoModo });
    setConfig(c => ({ ...c, modo_saque: novoModo }));
    toast.success(`Modo alterado para: ${novoModo}`);
  };

  const aprovar = async (saque) => {
    setProcessando(saque.id);
    await base44.entities.Saque.update(saque.id, {
      status: "processando",
      data_conclusao: new Date().toISOString(),
    });
    toast.success(`Saque de R$ ${saque.valor.toFixed(2)} aprovado!`);
    await carregar();
    setProcessando(null);
  };

  const recusar = async () => {
    if (!motivoRecusa.trim()) { toast.error("Informe o motivo da recusa."); return; }
    setProcessando(modalRecusa.id);
    await base44.entities.Saque.update(modalRecusa.id, {
      status: "cancelado",
      motivo_cancelamento: motivoRecusa,
      data_conclusao: new Date().toISOString(),
    });
    toast.success("Saque recusado. Saldo devolvido ao usuário.");
    setModalRecusa(null);
    setMotivoRecusa("");
    await carregar();
    setProcessando(null);
  };

  const saquesFiltrados = saques.filter(s => filtro === "todos" ? true : s.status === filtro);

  const statusCfg = {
    pendente:    { label: "Pendente",    bg: "#FFF8E1", color: "#F0A500", border: "#F0A500" },
    processando: { label: "Aprovado",    bg: "#E8F5E9", color: "#2E7D32", border: "#2E7D32" },
    concluido:   { label: "Concluído",   bg: "#E3F2FD", color: "#1565C0", border: "#1565C0" },
    cancelado:   { label: "Recusado",    bg: "#FFEBEE", color: "#C62828", border: "#C62828" },
    falha:       { label: "Falha",       bg: "#FFEBEE", color: "#C62828", border: "#C62828" },
  };

  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "hsl(var(--background))" }}>
      <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "hsl(var(--background))", color: "hsl(var(--foreground))", fontFamily: "'DM Sans', -apple-system, sans-serif" }}>

      {/* Header */}
      <div style={{ position: "sticky", top: 0, background: "hsl(var(--background))", borderBottom: "1px solid hsl(var(--border))", padding: "14px 20px", display: "flex", alignItems: "center", gap: 12, zIndex: 10 }}>
        <button onClick={() => navigate(-1)} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: "hsl(var(--foreground))", minWidth: 44, minHeight: 44, display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900 }}>Gestão de Saques</div>
          <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))" }}>Painel do Administrador</div>
        </div>
      </div>

      <div style={{ padding: "16px", maxWidth: 600, margin: "0 auto", paddingBottom: 100 }}>

        {/* Toggle de Modo */}
        <div style={{ background: "hsl(var(--muted))", borderRadius: 14, padding: 16, marginBottom: 16, border: "1px solid hsl(var(--border))" }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", marginBottom: 12 }}>Modo de Processamento</div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: config?.modo_saque === "automatico" ? "#2E7D32" : "#F0A500" }}>
                {config?.modo_saque === "automatico" ? "🤖 Automático" : "✋ Manual"}
              </div>
              <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", marginTop: 2 }}>
                {config?.modo_saque === "automatico"
                  ? "Saques processados automaticamente"
                  : "Saques requerem aprovação do admin"}
              </div>
            </div>
            <button onClick={toggleModoSaque}
              style={{ padding: "8px 16px", borderRadius: 20, border: "none", background: config?.modo_saque === "automatico" ? "#E8F5E9" : "#FFF8E1", color: config?.modo_saque === "automatico" ? "#2E7D32" : "#F0A500", fontWeight: 700, fontSize: 12, cursor: "pointer" }}>
              Alternar
            </button>
          </div>
        </div>

        {/* Estatísticas */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 16 }}>
          {[
            { label: "Pendentes", count: saques.filter(s => s.status === "pendente").length, color: "#F0A500" },
            { label: "Aprovados", count: saques.filter(s => s.status === "processando" || s.status === "concluido").length, color: "#2E7D32" },
            { label: "Recusados", count: saques.filter(s => s.status === "cancelado").length, color: "#C62828" },
          ].map(stat => (
            <div key={stat.label} style={{ background: "hsl(var(--muted))", borderRadius: 12, padding: "12px 10px", textAlign: "center", border: "1px solid hsl(var(--border))" }}>
              <div style={{ fontSize: 22, fontWeight: 900, color: stat.color }}>{stat.count}</div>
              <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginTop: 2 }}>{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Filtros */}
        <div style={{ display: "flex", gap: 8, marginBottom: 14, overflowX: "auto", paddingBottom: 4 }}>
          {[["pendente","Pendentes"],["processando","Aprovados"],["cancelado","Recusados"],["todos","Todos"]].map(([k, label]) => (
            <button key={k} onClick={() => setFiltro(k)}
              style={{ flexShrink: 0, padding: "6px 14px", borderRadius: 20, border: "none", background: filtro === k ? "hsl(var(--primary))" : "hsl(var(--muted))", color: filtro === k ? "hsl(var(--primary-foreground))" : "hsl(var(--muted-foreground))", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
              {label}
            </button>
          ))}
        </div>

        {/* Lista de Saques */}
        {saquesFiltrados.length === 0 ? (
          <div style={{ textAlign: "center", padding: 40, color: "hsl(var(--muted-foreground))", fontSize: 13 }}>
            Nenhuma solicitação encontrada
          </div>
        ) : (
          <div style={{ display: "grid", gap: 10 }}>
            {saquesFiltrados.map(saque => {
              const cfg = statusCfg[saque.status] || statusCfg.pendente;
              return (
                <div key={saque.id} style={{ background: "hsl(var(--card))", borderRadius: 14, padding: 16, border: "1px solid hsl(var(--border))" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>{saque.usuario_nome || saque.usuario_email}</div>
                      <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", marginTop: 2 }}>{saque.usuario_email}</div>
                    </div>
                    <span style={{ padding: "4px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}` }}>
                      {cfg.label}
                    </span>
                  </div>

                  <div style={{ display: "flex", gap: 12, marginBottom: 10 }}>
                    <div style={{ background: "hsl(var(--muted))", padding: "8px 12px", borderRadius: 10, flex: 1 }}>
                      <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))" }}>VALOR</div>
                      <div style={{ fontWeight: 900, fontSize: 16, color: "#2E7D32" }}>R$ {(saque.valor || 0).toFixed(2)}</div>
                    </div>
                    <div style={{ background: "hsl(var(--muted))", padding: "8px 12px", borderRadius: 10, flex: 1 }}>
                      <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))" }}>PIX ({saque.pix_tipo})</div>
                      <div style={{ fontWeight: 700, fontSize: 12, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{saque.pix_chave}</div>
                    </div>
                  </div>

                  {saque.motivo_cancelamento && (
                    <div style={{ background: "#FFEBEE", padding: "8px 12px", borderRadius: 8, fontSize: 11, color: "#C62828", marginBottom: 10 }}>
                      Motivo: {saque.motivo_cancelamento}
                    </div>
                  )}

                  <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginBottom: saque.status === "pendente" ? 12 : 0 }}>
                    Solicitado: {saque.data_solicitacao ? new Date(saque.data_solicitacao).toLocaleString("pt-BR") : new Date(saque.created_date).toLocaleString("pt-BR")}
                  </div>

                  {saque.status === "pendente" && (
                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => aprovar(saque)} disabled={processando === saque.id}
                        style={{ flex: 1, padding: "10px", borderRadius: 10, border: "none", background: "#2E7D32", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
                        {processando === saque.id ? "..." : "✓ Aprovar"}
                      </button>
                      <button onClick={() => { setModalRecusa(saque); setMotivoRecusa(""); }} disabled={processando === saque.id}
                        style={{ flex: 1, padding: "10px", borderRadius: 10, border: "none", background: "#C62828", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
                        ✕ Recusar
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal de Recusa */}
      {modalRecusa && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 9000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
          <div style={{ background: "hsl(var(--background))", borderRadius: "20px 20px 0 0", padding: 24, width: "100%", maxWidth: 500 }}>
            <div style={{ fontWeight: 900, fontSize: 16, marginBottom: 8, fontFamily: "Montserrat,sans-serif" }}>Recusar Saque</div>
            <div style={{ fontSize: 13, color: "hsl(var(--muted-foreground))", marginBottom: 16 }}>
              Informe o motivo da recusa. O saldo será devolvido ao usuário.
            </div>
            <textarea
              value={motivoRecusa}
              onChange={e => setMotivoRecusa(e.target.value)}
              placeholder="Ex: Chave PIX inválida, documento pendente..."
              style={{ width: "100%", padding: "12px 14px", borderRadius: 10, border: "1.5px solid hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))", fontSize: 13, outline: "none", resize: "none", boxSizing: "border-box", minHeight: 80 }}
            />
            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
              <button onClick={() => setModalRecusa(null)}
                style={{ flex: 1, padding: "12px", borderRadius: 10, border: "1px solid hsl(var(--border))", background: "transparent", color: "hsl(var(--foreground))", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
                Cancelar
              </button>
              <button onClick={recusar} disabled={processando}
                style={{ flex: 1, padding: "12px", borderRadius: 10, border: "none", background: "#C62828", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
                Confirmar Recusa
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}