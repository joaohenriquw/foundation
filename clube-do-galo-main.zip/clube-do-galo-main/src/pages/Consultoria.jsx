import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import PlanoGuard from "../components/PlanoGuard";
import NotificacoesSino from "../components/NotificacoesSino";
import { getPlano, getPlanoBundles } from "../lib/planos";
import BottomNav from "../components/BottomNav";

const ESPECIALIDADES = [
  { id: "advogado_civil",    emoji: "⚖️", titulo: "Advogado Civil",          desc: "Contratos, compra e venda, direitos do consumidor, litígios",  cor: "#170073" },
  { id: "advogado_criminal", emoji: "🔒", titulo: "Advogado Criminal",       desc: "Defesa criminal, crimes ambientais, maus-tratos, apreensões",  cor: "#C62828" },
  { id: "veterinario",       emoji: "🩺", titulo: "Consultoria Veterinária", desc: "Sanidade, medicamentos, criação, doenças aviárias",             cor: "#2E7D32" },
];

export default function Consultoria() {
  const [user, setUser]         = useState(null);
  const [userMeta, setUserMeta] = useState(null);
  const navigate = useNavigate();
  const [mostraModalUpgrade, setMostraModalUpgrade] = useState(false);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      if (me) {
        const users = await base44.entities.User.filter({ email: me.email });
        setUserMeta(users[0] || null);
      }
    };
    init();
  }, []);

  const planoBundles = getPlanoBundles(userMeta?.role, userMeta?.plano);
  const plano     = getPlano(planoBundles);
  const isPremium = plano.pode_consultoria;

  const abrirChat = async (tipo) => {
    if (!user) return;
    
    const profissionaisMap = {
      advogado_civil: { nome: "Advogado Civil", email: "civil@consultoria.local" },
      advogado_criminal: { nome: "Advogado Criminal", email: "criminal@consultoria.local" },
      veterinario: { nome: "Consultoria Veterinária", email: "vet@consultoria.local" }
    };
    
    const prof = profissionaisMap[tipo];
    
    try {
      const conversas = await base44.entities.ChatConversa.filter({
        usuario_email: user.email,
        tipo: tipo
      });
      
      if (conversas.length > 0) {
        // Conversa existe, abrir direto
        const conversa = conversas[0];
        navigate(`/chat?conversaId=${conversa.id}&tipo=${tipo}`);
      } else {
        // Criar nova conversa
        const novaConversa = await base44.entities.ChatConversa.create({
          usuario_id: user.id,
          usuario_nome: user.full_name,
          usuario_email: user.email,
          profissional_nome: prof.nome,
          profissional_email: prof.email,
          tipo: tipo,
          status: "aguardando",
          ultima_mensagem: "",
          ultima_mensagem_data: new Date().toISOString()
        });
        
        navigate(`/chat?conversaId=${novaConversa.id}&tipo=${tipo}`);
      }
    } catch (err) {
      console.error(err);
      navigate(`/chat?tipo=${tipo}`);
    }
  };

  const fazerUpgrade = () => {
    navigate("/planos");
  };

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 80, color: "#fff" }}>
      <div style={{ background: "#0A0A0A", padding: "52px 20px 16px", borderBottom: "1px solid #1C1C1E" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#00C9B8" }}>Consultorias</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Exclusivo Plano Premium · Chat ao vivo</div>
            </div>
          </div>
          {user && <NotificacoesSino userEmail={user.email} />}
        </div>
      </div>

      <div style={{ padding: "20px 16px 40px", maxWidth: 600, margin: "0 auto" }}>
        <div style={{ marginBottom: 20 }}>
          {ESPECIALIDADES.map(esp => (
            <PlanoGuard key={esp.id} planoUsuario={planoBundles} planoMinimo="premium"
              mensagem="A consultoria especializada é exclusiva para assinantes do plano ">
              <div
                onClick={() => isPremium && abrirChat(esp.id)}
                style={{ background: "#1C1C1E", borderRadius: 14, border: `1px solid ${isPremium ? "#333" : "#222"}`, padding: "16px", marginBottom: 12, cursor: isPremium ? "pointer" : "default", transition: ".2s" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div style={{ width: 52, height: 52, borderRadius: 14, background: esp.cor + "15", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, flexShrink: 0 }}>
                    {esp.emoji}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff", marginBottom: 2 }}>
                      {esp.titulo} {!isPremium && "🔒"}
                    </div>
                    <div style={{ fontSize: 12, color: "#888" }}>{esp.desc}</div>
                  </div>
                  {isPremium && (
                    <div style={{ background: esp.cor, color: "#fff", borderRadius: 10, padding: "6px 12px", fontSize: 12, fontWeight: 800, fontFamily: "Montserrat,sans-serif", whiteSpace: "nowrap" }}>
                      💬 Chat
                    </div>
                  )}
                </div>
              </div>
            </PlanoGuard>
          ))}
        </div>

        {!isPremium && (
          <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", borderRadius: 14, padding: 20, textAlign: "center", color: "#fff" }}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>👑</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 15, fontWeight: 900, marginBottom: 6 }}>Faça upgrade para Premium</div>
            <div style={{ fontSize: 12, opacity: .85, marginBottom: 14 }}>R$ 69,90/mês ou R$ 598,90/ano · Advogados civil, criminal e veterinário por chat ao vivo</div>
            <button onClick={fazerUpgrade} style={{
              width: "100%",
              padding: "12px",
              borderRadius: 12,
              border: "none",
              background: "#fff",
              color: "#170073",
              cursor: "pointer",
              fontFamily: "Montserrat,sans-serif",
              fontSize: 14,
              fontWeight: 900,
            }}>🚀 Fazer Upgrade de Plano</button>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}