import { useState } from "react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend
} from "recharts";

const SOCIOS = {
  jeder:  { nome: "Jeder",  pct: 50, cor: "#170073" },
  joao:   { nome: "João",   pct: 20, cor: "#00A893" },
  alvaro: { nome: "Álvaro", pct: 20, cor: "#F0A500" },
  lucas:  { nome: "Lucas",  pct: 10, cor: "#E21C3D" },
};

const RECEITA_MENSAL = [
  { mes: "Nov/25", leilao: 4200, rifa: 1800, assinaturas: 3100 },
  { mes: "Dez/25", leilao: 6800, rifa: 2400, assinaturas: 3400 },
  { mes: "Jan/26", leilao: 5100, rifa: 3200, assinaturas: 3700 },
  { mes: "Fev/26", leilao: 7300, rifa: 2900, assinaturas: 4100 },
  { mes: "Mar/26", leilao: 9200, rifa: 4100, assinaturas: 4500 },
  { mes: "Abr/26", leilao: 8400, rifa: 3600, assinaturas: 4800 },
];

const TRANSACOES = [
  { id: "TXN-001", tipo: "Leilão", desc: "Clube do Galo Linha Pura", valor: 1200.00, taxa: 120.00, data: "02/04/2026", status: "approved", gateway: "nyxpay" },
  { id: "TXN-002", tipo: "Rifa",   desc: "Trio Nacional 2025 · 3x bilhetes", valor: 75.00,   taxa: 7.50,   data: "01/04/2026", status: "approved", gateway: "nyxpay" },
  { id: "TXN-003", tipo: "Rifa",   desc: "Galo Faraó + Fêmeas · 1x bilhete", valor: 50.00,   taxa: 5.00,   data: "01/04/2026", status: "approved", gateway: "nyxpay" },
  { id: "TXN-004", tipo: "Assinatura", desc: "Premium — João da Silva", valor: 69.90,  taxa: 6.99,   data: "31/03/2026", status: "approved", gateway: "nyxpay" },
  { id: "TXN-005", tipo: "Leilão", desc: "Trio Campeão RS 2024 · Parcela 1", valor: 2000.00, taxa: 200.00, data: "20/03/2026", status: "approved", gateway: "nyxpay" },
  { id: "TXN-006", tipo: "Assinatura", desc: "Gold — Pedro Costa", valor: 49.90,  taxa: 4.99,   data: "18/03/2026", status: "approved", gateway: "nyxpay" },
  { id: "TXN-007", tipo: "Rifa",   desc: "Trio Nacional 2025 · 2x bilhetes", valor: 50.00,   taxa: 5.00,   data: "15/03/2026", status: "rejected", gateway: "nyxpay" },
  { id: "TXN-008", tipo: "Leilão", desc: "Guerreiro MG-001 — Venda direta", valor: 1500.00, taxa: 150.00, data: "10/03/2026", status: "approved", gateway: "nyxpay" },
];

const totalReceitaMes = RECEITA_MENSAL[RECEITA_MENSAL.length - 1];
const receitaTotal = totalReceitaMes.leilao + totalReceitaMes.rifa + totalReceitaMes.assinaturas;
const taxasTotal = TRANSACOES.filter(t => t.status === "approved").reduce((s, t) => s + t.taxa, 0);

const PIE_DATA = Object.entries(SOCIOS).map(([, s]) => ({
  name: s.nome,
  value: Math.round(taxasTotal * s.pct / 100 * 100) / 100,
  cor: s.cor,
}));

const TIPO_COR = { Leilão: "#170073", Rifa: "#E21C3D", Assinatura: "#00A893" };
const STATUS_STYLE = {
  approved: { bg: "#E6F9F0", color: "#04A24C", label: "Aprovado" },
  rejected: { bg: "#FEE2E2", color: "#E21C3D", label: "Recusado" },
};

const fmt = (v) => "R$ " + v.toFixed(2).replace(".", ",");

export default function FinanceiroDashboard() {
  const [tab, setTab] = useState("visao-geral");
  const [socioFiltro, setSocioFiltro] = useState("todos");
  const [tipoFiltro, setTipoFiltro] = useState("todos");

  const txFiltradas = TRANSACOES.filter(t => {
    if (tipoFiltro !== "todos" && t.tipo !== tipoFiltro) return false;
    return true;
  });

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px 24px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 4 }}>
          <a href="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</a>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>Dashboard Financeiro</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Clube do Galo · Sócios · Abril 2026</div>
          </div>
        </div>
        {/* Tabs */}
        <div style={{ display: "flex", gap: 6, marginTop: 14, overflowX: "auto" }}>
          {[
            { id: "visao-geral", label: "Visão Geral" },
            { id: "comissoes", label: "Comissões" },
            { id: "transacoes", label: "Transações" },
          ].map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              style={{ padding: "7px 16px", borderRadius: 20, border: "none", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap", transition: ".2s",
                background: tab === t.id ? "#fff" : "rgba(255,255,255,.15)",
                color: tab === t.id ? "#170073" : "#fff" }}>
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 900, margin: "0 auto" }}>

        {/* ── VISÃO GERAL ── */}
        {tab === "visao-geral" && (
          <>
            {/* KPI Cards */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 10, marginBottom: 16 }}>
              {[
                { label: "Receita Abr/26", val: fmt(receitaTotal), sub: "Leilões + Rifas + Assin.", cor: "#170073" },
                { label: "Taxas Arrecadadas", val: fmt(taxasTotal), sub: "10% das transações", cor: "#00A893" },
                { label: "Transações Aprovadas", val: TRANSACOES.filter(t=>t.status==="approved").length, sub: "Este mês", cor: "#F0A500" },
                { label: "Ticket Médio", val: fmt(TRANSACOES.filter(t=>t.status==="approved").reduce((s,t)=>s+t.valor,0)/TRANSACOES.filter(t=>t.status==="approved").length), sub: "Por transação", cor: "#8B5CF6" },
              ].map((k, i) => (
                <div key={i} style={{ background: "#fff", borderRadius: 14, padding: "14px 16px", border: "1px solid #E8ECF0" }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: .5, marginBottom: 4 }}>{k.label}</div>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 20, fontWeight: 900, color: k.cor }}>{k.val}</div>
                  <div style={{ fontSize: 10, color: "#57636C", marginTop: 2 }}>{k.sub}</div>
                </div>
              ))}
            </div>

            {/* Gráfico Receita */}
            <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213", marginBottom: 14 }}>📈 Receita Mensal</div>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={RECEITA_MENSAL} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="gl" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#170073" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#170073" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="gr" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#E21C3D" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#E21C3D" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="ga" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00A893" stopOpacity={0.15}/>
                      <stop offset="95%" stopColor="#00A893" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                  <XAxis dataKey="mes" tick={{ fontSize: 10, fill: "#57636C" }}/>
                  <YAxis tick={{ fontSize: 10, fill: "#57636C" }} tickFormatter={v => "R$"+v/1000+"k"}/>
                  <Tooltip formatter={(v, n) => [fmt(v), n === "leilao" ? "Leilão" : n === "rifa" ? "Rifa" : "Assinaturas"]}/>
                  <Area type="monotone" dataKey="leilao" stroke="#170073" strokeWidth={2} fill="url(#gl)"/>
                  <Area type="monotone" dataKey="rifa" stroke="#E21C3D" strokeWidth={2} fill="url(#gr)"/>
                  <Area type="monotone" dataKey="assinaturas" stroke="#00A893" strokeWidth={2} fill="url(#ga)"/>
                </AreaChart>
              </ResponsiveContainer>
              <div style={{ display: "flex", gap: 16, marginTop: 8, justifyContent: "center" }}>
                {[["#170073","Leilão"],["#E21C3D","Rifa"],["#00A893","Assinaturas"]].map(([cor,label])=>(
                  <div key={label} style={{ display:"flex", alignItems:"center", gap:5, fontSize:11, color:"#57636C" }}>
                    <div style={{ width:10, height:10, borderRadius:2, background:cor }}></div>{label}
                  </div>
                ))}
              </div>
            </div>

            {/* Barra mensal por tipo */}
            <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: "16px" }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213", marginBottom: 14 }}>📊 Receita por Categoria</div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={RECEITA_MENSAL.slice(-3)} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
                  <XAxis dataKey="mes" tick={{ fontSize: 10, fill: "#57636C" }}/>
                  <YAxis tick={{ fontSize: 10, fill: "#57636C" }} tickFormatter={v => "R$"+v/1000+"k"}/>
                  <Tooltip formatter={(v, n) => [fmt(v), n === "leilao" ? "Leilão" : n === "rifa" ? "Rifa" : "Assinaturas"]}/>
                  <Bar dataKey="leilao" fill="#170073" radius={[4,4,0,0]}/>
                  <Bar dataKey="rifa" fill="#E21C3D" radius={[4,4,0,0]}/>
                  <Bar dataKey="assinaturas" fill="#00A893" radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </>
        )}

        {/* ── COMISSÕES ── */}
        {tab === "comissoes" && (
          <>
            {/* Filtro sócio */}
            <div style={{ display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap" }}>
              {[["todos","Todos os Sócios"], ...Object.entries(SOCIOS).map(([k,s])=>[k,s.nome])].map(([k,label])=>(
                <button key={k} onClick={() => setSocioFiltro(k)}
                  style={{ padding: "6px 14px", borderRadius: 20, border: "1.5px solid", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 700, transition: ".2s",
                    borderColor: socioFiltro === k ? "#170073" : "#E8ECF0",
                    background: socioFiltro === k ? "#170073" : "#fff",
                    color: socioFiltro === k ? "#fff" : "#57636C" }}>
                  {label}
                </button>
              ))}
            </div>

            {/* Pizza distribuição */}
            <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", padding: 16, marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213", marginBottom: 10 }}>🥧 Distribuição de Taxas — Abr/26</div>
              <div style={{ display: "flex", alignItems: "center", gap: 0, flexWrap: "wrap" }}>
                <ResponsiveContainer width="50%" height={180}>
                  <PieChart>
                    <Pie data={PIE_DATA} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={3}>
                      {PIE_DATA.map((entry, i) => <Cell key={i} fill={entry.cor}/>)}
                    </Pie>
                    <Tooltip formatter={(v) => fmt(v)}/>
                  </PieChart>
                </ResponsiveContainer>
                <div style={{ flex: 1, padding: "0 8px" }}>
                  {PIE_DATA.map((s, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "6px 0", borderBottom: i < PIE_DATA.length-1 ? "1px solid #F8FAFC" : "none" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <div style={{ width: 10, height: 10, borderRadius: "50%", background: s.cor, flexShrink: 0 }}></div>
                        <div>
                          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 700, color: "#101213" }}>{s.name}</div>
                          <div style={{ fontSize: 10, color: "#57636C" }}>{Object.values(SOCIOS).find(x=>x.nome===s.name)?.pct}%</div>
                        </div>
                      </div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: s.cor }}>{fmt(s.value)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Cards individuais por sócio */}
            {Object.entries(SOCIOS).filter(([k]) => socioFiltro === "todos" || socioFiltro === k).map(([key, s]) => {
              const comissaoTotal = taxasTotal * s.pct / 100;
              return (
                <div key={key} style={{ background: "#fff", borderRadius: 14, border: `2px solid ${s.cor}20`, marginBottom: 12, overflow: "hidden" }}>
                  <div style={{ background: s.cor, padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff" }}>{s.nome}</div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,.8)" }}>Participação: {s.pct}%</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 20, fontWeight: 900, color: "#fff" }}>{fmt(comissaoTotal)}</div>
                      <div style={{ fontSize: 10, color: "rgba(255,255,255,.75)" }}>Abr/26</div>
                    </div>
                  </div>
                  <div style={{ padding: "12px 16px", display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
                    {[
                      { label: "De Leilões", val: fmt(totalReceitaMes.leilao * 0.10 * s.pct / 100) },
                      { label: "De Rifas", val: fmt(totalReceitaMes.rifa * 0.10 * s.pct / 100) },
                      { label: "De Assin.", val: fmt(totalReceitaMes.assinaturas * 0.10 * s.pct / 100) },
                    ].map((item, i) => (
                      <div key={i} style={{ textAlign: "center", padding: "8px 4px", background: "#F8FAFC", borderRadius: 10 }}>
                        <div style={{ fontSize: 9, color: "#57636C", fontWeight: 700, textTransform: "uppercase", letterSpacing: .5 }}>{item.label}</div>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: s.cor, marginTop: 4 }}>{item.val}</div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </>
        )}

        {/* ── TRANSAÇÕES ── */}
        {tab === "transacoes" && (
          <>
            {/* Filtros */}
            <div style={{ display: "flex", gap: 7, marginBottom: 14, overflowX: "auto", paddingBottom: 2 }}>
              {["todos","Leilão","Rifa","Assinatura"].map(t => (
                <button key={t} onClick={() => setTipoFiltro(t)}
                  style={{ padding: "6px 14px", borderRadius: 20, border: "1.5px solid", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap", transition: ".2s",
                    borderColor: tipoFiltro === t ? "#170073" : "#E8ECF0",
                    background: tipoFiltro === t ? "#170073" : "#fff",
                    color: tipoFiltro === t ? "#fff" : "#57636C" }}>
                  {t === "todos" ? "Todos" : t}
                </button>
              ))}
            </div>

            {/* Resumo rápido */}
            <div style={{ background: "linear-gradient(135deg,#170073,#2D0EA8)", borderRadius: 14, padding: "14px 16px", marginBottom: 14, display: "flex", gap: 24 }}>
              {[
                { label: "Total Processado", val: fmt(txFiltradas.filter(t=>t.status==="approved").reduce((s,t)=>s+t.valor,0)) },
                { label: "Taxas (10%)", val: fmt(txFiltradas.filter(t=>t.status==="approved").reduce((s,t)=>s+t.taxa,0)) },
              ].map((k,i) => (
                <div key={i}>
                  <div style={{ fontSize: 10, color: "rgba(255,255,255,.7)", fontWeight: 700, textTransform: "uppercase", letterSpacing:.5, marginBottom: 3 }}>{k.label}</div>
                  <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>{k.val}</div>
                </div>
              ))}
            </div>

            {/* Lista transações */}
            <div style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", overflow: "hidden" }}>
              {txFiltradas.map((t, i) => {
                const st = STATUS_STYLE[t.status];
                const tipoCor = TIPO_COR[t.tipo] || "#57636C";
                return (
                  <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 16px", borderBottom: i < txFiltradas.length-1 ? "1px solid #F8FAFC" : "none" }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: tipoCor+"15", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>
                      {t.tipo === "Leilão" ? "🔨" : t.tipo === "Rifa" ? "🎰" : "💎"}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 700, color: "#101213", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.desc}</div>
                      <div style={{ fontSize: 10, color: "#57636C", marginTop: 2 }}>{t.id} · {t.data} · {t.gateway}</div>
                    </div>
                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#101213" }}>{fmt(t.valor)}</div>
                      <div style={{ fontSize: 10, fontWeight: 700, color: "#04A24C" }}>Taxa: {fmt(t.taxa)}</div>
                      <div style={{ fontSize: 9, fontWeight: 700, background: st.bg, color: st.color, padding: "2px 6px", borderRadius: 5, marginTop: 3, display: "inline-block" }}>{st.label}</div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Nota gateway */}
            <div style={{ background: "#E8F5E9", borderRadius: 10, padding: "10px 14px", marginTop: 14, fontSize: 11, color: "#2E7D32" }}>
              🏦 <strong>Gateway NyxPay:</strong> Dados sincronizados via API · Taxa por transação: R$ 0,38 fixo + 10% administrativa
            </div>
          </>
        )}
      </div>
    </div>
  );
}