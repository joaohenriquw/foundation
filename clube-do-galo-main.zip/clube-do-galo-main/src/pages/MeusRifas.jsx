import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import BottomNav from "../components/BottomNav";

export default function MeusRifas() {
  const [user, setUser] = useState(null);
  const [rifas, setRifas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rifaSorteio, setRifaSorteio] = useState(null);
  const [modalSorteioAberto, setModalSorteioAberto] = useState(false);
  const [numerovencedor, setNumeroVencedor] = useState("");
  const [processando, setProcessando] = useState(false);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      if (!me) { setLoading(false); return; }

      const minhasRifas = await base44.entities.Rifa.filter(
        { dono_email: me.email },
        "-created_date",
        200
      );
      setRifas(minhasRifas);
      setLoading(false);
    };
    init();

    const unsub = base44.entities.Rifa.subscribe(() => init());
    return unsub;
  }, []);

  const abrirModalSorteio = (rifa) => {
    if (rifa.ganhador_id) {
      alert("Esta rifa já foi sorteada!");
      return;
    }
    setRifaSorteio(rifa);
    setNumeroVencedor("");
    setModalSorteioAberto(true);
  };

  const realizarSorteio = async () => {
    if (!numerovencedor || !rifaSorteio) return;

    const numero = parseInt(numerovencedor);
    if (numero < 1 || numero > rifaSorteio.qtd_numeros) {
      alert(`Número deve estar entre 1 e ${rifaSorteio.qtd_numeros}`);
      return;
    }

    setProcessando(true);

    const bilhetes = await base44.entities.RifaBilhete.filter({
      rifa_id: rifaSorteio.id,
      numero: numero,
    });

    if (bilhetes.length === 0) {
      alert("Número não vendido nesta rifa!");
      setProcessando(false);
      return;
    }

    const bilheteVencedor = bilhetes[0];

    await base44.entities.Rifa.update(rifaSorteio.id, {
      ganhador_id: bilheteVencedor.comprador_id,
      ganhador_nome: bilheteVencedor.comprador_nome,
      ganhador_email: bilheteVencedor.comprador_email,
      ganhador_numero: numero,
      status: "encerrada",
    });

    await base44.entities.RifaBilhete.update(bilheteVencedor.id, { status: "pago" });

    const updated = await base44.entities.Rifa.filter({ dono_email: user.email }, "-created_date", 200);
    setRifas(updated);
    setModalSorteioAberto(false);
    setProcessando(false);
  };

  const sorteioAleatorio = async () => {
    if (!rifaSorteio) return;

    setProcessando(true);

    const bilhetes = await base44.entities.RifaBilhete.filter({
      rifa_id: rifaSorteio.id,
    });

    if (bilhetes.length === 0) {
      alert("Nenhum bilhete vendido!");
      setProcessando(false);
      return;
    }

    const indexAleatorio = Math.floor(Math.random() * bilhetes.length);
    const bilheteVencedor = bilhetes[indexAleatorio];

    await base44.entities.Rifa.update(rifaSorteio.id, {
      ganhador_id: bilheteVencedor.comprador_id,
      ganhador_nome: bilheteVencedor.comprador_nome,
      ganhador_email: bilheteVencedor.comprador_email,
      ganhador_numero: bilheteVencedor.numero,
      status: "encerrada",
    });

    await base44.entities.RifaBilhete.update(bilheteVencedor.id, { status: "pago" });

    const updated = await base44.entities.Rifa.filter({ dono_email: user.email }, "-created_date", 200);
    setRifas(updated);
    alert(`🎉 Bilhete nº ${bilheteVencedor.numero} SORTEADO! Ganhador: ${bilheteVencedor.comprador_nome}`);
    setModalSorteioAberto(false);
    setProcessando(false);
  };

  if (loading) return <div style={{ textAlign: "center", padding: 40 }}>Carregando...</div>;

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px 20px 0" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
          <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
          <div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>🎰 Minhas Rifas</div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Gerencie e sorteie suas rifas</div>
          </div>
        </div>
      </div>

      <div style={{ padding: "16px", maxWidth: 900, margin: "0 auto" }}>
        {rifas.length === 0 ? (
          <div style={{ background: "#fff", borderRadius: 14, padding: 40, textAlign: "center", border: "1px solid #E8ECF0" }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🎰</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 6 }}>Nenhuma rifa criada</div>
            <div style={{ fontSize: 12, color: "#57636C" }}>Crie sua primeira rifa para começar!</div>
          </div>
        ) : (
          <div>
            {rifas.map(r => {
              const percentualVenda = r.qtd_numeros > 0 ? ((r.numeros_vendidos || 0) / r.qtd_numeros) * 100 : 0;
              const percentualMeta = r.valor_arrecadar > 0 ? ((r.total_arrecadado || 0) / r.valor_arrecadar) * 100 : 0;
              return (
                <div key={r.id} style={{ background: "#fff", borderRadius: 14, padding: 16, marginBottom: 12, border: "1px solid #E8ECF0" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                    <div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>{r.titulo || r.animal_nome}</div>
                      <div style={{ fontSize: 12, color: "#57636C", marginTop: 2 }}>Animal: {r.animal_nome} (Anilha: {r.animal_anilha})</div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ fontSize: 11, fontWeight: 800, borderRadius: 8, padding: "4px 12px", background: r.status === "ativa" ? "#E8F5E9" : "#F1F4F8", color: r.status === "ativa" ? "#2E7D32" : "#57636C" }}>
                        {r.status.toUpperCase()}
                      </div>
                      <div style={{ fontSize: 10, color: "#BDBDBD", marginTop: 6 }}>🗓️ Sorteio: {new Date(r.data_sorteio).toLocaleDateString("pt-BR")}</div>
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 10, marginBottom: 14 }}>
                    <div style={{ background: "#F8FAFC", borderRadius: 10, padding: 10, textAlign: "center" }}>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>💰 Arrecadado</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073", marginTop: 4 }}>R$ {Number(r.total_arrecadado || 0).toFixed(2)}</div>
                      <div style={{ fontSize: 9, color: "#00A893", marginTop: 2 }}>{percentualMeta.toFixed(0)}% da meta</div>
                    </div>
                    <div style={{ background: "#F8FAFC", borderRadius: 10, padding: 10, textAlign: "center" }}>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>🎟️ Números</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073", marginTop: 4 }}>{r.numeros_vendidos || 0}/{r.qtd_numeros}</div>
                      <div style={{ fontSize: 9, color: "#00A893", marginTop: 2 }}>{percentualVenda.toFixed(0)}% vendidos</div>
                    </div>
                    <div style={{ background: "#F8FAFC", borderRadius: 10, padding: 10, textAlign: "center" }}>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>💵 Por Número</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073", marginTop: 4 }}>R$ {Number(r.valor_por_numero || 0).toFixed(2)}</div>
                    </div>
                    <div style={{ background: "#F8FAFC", borderRadius: 10, padding: 10, textAlign: "center" }}>
                      <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700 }}>🎯 Meta</div>
                      <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073", marginTop: 4 }}>R$ {Number(r.valor_arrecadar || 0).toFixed(2)}</div>
                    </div>
                  </div>

                  {r.ganhador_id ? (
                    <div style={{ background: "#E8F5E9", borderRadius: 10, padding: 12, border: "1px solid #2E7D32" }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: "#2E7D32", marginBottom: 6 }}>🏆 RIFA SORTEADA</div>
                      <div style={{ fontSize: 13, fontWeight: 900, color: "#1B5E20", marginBottom: 4 }}>Ganhador: {r.ganhador_nome}</div>
                      <div style={{ fontSize: 11, color: "#2E7D32" }}>Email: {r.ganhador_email}</div>
                    </div>
                  ) : (
                    <button onClick={() => abrirModalSorteio(r)} style={{ width: "100%", padding: 12, borderRadius: 10, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, cursor: "pointer" }}>
                      🎯 Realizar Sorteio
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {modalSorteioAberto && rifaSorteio && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setModalSorteioAberto(false)}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px" }} onClick={e => e.stopPropagation()}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#170073", marginBottom: 12 }}>🎯 Realizar Sorteio</div>
            <div style={{ fontSize: 12, color: "#57636C", marginBottom: 16 }}>{rifaSorteio.titulo || rifaSorteio.animal_nome}</div>

            <div style={{ display: "grid", gap: 12, marginBottom: 16 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Número Vencedor</label>
                <input type="number" min="1" max={rifaSorteio.qtd_numeros} value={numerovencedor} onChange={e => setNumeroVencedor(e.target.value)} placeholder="Digite o número sorteado"
                  style={{ width: "100%", padding: "12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "Montserrat,sans-serif" }} />
                <div style={{ fontSize: 10, color: "#BDBDBD", marginTop: 6 }}>Entre 1 e {rifaSorteio.qtd_numeros}</div>
              </div>

              <button onClick={realizarSorteio} disabled={processando || !numerovencedor}
                style={{ width: "100%", padding: 12, borderRadius: 10, border: "none", background: processando || !numerovencedor ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontFamily: "Montserrat,sans-serif", fontWeight: 900, cursor: processando ? "default" : "pointer" }}>
                {processando ? "Processando..." : "✅ Confirmar Sorteio Manual"}
              </button>

              <div style={{ display: "flex", alignItems: "center", gap: 10, opacity: 0.5 }}>
                <div style={{ flex: 1, height: "1px", background: "#E8ECF0" }} />
                <span style={{ fontSize: 11, color: "#BDBDBD" }}>OU</span>
                <div style={{ flex: 1, height: "1px", background: "#E8ECF0" }} />
              </div>

              <button onClick={sorteioAleatorio} disabled={processando}
                style={{ width: "100%", padding: 12, borderRadius: 10, border: "1.5px solid #170073", background: "#fff", color: "#170073", fontFamily: "Montserrat,sans-serif", fontWeight: 900, cursor: processando ? "default" : "pointer", opacity: processando ? 0.6 : 1 }}>
                🎲 Sorteio Aleatório
              </button>
            </div>

            <div style={{ background: "#FFF8E1", borderRadius: 10, padding: 12, border: "1px solid #F0A500", fontSize: 11, color: "#856404" }}>
              ⚠️ Após confirmar o sorteio, o ganhador receberá uma notificação e a rifa não poderá ser alterada.
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}