import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";

const CORES = {
  azul_escuro: { label: "Azul Escuro", bg: "#0c3a78" },
  preto: { label: "Preto", bg: "#000" },
  verde: { label: "Verde", bg: "#15803d" },
  amarelo: { label: "Amarelo", bg: "#ca8a04" },
  laranja: { label: "Laranja", bg: "#c2410c" },
  roxo: { label: "Roxo", bg: "#6d28d9" },
  rosa: { label: "Rosa", bg: "#be185d" },
  branco: { label: "Branco", bg: "#fff" },
};

export default function NinhadaGestao() {
  const navigate = useNavigate();
  const params = new URLSearchParams(window.location.search);
  const ninhadaId = params.get("id");

  const [user, setUser] = useState(null);
  const [ninhada, setNinhada] = useState(null);
  const [filhotes, setFilhotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalObito, setModalObito] = useState(null);
  const [motivoObito, setMotivoObito] = useState("");
  const [modalConversao, setModalConversao] = useState(false);
  const [selecionados, setSelecionados] = useState([]);
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    carregar();
  }, [ninhadaId]);

  const carregar = async () => {
    setLoading(true);
    const [n, f] = await Promise.all([
      base44.entities.Ninhada.filter({ id: ninhadaId }),
      base44.entities.AnilhaFilha.filter({ ninhada_id: ninhadaId }),
    ]);
    setNinhada(n[0] || null);
    setFilhotes(f);
    setLoading(false);
  };

  const registrarObito = async () => {
    if (!modalObito) return;
    setSalvando(true);
    await base44.entities.AnilhaFilha.update(modalObito.id, {
      status: "obito",
      data_obito: new Date().toISOString().split("T")[0],
      motivo_obito: motivoObito,
    });
    await base44.entities.Ninhada.update(ninhadaId, {
      obitos: (ninhada.obitos || 0) + 1,
      vivos: Math.max(0, (ninhada.vivos || 0) - 1),
    });
    toast.success("Óbito registrado.");
    setModalObito(null);
    setMotivoObito("");
    setSalvando(false);
    carregar();
  };

  const converterSelecionados = async () => {
    if (selecionados.length === 0) { toast.error("Selecione ao menos um filhote."); return; }
    setSalvando(true);
    for (const filhote of selecionados) {
      const adulto = await base44.entities.Animal.create({
        nome: `Filhote ${filhote.anilha_numero}`,
        anilha: filhote.anilha_numero,
        origem: "filho",
        pai_id: filhote.animal_pai_id,
        pai_nome: filhote.animal_pai_nome,
        mae_id: filhote.animal_mae_id,
        mae_nome: filhote.animal_mae_nome,
        cor_plumagem: filhote.cor_anilha_definitiva,
        proprietario_email: filhote.usuario_email,
        proprietario_id: filhote.usuario_id,
        tipo_categoria: "elenco_principal",
        saude_status: "excelente",
        status_vitrine: "indisponivel",
        status_atual: "ativo",
      });
      await base44.entities.AnilhaFilha.update(filhote.id, {
        status: "convertida",
        animal_adulto_id: adulto.id,
      });
    }
    await base44.entities.Ninhada.update(ninhadaId, {
      convertidos: (ninhada.convertidos || 0) + selecionados.length,
      vivos: Math.max(0, (ninhada.vivos || 0) - selecionados.length),
    });
    toast.success(`${selecionados.length} filhote(s) convertido(s) para Adulto!`);
    setSelecionados([]);
    setModalConversao(false);
    setSalvando(false);
    carregar();
  };

  const toggleSelecionado = (filhote) => {
    setSelecionados(prev =>
      prev.find(f => f.id === filhote.id)
        ? prev.filter(f => f.id !== filhote.id)
        : [...prev, filhote]
    );
  };

  const vivos = filhotes.filter(f => f.status !== "obito" && f.status !== "convertida");
  const obitos = filhotes.filter(f => f.status === "obito");
  const convertidos = filhotes.filter(f => f.status === "convertida");

  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "hsl(var(--background))" }}>
      <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
    </div>
  );

  if (!ninhada) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "hsl(var(--background))", color: "hsl(var(--foreground))" }}>
      Ninhada não encontrada.
    </div>
  );

  const corCfg = CORES[ninhada.cor_anilha] || { bg: "#888" };

  return (
    <div style={{ minHeight: "100vh", background: "hsl(var(--background))", color: "hsl(var(--foreground))", fontFamily: "'DM Sans', -apple-system, sans-serif" }}>

      {/* Header */}
      <div style={{ position: "sticky", top: 0, background: "hsl(var(--background))", borderBottom: "1px solid hsl(var(--border))", padding: "14px 20px", display: "flex", alignItems: "center", gap: 12, zIndex: 10 }}>
        <button onClick={() => navigate(-1)} style={{ background: "none", border: "none", fontSize: 22, cursor: "pointer", color: "hsl(var(--foreground))", minWidth: 44, minHeight: 44, display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 15, fontWeight: 900 }}>Ninhada — {ninhada.pai_nome} × {ninhada.mae_nome}</div>
          <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))" }}>Anilhamento: {ninhada.data_anilhamento}</div>
        </div>
        <div style={{ width: 22, height: 22, borderRadius: "50%", background: corCfg.bg, border: "2px solid rgba(255,255,255,.3)" }} />
      </div>

      <div style={{ padding: "16px", maxWidth: 600, margin: "0 auto", paddingBottom: 120 }}>

        {/* Estatísticas */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 16 }}>
          {[
            { label: "Vivos", count: vivos.length, color: "#2E7D32", emoji: "🐣" },
            { label: "Óbitos", count: obitos.length, color: "#C62828", emoji: "💀" },
            { label: "Adultos", count: convertidos.length, color: "#1565C0", emoji: "🐓" },
          ].map(s => (
            <div key={s.label} style={{ background: "hsl(var(--muted))", borderRadius: 12, padding: "12px 8px", textAlign: "center", border: "1px solid hsl(var(--border))" }}>
              <div style={{ fontSize: 20 }}>{s.emoji}</div>
              <div style={{ fontSize: 22, fontWeight: 900, color: s.color }}>{s.count}</div>
              <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))" }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* Botão Conversão Antecipada */}
        {vivos.length > 0 && (
          <button onClick={() => { setModalConversao(true); setSelecionados([]); }}
            style={{ width: "100%", padding: "12px", borderRadius: 12, border: "2px solid #1565C0", background: "transparent", color: "#1565C0", fontWeight: 700, fontSize: 13, cursor: "pointer", marginBottom: 16 }}>
            🐓 Anilhar Antecipado (converter para Adulto)
          </button>
        )}

        {/* Lista Vivos */}
        {vivos.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#2E7D32", textTransform: "uppercase", marginBottom: 8 }}>🐣 Filhotes Vivos ({vivos.length})</div>
            <div style={{ display: "grid", gap: 8 }}>
              {vivos.map(f => (
                <div key={f.id} style={{ background: "hsl(var(--card))", borderRadius: 12, padding: "12px 14px", border: "1px solid hsl(var(--border))", display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 14, height: 14, borderRadius: "50%", background: corCfg.bg, flexShrink: 0, border: "1px solid rgba(255,255,255,.3)" }} />
                  <div style={{ flex: 1, fontWeight: 700, fontSize: 13 }}>{f.anilha_numero || "Sem nº"}</div>
                  <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 10, fontWeight: 700, background: "#E8F5E9", color: "#2E7D32" }}>
                    {f.status === "pronto_para_troca" ? "Pronto" : "Incubando"}
                  </span>
                  <button onClick={() => { setModalObito(f); setMotivoObito(""); }}
                    style={{ background: "#FFEBEE", border: "none", borderRadius: 8, padding: "6px 10px", color: "#C62828", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                    💀 Óbito
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Lista Óbitos */}
        {obitos.length > 0 && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#C62828", textTransform: "uppercase", marginBottom: 8 }}>💀 Óbitos ({obitos.length})</div>
            <div style={{ display: "grid", gap: 8 }}>
              {obitos.map(f => (
                <div key={f.id} style={{ background: "hsl(var(--card))", borderRadius: 12, padding: "12px 14px", border: "1px solid hsl(var(--border))", opacity: 0.6 }}>
                  <div style={{ fontWeight: 700, fontSize: 13 }}>{f.anilha_numero || "Sem nº"}</div>
                  {f.data_obito && <div style={{ fontSize: 11, color: "#C62828", marginTop: 2 }}>Óbito: {f.data_obito}</div>}
                  {f.motivo_obito && <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", marginTop: 2 }}>{f.motivo_obito}</div>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Lista Convertidos */}
        {convertidos.length > 0 && (
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#1565C0", textTransform: "uppercase", marginBottom: 8 }}>🐓 Convertidos para Adulto ({convertidos.length})</div>
            <div style={{ display: "grid", gap: 8 }}>
              {convertidos.map(f => (
                <div key={f.id} style={{ background: "hsl(var(--card))", borderRadius: 12, padding: "12px 14px", border: "1px solid hsl(var(--border))", display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ flex: 1, fontWeight: 700, fontSize: 13 }}>{f.anilha_numero || "Sem nº"}</div>
                  {f.animal_adulto_id && (
                    <button onClick={() => navigate(`/animal/${f.animal_adulto_id}`)}
                      style={{ padding: "5px 10px", borderRadius: 8, border: "none", background: "#E3F2FD", color: "#1565C0", fontSize: 11, fontWeight: 700, cursor: "pointer" }}>
                      Ver Adulto →
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modal Óbito */}
      {modalObito && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 9000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
          <div style={{ background: "hsl(var(--background))", borderRadius: "20px 20px 0 0", padding: 24, width: "100%", maxWidth: 500 }}>
            <div style={{ fontWeight: 900, fontSize: 16, marginBottom: 4, fontFamily: "Montserrat,sans-serif" }}>💀 Registrar Óbito</div>
            <div style={{ fontSize: 13, color: "hsl(var(--muted-foreground))", marginBottom: 16 }}>Filhote: {modalObito.anilha_numero}</div>
            <textarea
              value={motivoObito}
              onChange={e => setMotivoObito(e.target.value)}
              placeholder="Motivo do óbito (opcional)"
              style={{ width: "100%", padding: "12px 14px", borderRadius: 10, border: "1.5px solid hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))", fontSize: 13, outline: "none", resize: "none", boxSizing: "border-box", minHeight: 70 }}
            />
            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
              <button onClick={() => setModalObito(null)} style={{ flex: 1, padding: "12px", borderRadius: 10, border: "1px solid hsl(var(--border))", background: "transparent", color: "hsl(var(--foreground))", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>Cancelar</button>
              <button onClick={registrarObito} disabled={salvando} style={{ flex: 1, padding: "12px", borderRadius: 10, border: "none", background: "#C62828", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
                {salvando ? "..." : "Confirmar Óbito"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Conversão Antecipada */}
      {modalConversao && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.6)", zIndex: 9000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
          <div style={{ background: "hsl(var(--background))", borderRadius: "20px 20px 0 0", padding: 24, width: "100%", maxWidth: 500, maxHeight: "80vh", overflowY: "auto" }}>
            <div style={{ fontWeight: 900, fontSize: 16, marginBottom: 4, fontFamily: "Montserrat,sans-serif" }}>🐓 Anilhamento Antecipado</div>
            <div style={{ fontSize: 13, color: "hsl(var(--muted-foreground))", marginBottom: 16 }}>Selecione os filhotes a converter para Adulto agora:</div>
            <div style={{ display: "grid", gap: 8, marginBottom: 16 }}>
              {vivos.map(f => {
                const sel = selecionados.find(s => s.id === f.id);
                return (
                  <button key={f.id} onClick={() => toggleSelecionado(f)}
                    style={{ padding: "12px 14px", borderRadius: 10, border: `2px solid ${sel ? "#1565C0" : "hsl(var(--border))"}`, background: sel ? "#E3F2FD" : "transparent", color: sel ? "#1565C0" : "hsl(var(--foreground))", fontWeight: 700, fontSize: 13, cursor: "pointer", textAlign: "left", display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 16 }}>{sel ? "☑" : "☐"}</span>
                    {f.anilha_numero || "Sem nº"}
                  </button>
                );
              })}
            </div>
            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => setModalConversao(false)} style={{ flex: 1, padding: "12px", borderRadius: 10, border: "1px solid hsl(var(--border))", background: "transparent", color: "hsl(var(--foreground))", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>Cancelar</button>
              <button onClick={converterSelecionados} disabled={salvando || selecionados.length === 0}
                style={{ flex: 1, padding: "12px", borderRadius: 10, border: "none", background: selecionados.length > 0 ? "#1565C0" : "hsl(var(--muted))", color: selecionados.length > 0 ? "#fff" : "hsl(var(--muted-foreground))", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
                {salvando ? "..." : `Converter ${selecionados.length} filhote(s)`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}