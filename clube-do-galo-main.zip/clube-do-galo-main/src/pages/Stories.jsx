import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import NotificacoesSino from "../components/NotificacoesSino";
import { getPlano, getPlanoBundles } from "../lib/planos";

// Limites por plano
const STORIES_DIA = { iniciante: 1, standard: 3, gold: 5, premium: -1 };

export default function Stories() {
  const [stories, setStories]     = useState([]);
  const [user, setUser]           = useState(null);
  const [userMeta, setUserMeta]   = useState(null);
  const [storyAtivo, setStoryAtivo] = useState(null);
  const [indiceAtivo, setIndiceAtivo] = useState(0);
  const [criando, setCriando]     = useState(false);
  const [saving, setSaving]       = useState(false);

  // Form criar story
  const [legenda, setLegenda]     = useState("");
  const [arquivo, setArquivo]     = useState(null);
  const [preview, setPreview]     = useState(null);
  const [comEnquete, setComEnquete] = useState(false);
  const [enquetePergunta, setEnquetePergunta] = useState("");
  const [enqueteOpcoes, setEnqueteOpcoes] = useState(["", ""]);

  const fileRef = useRef();

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      if (me) {
        const users = await base44.entities.User.filter({ email: me.email });
        setUserMeta(users[0] || null);
      }
      carregarStories();
    };
    init();
  }, []);

  const carregarStories = async () => {
    const data = await base44.entities.Story.filter({ ativo: true }, "-created_date", 60);
    setStories(data);
  };

  const planoBundles = getPlanoBundles(userMeta?.role, userMeta?.plano);
  const limiteHoje   = STORIES_DIA[planoBundles] ?? 1;
  const labelLimite  = limiteHoje === -1 ? "ilimitados" : `${limiteHoje} por dia`;

  // Conta stories do user hoje
  const hoje = new Date().toISOString().split("T")[0];
  const storiesHoje = stories.filter(s => s.autor_id === user?.id && s.created_date?.startsWith(hoje)).length;
  const podePostar = limiteHoje === -1 || storiesHoje < limiteHoje;

  const onArquivo = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    setArquivo(f);
    setPreview(URL.createObjectURL(f));
  };

  const addOpcao = () => setEnqueteOpcoes(p => [...p, ""]);
  const setOpcao = (i, v) => setEnqueteOpcoes(p => p.map((o, idx) => idx === i ? v : o));
  const removeOpcao = (i) => setEnqueteOpcoes(p => p.filter((_, idx) => idx !== i));

  const publicar = async () => {
    if (!arquivo) return;
    setSaving(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file: arquivo });
    const expiracao = new Date();
    expiracao.setHours(expiracao.getHours() + 24);

    const payload = {
      autor_id:       user.id || user.email,
      autor_nome:     user.full_name || user.email,
      autor_plano:    planoBundles,
      midia_url:      file_url,
      tipo_midia:     arquivo.type.startsWith("video") ? "video" : "foto",
      legenda,
      ativo:          true,
      visualizacoes:  0,
      data_expiracao: expiracao.toISOString(),
    };

    if (comEnquete && enquetePergunta.trim()) {
      const opcoesFiltradas = enqueteOpcoes.filter(o => o.trim());
      payload.enquete_pergunta = enquetePergunta.trim();
      payload.enquete_opcoes   = opcoesFiltradas;
      payload.enquete_votos    = Array(opcoesFiltradas.length).fill(0);
    }

    await base44.entities.Story.create(payload);
    await carregarStories();
    setSaving(false);
    setCriando(false);
    setLegenda(""); setArquivo(null); setPreview(null);
    setComEnquete(false); setEnquetePergunta(""); setEnqueteOpcoes(["", ""]);
  };

  const votar = async (story, opcaoIdx) => {
    if (!story.enquete_votos) return;
    const novosVotos = [...story.enquete_votos];
    novosVotos[opcaoIdx] = (novosVotos[opcaoIdx] || 0) + 1;
    await base44.entities.Story.update(story.id, { enquete_votos: novosVotos });
    setStoryAtivo(prev => ({ ...prev, enquete_votos: novosVotos }));
    await carregarStories();
  };

  const abrirStory = (s, idx) => {
    setStoryAtivo(s);
    setIndiceAtivo(idx);
  };

  const proximoStory = (e) => {
    e.stopPropagation();
    if (indiceAtivo < stories.length - 1) {
      setIndiceAtivo(i => i + 1);
      setStoryAtivo(stories[indiceAtivo + 1]);
    } else {
      setStoryAtivo(null);
    }
  };

  const anteriorStory = (e) => {
    e.stopPropagation();
    if (indiceAtivo > 0) {
      setIndiceAtivo(i => i - 1);
      setStoryAtivo(stories[indiceAtivo - 1]);
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0A0A0A", fontFamily: "'DM Sans', sans-serif" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "16px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 20, textDecoration: "none" }}>←</Link>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#fff" }}>📸 Stories</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {user && <NotificacoesSino userEmail={user.email} />}
            {podePostar ? (
              <button onClick={() => setCriando(true)}
                style={{ background: "#fff", color: "#170073", border: "none", borderRadius: 10, padding: "7px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
                + Story
              </button>
            ) : (
              <div style={{ background: "rgba(255,255,255,.15)", borderRadius: 10, padding: "7px 14px", fontSize: 11, color: "rgba(255,255,255,.8)", fontWeight: 700 }}>
                🔒 Limite atingido
              </div>
            )}
          </div>
        </div>
        {/* Info plano */}
        <div style={{ marginTop: 8, fontSize: 10, color: "rgba(255,255,255,.65)", textAlign: "right" }}>
         Seu plano ({planoBundles}): {labelLimite} · Hoje: {storiesHoje} publicado{storiesHoje !== 1 ? "s" : ""}
        </div>
      </div>

      {/* Círculos de stories */}
      <div style={{ padding: "16px 16px 10px", display: "flex", gap: 14, overflowX: "auto" }}>
        {stories.map((s, idx) => (
          <div key={s.id} onClick={() => abrirStory(s, idx)} style={{ flexShrink: 0, cursor: "pointer", textAlign: "center" }}>
            <div style={{ width: 66, height: 66, borderRadius: "50%", background: s.midia_url ? `url(${s.midia_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", border: "3px solid #00A893", position: "relative" }}>
              {s.enquete_pergunta && (
                <div style={{ position: "absolute", bottom: -2, right: -2, background: "#F0A500", borderRadius: "50%", width: 18, height: 18, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10 }}>📊</div>
              )}
            </div>
            <div style={{ fontSize: 10, color: "#fff", marginTop: 5, maxWidth: 70, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {s.autor_nome.split(" ")[0]}
            </div>
          </div>
        ))}
        {stories.length === 0 && (
          <div style={{ color: "#57636C", fontSize: 13, padding: "10px 0" }}>Nenhum story ativo no momento</div>
        )}
      </div>

      {/* Grade */}
      <div style={{ padding: "4px 16px 40px", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 2 }}>
        {stories.map((s, idx) => (
          <div key={s.id} onClick={() => abrirStory(s, idx)}
            style={{ aspectRatio: "9/16", background: s.midia_url ? `url(${s.midia_url}) center/cover` : "linear-gradient(135deg,#170073,#2D0EA8)", cursor: "pointer", position: "relative" }}>
            <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, background: "linear-gradient(transparent,rgba(0,0,0,.75))", padding: "20px 6px 6px" }}>
              <div style={{ fontSize: 10, color: "#fff", fontWeight: 700 }}>{s.autor_nome.split(" ")[0]}</div>
              {s.enquete_pergunta && <div style={{ fontSize: 9, color: "#FFD700" }}>📊 Enquete</div>}
            </div>
          </div>
        ))}
      </div>

      {/* Visualizador fullscreen */}
      {storyAtivo && (
        <div style={{ position: "fixed", inset: 0, background: "#000", zIndex: 2000, display: "flex", flexDirection: "column" }}>
          {/* Barra de progresso */}
          <div style={{ display: "flex", gap: 3, padding: "10px 12px 0" }}>
            {stories.map((_, i) => (
              <div key={i} style={{ flex: 1, height: 3, borderRadius: 2, background: i <= indiceAtivo ? "#fff" : "rgba(255,255,255,.3)" }} />
            ))}
          </div>

          {/* Header */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 16px" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>🐓</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#fff" }}>{storyAtivo.autor_nome}</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,.6)" }}>{new Date(storyAtivo.created_date).toLocaleDateString("pt-BR")} · 👁️ {storyAtivo.visualizacoes || 0}</div>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              {(user?.email === storyAtivo?.usuario_email || user?.id === storyAtivo?.autor_id) && (
                <button onClick={async () => {
                  if (!confirm("Apagar este story?")) return;
                  await base44.entities.Story.delete(storyAtivo.id);
                  setStoryAtivo(null);
                  carregarStories();
                }}
                  style={{ background: "rgba(226,28,61,.3)", border: "none", borderRadius: "50%", width: 36, height: 36, color: "#ff6b81", fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>🗑️</button>
              )}
              <button onClick={() => setStoryAtivo(null)} style={{ background: "none", border: "none", color: "#fff", fontSize: 22, cursor: "pointer" }}>✕</button>
            </div>
          </div>

          {/* Mídia */}
          <div style={{ flex: 1, position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ position: "absolute", inset: 0, background: `url(${storyAtivo.midia_url}) center/contain no-repeat` }} />

            {/* Navegar anterior */}
            <div onClick={anteriorStory} style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: "35%", cursor: "pointer", zIndex: 1 }} />
            {/* Navegar próximo */}
            <div onClick={proximoStory} style={{ position: "absolute", right: 0, top: 0, bottom: 0, width: "35%", cursor: "pointer", zIndex: 1 }} />

            {/* Legenda */}
            {storyAtivo.legenda && (
              <div style={{ position: "absolute", bottom: storyAtivo.enquete_pergunta ? 180 : 20, left: 16, right: 16, background: "rgba(0,0,0,.65)", borderRadius: 10, padding: "8px 12px", fontSize: 13, color: "#fff", zIndex: 2 }}>
                {storyAtivo.legenda}
              </div>
            )}

            {/* Enquete */}
            {storyAtivo.enquete_pergunta && (
              <div style={{ position: "absolute", bottom: 20, left: 16, right: 16, background: "rgba(0,0,0,.8)", borderRadius: 14, padding: "14px 16px", zIndex: 2 }}
                onClick={e => e.stopPropagation()}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 800, color: "#fff", marginBottom: 10 }}>
                  📊 {storyAtivo.enquete_pergunta}
                </div>
                {(storyAtivo.enquete_opcoes || []).map((opcao, i) => {
                  const totalVotos = (storyAtivo.enquete_votos || []).reduce((a, b) => a + b, 0);
                  const votos = storyAtivo.enquete_votos?.[i] || 0;
                  const pct = totalVotos > 0 ? Math.round((votos / totalVotos) * 100) : 0;
                  return (
                    <button key={i} onClick={() => votar(storyAtivo, i)}
                      style={{ width: "100%", marginBottom: 6, padding: "0", border: "none", background: "none", cursor: "pointer", textAlign: "left" }}>
                      <div style={{ position: "relative", background: "rgba(255,255,255,.15)", borderRadius: 10, overflow: "hidden", height: 38 }}>
                        <div style={{ position: "absolute", top: 0, left: 0, bottom: 0, width: `${pct}%`, background: "rgba(0,168,147,.5)", transition: ".3s" }} />
                        <div style={{ position: "relative", display: "flex", justifyContent: "space-between", alignItems: "center", height: "100%", padding: "0 12px", zIndex: 1 }}>
                          <span style={{ fontSize: 12, color: "#fff", fontWeight: 700 }}>{opcao}</span>
                          <span style={{ fontSize: 11, color: "rgba(255,255,255,.8)", fontWeight: 800 }}>{pct}%</span>
                        </div>
                      </div>
                    </button>
                  );
                })}
                <div style={{ fontSize: 10, color: "rgba(255,255,255,.5)", marginTop: 4, textAlign: "right" }}>
                  {(storyAtivo.enquete_votos || []).reduce((a, b) => a + b, 0)} voto{(storyAtivo.enquete_votos || []).reduce((a, b) => a + b, 0) !== 1 ? "s" : ""}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal criar story */}
      {criando && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.75)", zIndex: 2000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
          <div style={{ background: "#fff", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 520, maxHeight: "92vh", overflowY: "auto", padding: "20px 20px 40px" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 4 }}>📸 Novo Story</div>
            <div style={{ fontSize: 11, color: "#57636C", marginBottom: 16 }}>
             Seu plano ({planoBundles}) permite {labelLimite} · Hoje: {storiesHoje} publicado{storiesHoje !== 1 ? "s" : ""}
            </div>

            <input type="file" ref={fileRef} accept="image/*,video/*" onChange={onArquivo} style={{ display: "none" }} />

            {/* Preview ou botão de upload */}
            <div onClick={() => fileRef.current.click()}
              style={{ border: "2px dashed #E8ECF0", borderRadius: 12, overflow: "hidden", cursor: "pointer", marginBottom: 12, background: "#F8FAFC", minHeight: 140, display: "flex", alignItems: "center", justifyContent: "center" }}>
              {preview ? (
                <img src={preview} alt="preview" style={{ width: "100%", maxHeight: 200, objectFit: "cover" }} />
              ) : (
                <div style={{ textAlign: "center", padding: 24 }}>
                  <div style={{ fontSize: 36, marginBottom: 8 }}>📷</div>
                  <div style={{ fontSize: 13, color: "#57636C" }}>Clique para selecionar foto ou vídeo</div>
                </div>
              )}
            </div>

            <textarea value={legenda} onChange={e => setLegenda(e.target.value)} placeholder="Legenda (opcional)..."
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", height: 64, resize: "none", marginBottom: 12 }} />

            {/* Toggle enquete */}
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: comEnquete ? 12 : 16, padding: "10px 14px", background: "#F8FAFC", borderRadius: 10, cursor: "pointer" }}
              onClick={() => setComEnquete(p => !p)}>
              <div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, color: "#101213" }}>📊 Adicionar Enquete</div>
                <div style={{ fontSize: 10, color: "#57636C" }}>Deixe seus seguidores votarem</div>
              </div>
              <div style={{ width: 36, height: 20, borderRadius: 10, background: comEnquete ? "#170073" : "#E8ECF0", position: "relative", transition: ".2s" }}>
                <div style={{ width: 16, height: 16, borderRadius: "50%", background: "#fff", position: "absolute", top: 2, left: comEnquete ? 18 : 2, transition: ".2s" }} />
              </div>
            </div>

            {/* Campos enquete */}
            {comEnquete && (
              <div style={{ background: "#F0F4FF", borderRadius: 12, padding: "14px", marginBottom: 14 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 8 }}>Pergunta da Enquete</div>
                <input value={enquetePergunta} onChange={e => setEnquetePergunta(e.target.value)}
                  placeholder="Ex: Qual é o melhor galo?"
                  style={{ width: "100%", padding: "9px 12px", borderRadius: 8, border: "1.5px solid #D0D8FF", fontSize: 13, outline: "none", boxSizing: "border-box", marginBottom: 10 }} />
                <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 6 }}>Opções (mín. 2)</div>
                {enqueteOpcoes.map((o, i) => (
                  <div key={i} style={{ display: "flex", gap: 6, marginBottom: 6 }}>
                    <input value={o} onChange={e => setOpcao(i, e.target.value)}
                      placeholder={`Opção ${i + 1}`}
                      style={{ flex: 1, padding: "8px 10px", borderRadius: 8, border: "1.5px solid #D0D8FF", fontSize: 12, outline: "none" }} />
                    {enqueteOpcoes.length > 2 && (
                      <button onClick={() => removeOpcao(i)} style={{ background: "#FFEBEE", border: "none", borderRadius: 8, width: 30, cursor: "pointer", color: "#C62828", fontSize: 14 }}>✕</button>
                    )}
                  </div>
                ))}
                {enqueteOpcoes.length < 4 && (
                  <button onClick={addOpcao}
                    style={{ width: "100%", padding: "7px", borderRadius: 8, border: "1.5px dashed #170073", background: "transparent", color: "#170073", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>
                    + Adicionar opção
                  </button>
                )}
              </div>
            )}

            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={() => { setCriando(false); setPreview(null); setArquivo(null); }}
                style={{ flex: 1, padding: 12, borderRadius: 12, border: "1.5px solid #E8ECF0", background: "#fff", color: "#57636C", cursor: "pointer", fontWeight: 700 }}>Cancelar</button>
              <button onClick={publicar} disabled={!arquivo || saving}
                style={{ flex: 2, padding: 12, borderRadius: 12, border: "none", background: !arquivo || saving ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: !arquivo || saving ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
                {saving ? "Publicando..." : "📤 Publicar Story"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}