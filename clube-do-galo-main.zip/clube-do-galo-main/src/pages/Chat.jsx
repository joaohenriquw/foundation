import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import ChatConsultoria from '../components/ChatConsultoria';
import ListaConsultorias from '../components/ListaConsultorias';
import BottomNav from '../components/BottomNav';
import PaginationList from '../components/PaginationList';

export default function Chat() {
  const { id: conversaIdParam } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [conversas, setConversas] = useState([]);
  const [conversaIdModal, setConversaIdModal] = useState(conversaIdParam || null);
  const [mostraNovaConversa, setMostraNovaConversa] = useState(false);
  const [tipo, setTipo] = useState('advogado_civil');
  const [descricao, setDescricao] = useState('');
  const [criando, setCriando] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      await carregar();
      setLoading(false);
    };
    init();
  }, []);

  const carregar = async () => {
    if (!user && !loading) return;
    try {
      const convs = await base44.entities.ChatConversa.filter({ usuario_email: user?.email }, '-created_date', 50).catch(() => []);
      setConversas(convs);
    } catch (e) {
      console.error('Erro ao carregar conversas:', e);
    }
  };

  const criarConversa = async () => {
    setCriando(true);
    try {
      const res = await base44.functions.invoke('criarConversaConsultoria', {
        tipo_consultoria: tipo,
        descricao
      });
      setConversaIdModal(res.data.id);
      setMostraNovaConversa(false);
      setTipo('advogado_civil');
      setDescricao('');
      await carregar();
    } catch (e) {
      alert('Erro: ' + e.message);
    } finally {
      setCriando(false);
    }
  };

  if (loading) return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>⏳</div>;
  if (!user) return null;

  return (
    <div style={{ minHeight: '100vh', background: '#000', fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 120, color: '#fff' }}>
      {/* Header */}
      <div style={{ background: '#0A0A0A', padding: '52px 20px 16px', borderBottom: '1px solid #1C1C1E', position: 'sticky', top: 0, zIndex: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, maxWidth: 700, margin: '0 auto' }}>
          <button onClick={() => navigate('/')} style={{ background: 'rgba(255,255,255,.2)', border: 'none', borderRadius: 10, width: 38, height: 38, cursor: 'pointer', fontSize: 18, color: '#fff' }}>
            ←
          </button>
          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 16, fontWeight: 900, color: '#00C9B8' }}>
            💬 Consultorias
          </div>
          <button onClick={() => setMostraNovaConversa(true)} style={{ background: 'rgba(255,255,255,.2)', border: 'none', borderRadius: 10, width: 38, height: 38, cursor: 'pointer', fontSize: 18, color: '#fff' }}>
            ➕
          </button>
        </div>
      </div>

      <div style={{ padding: '16px 14px 20px', maxWidth: 700, margin: '0 auto' }}>
        {/* Modal nova consulta */}
        {mostraNovaConversa && (
          <>
            <div onClick={() => setMostraNovaConversa(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.5)', zIndex: 999 }} />
            <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: '90%', maxWidth: 400, background: '#1C1C1E', borderRadius: 16, padding: 24, zIndex: 1000, boxShadow: '0 20px 60px rgba(0,0,0,.6)' }}>
              <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 16, fontWeight: 900, color: '#00C9B8', marginBottom: 14 }}>
                ➕ Nova Consultoria
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#888', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>Tipo de Consultoria</label>
                <select value={tipo} onChange={e => setTipo(e.target.value)}
                  style={{ width: '100%', padding: '10px 12px', border: 'none', borderRadius: 10, fontSize: 13, outline: 'none', boxSizing: 'border-box', background: '#2C2C2E', color: '#fff' }}>
                  <option value="advogado_civil">⚖️ Advogado Civil</option>
                  <option value="advogado_criminal">🔒 Advogado Criminal</option>
                  <option value="veterinario">🩺 Veterinário</option>
                </select>
              </div>

              <div style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#888', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>Descrição da Consulta</label>
                <textarea value={descricao} onChange={e => setDescricao(e.target.value)}
                  placeholder="Descreva brevemente sua questão..."
                  style={{ width: '100%', padding: '10px 12px', border: 'none', borderRadius: 10, fontSize: 13, outline: 'none', boxSizing: 'border-box', minHeight: 80, fontFamily: 'DM Sans, sans-serif', resize: 'none', background: '#2C2C2E', color: '#fff' }} />
              </div>

              <div style={{ display: 'flex', gap: 10 }}>
                <button onClick={() => setMostraNovaConversa(false)}
                  style={{ flex: 1, padding: 12, borderRadius: 10, border: 'none', background: '#2C2C2E', cursor: 'pointer', fontSize: 13, fontWeight: 700, fontFamily: 'Montserrat,sans-serif', color: '#aaa' }}>
                  Cancelar
                </button>
                <button onClick={criarConversa} disabled={criando}
                  style={{ flex: 1, padding: 12, borderRadius: 10, border: 'none', background: criando ? '#ccc' : 'linear-gradient(135deg,#170073,#00A893)', color: '#fff', cursor: criando ? 'default' : 'pointer', fontSize: 13, fontWeight: 700, fontFamily: 'Montserrat,sans-serif' }}>
                  {criando ? '⏳' : '💬'} Iniciar
                </button>
              </div>
            </div>
          </>
        )}

        {/* Lista de conversas */}
        <div style={{ display: 'grid', gap: 12 }}>
          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 13, fontWeight: 900, color: '#00C9B8', marginBottom: 4 }}>
            💬 Minhas Conversas
          </div>
          <PaginationList
            items={conversas}
            itemsPerPage={10}
            renderItem={(conv) => (
              <div onClick={() => setConversaIdModal(conv.id)}
                style={{
                  background: conversaIdModal === conv.id ? '#2C2C2E' : '#1C1C1E',
                  borderRadius: 12,
                  padding: '12px 14px',
                  cursor: 'pointer',
                  border: conversaIdModal === conv.id ? '1.5px solid #00C9B8' : '1px solid #333',
                  transition: '.2s'
                }}>
                <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 13, fontWeight: 800, color: '#fff', marginBottom: 2 }}>
                  {conv.tipo === 'advogado_civil' ? '⚖️' : conv.tipo === 'advogado_criminal' ? '🔒' : '🩺'} {conv.tipo.replace('_', ' ')}
                </div>
                <div style={{ fontSize: 11, color: '#888', marginBottom: 4 }}>
                  {conv.profissional_nome || 'Aguardando profissional'}
                </div>
                <div style={{ fontSize: 10, color: conv.status === 'ativa' ? '#2E7D32' : '#888' }}>
                  {conv.status === 'ativa' ? '🟢 Ativa' : '⚪ Encerrada'}
                </div>
              </div>
            )}
            emptyComponent={<div style={{ textAlign: 'center', color: '#666', padding: 20, fontSize: 12 }}>Nenhuma conversa iniciada</div>}
          />
        </div>
      </div>

      {/* Modal Chat Overlay */}
      {conversaIdModal && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,.8)',
            zIndex: 2000,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 0,
            backdropFilter: 'blur(4px)'
          }}
          onClick={() => setConversaIdModal(null)}
        >
          <div
            style={{
              background: '#0A0A0A',
              borderRadius: 24,
              width: '95vw',
              maxWidth: 480,
              height: '90vh',
              maxHeight: '90vh',
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
              boxShadow: '0 25px 50px rgba(0,0,0,.8)',
              animation: 'slideUp .3s ease-out'
            }}
            onClick={e => e.stopPropagation()}
          >
            <ChatConsultoria
              conversaId={conversaIdModal}
              user={user}
              onEncerrar={() => {
                setConversaIdModal(null);
                carregar();
              }}
            />
          </div>
          <style>{`
            @keyframes slideUp {
              from {
                opacity: 0;
                transform: translateY(40px);
              }
              to {
                opacity: 1;
                transform: translateY(0);
              }
            }
          `}</style>
        </div>
      )}

      <BottomNav />
    </div>
  );
}