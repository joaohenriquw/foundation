import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import AnimalGenealogiaSection from "../components/AnimalGenealogiaSection";
import AnimalAnilhasSection from "../components/AnimalAnilhasSection";

const CORES_ANILHA = {
  azul_escuro: { label: "Azul Escuro", bg: "#0c3a78" },
  preto: { label: "Preto", bg: "#000" },
  verde: { label: "Verde", bg: "#15803d" },
  amarelo: { label: "Amarelo", bg: "#ca8a04" },
  laranja: { label: "Laranja", bg: "#c2410c" },
  roxo: { label: "Roxo", bg: "#6d28d9" },
  rosa: { label: "Rosa", bg: "#be185d" },
  branco: { label: "Branco", bg: "#fff", borda: "#333" },
};

const SAUDE_CFG = {
  excelente:  { label: "Excelente" },
  bom:        { label: "Bom" },
  regular:    { label: "Regular" },
  tratamento: { label: "Tratamento" },
};

const VITRINE_CFG = {
  disponivel:    { label: "Disponível",    emoji: "🟢" },
  em_negociacao: { label: "Em Negociação", emoji: "🔵" },
  reservado:     { label: "Reservado",     emoji: "🟡" },
  vendido:       { label: "Vendido",       emoji: "⚫" },
  indisponivel:  { label: "Indisponível",  emoji: "🔴" },
};

const CATEGORIA_CFG = {
  elenco_principal: { label: "Elenco Principal", emoji: "⭐" },
  reprodutor:       { label: "Reprodutor",        emoji: "♂️" },
  matriz:           { label: "Matriz",            emoji: "♀️" },
  criacao:          { label: "Criação",           emoji: "🐣" },
};

const empty = {
  nome: "", especie: "", tipo_categoria: "elenco_principal",
  data_de_nascimento: "", sexo: "macho", cor_plumagem: "", peso_gramas: "",
  saude_status: "excelente", observacoes_saude: "",
  status_vitrine: "disponivel", valor_estimado: "", foto_url: "",
  premiacoes: "", observacoes: "", anilha: "",
  combate_vitrias: 0, combate_derrotas: 0,
  origem: "filho",
  pai_id: null, pai_nome: "", mae_id: null, mae_nome: "",
  avo_paterno_id: null, avo_paterno_nome: "", avo_paterna_id: null, avo_paterna_nome: "",
  avo_materno_id: null, avo_materno_nome: "", avo_materna_id: null, avo_materna_nome: "",
  anilha_pe_cor: "", anilha_asa_numero: "",
};

const inp = { width: "100%", padding: "11px 14px", borderRadius: 10, border: `1.5px solid hsl(var(--border))`, fontSize: 13, outline: "none", boxSizing: "border-box", background: "hsl(var(--background))", color: "#FFFFFF !important" };

export default function AnimalForm() {
  const navigate = useNavigate();
  const params = new URLSearchParams(window.location.search);
  const animalId = params.get("id");

  const [form, setForm] = useState({ ...empty });
  const [user, setUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const [uploadingFoto, setUploadingFoto] = useState(false);
  const [anilhasFilhas, setAnilhasFilhas] = useState([]);
  const [anilhaSelecionada, setAnilhaSelecionada] = useState(null);
  const [anilhasGeradas, setAnilhasGeradas] = useState([]);
  const [dataTroca, setDataTroca] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(!!animalId);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    if (animalId) {
      base44.entities.Animal.filter({ id: animalId }).then(res => {
        if (res[0]) setForm(res[0]);
        setLoading(false);
      });
    }
  }, [animalId]);

  useEffect(() => {
    if (user?.email && form.origem === "filho") {
      base44.entities.AnilhaFilha.filter({ usuario_email: user.email, status: "incubando" }, "-created_date", 100).then(setAnilhasFilhas);
    }
  }, [user?.email, form.origem]);

  const gerarAnilhas = (cor, quantidade = 10) => {
    const novas = Array.from({ length: quantidade }, (_, i) => ({
      id: `temp-${Date.now()}-${i}`,
      cor: cor,
    }));
    setAnilhasGeradas(prev => [...prev, ...novas]);
  };

  const deletarAnilha = (id) => {
    setAnilhasGeradas(prev => prev.filter(a => a.id !== id));
  };

  const handleUploadFoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingFoto(true);
    const res = await base44.integrations.Core.UploadFile({ file });
    setForm(p => ({ ...p, foto_url: res.file_url }));
    setUploadingFoto(false);
  };

  const salvar = async () => {
    if (!form.nome) {
      toast.error("⚠️ Nome do animal é obrigatório");
      return;
    }
    if (form.origem === "filho" && (!form.pai_id || !form.mae_id)) {
      toast.error("⚠️ Genealogia obrigatória: Pai e Mãe devem ser selecionados");
      return;
    }
    if (form.origem === "filho" && !dataTroca) {
      toast.error("⚠️ Escolha a data de notificação");
      return;
    }
    if (form.origem === "adulto" && !form.anilha) {
      toast.error("⚠️ Número da anilha obrigatório para adultos");
      return;
    }
    setSaving(true);
    const payload = {
      ...form,
      peso_gramas:    form.peso_gramas    ? Number(form.peso_gramas)    : null,
      valor_estimado: form.valor_estimado ? Number(form.valor_estimado) : null,
      proprietario_email: user?.email,
      proprietario_id:    user?.id,
      proprietario_nome:  user?.full_name || user?.email,
    };
    try {
      let animalId_saved = animalId;
      if (animalId) {
        await base44.entities.Animal.update(animalId, payload);
        toast.success("✅ Registro atualizado!");
      } else {
        const newAnimal = await base44.entities.Animal.create(payload);
        animalId_saved = newAnimal.id;
        toast.success("✅ Animal registrado com sucesso!");
      }
      
      if (form.origem === "filho") {
        for (const anilha of anilhasGeradas) {
          await base44.entities.AnilhaFilha.create({
            usuario_id: user?.id,
            usuario_email: user?.email,
            tipo: "filha",
            animal_pai_id: form.pai_id,
            animal_pai_nome: form.pai_nome,
            animal_mae_id: form.mae_id,
            animal_mae_nome: form.mae_nome,
            anilha_numero: anilha.numero,
            cor_anilha_definitiva: anilha.cor,
            data_criacao: new Date().toISOString().split('T')[0],
            data_troca_definitiva: dataTroca,
            status: "incubando",
          });
        }
      }
      
      navigate("/", { replace: true });
    } catch (e) {
      toast.error("❌ Erro ao salvar. Tente novamente.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#000", color: "#fff" }}>
      Carregando...
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "hsl(var(--background))", fontFamily: "'DM Sans', -apple-system, sans-serif", color: "hsl(var(--foreground))", overflowX: "hidden", width: "100%" }}>
      {/* Header */}
      <div style={{ position: "sticky", top: 0, background: "hsl(var(--background))", borderBottom: `1px solid hsl(var(--border))`, padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", zIndex: 10 }}>
        <button onClick={() => navigate("/", { replace: true })} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "hsl(var(--foreground))", minWidth: 44, minHeight: 44, display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 15, fontWeight: 900, color: "hsl(var(--primary))" }}>
          {animalId ? "Editar Registro" : "Novo Cadastro"}
        </div>
        <button onClick={() => navigate("/", { replace: true })} style={{ background: "none", border: "none", fontSize: 18, cursor: "pointer", color: "hsl(var(--muted-foreground))", minWidth: 44, minHeight: 44, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
      </div>

      {/* Conteúdo */}
      <div style={{ padding: "16px", maxWidth: 600, margin: "0 auto", paddingBottom: 100, boxSizing: "border-box", width: "100%", overflowX: "hidden" }}>
        <div style={{ display: "grid", gap: 12 }}>

          {/* SELETOR DE ORIGEM */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", marginBottom: 8 }}>Qual a origem deste animal?</div>
            <div style={{ display: "flex", gap: 8, width: "100%", boxSizing: "border-box" }}>
              {[["filho", "🐣 Ninhada"], ["adulto", "🐓 Adulto"]].map(([k, label]) => (
                <button key={k} onClick={() => { setForm(p => ({ ...p, origem: k })); setAnilhaSelecionada(null); }}
                  style={{ flex: 1, padding: "8px 6px", borderRadius: 8, border: `2px solid ${form.origem === k ? "hsl(var(--primary))" : "hsl(var(--border))"}`, background: form.origem === k ? "hsl(var(--primary))" : "transparent", color: form.origem === k ? "hsl(var(--primary-foreground))" : "hsl(var(--foreground))", cursor: "pointer", fontSize: 12, fontWeight: 700, transition: ".15s", minHeight: 36 }}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Seletor de Cor - só para filhos */}
           {form.origem === "filho" && (
             <div>
               <label style={{ fontSize: 10, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", marginBottom: 6, display: "block" }}>🎨 Cor da Anilha Definitiva</label>
               <div style={{ display: "flex", gap: 5, flexWrap: "wrap", paddingBottom: 2, width: "100%", boxSizing: "border-box" }}>
                 {Object.entries(CORES_ANILHA).map(([key, cor]) => (
                   <button key={key} onClick={() => { setForm(p => ({ ...p, anilha_pe_cor: key })); setAnilhasGeradas([]); gerarAnilhas(key); }}
                     style={{ width: 20, height: 20, minWidth: 20, minHeight: 20, borderRadius: "50%", border: form.anilha_pe_cor === key ? `3px solid #00C9B8` : `2px solid ${cor.borda || "rgba(255,255,255,0.2)"}`, background: cor.bg, cursor: "pointer", flexShrink: 0, outline: "none", padding: 0 }} title={cor.label} />
                 ))}
               </div>
               {form.anilha_pe_cor && <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", marginTop: 6, fontWeight: 600 }}>{CORES_ANILHA[form.anilha_pe_cor].label}</div>}
             </div>
           )}

          {/* Anilhas Geradas */}
          {anilhasGeradas.length > 0 && form.origem === "filho" && (
            <div>
              <div style={{ fontSize: 10, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", marginBottom: 8, display: "flex", justifyContent: "space-between" }}>
                <span>🏷️ NÚMEROS DAS ANILHAS</span>
                <span style={{ color: "#00C9B8" }}>{anilhasGeradas.length}</span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4, marginBottom: 8 }}>
                {anilhasGeradas.map((a, idx) => {
                  const corCfg = CORES_ANILHA[form.anilha_pe_cor];
                  const dotColor = corCfg ? corCfg.bg : "#FF6B7A";
                  return (
                    <div key={a.id} style={{ display: "grid", gridTemplateColumns: "20px 1fr 36px", gap: 6, alignItems: "center", boxSizing: "border-box" }}>
                      <div style={{ width: 10, height: 10, minWidth: 10, minHeight: 10, borderRadius: "50%", background: dotColor, justifySelf: "center" }} />
                      <input
                        type="text"
                        placeholder={"Anilha " + (idx + 1)}
                        onChange={e => {
                          const updated = [...anilhasGeradas];
                          updated[idx] = { ...updated[idx], numero: e.target.value };
                          setAnilhasGeradas(updated);
                        }}
                        value={a.numero || ""}
                        style={{ width: "100%", padding: "6px 8px", borderRadius: 6, border: "1px solid hsl(var(--border))", background: "hsl(var(--background))", color: "hsl(var(--foreground))", fontSize: 12, outline: "none", boxSizing: "border-box" }}
                      />
                      <button
                        onClick={() => deletarAnilha(a.id)}
                        style={{ width: 32, height: 32, minWidth: 32, minHeight: 32, background: "#E21C3D", border: "none", borderRadius: 6, color: "#fff", cursor: "pointer", fontSize: 14, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}
                      >✕</button>
                    </div>
                  );
                })}
              </div>
              <button onClick={() => gerarAnilhas(form.anilha_pe_cor, 1)}
                style={{ width: "100%", padding: "7px", borderRadius: 7, border: "1px dashed #00C9B8", background: "transparent", color: "#00C9B8", cursor: "pointer", fontWeight: 700, fontSize: 11 }}>+ Adicionar</button>
            </div>
          )}

          {/* Foto */}
          <div>
            {form.foto_url && (
              <div style={{ marginBottom: 10, borderRadius: 14, overflow: "hidden", height: 150, backgroundImage: "url(" + form.foto_url + ")", backgroundSize: "cover", backgroundPosition: "center" }} />
            )}
            <label style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "9px 20px", borderRadius: 8, cursor: "pointer", background: "linear-gradient(135deg,hsl(var(--primary)),#00A893)", fontSize: 12, fontWeight: 700, color: "hsl(var(--primary-foreground))", width: "100%", boxSizing: "border-box" }}>
              📷 {form.foto_url ? "Trocar foto" : "Adicionar foto"}
              <input type="file" accept="image/*" onChange={handleUploadFoto} disabled={uploadingFoto} style={{ display: "none" }} />
            </label>
            {uploadingFoto && <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", marginTop: 6, textAlign: "center" }}>⏳ Enviando...</div>}
          </div>

          {/* Data de Troca - apenas para filhos */}
          {form.origem === "filho" && (
            <div style={{ marginTop: 4 }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>📅 Data para Registrar com 30 dias *</label>
              <input type="date" value={dataTroca || ""}
                onChange={e => setDataTroca(e.target.value)}
                style={{ ...inp, colorScheme: "light" }} />
              <div style={{ fontSize: 11, color: "hsl(var(--muted-foreground))", marginTop: 4, lineHeight: 1.4 }}>Quando essa data chegar, você receberá uma notificação e cada anilha se tornará um cadastro automático.</div>
            </div>
          )}

          {/* Nome - apenas para adultos */}
          {form.origem === "adulto" && (
            <input type="text" value={form.nome || ""} placeholder="Nome do animal *"
              onChange={e => setForm(p => ({ ...p, nome: e.target.value }))}
              style={inp} />
          )}

          {/* SEÇÕES ADICIONAIS - Apenas para ADULTOS */}
          {form.origem === "adulto" && (
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>🔢 Número da Anilha *</label>
              <input type="text" value={form.anilha || ""} placeholder="Ex: BR-2024-001234"
                onChange={e => setForm(p => ({ ...p, anilha: e.target.value }))}
                style={inp} />
            </div>
          )}

          {/* Genealogia - apenas se Filho */}
          {form.origem === "filho" && (
            <div style={{ background: "hsl(var(--muted))", borderRadius: 12, padding: 12, border: "1px solid hsl(var(--border))" }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--primary))", textTransform: "uppercase", marginBottom: 10 }}>👨‍👩‍👧 GENEALOGIA (OBRIGATÓRIO)</div>
              <AnimalGenealogiaSection form={form} setForm={setForm} userEmail={user?.email} />
            </div>
          )}

          {form.origem === "adulto" && (
            <>
          {/* Data de Nascimento */}
          <div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", display: "block", marginBottom: 6 }}>📅 Data de Nascimento</label>
            <input type="date" value={form.data_de_nascimento || ""}
              onChange={e => setForm(p => ({ ...p, data_de_nascimento: e.target.value }))}
              style={{ ...inp, colorScheme: "light" }} />
          </div>

          {/* Cor Plumagem */}
          <input type="text" value={form.cor_plumagem || ""} placeholder="Cor / Plumagem"
            onChange={e => setForm(p => ({ ...p, cor_plumagem: e.target.value }))}
            style={inp} />

          {/* Peso e Valor */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <input type="number" value={form.peso_gramas || ""} placeholder="Peso (g)"
              onChange={e => setForm(p => ({ ...p, peso_gramas: e.target.value }))}
              style={inp} />
            <input type="number" value={form.valor_estimado || ""} placeholder="Valor estimado (R$)"
              onChange={e => setForm(p => ({ ...p, valor_estimado: e.target.value }))}
              style={inp} />
          </div>

          {/* Sexo */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", marginBottom: 8 }}>Sexo</div>
            <div style={{ display: "flex", gap: 8 }}>
              {[["macho", "♂️ Macho"], ["femea", "♀️ Fêmea"]].map(([k, label]) => (
                <button key={k} onClick={() => setForm(p => ({ ...p, sexo: k }))}
                  style={{ flex: 1, padding: "10px", borderRadius: 10, border: "none", background: form.sexo === k ? "hsl(var(--primary))" : "hsl(var(--muted))", color: form.sexo === k ? "hsl(var(--primary-foreground))" : "hsl(var(--muted-foreground))", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Categoria */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", marginBottom: 8 }}>Categoria</div>
            <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
              {Object.entries(CATEGORIA_CFG).map(([k, c]) => (
                <button key={k} onClick={() => setForm(p => ({ ...p, tipo_categoria: k }))}
                  style={{ padding: "8px 10px", borderRadius: 10, border: "none", background: form.tipo_categoria === k ? "hsl(var(--primary))" : "hsl(var(--muted))", color: form.tipo_categoria === k ? "hsl(var(--primary-foreground))" : "hsl(var(--muted-foreground))", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                  {c.emoji} {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Saúde */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", marginBottom: 8 }}>Saúde</div>
            <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
              {Object.entries(SAUDE_CFG).map(([k, c]) => (
                <button key={k} onClick={() => setForm(p => ({ ...p, saude_status: k }))}
                  style={{ padding: "8px 10px", borderRadius: 10, border: "none", background: form.saude_status === k ? "hsl(var(--primary))" : "hsl(var(--muted))", color: form.saude_status === k ? "hsl(var(--primary-foreground))" : "hsl(var(--muted-foreground))", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Obs saúde */}
          <textarea value={form.observacoes_saude || ""} placeholder="Observações de saúde (opcional)"
           onChange={e => setForm(p => ({ ...p, observacoes_saude: e.target.value }))}
           style={{ ...inp, height: 70, resize: "none", color: "#FFFFFF !important" }} />

          {/* Status Vitrine */}
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", textTransform: "uppercase", marginBottom: 8 }}>Status na Vitrine</div>
            <div style={{ display: "flex", gap: 7, flexWrap: "wrap" }}>
              {Object.entries(VITRINE_CFG).map(([k, c]) => (
                <button key={k} onClick={() => setForm(p => ({ ...p, status_vitrine: k }))}
                  style={{ padding: "8px 10px", borderRadius: 10, border: "none", background: form.status_vitrine === k ? "hsl(var(--primary))" : "hsl(var(--muted))", color: form.status_vitrine === k ? "hsl(var(--primary-foreground))" : "hsl(var(--muted-foreground))", cursor: "pointer", fontSize: 11, fontWeight: 700 }}>
                  {c.emoji} {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Observações */}
          <textarea value={form.observacoes || ""} placeholder="Observações gerais (opcional)"
           onChange={e => setForm(p => ({ ...p, observacoes: e.target.value }))}
           style={{ ...inp, height: 70, resize: "none", color: "#FFFFFF !important" }} />
            </>
          )}
        </div>
      </div>

      {/* Botão fixo */}
      <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, padding: "14px 16px", background: "hsl(var(--background))", borderTop: "1px solid hsl(var(--border))" }}>
        <button onClick={salvar}
          style={{ width: "100%", padding: "13px", borderRadius: 12, border: "none", background: saving ? "hsl(var(--muted))" : "linear-gradient(135deg,hsl(var(--primary)),#00A893)", color: saving ? "hsl(var(--muted-foreground))" : "hsl(var(--primary-foreground))", cursor: saving ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
          {saving ? "Salvando..." : "✓ Salvar Cadastro"}
        </button>
      </div>
    </div>
  );
}