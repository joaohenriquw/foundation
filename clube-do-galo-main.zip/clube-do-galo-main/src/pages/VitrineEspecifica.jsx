import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import NotificacoesSino from "../components/NotificacoesSino";
import BottomNav from "../components/BottomNav";

const fmt = (v) => v != null ? "R$ " + Number(v).toFixed(2).replace(".", ",") : "—";
const diasAteExpiracao = (dataExp) => {
  const hoje = new Date();
  const expira = new Date(dataExp + "T23:59:59");
  const diff = Math.ceil((expira - hoje) / (1000 * 60 * 60 * 24));
  return diff;
};

export default function VitrineEspecifica() {
  const { proprietarioId } = useParams();
  const navigate = useNavigate();
  const [animais, setAnimais] = useState([]);
  const [proprietario, setProprietario] = useState(null);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);

      // Buscar exposições deste proprietário (não expiradas)
      const hoje = new Date().toISOString().split('T')[0];
      const allExp = await base44.entities.VitrineExposicao.filter({ proprietario_id: proprietarioId, ativa: true }, "-created_date", 200);
      const validas = allExp.filter(e => e.data_expiracao >= hoje);

      // Usar nome do proprietário da própria exposição
      if (validas[0]) setProprietario({ full_name: validas[0].proprietario_nome });

      setAnimais(validas);
      setLoading(false);
    };
    init();

    const unsub = base44.entities.VitrineExposicao.subscribe(() => {
      init();
    });
    return unsub;
  }, [proprietarioId]);

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px 24px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Link to="/vitrine" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none" }}>←</Link>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>
                🐓 {proprietario?.nome_criatório || proprietario?.full_name || "Criatório"}
              </div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>{animais.length} animal{animais.length !== 1 ? "is" : ""} expostos</div>
            </div>
          </div>
          {user && <NotificacoesSino userEmail={user.email} />}
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 800, margin: "0 auto" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#57636C" }}>Carregando...</div>
        ) : animais.length === 0 ? (
          <div style={{ textAlign: "center", padding: 48 }}>
            <div style={{ fontSize: 52, marginBottom: 12 }}>🐓</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "#101213" }}>Sem animais expostos</div>
            <div style={{ fontSize: 12, color: "#57636C", marginTop: 6 }}>Este criatório não tem animais na vitrine no momento</div>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 14 }}>
            {animais.map(a => {
              const dias = diasAteExpiracao(a.data_expiracao);
              const urgente = dias < 7;
              return (
                <div key={a.id} style={{ background: "#fff", borderRadius: 14, border: "1px solid #E8ECF0", overflow: "hidden" }}>
                  <div style={{ height: 160, background: a.animal_foto_url ? `url(${a.animal_foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                    {!a.animal_foto_url && <span style={{ fontSize: 48 }}>🐓</span>}
                    <div style={{ position: "absolute", bottom: 8, right: 8, background: urgente ? "#C62828" : "rgba(0,0,0,.6)", borderRadius: 8, padding: "3px 8px", fontSize: 10, color: "#fff", fontWeight: 700 }}>
                      {urgente ? "⏰ " : "📅 "} Expira em {dias}d
                    </div>
                  </div>

                  <div style={{ padding: "12px 14px" }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 2 }}>
                      {a.animal_nome}
                    </div>
                    <div style={{ fontSize: 11, color: "#57636C", marginBottom: 4 }}>
                      Anilha: {a.animal_anilha} · {a.animal_especie || "—"}
                    </div>
                    {a.descricao && (
                      <div style={{ fontSize: 11, color: "#57636C", marginBottom: 8, lineHeight: 1.5 }}>
                        {a.descricao}
                      </div>
                    )}

                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 8 }}>
                      {a.animal_valor ? (
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>
                          {fmt(a.animal_valor)}
                        </div>
                      ) : <div />}
                      <button onClick={() => navigate(`/animal/${a.animal_id}`)}
                        style={{ padding: "6px 12px", borderRadius: 8, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", fontSize: 11, fontWeight: 800, cursor: "pointer", fontFamily: "Montserrat,sans-serif" }}>
                        Ver perfil →
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}