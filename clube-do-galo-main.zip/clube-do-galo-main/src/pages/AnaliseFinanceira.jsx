import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import NotificacoesSino from "../components/NotificacoesSino";
import BottomNav from "../components/BottomNav";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");
const meses = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

export default function AnaliseFinanceira() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [fluxoCaixa, setFluxoCaixa] = useState([]);
  const [receitas, setReceitas] = useState([]);
  const [lucroLotes, setLucroLotes] = useState([]);
  const [stats, setStats] = useState({ receita: 0, gasto: 0, lucro: 0 });

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);

      if (!me) {
        setLoading(false);
        return;
      }

      // Buscar transações, leilões e rifas do usuário
      const [transacoes, leiloes, rifas, bilhetes, animais] = await Promise.all([
        base44.entities.Transacao.filter({}, "-created_date", 500),
        base44.entities.Leilao.filter({ dono_email: me.email }, "-created_date", 500),
        base44.entities.Rifa.filter({ dono_email: me.email }, "-created_date", 500),
        base44.entities.RifaBilhete.filter({}, "-created_date", 500),
        base44.entities.Animal.filter({ proprietario_email: me.email }, "-created_date", 500),
      ]);

      // Calcular fluxo de caixa por mês (últimos 12 meses)
      const agora = new Date();
      const fluxo = {};
      for (let i = 11; i >= 0; i--) {
        const data = new Date(agora.getFullYear(), agora.getMonth() - i, 1);
        const mesAno = `${meses[data.getMonth()]}/${data.getFullYear()}`;
        fluxo[mesAno] = { mes: mesAno, receita: 0, gasto: 0 };
      }

      // Processar leilões (receitas quando status = encerrado e com ganhador)
      let totalReceitaLeiloes = 0;
      for (const l of leiloes.filter(l => l.status === "encerrado" && l.maior_lance)) {
        const data = new Date(l.data_fim);
        const mesAno = `${meses[data.getMonth()]}/${data.getFullYear()}`;
        if (fluxo[mesAno]) {
          fluxo[mesAno].receita += l.maior_lance;
          totalReceitaLeiloes += l.maior_lance;
        }
      }

      // Processar rifas (receitas de bilhetes vendidos)
      let totalReceitaRifas = 0;
      for (const r of rifas.filter(r => r.status === "encerrada")) {
        const data = new Date(r.data_sorteio);
        const mesAno = `${meses[data.getMonth()]}/${data.getFullYear()}`;
        const receitaRifa = r.total_arrecadado || r.numeros_vendidos * r.valor_por_numero;
        if (fluxo[mesAno]) {
          fluxo[mesAno].receita += receitaRifa;
          totalReceitaRifas += receitaRifa;
        }
      }

      // Estimar gastos com base em animais (ração ~R$50/mês, vet ~R$30/semestre por animal)
      let totalGastos = 0;
      for (const animal of animais) {
        const mesesPosse = Math.floor((agora - new Date(animal.created_date)) / (1000 * 60 * 60 * 24 * 30));
        const gastoRacao = 50; // R$50/mês estimado
        const gastoVet = 30 / 6; // R$30 a cada 6 meses
        const gastoMensal = gastoRacao + gastoVet;
        
        for (let i = 11; i >= Math.max(0, 11 - mesesPosse); i--) {
          const data = new Date(agora.getFullYear(), agora.getMonth() - i, 1);
          const mesAno = `${meses[data.getMonth()]}/${data.getFullYear()}`;
          if (fluxo[mesAno]) {
            fluxo[mesAno].gasto += gastoMensal;
            totalGastos += gastoMensal;
          }
        }
      }

      // Calcular lucro por lote (agrupando animais por tipo_categoria)
      const lotes = {};
      for (const animal of animais) {
        const lote = animal.tipo_categoria || "Sem categoria";
        if (!lotes[lote]) {
          lotes[lote] = { lote, animais: 0, receita: 0, gasto: 0 };
        }
        lotes[lote].animais += 1;
        
        // Estimar receita por animal vendido
        const leilaoAnimal = leiloes.find(l => l.animal_id === animal.id && l.status === "encerrado");
        if (leilaoAnimal) {
          lotes[lote].receita += leilaoAnimal.maior_lance;
        }
        
        // Estimar gasto por animal
        const mesesPosse = Math.floor((agora - new Date(animal.created_date)) / (1000 * 60 * 60 * 24 * 30));
        const gastoAnimal = (50 + 5) * Math.max(1, mesesPosse); // R$55/mês
        lotes[lote].gasto += gastoAnimal;
      }

      const dataLotes = Object.values(lotes).map(l => ({
        ...l,
        lucro: l.receita - l.gasto,
      })).sort((a, b) => b.receita - a.receita);

      const dataReceitas = [
        { nome: "Leilões", valor: totalReceitaLeiloes, fill: "#170073" },
        { nome: "Rifas", valor: totalReceitaRifas, fill: "#00A893" },
      ].filter(r => r.valor > 0);

      setFluxoCaixa(Object.values(fluxo));
      setReceitas(dataReceitas);
      setLucroLotes(dataLotes);
      setStats({
        receita: totalReceitaLeiloes + totalReceitaRifas,
        gasto: totalGastos,
        lucro: (totalReceitaLeiloes + totalReceitaRifas) - totalGastos,
      });

      setLoading(false);
    };

    init();
  }, []);

  if (loading) {
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", color: "#57636C" }}>
        Carregando análises...
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "16px 16px", position: "sticky", top: 0, zIndex: 10 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: 800, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button onClick={() => navigate(-1)} style={{ background: "#1C1C1E", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", fontSize: 18, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#fff" }}>📊 Análise Financeira</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,.75)" }}>Últimos 12 meses</div>
            </div>
          </div>
          {user && <NotificacoesSino userEmail={user.email} />}
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 800, margin: "0 auto" }}>
        {/* Cards de resumo */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 20 }}>
          {[
            { label: "Receita Total", valor: stats.receita, cor: "#00A893", icon: "📈" },
            { label: "Gastos", valor: stats.gasto, cor: "#E21C3D", icon: "📉" },
            { label: "Lucro", valor: stats.lucro, cor: "#170073", icon: "💰" },
          ].map((card, i) => (
            <div key={i} style={{ background: "#fff", borderRadius: 12, border: "1px solid #E8ECF0", padding: 12 }}>
              <div style={{ fontSize: 18, marginBottom: 4 }}>{card.icon}</div>
              <div style={{ fontSize: 10, color: "#57636C", fontWeight: 700, marginBottom: 4 }}>{card.label}</div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: card.cor }}>
                {fmt(card.valor)}
              </div>
            </div>
          ))}
        </div>

        {/* Fluxo de Caixa */}
        <div style={{ background: "#fff", borderRadius: 12, border: "1px solid #E8ECF0", padding: 12, marginBottom: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213", marginBottom: 12 }}>
            📈 Fluxo de Caixa Mensal
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={fluxoCaixa}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E8ECF0" />
              <XAxis dataKey="mes" stroke="#57636C" style={{ fontSize: 11 }} />
              <YAxis stroke="#57636C" style={{ fontSize: 11 }} />
              <Tooltip 
                contentStyle={{ background: "#fff", border: "1px solid #E8ECF0", borderRadius: 8 }}
                formatter={(v) => fmt(v)}
              />
              <Legend />
              <Line type="monotone" dataKey="receita" stroke="#00A893" strokeWidth={2} name="Receita" />
              <Line type="monotone" dataKey="gasto" stroke="#E21C3D" strokeWidth={2} name="Gasto" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Comparativo Receita */}
        {receitas.length > 0 && (
          <div style={{ background: "#fff", borderRadius: 12, border: "1px solid #E8ECF0", padding: 12, marginBottom: 16 }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213", marginBottom: 12 }}>
              🎯 Receita por Tipo
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={receitas} cx="50%" cy="50%" labelLine={false} label={({ nome, valor }) => `${nome}: ${fmt(valor)}`} outerRadius={70}>
                  {receitas.map((entry, idx) => (
                    <Cell key={idx} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip formatter={(v) => fmt(v)} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Lucro por Lote */}
        {lucroLotes.length > 0 && (
          <div style={{ background: "#fff", borderRadius: 12, border: "1px solid #E8ECF0", padding: 12, marginBottom: 16 }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213", marginBottom: 12 }}>
              📊 Lucro por Lote
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={lucroLotes}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8ECF0" />
                <XAxis dataKey="lote" stroke="#57636C" style={{ fontSize: 11 }} />
                <YAxis stroke="#57636C" style={{ fontSize: 11 }} />
                <Tooltip 
                  contentStyle={{ background: "#fff", border: "1px solid #E8ECF0", borderRadius: 8 }}
                  formatter={(v) => fmt(v)}
                />
                <Legend />
                <Bar dataKey="receita" fill="#00A893" name="Receita" />
                <Bar dataKey="gasto" fill="#E21C3D" name="Gasto" />
                <Bar dataKey="lucro" fill="#170073" name="Lucro" />
              </BarChart>
            </ResponsiveContainer>

            {/* Tabela de detalhe */}
            <div style={{ marginTop: 16, display: "grid", gap: 8 }}>
              {lucroLotes.map(l => (
                <div key={l.lote} style={{ background: "#F8FAFC", borderRadius: 8, padding: 10, display: "grid", gridTemplateColumns: "1fr auto auto auto", gap: 10, alignItems: "center" }}>
                  <div style={{ fontWeight: 700, color: "#101213", fontSize: 12 }}>{l.lote}</div>
                  <div style={{ textAlign: "center" }}>
                    <div style={{ fontSize: 9, color: "#57636C" }}>Animais</div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 800, color: "#101213" }}>{l.animais}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 9, color: "#57636C" }}>Receita</div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 800, color: "#00A893" }}>{fmt(l.receita)}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 9, color: "#57636C" }}>Lucro</div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 800, color: l.lucro >= 0 ? "#170073" : "#E21C3D" }}>{fmt(l.lucro)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Empty state */}
        {lucroLotes.length === 0 && receitas.length === 0 && (
          <div style={{ textAlign: "center", padding: 40, background: "#fff", borderRadius: 12, border: "1px solid #E8ECF0" }}>
            <div style={{ fontSize: 40, marginBottom: 10 }}>📊</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 700, color: "#101213" }}>Sem dados para análise</div>
            <div style={{ fontSize: 12, color: "#57636C", marginTop: 6 }}>Complete alguns leilões ou rifas para ver as análises</div>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}