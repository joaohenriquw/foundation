import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import ModalPixRifa from "../components/ModalPixRifa";
import BottomNav from "../components/BottomNav";
import AvaliacaoModal from "../components/AvaliacaoModal";
import { jsPDF } from "jspdf";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

function BarraProgresso({ vendidos, total }) {
  const pct = total > 0 ? Math.min((vendidos / total) * 100, 100) : 0;
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#57636C", marginBottom: 4 }}>
        <span>{vendidos.toLocaleString("pt-BR")} de {total.toLocaleString("pt-BR")} números</span>
        <span style={{ fontWeight: 700 }}>{pct.toFixed(1)}%</span>
      </div>
      <div style={{ height: 8, borderRadius: 6, background: "#E8ECF0", overflow: "hidden" }}>
        <div style={{ height: "100%", borderRadius: 6, width: `${pct}%`, background: "linear-gradient(90deg,#170073,#00A893)", transition: ".4s" }} />
      </div>
    </div>
  );
}

export default function RifaDetalhe() {
  const { id }              = useParams();
  const [rifa, setRifa]     = useState(null);
  const [bilhetes, setBilhetes] = useState([]);
  const [user, setUser]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState(false);
  const [qtdCompra, setQtdCompra] = useState(1);
  const [whatsapp, setWhatsapp] = useState("");

  // Dono: encerrar / extender prazo / inserir resultado
  const [modalResultado, setModalResultado] = useState(false);
  const [resultado, setResultado] = useState("");
  const [savingResultado, setSavingResultado] = useState(false);
  const [cpfInput, setCpfInput] = useState("");
  const [mostraCpfModal, setMostraCpfModal] = useState(false);
  const [cpfValidado, setCpfValidado] = useState(null);
  const [mostraModalPix, setMostraModalPix] = useState(false);
  
  // Avaliação
  const [mostraAvaliacao, setMostraAvaliacao] = useState(false);
  const [jaAvaliou, setJaAvaliou] = useState(false);

  const carregar = async () => {
    const [r, me, b] = await Promise.all([
      base44.entities.Rifa.filter({ id }),
      base44.auth.me().catch(() => null),
      base44.entities.RifaBilhete.filter({ rifa_id: id }, "-created_date", 500),
    ]);
    const rifaData = r[0];
    setRifa(rifaData);
    setUser(me);
    setBilhetes(b);
    setLoading(false);
    
    // Verificar se já avaliou
    if (me && rifaData?.status === "encerrada" && me.id === rifaData.ganhador_id) {
      const aval = await base44.entities.Avaliacao.filter({ tipo: "rifa", referencia_id: id, comprador_email: me.email });
      if (aval.length > 0) setJaAvaliou(true);
      else setMostraAvaliacao(true);
    }
  };

  useEffect(() => {
    carregar();
    const unsub = base44.entities.RifaBilhete.subscribe(() => carregar());
    return unsub;
  }, [id]);

  const abrirModalPix = () => {
    setMostraModalPix(true);
  };

  const comprar = async (metodo = "carteira") => {
    if (!user || !rifa || buying) return;
    
    setBuying(true);
    try {
      const valorTotal = qtdCompra * rifa.valor_por_numero;
      const me = await base44.auth.me();
      const saldoCarteira = me?.saldo_carteira || 0;
      
      if (saldoCarteira >= valorTotal) {
        // Débito da carteira
        await base44.auth.updateMe({ saldo_carteira: saldoCarteira - valorTotal });
      } else {
        // Saldo insuficiente, abrir modal PIX
        setBuying(false);
        abrirModalPix();
        return;
      }
      
      // Limpa modais e gera números aleatórios disponíveis
      setMostraModalPix(false);
      const numerosUsados = new Set(bilhetes.map(b => b.numero));
      const numerosDisponiveis = [];
      let tentativas = 0;
      while (numerosDisponiveis.length < qtdCompra && tentativas < 10000) {
        const n = Math.floor(Math.random() * rifa.qtd_numeros) + 1;
        if (!numerosUsados.has(n)) {
          numerosUsados.add(n);
          numerosDisponiveis.push(n);
        }
        tentativas++;
      }
      
      for (const num of numerosDisponiveis) {
        await base44.entities.RifaBilhete.create({
          rifa_id:          rifa.id,
          numero:           num,
          comprador_id:     user.id,
          comprador_nome:   user.full_name,
          comprador_email:  user.email,
          comprador_whatsapp: whatsapp,
          valor_pago:       rifa.valor_por_numero,
          status:           "pago",
        });
      }
      
      // Atualiza contadores da rifa
      const novosVendidos = (rifa.numeros_vendidos || 0) + numerosDisponiveis.length;
      const novoTotal = novosVendidos * rifa.valor_por_numero;
      await base44.entities.Rifa.update(rifa.id, {
        numeros_vendidos: novosVendidos,
        total_arrecadado: novoTotal,
      });
      
      carregar();
    } catch (e) {
      alert("Erro na compra: " + e.message);
    } finally {
      setBuying(false);
    }
  };

  const estenderPrazo = async (novaData) => {
    if (rifa.prazo_estendido) return alert("O prazo desta rifa já foi estendido uma vez e não pode ser alterado novamente.");
    await base44.entities.Rifa.update(rifa.id, { data_sorteio: novaData, prazo_estendido: true });
    carregar();
  };

  const realizarSorteio = async () => {
    if (!resultado.trim()) return;
    setSavingResultado(true);
    // Determina ganhador pelo resultado (número sorteado)
    const numSorteado = parseInt(resultado.replace(/\D/g, "").slice(-5)) % rifa.qtd_numeros + 1;
    const bilheteGanhador = bilhetes.find(b => b.numero === numSorteado) || bilhetes[0];
    if (!bilheteGanhador) { setSavingResultado(false); return alert("Nenhum bilhete vendido!"); }

    const ganh_id = bilheteGanhador.comprador_id;
    const ganh_nome = bilheteGanhador.comprador_nome;
    const ganh_email = bilheteGanhador.comprador_email;

    await base44.entities.Rifa.update(rifa.id, {
     status:           "encerrada",
     resultado_loteria: resultado,
     ganhador_id:      ganh_id,
     ganhador_nome:    ganh_nome,
     ganhador_email:   ganh_email,
     ganhador_numero:  bilheteGanhador.numero,
    });

    // Notificação para o ganhador
    await base44.entities.Notificacao.create({
      destinatario_email: ganh_email,
      titulo: "🏆 Você ganhou a rifa!",
      mensagem: `Parabéns! Você foi sorteado na rifa "${rifa.titulo || rifa.animal_nome}" com o número ${bilheteGanhador.numero}. Entre em contato com o dono via WhatsApp!`,
      tipo: "rifa",
      icone: "🏆",
      link: `/rifa/${rifa.id}`,
    });

    setSavingResultado(false);
    setModalResultado(false);
    carregar();
  };

  const meusBilhetes = user ? bilhetes.filter(b => b.comprador_id === user.id) : [];
  const isDono = user && rifa && user.email === rifa.dono_email;

  const baixarComprovante = () => {
    const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const azul = [23, 0, 115];
    const verde = [0, 168, 147];
    const cinza = [87, 99, 108];

    // Fundo header
    doc.setFillColor(...azul);
    doc.rect(0, 0, 210, 45, "F");

    // Gradiente simulado
    doc.setFillColor(...verde);
    doc.rect(150, 0, 60, 45, "F");

    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(22);
    doc.text("CLUBE DO GALO", 14, 18);
    doc.setFontSize(11);
    doc.setFont("helvetica", "normal");
    doc.text("Comprovante de Participação em Rifa", 14, 27);
    doc.setFontSize(9);
    doc.text(`Emitido em: ${new Date().toLocaleString("pt-BR")}`, 14, 35);

    // ID do comprovante
    doc.setFontSize(9);
    doc.text(`Nº ${rifa.id?.slice(-8).toUpperCase()}`, 165, 35);

    // Caixa dados da rifa
    doc.setFillColor(240, 244, 255);
    doc.roundedRect(14, 52, 182, 36, 4, 4, "F");
    doc.setTextColor(...azul);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.text(rifa.titulo || rifa.animal_nome, 20, 63);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(...cinza);
    doc.text(`Animal: ${rifa.animal_nome}  |  Anilha: ${rifa.animal_anilha}`, 20, 72);
    doc.text(`Data do sorteio: ${rifa.data_sorteio ? new Date(rifa.data_sorteio + "T12:00:00").toLocaleDateString("pt-BR") : "—"}  |  ${rifa.tipo_sorteio === "manual" ? "Loteria Federal" : "Sorteio Automático"}`, 20, 80);

    // Dados do comprador
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(14, 95, 182, 30, 4, 4, "F");
    doc.setTextColor(...azul);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("DADOS DO PARTICIPANTE", 20, 105);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(...cinza);
    doc.text(`Nome: ${user?.full_name || user?.email}`, 20, 113);
    doc.text(`E-mail: ${user?.email}`, 20, 120);

    // Tabela de números
    doc.setFillColor(...azul);
    doc.roundedRect(14, 132, 182, 10, 3, 3, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text("NÚMEROS ADQUIRIDOS", 20, 139);
    doc.text("VALOR UNIT.", 130, 139);
    doc.text("TOTAL", 170, 139);

    let y = 150;
    meusBilhetes.forEach((b, i) => {
      if (y > 260) { doc.addPage(); y = 20; }
      doc.setFillColor(i % 2 === 0 ? 245 : 255, i % 2 === 0 ? 247 : 255, i % 2 === 0 ? 250 : 255);
      doc.rect(14, y - 6, 182, 10, "F");
      doc.setTextColor(...cinza);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10);
      doc.text(`#${String(b.numero).padStart(5, "0")}`, 20, y);
      doc.text(`R$ ${Number(rifa.valor_por_numero).toFixed(2)}`, 130, y);
      doc.text(`R$ ${Number(b.valor_pago).toFixed(2)}`, 170, y);
      y += 10;
    });

    // Resumo financeiro
    y += 6;
    doc.setFillColor(...azul);
    doc.roundedRect(100, y, 96, 32, 4, 4, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text("Total de números:", 106, y + 10);
    doc.text("Valor total pago:", 106, y + 20);
    doc.setFontSize(11);
    doc.text(String(meusBilhetes.length), 175, y + 10);
    doc.text(`R$ ${(meusBilhetes.length * rifa.valor_por_numero).toFixed(2)}`, 148, y + 20);

    // Rodapé
    doc.setFillColor(23, 0, 115);
    doc.rect(0, 280, 210, 17, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text("Clube do Galo", 14, 290);
    doc.text(`Este comprovante foi gerado automaticamente em ${new Date().toLocaleString("pt-BR")}`, 14, 296);

    doc.save(`comprovante-rifa-${rifa.id?.slice(-8)}.pdf`);
  };

  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "DM Sans,sans-serif" }}>
      <div style={{ textAlign: "center", color: "#57636C" }}>⏳ Carregando...</div>
    </div>
  );

  if (!rifa) return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 12 }}>
      <div style={{ fontSize: 48 }}>😕</div>
      <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 800 }}>Rifa não encontrada</div>
      <Link to="/rifas" style={{ color: "#170073" }}>← Voltar às rifas</Link>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      {/* Header foto com carousel de imagens */}
      <div style={{ position: "relative", height: 220, background: rifa.imagens && rifa.imagens.length > 0 ? `url(${rifa.imagens[0]}) center/cover` : (rifa.animal_foto_url ? `url(${rifa.animal_foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)"), display: "flex", alignItems: "center", justifyContent: "center" }}>
        {!rifa.animal_foto_url && !rifa.imagens?.length && <span style={{ fontSize: 80 }}>🐓</span>}
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, transparent 40%, rgba(0,0,0,.6))" }} />
        <Link to="/rifas" style={{ position: "absolute", top: 16, left: 16, background: "rgba(0,0,0,.4)", color: "#fff", textDecoration: "none", fontSize: 22, borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700 }}>←</Link>
        <div style={{ position: "absolute", bottom: 14, left: 16, right: 16 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>{rifa.titulo || rifa.animal_nome}</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,.8)" }}>Por {rifa.dono_nome} · Anilha: {rifa.animal_anilha}</div>
        </div>
        {/* Indicador de imagens adicionais */}
        {rifa.imagens && rifa.imagens.length > 1 && (
          <div style={{ position: "absolute", bottom: 12, left: 12, background: "rgba(0,0,0,.5)", color: "#fff", borderRadius: 8, padding: "4px 10px", fontSize: 10, fontWeight: 700 }}>
            📸 {rifa.imagens.length} fotos
          </div>
        )}
        {rifa.status !== "ativa" && (
          <div style={{ position: "absolute", top: 16, right: 16, background: rifa.status === "encerrada" ? "#F1F4F8" : "#FFEBEE", color: rifa.status === "encerrada" ? "#57636C" : "#C62828", borderRadius: 10, padding: "4px 12px", fontSize: 11, fontWeight: 800 }}>
            {rifa.status === "encerrada" ? "⚫ Encerrada" : "🔴 Cancelada"}
          </div>
        )}
      </div>

      <div style={{ padding: "16px", maxWidth: 600, margin: "0 auto" }}>
        {/* Galeria de imagens adicionais */}
        {rifa.imagens && rifa.imagens.length > 0 && (
          <div style={{ marginBottom: 14 }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(100px, 1fr))", gap: 8 }}>
              {rifa.imagens.map((url, idx) => (
                <div key={idx} style={{ borderRadius: 12, overflow: "hidden", height: 100, background: `url(${url}) center/cover`, border: "1px solid #E8ECF0" }} />
              ))}
            </div>
          </div>
        )}

        {/* Ganhador */}
        {rifa.ganhador_nome && (
          <div style={{ background: "linear-gradient(135deg,#F0A500,#FFD700)", borderRadius: 16, padding: "16px 20px", marginBottom: 16, textAlign: "center" }}>
            <div style={{ fontSize: 36, marginBottom: 4 }}>🏆</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#101213" }}>
              Ganhador: {rifa.ganhador_nome}
            </div>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#4A3200", marginTop: 2 }}>Número sorteado: {rifa.ganhador_numero}</div>
            {rifa.dono_whatsapp && (
              <a href={`https://wa.me/${rifa.dono_whatsapp}?text=Olá! Sou ${rifa.ganhador_nome}, ganhador da rifa "${rifa.titulo || rifa.animal_nome}" com o número ${rifa.ganhador_numero}. Vim retirar o prêmio!`}
                target="_blank" rel="noopener noreferrer"
                style={{ display: "inline-block", marginTop: 10, background: "#25D366", color: "#fff", borderRadius: 10, padding: "8px 18px", textDecoration: "none", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800 }}>
                📱 Contatar Dono via WhatsApp
              </a>
            )}
          </div>
        )}

        {/* Avaliação pós-rifa */}
        {rifa.status === "encerrada" && user?.id === rifa.ganhador_id && !jaAvaliou && (
          <div style={{ background: "#FFF8E1", borderRadius: 14, padding: "14px 16px", marginBottom: 14, border: "1px solid #F0A500", textAlign: "center" }}>
            <div style={{ fontSize: 12, color: "#856404", marginBottom: 10 }}>
              ⭐ <strong>Avalie sua experiência</strong> com {rifa.dono_nome}
            </div>
            <button onClick={() => setMostraAvaliacao(true)}
              style={{ background: "#F0A500", color: "#fff", border: "none", borderRadius: 10, padding: "8px 16px", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800 }}>
              ⭐ Avaliar
            </button>
          </div>
        )}

        {/* Progresso */}
        <div style={{ background: "#fff", borderRadius: 16, padding: "16px", marginBottom: 14, border: "1px solid #E8ECF0" }}>
          <BarraProgresso vendidos={rifa.numeros_vendidos || 0} total={rifa.qtd_numeros || 1} />
          {(() => {
            const isAdmin = user?.role === "admin" || user?.role === "master_admin";
            const podeVerTotal = isDono || isAdmin;
            const taxaGateway = (rifa.numeros_vendidos || 0) * 0.38;
            const taxaAdmin = (rifa.total_arrecadado || 0) * 0.10;
            const totalLiquido = (rifa.total_arrecadado || 0) - taxaGateway - taxaAdmin;
            const stats = [
              { label: "Por número", val: fmt(rifa.valor_por_numero) },
              ...(podeVerTotal ? [{ label: "Total líquido (após taxas)", val: fmt(totalLiquido), destaque: true }] : []),
              { label: "Meta", val: fmt(rifa.valor_arrecadar) },
            ];
            return (
              <div style={{ display: "grid", gridTemplateColumns: `repeat(${stats.length}, 1fr)`, gap: 8, marginTop: 14 }}>
                {stats.map((k, i) => (
                  <div key={i} style={{ background: k.destaque ? "#F0F4FF" : "#F8FAFC", borderRadius: 10, padding: "8px 10px", textAlign: "center", border: k.destaque ? "1px solid #C7D4FF" : "none" }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: k.destaque ? "#170073" : "#170073" }}>{k.val}</div>
                    <div style={{ fontSize: 9, color: "#57636C" }}>{k.label}</div>
                  </div>
                ))}
              </div>
            );
          })()}
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10, fontSize: 11, color: "#57636C" }}>
            <span>📅 Sorteio: {rifa.data_sorteio ? new Date(rifa.data_sorteio + "T12:00:00").toLocaleDateString("pt-BR") : "—"}</span>
            <span>{rifa.tipo_sorteio === "manual" ? "📋 Loteria Federal" : "🤖 Automático"}</span>
          </div>
        </div>

        {/* Taxas info */}
        <div style={{ background: "#FFF8E1", borderRadius: 12, padding: "10px 14px", marginBottom: 14, fontSize: 11, color: "#856404" }}>
          💰 <strong>Taxas:</strong> R$ 0,38/transação + 10% administrativo. O restante vai diretamente para {rifa.dono_nome}.
        </div>

        {/* Controles do Dono */}
        {isDono && rifa.status === "ativa" && (
          <div style={{ background: "#F0F4FF", borderRadius: 16, padding: "16px", marginBottom: 14, border: "1.5px solid #170073" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#170073", marginBottom: 12 }}>⚙️ Painel do Dono</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <button onClick={() => setModalResultado(true)}
                style={{ padding: "10px", borderRadius: 10, border: "none", background: "linear-gradient(135deg,#170073,#00A893)", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 700 }}>
                🎲 Inserir Resultado
              </button>
              {!rifa.prazo_estendido && (
                <button onClick={() => {
                  const novaData = prompt("Nova data do sorteio (YYYY-MM-DD):");
                  if (novaData) estenderPrazo(novaData);
                }}
                  style={{ padding: "10px", borderRadius: 10, border: "1.5px solid #F0A500", background: "#fff", color: "#F0A500", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 700 }}>
                  📅 Estender Prazo
                </button>
              )}
            </div>
          </div>
        )}

        {/* Comprar bilhete */}
        {rifa.status === "ativa" && user && !isDono && (
          <div style={{ background: "#fff", borderRadius: 16, padding: "16px", marginBottom: 14, border: "1px solid #E8ECF0" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", marginBottom: 12 }}>🎟️ Comprar Números</div>

            <div style={{ marginBottom: 10 }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 4 }}>Seu WhatsApp</label>
              <input type="text" value={whatsapp} placeholder="5511999999999"
                onChange={e => setWhatsapp(e.target.value)}
                style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }} />
            </div>

            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Quantidade de Números</label>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 8 }}>
                {[1, 2, 5, 10, 20, 50].map(q => (
                  <button key={q} onClick={() => setQtdCompra(q)}
                    style={{ padding: "8px 14px", borderRadius: 10, cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800,
                      border: `1.5px solid ${qtdCompra === q ? "#170073" : "#E8ECF0"}`,
                      background: qtdCompra === q ? "#170073" : "#fff",
                      color: qtdCompra === q ? "#fff" : "#57636C" }}>
                    {q}
                  </button>
                ))}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 11, color: "#57636C", fontWeight: 700, whiteSpace: "nowrap" }}>Outro valor:</span>
                <input
                  type="number" min="1"
                  placeholder="Digite a quantidade"
                  onChange={e => { const v = parseInt(e.target.value); if (v > 0) setQtdCompra(v); }}
                  style={{ flex: 1, padding: "8px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box" }}
                />
              </div>
            </div>

            <div style={{ background: "#F0F4FF", borderRadius: 10, padding: "10px 14px", marginBottom: 12, display: "flex", justifyContent: "space-between" }}>
              <span style={{ fontSize: 12, color: "#57636C", fontWeight: 700 }}>Total a pagar:</span>
              <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073" }}>{fmt(qtdCompra * rifa.valor_por_numero)}</span>
            </div>

            <button onClick={() => comprar("carteira")} disabled={buying}
              style={{ width: "100%", padding: "13px", borderRadius: 12, border: "none", cursor: buying ? "default" : "pointer",
                background: buying ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
                color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
              {buying ? "Reservando números..." : `🎟️ Comprar ${qtdCompra} número${qtdCompra > 1 ? "s" : ""}`}
            </button>
          </div>
        )}

        {/* Meus bilhetes */}
        {meusBilhetes.length > 0 && (
          <div style={{ background: "#fff", borderRadius: 16, padding: "16px", marginBottom: 14, border: "1px solid #E8ECF0" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>
                🎟️ Meus Números ({meusBilhetes.length})
              </div>
              <button onClick={baixarComprovante}
                style={{ display: "flex", alignItems: "center", gap: 6, background: "linear-gradient(135deg,#170073,#00A893)", border: "none", borderRadius: 10, padding: "7px 14px", cursor: "pointer", color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 800 }}>
                📄 Baixar Comprovante
              </button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 6, maxHeight: 120, overflowY: "auto" }}>
              {meusBilhetes.map(b => (
                <div key={b.id} style={{ background: rifa.ganhador_numero === b.numero ? "#FFD700" : "#F0F4FF", borderRadius: 8, padding: "6px 4px", fontFamily: "Montserrat,sans-serif", fontSize: 11, fontWeight: 800, color: rifa.ganhador_numero === b.numero ? "#101213" : "#170073", textAlign: "center", display: "flex", alignItems: "center", justifyContent: "center", minHeight: 32 }}>
                  <span>{b.numero.toString().padStart(5, "0")}</span> {rifa.ganhador_numero === b.numero && <span style={{ marginLeft: 2 }}>🏆</span>}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Lista de participantes */}
        {bilhetes.length > 0 && (
          <div style={{ background: "#fff", borderRadius: 16, padding: "16px", border: "1px solid #E8ECF0" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, marginBottom: 10, color: "#101213" }}>
              👥 Participantes ({bilhetes.length} bilhetes)
            </div>
            {Array.from(new Map(bilhetes.map(b => [b.comprador_id, b])).values()).map(b => {
              const qtd = bilhetes.filter(x => x.comprador_id === b.comprador_id).length;
              return (
                <div key={b.comprador_id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: "1px solid #F8FAFC" }}>
                  <div>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800 }}>{b.comprador_nome}</div>
                    <div style={{ fontSize: 10, color: "#57636C" }}>{qtd} número{qtd > 1 ? "s" : ""} · {fmt(qtd * rifa.valor_por_numero)}</div>
                  </div>
                  {b.comprador_whatsapp && (
                    <a href={`https://wa.me/${b.comprador_whatsapp}`} target="_blank" rel="noopener noreferrer"
                      style={{ fontSize: 10, background: "#25D366", color: "#fff", borderRadius: 8, padding: "4px 10px", textDecoration: "none", fontWeight: 700 }}>
                      📱 Zap
                    </a>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal resultado */}
      {modalResultado && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}
          onClick={e => e.target === e.currentTarget && setModalResultado(false)}>
          <div style={{ background: "#fff", borderRadius: 20, padding: "24px 20px", maxWidth: 360, width: "100%" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 4 }}>🎲 Resultado do Sorteio</div>
            <div style={{ fontSize: 11, color: "#57636C", marginBottom: 14 }}>
              Insira o resultado da Loteria Federal. O sistema calculará automaticamente o número ganhador e notificará o vencedor.
            </div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Resultado Loteria Federal</label>
            <input type="text" value={resultado} placeholder="Ex: 12345 — copie o resultado aqui"
              onChange={e => setResultado(e.target.value)}
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", marginBottom: 14 }} />
            <button onClick={realizarSorteio} disabled={savingResultado || !resultado.trim()}
              style={{ width: "100%", padding: "13px", borderRadius: 12, border: "none", cursor: savingResultado ? "default" : "pointer",
                background: savingResultado ? "#ccc" : "linear-gradient(135deg,#170073,#00A893)",
                color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
              {savingResultado ? "Sorteando..." : "🏆 Confirmar Sorteio"}
            </button>
            <button onClick={() => setModalResultado(false)} style={{ width: "100%", marginTop: 8, background: "none", border: "none", color: "#57636C", fontSize: 12, cursor: "pointer" }}>Cancelar</button>
          </div>
        </div>
      )}

      {/* Modal Avaliação */}
      {mostraAvaliacao && user && rifa && (
        <AvaliacaoModal
          tipo="rifa"
          referenciaId={id}
          vendedorEmail={rifa.dono_email}
          vendedorNome={rifa.dono_nome}
          animalNome={rifa.animal_nome}
          compradorUser={user}
          onClose={() => setMostraAvaliacao(false)}
          onAvaliado={() => setJaAvaliou(true)}
        />
      )}

      {/* Modal PIX */}
      {mostraModalPix && user && rifa && (
        <ModalPixRifa
          valor={qtdCompra * rifa.valor_por_numero}
          user={user}
          onClose={() => setMostraModalPix(false)}
          onSucesso={() => {
            setMostraModalPix(false);
            carregar();
          }}
        />
      )}

      {/* Modal CPF (removido - não mais necessário) */}
      {false && mostraCpfModal && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}
          onClick={e => e.target === e.currentTarget && setMostraCpfModal(false)}>
          <div style={{ background: "#fff", borderRadius: 20, padding: "24px 20px", maxWidth: 360, width: "100%" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "#170073", marginBottom: 4 }}>📋 CPF Obrigatório</div>
            <div style={{ fontSize: 11, color: "#57636C", marginBottom: 14 }}>Precisamos do seu CPF para processar o pagamento via gateway.</div>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", display: "block", marginBottom: 6 }}>CPF (11 dígitos)</label>
            <input type="text" value={cpfInput} placeholder="00000000000"
              onChange={e => setCpfInput(e.target.value.replace(/\D/g, "").slice(0, 11))}
              maxLength="11"
              style={{ width: "100%", padding: "10px 12px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 13, outline: "none", boxSizing: "border-box", marginBottom: 14 }} />
            <button onClick={() => validarCpf(cpfInput)} disabled={cpfInput.length !== 11}
              style={{ width: "100%", padding: "13px", borderRadius: 12, border: "none", cursor: cpfInput.length === 11 ? "pointer" : "default",
                background: cpfInput.length === 11 ? "linear-gradient(135deg,#170073,#00A893)" : "#ccc",
                color: "#fff", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900 }}>
              ✓ Confirmar e Comprar
            </button>
            <button onClick={() => setMostraCpfModal(false)} style={{ width: "100%", marginTop: 8, background: "none", border: "none", color: "#57636C", fontSize: 12, cursor: "pointer" }}>Cancelar</button>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}