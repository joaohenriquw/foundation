import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BottomNav from "../components/BottomNav";
import PullToRefresh from "../components/PullToRefresh";
import CriarRifaModal from "../components/CriarRifaModal";
import NotificacoesSino from "../components/NotificacoesSino";

const fmt = (v) => "R$ " + Number(v || 0).toFixed(2).replace(".", ",");

const STATUS_CFG = {
  ativa:     { label: "Ativa",     cor: "#2E7D32", bg: "#E8F5E9", emoji: "🟢" },
  encerrada: { label: "Encerrada", cor: "#57636C", bg: "#F1F4F8", emoji: "⚫" },
  cancelada: { label: "Cancelada", cor: "#C62828", bg: "#FFEBEE", emoji: "🔴" },
};

function BarraProgresso({ vendidos, total }) {
  const pct = total > 0 ? Math.min((vendidos / total) * 100, 100) : 0;
  return (
    <div style={{ marginTop: 6 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 10, color: "#57636C", marginBottom: 3 }}>
        <span>{vendidos.toLocaleString("pt-BR")} vendidos</span>
        <span>{pct.toFixed(1)}%</span>
      </div>
      <div style={{ height: 6, borderRadius: 4, background: "#E8ECF0", overflow: "hidden" }}>
        <div style={{ height: "100%", borderRadius: 4, width: `${pct}%`, background: "linear-gradient(90deg,#170073,#00A893)", transition: ".3s" }} />
      </div>
    </div>
  );
}

export default function Rifas() {
  const navigate = useNavigate();
  const [rifas, setRifas]       = useState([]);
  const [loading, setLoading]   = useState(true);
  const [user, setUser]         = useState(null);
  const [userMeta, setUserMeta] = useState(null);
  const [modal, setModal]       = useState(false);
  const [loadingMeta, setLoadingMeta] = useState(true);
  const [filtro, setFiltro]     = useState("ativa");
  const [paginaAtual, setPaginaAtual] = useState(1);
  const ITENS_POR_PAGINA = 10;

  const carregar = async () => {
    setLoading(true);
    setLoadingMeta(true);
    try {
      const [data, me] = await Promise.all([
        base44.entities.Rifa.list("-created_date", 200).catch(() => []),
        base44.auth.me().catch(() => null),
      ]);
      setRifas(data);
      setUser(me);
      if (me) {
        const users = await base44.entities.User.filter({ email: me.email }).catch(() => []);
        setUserMeta(users?.[0] || null);
      }
    } finally {
      setLoading(false);
      setLoadingMeta(false);
    }
  };

  useEffect(() => {
    carregar();
  }, []);

  const isAdmin = user?.role === "admin" || user?.role === "master_admin";
  const planoEfetivo = isAdmin ? "premium" : (userMeta?.plano || "iniciante");
  const planoOk = ["gold", "premium"].includes(planoEfetivo);

  const rifasFiltradas = rifas.filter(r => filtro === "todas" ? true : r.status === filtro);
  const totalPaginas = Math.ceil(rifasFiltradas.length / ITENS_POR_PAGINA);
  const inicio = (paginaAtual - 1) * ITENS_POR_PAGINA;
  const fim = inicio + ITENS_POR_PAGINA;
  const rifasPaginadas = rifasFiltradas.slice(inicio, fim);

  const handleFiltro = (novoFiltro) => {
    setFiltro(novoFiltro);
    setPaginaAtual(1);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#F8FAFC", fontFamily: "'DM Sans', sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "20px 20px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none", fontWeight: 700 }}>←</Link>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>🎰 Rifas</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Clube do Galo</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {user && <NotificacoesSino userEmail={user.email} />}
            {loadingMeta ? (
              <button disabled style={{ background: "rgba(255,255,255,.15)", borderRadius: 12, padding: "9px 14px", fontSize: 11, color: "rgba(255,255,255,.5)", fontWeight: 700, border: "none", cursor: "wait" }}>...</button>
            ) : planoOk ? (
              <button onClick={() => setModal(true)}
                style={{ background: "#fff", color: "#170073", border: "none", borderRadius: 12, padding: "9px 14px", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 800, cursor: "pointer" }}>
                + Criar Rifa
              </button>
            ) : (
              <button onClick={() => navigate("/planos")}
                style={{ background: "rgba(255,255,255,.15)", borderRadius: 12, padding: "9px 14px", fontSize: 11, color: "rgba(255,255,255,.8)", fontWeight: 800, border: "1.5px solid rgba(255,255,255,.4)", cursor: "pointer" }}>
                + Criar 🔒
              </button>
            )}
          </div>
        </div>

        {/* Filtros */}
        <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
          {[["ativa", "🟢 Ativas"], ["encerrada", "⚫ Encerradas"], ["todas", "🎰 Todas"]].map(([k, l]) => (
            <button key={k} onClick={() => handleFiltro(k)}
              style={{ padding: "8px 16px", borderRadius: 24, border: "1.5px solid", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 700,
                borderColor: filtro === k ? "#fff" : "rgba(255,255,255,.4)",
                background:  filtro === k ? "#fff" : "rgba(255,255,255,.1)",
                color:       filtro === k ? "#170073" : "#fff" }}>
              {l}
            </button>
          ))}
        </div>
      </div>

      <PullToRefresh onRefresh={carregar}>
        <div style={{ padding: "16px", maxWidth: 800, margin: "0 auto", "data-tab-scroll": true }}>
          {loading ? (
            <div style={{ textAlign: "center", padding: 60, color: "#57636C" }}>⏳ Carregando...</div>
          ) : rifasFiltradas.length === 0 ? (
          <div style={{ textAlign: "center", padding: 60 }}>
            <div style={{ fontSize: 52, marginBottom: 12 }}>🎰</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 800 }}>Nenhuma rifa encontrada</div>
            {planoOk && <div style={{ fontSize: 12, color: "#57636C", marginTop: 6 }}>Clique em "+ Criar Rifa" para começar!</div>}
          </div>
        ) : (
          <>
            <div style={{ display: "grid", gap: 12 }}>
              {rifasPaginadas.map(r => {
                const scfg = STATUS_CFG[r.status] || STATUS_CFG.ativa;
                return (
                  <Link key={r.id} to={`/rifa/${r.id}`} style={{ textDecoration: "none" }}>
                    <div style={{ background: "#fff", borderRadius: 16, border: "1px solid #E8ECF0", overflow: "hidden", transition: ".15s", cursor: "pointer" }}>
                      {/* Foto */}
                      <div style={{ height: 130, background: r.animal_foto_url ? `url(${r.animal_foto_url}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
                        {!r.animal_foto_url && <span style={{ fontSize: 52 }}>🐓</span>}
                        <div style={{ position: "absolute", top: 10, right: 10, background: scfg.bg, color: scfg.cor, borderRadius: 8, padding: "3px 10px", fontSize: 10, fontWeight: 800 }}>
                          {scfg.emoji} {scfg.label}
                        </div>
                        {r.ganhador_nome && (
                          <div style={{ position: "absolute", bottom: 8, left: 0, right: 0, textAlign: "center", background: "rgba(0,0,0,.6)", padding: "5px 12px", color: "#FFD700", fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900 }}>
                            🏆 Ganhador: {r.ganhador_nome} — Nº {r.ganhador_numero}
                          </div>
                        )}
                      </div>

                      <div style={{ padding: "14px 16px" }}>
                        <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 15, fontWeight: 900, color: "#101213", marginBottom: 3 }}>{r.titulo || r.animal_nome}</div>
                        <div style={{ fontSize: 10, color: "#57636C", marginBottom: 10 }}>Por {r.dono_nome} · {r.animal_anilha}</div>

                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
                          {[
                            { label: "Por número", val: fmt(r.valor_por_numero) },
                            { label: "Total", val: (r.qtd_numeros || 0).toLocaleString("pt-BR") },
                          ].map((k, i) => (
                            <div key={i} style={{ background: "#F8FAFC", borderRadius: 10, padding: "8px", textAlign: "center" }}>
                              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#170073" }}>{k.val}</div>
                              <div style={{ fontSize: 10, color: "#57636C", fontWeight: 600 }}>{k.label}</div>
                            </div>
                          ))}
                        </div>

                        <BarraProgresso vendidos={r.numeros_vendidos || 0} total={r.qtd_numeros || 1} />

                        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, fontSize: 10, color: "#57636C" }}>
                          <span>📅 Sorteio: {r.data_sorteio ? new Date(r.data_sorteio + "T12:00:00").toLocaleDateString("pt-BR") : "—"}</span>
                          <span>{r.tipo_sorteio === "manual" ? "📋 Loteria Federal" : "🤖 Automático"}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>

            {rifasFiltradas.length > ITENS_POR_PAGINA && (
              <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 20, paddingBottom: 20 }}>
                <button onClick={() => setPaginaAtual(p => Math.max(1, p - 1))} disabled={paginaAtual === 1}
                  style={{ padding: "8px 16px", borderRadius: 8, border: "1.5px solid #E8ECF0", background: paginaAtual === 1 ? "#f0f0f0" : "#fff", cursor: paginaAtual === 1 ? "default" : "pointer", fontWeight: 700 }}>← Anterior</button>
                <div style={{ padding: "8px 16px", borderRadius: 8, background: "#F8FAFC", fontWeight: 700, color: "#170073" }}>Página {paginaAtual} de {totalPaginas}</div>
                <button onClick={() => setPaginaAtual(p => Math.min(totalPaginas, p + 1))} disabled={paginaAtual === totalPaginas}
                  style={{ padding: "8px 16px", borderRadius: 8, border: "1.5px solid #E8ECF0", background: paginaAtual === totalPaginas ? "#f0f0f0" : "#fff", cursor: paginaAtual === totalPaginas ? "default" : "pointer", fontWeight: 700 }}>Próxima →</button>
              </div>
            )}
          </>
        )}
        </div>
      </PullToRefresh>

      {modal && user && (
        <CriarRifaModal user={user} onClose={() => setModal(false)} onCriada={carregar} />
      )}

      <BottomNav />
    </div>
  );
}