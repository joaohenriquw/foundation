import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";

const fmt = (v) => v != null ? "R$ " + Number(v).toLocaleString("pt-BR", { minimumFractionDigits: 2 }) : null;

export default function AnimalPublico() {
  const { animalId } = useParams();
  const [dados, setDados] = useState(null);
  const [animal, setAnimal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copiado, setCopiado] = useState(false);
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    const init = async () => {
      base44.auth.me().then(setUser).catch(() => {});
      const exps = await base44.entities.VitrineExposicao.filter({ animal_id: animalId, ativa: true }, "-created_date", 1);
      if (exps[0]) setDados(exps[0]);

      const isUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(animalId);
      if (isUUID) {
        const animais = await base44.entities.Animal.filter({ id: animalId }, "-created_date", 1).catch(() => []);
        if (animais[0]) setAnimal(animais[0]);
      }
      setLoading(false);
    };
    init();
  }, [animalId]);

  const nome = dados?.animal_nome || animal?.nome || "Animal";
  const anilha = dados?.animal_anilha || animal?.anilha || "—";
  const foto = dados?.animal_foto_url || animal?.foto_url;
  const valor = dados?.animal_valor || animal?.valor_estimado;
  const descricao = dados?.descricao || animal?.observacoes;
  const proprietarioNome = dados?.proprietario_nome || animal?.proprietario_nome || "—";
  const especie = dados?.animal_especie || animal?.especie;
  const wppNumero = animal?.whatsapp;

  const compartilhar = () => {
    navigator.clipboard.writeText(window.location.href).catch(() => {});
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2000);
  };

  if (loading) return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", background: "#0D0D0D", color: "#888", fontFamily: "'DM Sans',sans-serif" }}>
      Carregando...
    </div>
  );

  if (!dados && !animal) return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh", background: "#0D0D0D", fontFamily: "'DM Sans',sans-serif" }}>
      <div style={{ fontSize: 52, marginBottom: 16 }}>🐓</div>
      <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 900, fontSize: 18, color: "#fff" }}>Animal não encontrado</div>
      <div style={{ fontSize: 13, color: "#555", marginTop: 6 }}>Este link pode ter expirado</div>
    </div>
  );

  // Linhas de detalhe do animal (filtra vazios)
  const detalhes = [
    ["Anilha", anilha],
    ["Espécie", especie],
    ["Sexo", animal?.sexo === "macho" ? "♂️ Macho" : animal?.sexo === "femea" ? "♀️ Fêmea" : null],
    ["Cor / Plumagem", animal?.cor_plumagem],
    ["Peso", animal?.peso_gramas ? animal.peso_gramas + "g" : null],
    ["Nascimento", animal?.data_de_nascimento ? new Date(animal.data_de_nascimento + "T12:00").toLocaleDateString("pt-BR") : null],
    ["Pai", animal?.pai_nome],
    ["Mãe", animal?.mae_nome],
    ["Criatório", proprietarioNome],
  ].filter(([, v]) => v);

  return (
    <div style={{ minHeight: "100vh", background: "#0D0D0D", fontFamily: "'DM Sans',sans-serif", color: "#fff", paddingBottom: 90, overflowX: "hidden", maxWidth: "100vw" }}>

      {/* Botão Voltar */}
      <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", padding: "12px 16px", display: "flex", alignItems: "center" }}>
        <Link to="/vitrine" style={{ color: "rgba(255,255,255,.9)", fontSize: 20, textDecoration: "none", fontWeight: 700 }}>←</Link>
      </div>

      {/* Hero com foto */}
      <div style={{ position: "relative", height: 220, background: foto ? `url(${foto}) center/cover` : "linear-gradient(135deg,#170073,#00A893)", display: "flex", alignItems: "flex-end" }}>
        {!foto && (
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 60 }}>🐓</div>
        )}

        {/* Gradiente escuro na base */}
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(0,0,0,0.1) 30%, #0D0D0D 100%)" }} />

        {/* Botões topo */}
        <div style={{ position: "absolute", top: 12, left: 12, right: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <button onClick={compartilhar}
            style={{ display: "flex", alignItems: "center", gap: 5, background: "rgba(0,0,0,.55)", border: "1px solid rgba(255,255,255,.2)", backdropFilter: "blur(8px)", borderRadius: 20, padding: "6px 12px", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
            🔗 {copiado ? "Copiado!" : "Compartilhar"}
          </button>
          {valor && (
            <div style={{ background: "linear-gradient(135deg,#170073,#00A893)", borderRadius: 20, padding: "6px 14px", fontFamily: "Montserrat,sans-serif", fontWeight: 900, fontSize: 13, color: "#fff" }}>
              {fmt(valor)}
            </div>
          )}
        </div>

        {/* Nome sobre a foto */}
        <div style={{ position: "relative", zIndex: 2, padding: "0 16px 14px", width: "100%", boxSizing: "border-box" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 24, fontWeight: 900, color: "#fff", lineHeight: 1.1, textShadow: "0 2px 8px rgba(0,0,0,.5)", flex: 1 }}>
              {nome}
            </div>
            {wppNumero && (
              <a href={`https://wa.me/55${wppNumero.replace(/\D/g, "")}?text=${encodeURIComponent(`Olá! Vi o animal *${nome}* (Anilha: ${anilha}) no Clube do Galo e tenho interesse!`)}`}
                target="_blank" rel="noopener noreferrer"
                style={{ display: "flex", alignItems: "center", gap: 5, background: "#25D366", color: "#fff", textDecoration: "none", borderRadius: 20, padding: "6px 12px", fontFamily: "Montserrat,sans-serif", fontWeight: 800, fontSize: 11, whiteSpace: "nowrap", flexShrink: 0 }}>
                💬 Entrar em contato
              </a>
            )}
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 4, flexWrap: "wrap" }}>
            <span style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>🏷 {anilha}</span>
            {especie && <span style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>· {especie}</span>}
          </div>
        </div>
      </div>

      {/* Conteúdo */}
      <div style={{ padding: "12px 16px", maxWidth: 520, margin: "0 auto" }}>

        {/* Criatório badge */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, background: "#1A1A1A", borderRadius: 12, padding: "10px 14px", marginBottom: 8 }}>
          <span style={{ fontSize: 22 }}>🐓</span>
          <div>
            <div style={{ fontSize: 10, color: "#666", fontWeight: 700, textTransform: "uppercase", letterSpacing: 0.5 }}>Criatório</div>
            <div style={{ fontSize: 14, fontWeight: 800, color: "#fff", marginTop: 1 }}>{proprietarioNome}</div>
          </div>
        </div>

        {/* Descrição */}
        {descricao && (
          <div style={{ background: "#1A1A1A", borderRadius: 12, padding: "10px 14px", marginBottom: 8 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: "#00A893", textTransform: "uppercase", letterSpacing: 1, marginBottom: 8 }}>📝 Descrição</div>
            <div style={{ fontSize: 13, color: "#bbb", lineHeight: 1.7 }}>{descricao}</div>
          </div>
        )}

        {/* Combates - botão WhatsApp abaixo do nome já está no hero, esse bloco é de stats */}
        {(animal?.combate_vitrias > 0 || animal?.combate_derrotas > 0) && (
          <div style={{ background: "#1A1A1A", borderRadius: 12, padding: "10px 14px", marginBottom: 8 }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: "#00A893", textTransform: "uppercase", letterSpacing: 1, marginBottom: 12 }}>⚔️ Combates</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              <div style={{ background: "#111", borderRadius: 10, padding: "12px", textAlign: "center", borderLeft: "3px solid #22c55e" }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 26, fontWeight: 900, color: "#22c55e" }}>{animal.combate_vitrias || 0}</div>
                <div style={{ fontSize: 10, color: "#666", marginTop: 2 }}>Vitórias</div>
              </div>
              <div style={{ background: "#111", borderRadius: 10, padding: "12px", textAlign: "center", borderLeft: "3px solid #ef4444" }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 26, fontWeight: 900, color: "#ef4444" }}>{animal.combate_derrotas || 0}</div>
                <div style={{ fontSize: 10, color: "#666", marginTop: 2 }}>Derrotas</div>
              </div>
            </div>
          </div>
        )}

        {/* Botão Ninhada - se animal é reprodutor/matriz e é do proprietário */}
        {animal && user && animal.proprietario_email === user.email && (animal.tipo_categoria === "reprodutor" || animal.tipo_categoria === "matriz" || animal.origem === "adulto") && (
          <button onClick={() => {
            const url = `/animal-form?pai_id=${animal.sexo === "macho" ? animal.id : ""}&pai_nome=${animal.sexo === "macho" ? animal.nome : ""}&mae_id=${animal.sexo === "femea" ? animal.id : ""}&mae_nome=${animal.sexo === "femea" ? animal.nome : ""}&origem=filho`;
            navigate(url);
          }}
            style={{ width: "100%", padding: "14px", borderRadius: 12, background: "linear-gradient(135deg,#7C3AED,#5B2BE0)", border: "none", color: "#fff", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, marginBottom: 8, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            👶 + Registrar Ninhada
          </button>
        )}

        {/* Detalhes */}
        {detalhes.length > 0 && (
          <div style={{ background: "#1A1A1A", borderRadius: 12, overflow: "hidden", marginBottom: 8 }}>
            <div style={{ padding: "12px 16px", borderBottom: "1px solid #222", fontSize: 11, fontWeight: 800, color: "#00A893", textTransform: "uppercase", letterSpacing: 1 }}>
              📋 Dados
            </div>
            {detalhes.map(([k, v], i) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "9px 14px", borderTop: i > 0 ? "1px solid #1e1e1e" : "none" }}>
                <span style={{ fontSize: 13, color: "#666" }}>{k}</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: "#fff", textAlign: "right", maxWidth: "55%" }}>{v}</span>
              </div>
            ))}
          </div>
        )}

        {/* Branding */}
        <div style={{ textAlign: "center", marginTop: 12, paddingTop: 12, borderTop: "1px solid #1a1a1a" }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 900, color: "#00A893", fontSize: 13 }}>Clube do Galo</div>
          <div style={{ fontSize: 11, color: "#444", marginTop: 3 }}>Marketplace de Criatórios</div>
        </div>
      </div>

      {/* Botão fixo WhatsApp */}
    </div>
  );
}