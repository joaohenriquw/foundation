import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useLeilaoAoVivo } from "../hooks/useLeilaoAoVivo";
import ControleAoVivo from "../components/ControleAoVivo";
import ListaLances from "../components/ListaLances";
import ChatAoVivo from "../components/ChatAoVivo";
import BottomNav from "../components/BottomNav";

const fmt = (v) => v != null ? "R$ " + Number(v).toLocaleString("pt-BR", { minimumFractionDigits: 2 }) : "—";
const PARCELAS = [1, 2, 3, 6, 12];

function useCountdown(dataFim) {
  const [txt, setTxt] = useState("...");
  const [urgente, setUrgente] = useState(false);
  useEffect(() => {
    if (!dataFim) return;
    const tick = () => {
      const diff = new Date(dataFim) - new Date();
      if (diff <= 0) { setTxt("Encerrado"); return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setUrgente(h === 0 && m < 5);
      setTxt(`${h > 0 ? h + "h " : ""}${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [dataFim]);
  return { txt, urgente };
}

export default function LeilaoAoVivo() {
  const { id } = useParams();
  const [leilao, setLeilao] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [meuLance, setMeuLance] = useState("");
  const [parcelas, setParcelas] = useState(1);
  const [enviando, setEnviando] = useState(false);
  const [dbLances, setDbLances] = useState([]);
  const [lanceOtimista, setLanceOtimista] = useState(null);
  const { conectado, status, encerrado, enviarLance: enviarLanceSSE } = useLeilaoAoVivo(id);
  const { txt: countdownTxt, urgente } = useCountdown(leilao?.data_fim);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);
      const lista = await base44.entities.Leilao.list("-created_date", 100);
      setLeilao(lista.find(l => l.id === id) || null);
      const lancesDB = await base44.entities.LeilaoLance.filter({ leilao_id: id }, "-created_date", 100);
      setDbLances(lancesDB);
      setLoading(false);
    };
    init();
    const unsubLeilao = base44.entities.Leilao.subscribe((ev) => {
      if (ev.data?.id === id) setLeilao(ev.data);
    });
    const unsubLances = base44.entities.LeilaoLance.subscribe((ev) => {
      if (ev.data?.leilao_id !== id) return;
      if (ev.type === "create") setDbLances(prev => [ev.data, ...prev.filter(l => l.id !== ev.data.id)]);
    });
    return () => { unsubLeilao(); unsubLances(); };
  }, [id]);

  // Encerra automaticamente quando o timer chega a zero e envia relatório ao dono
  useEffect(() => {
    if (countdownTxt !== "Encerrado") return;
    if (!leilao || leilao.status !== "ativo") return;
    base44.entities.Leilao.update(id, {
      status: "encerrado",
      ganhador_id: leilao.maior_lance_user_id || "",
      ganhador_nome: leilao.maior_lance_user_nome || "",
      ganhador_email: leilao.maior_lance_user_email || "",
    });
    // Envia relatório por email ao dono
    if (leilao.dono_email && dbLances.length > 0) {
      const linhas = dbLances.map((l, i) =>
        `${i + 1}. ${l.user_nome} — R$ ${Number(l.valor).toFixed(2)} (${l.parcelas}x)`
      ).join("\n");
      const vencedor = dbLances[0];
      base44.integrations.Core.SendEmail({
        to: leilao.dono_email,
        subject: `🏆 Relatório Final — Leilão: ${leilao.titulo || leilao.animal_nome}`,
        body: `Olá ${leilao.dono_nome},\n\nSeu leilão foi encerrado!\n\n🥇 VENCEDOR: ${vencedor?.user_nome} (${vencedor?.user_email})\nValor: R$ ${Number(vencedor?.valor || 0).toFixed(2)} em ${vencedor?.parcelas}x\n\n📊 TODOS OS LANCES (${dbLances.length}):\n${linhas}\n\nAtenciosamente,\nEquipe Galo Mura`,
      }).catch(() => {});
    }
  }, [countdownTxt, leilao?.status]);

  const enviarLance = async () => {
    if (!user) return;
    const lanceAtual = leilao?.maior_lance || leilao?.lance_minimo || 0;
    const val = Number(meuLance);
    if (!val || val <= lanceAtual) { alert(`Lance deve ser maior que ${fmt(lanceAtual)}`); return; }
    
    // Optimistic UI: adiciona lance à lista imediatamente
    const novoLanceOtimista = {
      id: `temp-${Date.now()}`,
      leilao_id: id,
      user_id: user.id,
      user_nome: user.full_name,
      user_email: user.email,
      valor: val,
      parcelas,
      valor_parcela: val / parcelas,
      created_date: new Date().toISOString(),
    };
    setLanceOtimista(novoLanceOtimista);
    setMeuLance("");
    setEnviando(true);
    
    try {
      await enviarLanceSSE(val, user.full_name, user.email);
      await base44.entities.LeilaoLance.create({
        leilao_id: id, user_id: user.id, user_nome: user.full_name,
        user_email: user.email, valor: val, parcelas, valor_parcela: val / parcelas,
      });
      await base44.entities.Leilao.update(id, {
        maior_lance: val, maior_lance_user_id: user.id,
        maior_lance_user_nome: user.full_name, maior_lance_user_email: user.email,
      });
      setLanceOtimista(null);
    } catch (e) {
      setLanceOtimista(null);
      console.error("Erro ao enviar lance:", e);
      alert("Erro ao enviar lance. Tente novamente.");
    } finally {
      setEnviando(false);
    }
  };

  if (loading) return <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh" }}>Carregando...</div>;
  if (!leilao) return <div style={{ textAlign: "center", padding: 40 }}>Leilão não encontrado</div>;

  const lanceAtual = leilao.maior_lance || leilao.lance_minimo || 0;
  const sugestao = lanceAtual + Math.max(50, Math.ceil(lanceAtual * 0.1));
  const ehDono = user?.email === leilao.dono_email;
  const pagou = leilao.pagamento_confirmado;

  return (
    <div style={{ minHeight: "100vh", background: "#F1F4F8", fontFamily: "'DM Sans', sans-serif", paddingBottom: 90 }}>

      {/* ── Header ── */}
      <div style={{ background: "#fff", borderBottom: "1px solid #E8ECF0", padding: "13px 16px", display: "flex", alignItems: "center", gap: 12, position: "sticky", top: 0, zIndex: 20 }}>
        <Link to="/leiloes" style={{ color: "#101213", fontSize: 20, textDecoration: "none", lineHeight: 1 }}>←</Link>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {leilao.titulo || leilao.animal_nome}
          </div>
          <div style={{ fontSize: 11, color: conectado ? "#2E7D32" : "#BDBDBD", marginTop: 1 }}>
            ● {conectado ? "Conectado" : "Desconectado"}
          </div>
        </div>
        <div style={{ fontSize: 20 }}>🔔</div>
      </div>

      <div style={{ padding: "14px", maxWidth: 520, margin: "0 auto" }}>

        {/* ── Card principal ── */}
        <div style={{ background: "#fff", borderRadius: 16, overflow: "hidden", marginBottom: 14, boxShadow: "0 2px 12px rgba(0,0,0,.07)" }}>
          {leilao.animal_foto_url && (
            <div style={{ height: 200, background: `url(${leilao.animal_foto_url}) center/cover` }} />
          )}

          <div style={{ padding: "18px 16px 18px" }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#57636C", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 }}>
              Maior Lance Atual
            </div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 32, fontWeight: 900, color: "#170073", marginBottom: 4 }}>
              {fmt(lanceAtual)}
            </div>
            <div style={{ fontSize: 12, color: "#57636C", marginBottom: 16 }}>
              Por: {leilao.maior_lance_user_nome || "Aguardando..."} ({dbLances.length} lance{dbLances.length !== 1 ? "s" : ""})
            </div>

            {/* Timer badge */}
            <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: urgente ? "#FFEBEE" : "#E8F5E9", borderRadius: 22, padding: "7px 16px", marginBottom: 16 }}>
              <span style={{ fontSize: 13 }}>⏱</span>
              <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: urgente ? "#E21C3D" : "#2E7D32" }}>{countdownTxt}</span>
            </div>

            {/* Lance mínimo + Sugestão */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
              <div style={{ background: "#F8FAFC", borderRadius: 10, padding: "10px 12px" }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: "#57636C", textTransform: "uppercase", marginBottom: 4 }}>Lance Mínimo</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#101213" }}>{fmt(leilao.lance_minimo)}</div>
              </div>
              <div style={{ background: "#E8F5E9", borderRadius: 10, padding: "10px 12px", cursor: "pointer" }}
                onClick={() => setMeuLance(String(sugestao))}>
                <div style={{ fontSize: 10, fontWeight: 700, color: "#2E7D32", textTransform: "uppercase", marginBottom: 4 }}>Sugestão ↗</div>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "#00A893" }}>{fmt(sugestao)}</div>
              </div>
            </div>

            {/* Parcelamento + input + botão */}
            {user && leilao.status === "ativo" && !ehDono && (
              <>
                <div style={{ fontSize: 12, fontWeight: 700, color: "#57636C", marginBottom: 10 }}>Escolha as parcelas:</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 16 }}>
                  {PARCELAS.map(p => {
                    const base = Number(meuLance) > 0 ? Number(meuLance) : sugestao;
                    const vp = Math.ceil(base / p);
                    const sel = parcelas === p;
                    return (
                      <button key={p} onClick={() => setParcelas(p)}
                        style={{ padding: "6px 12px", borderRadius: 20, border: sel ? "2px solid #170073" : "1.5px solid #D8DCE5", background: sel ? "#170073" : "#F8FAFC", color: sel ? "#fff" : "#101213", fontFamily: "Montserrat,sans-serif", fontWeight: 800, fontSize: 11, cursor: "pointer", boxShadow: sel ? "0 4px 12px rgba(23,0,115,.25)" : "none", transition: "all .15s", whiteSpace: "nowrap" }}>
                        {p}x R${Number(vp).toLocaleString("pt-BR")}
                      </button>
                    );
                  })}
                </div>

                <div style={{ display: "flex", gap: 8, width: "100%" }}>
                  <input
                    type="number"
                    value={meuLance}
                    onChange={e => setMeuLance(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && enviarLance()}
                    placeholder={`R$ ${sugestao.toFixed(2).replace(".", ",")}`}
                    style={{ flex: 1, minWidth: 0, padding: "12px 10px", borderRadius: 10, border: "1.5px solid #E8ECF0", fontSize: 14, fontWeight: 700, outline: "none", color: "#101213", fontFamily: "Montserrat,sans-serif", boxSizing: "border-box" }}
                  />
                  <button onClick={enviarLance} disabled={enviando}
                    style={{ flexShrink: 0, padding: "12px 16px", borderRadius: 10, border: "none", background: enviando ? "#aaa" : "linear-gradient(135deg,#00A893,#170073)", color: "#fff", cursor: enviando ? "default" : "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 800, fontSize: 13, whiteSpace: "nowrap" }}>
                    🔨 Lance
                  </button>
                </div>
              </>
            )}

            {leilao.status !== "ativo" && (
              <div style={{ background: "#F1F4F8", borderRadius: 10, padding: 12, textAlign: "center", fontSize: 12, fontWeight: 700, color: "#57636C" }}>
                Leilão {leilao.status}
              </div>
            )}
          </div>
        </div>

        {/* ── Controle do dono ── */}
        {ehDono && <ControleAoVivo leilao={leilao} user={user} isOwner={true} />}

        {/* ── Detalhes do Animal ── */}
        <div style={{ background: "#fff", borderRadius: 16, overflow: "hidden", marginBottom: 14, boxShadow: "0 1px 6px rgba(0,0,0,.06)" }}>
          <div style={{ padding: "14px 16px 10px", borderBottom: "1px solid #F1F4F8" }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: 900, color: "#101213" }}>ℹ️ Detalhes do Animal</div>
          </div>
          <div style={{ padding: "12px 16px" }}>
            {[
              { l: "Anilha",   v: leilao.animal_anilha || "—" },
              { l: "Espécie",  v: leilao.animal_especie || "—" },
              { l: "Vendedor", v: leilao.dono_nome || "—", bold: true },
              { l: "WhatsApp", v: pagou ? (leilao.dono_whatsapp || "—") : "🔒 Liberado após pagamento PIX", cor: pagou ? "#1565C0" : "#BDBDBD" },
            ].map((r, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingBottom: 9, marginBottom: 9, borderBottom: i < 3 ? "1px solid #F1F4F8" : "none" }}>
                <span style={{ fontSize: 13, color: "#57636C" }}>{r.l}</span>
                <span style={{ fontFamily: "Montserrat,sans-serif", fontSize: 13, fontWeight: r.bold ? 900 : 700, color: r.cor || "#101213" }}>{r.v}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ── Status conexão ── */}
        <div style={{ background: "#fff", borderRadius: 12, padding: "10px 14px", marginBottom: 14, display: "flex", alignItems: "center", gap: 8, boxShadow: "0 1px 4px rgba(0,0,0,.05)" }}>
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: conectado ? "#2E7D32" : "#BDBDBD", flexShrink: 0 }} />
          <span style={{ fontSize: 12, color: "#57636C", fontWeight: 600 }}>
            {conectado ? "conectado ao servidor de lances" : "desconectado"}
          </span>
          {status && <span style={{ fontSize: 11, color: "#57636C", marginLeft: "auto" }}>📡 {status}</span>}
        </div>

        {/* ── Encerrado ── */}
        {(encerrado || leilao.status === "encerrado") && (
          <div style={{ background: "#E8F5E9", borderRadius: 12, padding: "14px 16px", marginBottom: 14, textAlign: "center", border: "1px solid #A5D6A7" }}>
            <div style={{ fontSize: 28, marginBottom: 6 }}>✅</div>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontWeight: 900, color: "#1B5E20", fontSize: 14 }}>Leilão Encerrado</div>
            {leilao.ganhador_nome && <div style={{ fontSize: 12, color: "#2E7D32", marginTop: 4 }}>Ganhador: <strong>{leilao.ganhador_nome}</strong></div>}
          </div>
        )}

        {/* ── Lista de lances ── */}
        <ListaLances lances={lanceOtimista ? [lanceOtimista, ...dbLances] : dbLances} userEmail={user?.email} />

        {/* ── Chat ao vivo ── */}
        <ChatAoVivo leilaoId={id} user={user} />
      </div>

      <BottomNav />
    </div>
  );
}