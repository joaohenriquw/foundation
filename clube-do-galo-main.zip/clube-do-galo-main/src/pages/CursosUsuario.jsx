import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import NotificacoesSino from "../components/NotificacoesSino";
import BottomNav from "../components/BottomNav";
import { getPlano } from "../lib/planos";

const CATEGORIAS = {
  tecnica_criacao: { label: "Técnica de Criação", emoji: "🐓", cor: "#1565C0" },
  saude_animal: { label: "Saúde do Animal", emoji: "🏥", cor: "#E21C3D" },
  nutricao: { label: "Nutrição", emoji: "🥗", cor: "#00A893" },
  genetica: { label: "Genética", emoji: "🧬", cor: "#8B5CF6" },
  comportamento: { label: "Comportamento", emoji: "🧠", cor: "#F0A500" },
  negociacao: { label: "Negociação", emoji: "💼", cor: "#2E7D32" },
};

export default function CursosUsuario() {
  const [user, setUser] = useState(null);
  const [cursos, setCursos] = useState([]);
  const [aulas, setAulas] = useState([]);
  const [filtroCategoria, setFiltroCategoria] = useState("todos");
  const [loading, setLoading] = useState(true);
  const [cursoSelecionado, setCursoSelecionado] = useState(null);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      setUser(me);

      const cursosData = await base44.entities.Curso.filter({ ativo: true }, "-created_date", 200);
      const aulasData = await base44.entities.Aula.list("-created_date", 500);
      setCursos(cursosData);
      setAulas(aulasData);
      setLoading(false);
    };
    init();

    const unsub = base44.entities.Curso.subscribe(() => {
      init();
    });
    return unsub;
  }, []);

  // Verificar permissão de acesso aos cursos
  const planoUser = user?.role === "admin" || user?.role === "master_admin" ? "premium" : (user?.plano || "iniciante");
  const planoConfig = getPlano(planoUser);
  const podeCourses = planoConfig.pode_curso;
  
  // Combinar cursos com aulas criadas se tiver permissão
  const cursosExibir = podeCourses ? cursos : [];
  const aulasExibir = podeCourses ? aulas : [];
  const cursosFiltrados = filtroCategoria === "todos" ? cursosExibir : cursosExibir.filter(c => c.categoria === filtroCategoria);

  if (loading) return <div style={{ textAlign: "center", padding: 20 }}>Carregando...</div>;

  return (
    <div style={{ minHeight: "100vh", background: "hsl(var(--background))", paddingBottom: 80 }}>
      <div style={{ background: "linear-gradient(135deg,hsl(var(--primary)),#00A893)", padding: "20px 24px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <Link to="/" style={{ color: "rgba(255,255,255,.7)", fontSize: 22, textDecoration: "none" }}>←</Link>
            <div>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 18, fontWeight: 900, color: "#fff" }}>📚 Cursos</div>
              <div style={{ fontSize: 11, color: "rgba(255,255,255,.75)" }}>Aprenda com especialistas</div>
            </div>
          </div>
          <NotificacoesSino userEmail={user?.email} />
        </div>
      </div>

      <div style={{ padding: "16px 16px 40px", maxWidth: 900, margin: "0 auto" }}>
        {/* Filtros */}
        <div style={{ display: "flex", gap: 6, marginBottom: 16, overflowX: "auto", paddingBottom: 6 }}>
          <button onClick={() => setFiltroCategoria("todos")}
            style={{ padding: "8px 14px", borderRadius: 10, border: "none", background: filtroCategoria === "todos" ? "hsl(var(--primary))" : "hsl(var(--background))", color: filtroCategoria === "todos" ? "hsl(var(--primary-foreground))" : "hsl(var(--muted-foreground))", cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif", whiteSpace: "nowrap", border: filtroCategoria === "todos" ? "none" : `1px solid hsl(var(--border))` }}>
            Todos
          </button>
          {Object.entries(CATEGORIAS).map(([k, v]) => (
            <button key={k} onClick={() => setFiltroCategoria(k)}
              style={{ padding: "8px 14px", borderRadius: 10, border: "none", background: filtroCategoria === k ? v.cor : "hsl(var(--background))", color: filtroCategoria === k ? "#fff" : v.cor, cursor: "pointer", fontWeight: 700, fontSize: 11, fontFamily: "Montserrat,sans-serif", whiteSpace: "nowrap", border: filtroCategoria === k ? "none" : `1.5px solid ${v.cor}` }}>
              {v.emoji}
            </button>
          ))}
        </div>

        {!podeCourses && (
          <div style={{ background: 'hsl(var(--destructive)/.1)', borderRadius: 12, padding: "16px", marginBottom: 16, border: `1px solid hsl(var(--destructive)/.2)` }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'hsl(var(--destructive))' }}>
              🔒 Acesso a cursos disponível apenas nos planos Gold e Premium
            </div>
          </div>
        )}
        
        {/* Aulas Criadas */}
        {aulasExibir.length > 0 && (
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 14, fontWeight: 900, color: "hsl(var(--foreground))", marginBottom: 12 }}>🎓 Aulas Criadas</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12, marginBottom: 20 }}>
              {aulasExibir.map(a => (
                <div key={a.id}
                  style={{ background: "hsl(var(--background))", borderRadius: 14, border: "1px solid hsl(var(--border))", overflow: "hidden", cursor: "pointer", transition: "all 0.3s ease" }}
                  onMouseEnter={e => { e.currentTarget.style.transform = "scale(1.02)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,.12)"; }}
                  onMouseLeave={e => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.boxShadow = "none"; }}>
                  
                  <div style={{ background: "linear-gradient(135deg,hsl(var(--primary)),#00A893)", height: 140, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 48 }}>🎬</div>
                  
                  <div style={{ padding: 12 }}>
                    <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "hsl(var(--foreground))", marginBottom: 4, lineHeight: 1.3 }}>
                      {a.titulo}
                    </div>
                    <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginBottom: 8, lineHeight: 1.4 }}>
                      {a.descricao?.substring(0, 60) || "Aula"}
                    </div>
                    <div style={{ display: "flex", gap: 6 }}>
                      <span style={{ background: 'hsl(var(--primary)/.1)', color: "hsl(var(--primary))", padding: "2px 6px", borderRadius: 4, fontSize: 9, fontWeight: 700 }}>
                        ⏱️ {a.duracao_minutos || 0}min
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Cursos */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12 }}>
          {cursosFiltrados.map(c => (
            <div key={c.id} onClick={() => setCursoSelecionado(c)}
              style={{ background: "hsl(var(--background))", borderRadius: 14, border: "1px solid hsl(var(--border))", overflow: "hidden", cursor: "pointer", transition: "all 0.3s ease", transform: "scale(1)" }}
              onMouseEnter={e => { e.currentTarget.style.transform = "scale(1.02)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,.12)"; }}
              onMouseLeave={e => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.boxShadow = "none"; }}>
              
              {/* Thumbnail */}
              <div style={{ background: CATEGORIAS[c.categoria]?.cor, height: 140, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 48 }}>
                {CATEGORIAS[c.categoria]?.emoji}
              </div>

              {/* Info */}
              <div style={{ padding: 12 }}>
                <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 12, fontWeight: 900, color: "hsl(var(--foreground))", marginBottom: 4, lineHeight: 1.3 }}>
                  {c.titulo}
                </div>
                <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", marginBottom: 8, lineHeight: 1.4 }}>
                  {c.descricao.substring(0, 60)}...
                </div>
                <div style={{ display: "flex", gap: 6, marginBottom: 8 }}>
                  <span style={{ background: 'hsl(var(--primary)/.1)', color: "hsl(var(--primary))", padding: "2px 6px", borderRadius: 4, fontSize: 9, fontWeight: 700 }}>
                    {c.nivel.toUpperCase()}
                  </span>
                  <span style={{ background: 'hsl(var(--primary)/.05)', color: "hsl(var(--muted-foreground))", padding: "2px 6px", borderRadius: 4, fontSize: 9, fontWeight: 700 }}>
                    ⏱️ {c.duracao_minutos}min
                  </span>
                </div>
                <div style={{ fontSize: 9, color: "hsl(var(--muted-foreground))" }}>👁️ {c.visualizacoes} visualizações</div>
              </div>
            </div>
          ))}
        </div>

        {!podeCourses && aulasExibir.length === 0 && (
          <div style={{ textAlign: "center", padding: 40, color: "hsl(var(--muted-foreground))" }}>
            <div style={{ fontSize: 32, marginBottom: 10 }}>🔒</div>
            <div style={{ fontWeight: 700 }}>Acesso restrito</div>
            <div style={{ fontSize: 12, marginTop: 8 }}>Faça upgrade para Gold ou Premium</div>
          </div>
        )}
        
        {podeCourses && cursosFiltrados.length === 0 && aulasExibir.length === 0 && (
          <div style={{ textAlign: "center", padding: 40, color: "hsl(var(--muted-foreground))" }}>
            <div style={{ fontSize: 32, marginBottom: 10 }}>📚</div>
            <div style={{ fontWeight: 700 }}>Nenhum conteúdo disponível</div>
          </div>
        )}
      </div>

      {/* Modal Detalhes Curso */}
      {cursoSelecionado && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.55)", zIndex: 2000, display: "flex", alignItems: "flex-end" }} onClick={() => setCursoSelecionado(null)}>
          <div style={{ background: "hsl(var(--background))", borderRadius: "20px 20px 0 0", width: "100%", maxWidth: 500, padding: "24px 20px 40px", maxHeight: "90vh", overflowY: "auto" }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
              <div style={{ fontFamily: "Montserrat,sans-serif", fontSize: 16, fontWeight: 900, color: "hsl(var(--primary))" }}>
                {CATEGORIAS[cursoSelecionado.categoria]?.emoji} {cursoSelecionado.titulo}
              </div>
              <button onClick={() => setCursoSelecionado(null)} style={{ background: "none", border: "none", fontSize: 20, cursor: "pointer", color: "hsl(var(--muted-foreground))" }}>✕</button>
            </div>

            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: "hsl(var(--muted-foreground))", marginBottom: 6 }}>Descrição</div>
              <div style={{ fontSize: 12, color: "hsl(var(--foreground))", lineHeight: 1.6 }}>
                {cursoSelecionado.descricao}
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
              <div style={{ background: 'hsl(var(--primary)/.1)', borderRadius: 8, padding: 10 }}>
                <div style={{ fontSize: 10, color: "hsl(var(--primary))", fontWeight: 700 }}>⏱️ Duração</div>
                <div style={{ fontSize: 12, color: "hsl(var(--primary))", fontWeight: 900 }}>{cursoSelecionado.duracao_minutos} min</div>
              </div>
              <div style={{ background: 'hsl(var(--secondary)/.2)', borderRadius: 8, padding: 10 }}>
                <div style={{ fontSize: 10, color: "hsl(var(--muted-foreground))", fontWeight: 700 }}>📊 Nível</div>
                <div style={{ fontSize: 12, color: "hsl(var(--foreground))", fontWeight: 900 }}>{cursoSelecionado.nivel.toUpperCase()}</div>
              </div>
            </div>

            <a href={cursoSelecionado.video_url} target="_blank" rel="noopener noreferrer"
              style={{ width: "100%", padding: "12px", borderRadius: 10, border: "none", background: "linear-gradient(135deg,hsl(var(--primary)),#00A893)", color: "hsl(var(--primary-foreground))", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 900, display: "block", textAlign: "center", textDecoration: "none", marginBottom: 10 }}>
              🎥 Assistir Aula
            </a>

            <Link to="/meus-treinos"
              style={{ width: "100%", padding: "12px", borderRadius: 10, border: `1.5px solid hsl(var(--primary))`, background: "hsl(var(--background))", color: "hsl(var(--primary))", cursor: "pointer", fontFamily: "Montserrat,sans-serif", fontWeight: 900, display: "block", textAlign: "center", textDecoration: "none" }}>
              📝 Registrar Treino
            </Link>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}