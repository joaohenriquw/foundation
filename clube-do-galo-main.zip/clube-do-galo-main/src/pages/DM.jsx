import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import ChatDM from '../components/ChatDM';
import ListaConversasDM from '../components/ListaConversasDM';
import BottomNav from '../components/BottomNav';

export default function DM() {
  const { conversaId } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [conversa, setConversa] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      if (!me) {
        navigate('/');
        return;
      }
      setUser(me);
      
      if (conversaId) {
        const convs = await base44.entities.ConversaDM.filter({ id: conversaId });
        if (convs.length > 0) {
          setConversa(convs[0]);
        }
      }
      setLoading(false);
    };
    init();
  }, [conversaId, navigate]);

  if (loading) return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>⏳</div>;
  if (!user) return null;

  const outroUsuario = conversa ? {
    email: user.email === conversa.usuario1_email ? conversa.usuario2_email : conversa.usuario1_email,
    nome: user.email === conversa.usuario1_email ? conversa.usuario2_email : conversa.usuario1_nome
  } : null;

  return (
    <div style={{ minHeight: '100vh', background: '#F8FAFC', fontFamily: "'DM Sans', sans-serif", paddingBottom: 120 }}>
      {/* Header */}
      <div style={{ background: 'linear-gradient(135deg,#170073,#00A893)', padding: '20px 16px', color: '#fff' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={() => navigate('/')} style={{ background: 'rgba(255,255,255,.2)', border: 'none', borderRadius: 10, width: 38, height: 38, cursor: 'pointer', fontSize: 18, color: '#fff' }}>
            ←
          </button>
          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 18, fontWeight: 900 }}>
            💬 Mensagens Diretas
          </div>
        </div>
      </div>

      <div style={{ padding: '16px', maxWidth: 900, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: 16, minHeight: 'calc(100vh - 200px)' }}>
          {/* Lista */}
          <div style={{ background: '#fff', borderRadius: 14, padding: 16, border: '1px solid #E8ECF0', height: 'fit-content' }}>
            <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 13, fontWeight: 900, color: '#170073', marginBottom: 12 }}>
              💬 Conversas
            </div>
            <ListaConversasDM user={user} />
          </div>

          {/* Chat */}
          {conversa && outroUsuario ? (
            <ChatDM conversaId={conversaId} user={user} outroUsuario={outroUsuario} />
          ) : (
            <div style={{ background: '#fff', borderRadius: 14, border: '1px solid #E8ECF0', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div style={{ textAlign: 'center', color: '#57636C' }}>
                <div style={{ fontSize: 40, marginBottom: 10 }}>💬</div>
                <div style={{ fontSize: 13, fontWeight: 700 }}>Selecione uma conversa</div>
              </div>
            </div>
          )}
        </div>
      </div>

      <BottomNav />
    </div>
  );
}