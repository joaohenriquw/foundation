import { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BackHeader from "../components/BackHeader";
import AnilhasFilhas from "../components/AnilhasFilhas";
import TrocaPosseModal from "../components/TrocaPosseModal";
import CriarLeilaoModal from "../components/CriarLeilaoModal";
import PlanoGuard from "../components/PlanoGuard";
import AdicionarVitrineModal from "../components/AdicionarVitrineModal";
import PedigreeTree from "../components/PedigreeTree";
import TemporadaCombateModal from "../components/TemporadaCombateModal";
import AnimalPDFModal from "../components/AnimalPDFModal";
import { getPlano } from "../lib/planos";
import BottomNav from "../components/BottomNav";
import { createPortal } from "react-dom";

const CATEGORIA_TABS = [
  { key: "todos",           label: "Todos" },
  { key: "elenco_principal",label: "Elenco Principal" },
  { key: "reprodutor",      label: "Reprodutores" },
  { key: "matriz",          label: "Matrizes" },
  { key: "criacao",         label: "Criação" },
];

const CATEGORIA_COR = {
  elenco_principal: "#00C9B8",
  reprodutor:       "#00C9B8",
  matriz:           "#00C9B8",
  criacao:          "#00C9B8",
};

const CATEGORIA_LABEL = {
  elenco_principal: "Elenco Principal",
  reprodutor:       "Reprodutor",
  matriz:           "Matriz",
  criacao:          "Criação",
};

const SEXO_LABEL = { macho: "Macho", femea: "Fêmea" };

function ActionSheet({ animal, onClose, onEditar, onNinhada, onVitrine, onTemporada, onPdf, onLeilao, onTroca, onExcluir, userMeta }) {
  return createPortal(
    <div style={{ position: "fixed", inset: 0, zIndex: 9999, display: "flex", flexDirection: "column", justifyContent: "flex-end" }}>
      <div onClick={onClose} style={{ flex: 1, background: "rgba(0,0,0,.5)" }} />
      <div style={{ background: "#1C1C1E", borderRadius: "20px 20px 0 0", padding: "16px 16px 32px" }}>
        <div style={{ width: 40, height: 4, background: "#555", borderRadius: 2, margin: "0 auto 20px" }} />
        {[
          { label: "✏️  Editar", action: onEditar, color: "#fff" },
          { label: "🔄  Troca de Posse", action: onTroca, color: "#fff" },
          { label: "🐣  Registrar Ninhada", action: onNinhada, color: "#fff" },
          { label: "🏪  Vitrine", action: onVitrine, color: "#00C9B8" },
          { label: "🏆  Temporadas de Apresentações", action: onTemporada, color: "#fff" },
          { label: "📄  Baixar PDF", action: onPdf, color: "#fff" },
          { label: "🔨  Criar Leilão", action: onLeilao, color: "#A78BFA" },
          { label: "🗑️  Excluir Registro", action: onExcluir, color: "#FF453A" },
        ].map(({ label, action, color }) => (
          <button key={label} onClick={action}
            style={{ width: "100%", padding: "16px", background: "#2C2C2E", border: "none", borderRadius: 14, marginBottom: 8, color, fontSize: 15, fontWeight: 600, textAlign: "left", cursor: "pointer", fontFamily: "inherit" }}>
            {label}
          </button>
        ))}
        <button onClick={onClose}
          style={{ width: "100%", padding: "16px", background: "#2C2C2E", border: "none", borderRadius: 14, color: "#fff", fontSize: 15, fontWeight: 700, textAlign: "center", cursor: "pointer", fontFamily: "inherit" }}>
          Cancelar
        </button>
      </div>
    </div>,
    document.body
  );
}

export default function Plantel() {
  const navigate = useNavigate();
  const [animais, setAnimais]     = useState([]);
  const [loading, setLoading]     = useState(true);
  const [filtroCategoria, setFiltroCategoria] = useState("todos");
  const [busca, setBusca]         = useState("");
  const [user, setUser]           = useState(null);
  const [userMeta, setUserMeta]   = useState(null);

  const [actionAnimal, setActionAnimal]       = useState(null);
  const [anilhasAnimal, setAnilhasAnimal]     = useState(null);
  const [trocaAnimal, setTrocaAnimal]         = useState(null);
  const [leilaoAnimal, setLeilaoAnimal]       = useState(null);
  const [vitrineAnimal, setVitrineAnimal]     = useState(null);
  const [pedigreeAnimal, setPedigreeAnimal]   = useState(null);
  const [temporadaAnimal, setTemporadaAnimal] = useState(null);
  const [pdfAnimal, setPdfAnimal]             = useState(null);

  const carregar = async () => {
    setLoading(true);
    const me = await base44.auth.me().catch(() => null);
    const data = me ? await base44.entities.Animal.filter({ proprietario_email: me.email }, "-created_date", 200) : [];
    setAnimais(data);
    setUser(me);
    if (me) setUserMeta(me);
    setLoading(false);
  };

  useEffect(() => { carregar(); }, []);

  const excluir = async (id) => {
    setActionAnimal(null);
    if (!confirm("Excluir este animal do plantel?")) return;
    await base44.entities.Animal.delete(id);
    setAnimais(prev => prev.filter(a => a.id !== id));
  };

  const animaisFiltrados = animais.filter(a => {
    if (filtroCategoria !== "todos" && a.tipo_categoria !== filtroCategoria) return false;
    if (busca && !`${a.nome} ${a.anilha} ${a.especie || ""}`.toLowerCase().includes(busca.toLowerCase())) return false;
    return true;
  });

  return (
    <div style={{ minHeight: "100vh", background: "#000", fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 90, color: "#fff" }}>
      <BackHeader 
        title="Plantel"
        showBackButton={true}
        rightAction={
          <button onClick={() => navigate('/animal-form')}
            style={{ background: "#170073", border: "none", borderRadius: 10, width: 38, height: 38, cursor: "pointer", fontSize: 18, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>+</button>
        }
      />

      {/* Search */}
      <div style={{ padding: "0 16px 12px", background: "#0A0A0A" }}>
        <input
          placeholder="Pesquisar"
          value={busca}
          onChange={e => setBusca(e.target.value)}
          style={{ width: "100%", padding: "12px 16px", background: "#1C1C1E", border: "none", borderRadius: 12, color: "#fff", fontSize: 15, outline: "none", boxSizing: "border-box" }}
        />
      </div>

      {/* Category Tabs */}
      <div style={{ display: "flex", overflowX: "auto", padding: "0 16px 2px", gap: 0, borderBottom: "1px solid #222", scrollbarWidth: "none", WebkitOverflowScrolling: "touch" }}>
        {CATEGORIA_TABS.map(tab => (
          <button key={tab.key} onClick={() => setFiltroCategoria(tab.key)}
            style={{ background: "none", border: "none", borderBottom: filtroCategoria === tab.key ? "2px solid #00C9B8" : "2px solid transparent", color: filtroCategoria === tab.key ? "#fff" : "#888", fontSize: 12, fontWeight: filtroCategoria === tab.key ? 700 : 500, padding: "8px 12px", cursor: "pointer", whiteSpace: "nowrap", fontFamily: "inherit", marginBottom: -1, flexShrink: 0 }}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* List */}
      <div style={{ padding: "12px 16px" }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: 60, color: "#555" }}>Carregando...</div>
        ) : animaisFiltrados.length === 0 ? (
          <div style={{ textAlign: "center", padding: 60 }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🐓</div>
            <div style={{ color: "#555", fontSize: 14 }}>Nenhum animal encontrado</div>
            <button onClick={() => navigate('/animal-form')}
              style={{ marginTop: 20, background: "linear-gradient(135deg, #00C9B8, #7C3AED)", border: "none", borderRadius: 12, padding: "12px 28px", color: "#fff", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
              + Adicionar Animal
            </button>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {animaisFiltrados.map(a => {
              const catLabel = CATEGORIA_LABEL[a.tipo_categoria] || "—";
              const catCor = CATEGORIA_COR[a.tipo_categoria] || "#00C9B8";
              return (
                <div key={a.id} style={{ background: "#1A1A2E", borderRadius: 16, overflow: "hidden" }}>
                  {/* Card gradient header */}
                  <div style={{ background: "linear-gradient(90deg, #00C9B8 0%, #5B2BE0 100%)", padding: "10px 14px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    {a.nome ? <span style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>{a.nome}</span> : <span />}
                    <button onClick={() => setActionAnimal(a)}
                      style={{ background: "none", border: "none", color: "#fff", fontSize: 20, cursor: "pointer", padding: "0 4px", lineHeight: 1 }}>
                      •••
                    </button>
                  </div>

                  {/* Card body */}
                  <div style={{ display: "flex", gap: 0 }}>
                    {/* Photo */}
                    <div style={{ width: 130, height: 130, flexShrink: 0, background: a.foto_url ? `url(${a.foto_url}) center/cover` : "#2A2A3E", display: "flex", alignItems: "center", justifyContent: "center" }}>
                      {!a.foto_url && <span style={{ fontSize: 48 }}>🐓</span>}
                    </div>
                    {/* Info */}
                    <div style={{ padding: "14px 14px", flex: 1 }}>
                      <div style={{ fontSize: 14, color: "#fff", marginBottom: 4 }}>Anilha: {a.anilha || "—"}</div>
                      <div style={{ fontSize: 13, color: catCor, fontWeight: 600, marginBottom: 4 }}>{catLabel}</div>
                      <div style={{ fontSize: 13, color: "#aaa", marginBottom: 2 }}>Peso: {a.peso_gramas ? `${a.peso_gramas}g` : "Kg"}</div>
                      <div style={{ fontSize: 13, color: "#aaa" }}>{SEXO_LABEL[a.sexo] || "—"}</div>
                      {a.especie && <div style={{ fontSize: 12, color: "#666", marginTop: 4 }}>{a.especie}</div>}
                    </div>
                  </div>

                  {/* Pedigree */}
                  {(a.pai_nome || a.mae_nome) && (
                    <div style={{ padding: "8px 14px 12px", borderTop: "1px solid #2A2A3E" }}>
                      {a.pai_nome && <div style={{ fontSize: 12, color: "#aaa" }}>Pai: {a.pai_nome}</div>}
                      {a.mae_nome && <div style={{ fontSize: 12, color: "#aaa" }}>Mãe: {a.mae_nome}</div>}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Action Sheet */}
      {actionAnimal && (
        <ActionSheet
          animal={actionAnimal}
          userMeta={userMeta}
          onClose={() => setActionAnimal(null)}
          onEditar={() => { setActionAnimal(null); navigate(`/animal-form?id=${actionAnimal.id}`); }}
          onTroca={() => { setTrocaAnimal(actionAnimal); setActionAnimal(null); }}
          onNinhada={() => { setAnilhasAnimal(actionAnimal); setActionAnimal(null); }}
          onVitrine={() => { setVitrineAnimal(actionAnimal); setActionAnimal(null); }}
          onTemporada={() => { setTemporadaAnimal(actionAnimal); setActionAnimal(null); }}
          onPdf={() => { setPdfAnimal(actionAnimal); setActionAnimal(null); }}
          onLeilao={() => { setLeilaoAnimal(actionAnimal); setActionAnimal(null); }}
          onExcluir={() => excluir(actionAnimal.id)}
        />
      )}

      {anilhasAnimal && <AnilhasFilhas animal={anilhasAnimal} user={user} onClose={() => setAnilhasAnimal(null)} />}
      {trocaAnimal && <TrocaPosseModal animal={trocaAnimal} user={user} onClose={() => setTrocaAnimal(null)} onConcluido={carregar} />}
      {leilaoAnimal && <CriarLeilaoModal user={user} animalPreSelecionado={leilaoAnimal} onClose={() => setLeilaoAnimal(null)} onCriado={carregar} />}
      {vitrineAnimal && <AdicionarVitrineModal animal={vitrineAnimal} user={user} userMeta={userMeta} onClose={() => setVitrineAnimal(null)} onConcluido={carregar} />}
      {pedigreeAnimal && <PedigreeTree animal={pedigreeAnimal} onClose={() => setPedigreeAnimal(null)} />}
      {temporadaAnimal && user && <TemporadaCombateModal animal={temporadaAnimal} user={user} onClose={() => setTemporadaAnimal(null)} />}
      {pdfAnimal && <AnimalPDFModal animal={pdfAnimal} onClose={() => setPdfAnimal(null)} />}

      <BottomNav />
    </div>
  );
}