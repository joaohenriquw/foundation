import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import FeedSocial from '../components/FeedSocial';
import PullToRefresh from '../components/PullToRefresh';
import BottomNav from '../components/BottomNav';

export default function Social() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [abaMostrada, setAbaMostrada] = useState('seguindo');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      const me = await base44.auth.me().catch(() => null);
      if (!me) {
        navigate('/');
        return;
      }
      setUser(me);
      setLoading(false);
    };
    init();
  }, [navigate]);

  if (loading) return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>⏳</div>;
  if (!user) return null;

  return (
    <div style={{ minHeight: '100vh', background: '#000', fontFamily: "'DM Sans', -apple-system, sans-serif", paddingBottom: 120, color: '#fff' }}>
      {/* Header */}
      <div style={{ background: '#0A0A0A', padding: '52px 16px 16px', borderBottom: '1px solid #1C1C1E' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 12 }}>
          <button onClick={() => navigate('/')} style={{ background: 'rgba(255,255,255,.2)', border: 'none', borderRadius: 10, width: 38, height: 38, cursor: 'pointer', fontSize: 18, color: '#fff' }}>
            ←
          </button>
          <div style={{ fontFamily: 'Montserrat,sans-serif', fontSize: 18, fontWeight: 900 }}>
            📱 Social
          </div>
        </div>
      </div>

      <PullToRefresh onRefresh={() => setAbaMostrada(abaMostrada)}>
        <div style={{ padding: '16px', maxWidth: 600, margin: '0 auto', 'data-tab-scroll': true }}>
          {/* Abas */}
          <div style={{ display: 'flex', gap: 10, marginBottom: 16, borderBottom: '1px solid #1C1C1E', paddingBottom: 12 }}>
            <button onClick={() => setAbaMostrada('seguindo')}
            style={{
              padding: '8px 14px',
              borderRadius: 10,
              border: 'none',
              background: abaMostrada === 'seguindo' ? '#7C3AED' : 'transparent',
              color: abaMostrada === 'seguindo' ? '#fff' : '#555',
              cursor: 'pointer',
              fontSize: 12,
              fontWeight: 700,
              fontFamily: 'Montserrat,sans-serif'
            }}>
            👥 Seguindo
          </button>
          <button onClick={() => setAbaMostrada('todos')}
            style={{
              padding: '8px 14px',
              borderRadius: 10,
              border: 'none',
              background: abaMostrada === 'todos' ? '#7C3AED' : 'transparent',
              color: abaMostrada === 'todos' ? '#fff' : '#555',
              cursor: 'pointer',
              fontSize: 12,
              fontWeight: 700,
              fontFamily: 'Montserrat,sans-serif'
            }}>
            🌍 Explorar
          </button>
        </div>

          {/* Feed */}
          <FeedSocial user={user} tipo={abaMostrada} />
        </div>
      </PullToRefresh>

      <BottomNav />
    </div>
  );
}