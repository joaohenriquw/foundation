import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Buscar usuários criados nos últimos 15 minutos que ainda não receberam email
    const agora = new Date();
    const ha15min = new Date(agora.getTime() - 15 * 60 * 1000);

    const usuarios = await base44.asServiceRole.entities.User.filter(
      { created_date: { $gte: ha15min.toISOString() } },
      "-created_date",
      100
    );

    let enviados = 0;

    for (const usuario of usuarios) {
      if (!usuario.email) continue;

      // Verificar se já enviou email
      const notifs = await base44.asServiceRole.entities.Notificacao.filter({
        destinatario_email: usuario.email,
        tipo: 'boas_vindas',
      });

      if (notifs.length > 0) continue; // Já enviou

      const appUrl = 'https://clube-do-galo.app';
      const nome = usuario.full_name?.split(' ')[0] || usuario.email;

      await base44.integrations.Core.SendEmail({
        to: usuario.email,
        subject: `🎉 Bem-vindo(a) ao Clube do Galo, ${nome}!`,
        body: `
<html>
  <body style="font-family: 'DM Sans', sans-serif; background: #f8fafc; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
      <div style="background: linear-gradient(135deg, #170073, #00A893); padding: 40px 20px; text-align: center; color: #fff;">
        <div style="font-size: 48px; margin-bottom: 16px;">🐓</div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 900;">Bem-vindo ao Clube do Galo!</h1>
        <p style="margin: 8px 0 0; opacity: 0.9; font-size: 14px;">A maior plataforma de leilões, rifas e consultorias de aves</p>
      </div>
      
      <div style="padding: 40px 24px;">
        <p style="margin: 0 0 20px; font-size: 16px; color: #101213;">
          Olá, <strong>${nome}!</strong>
        </p>
        
        <p style="margin: 0 0 20px; font-size: 14px; color: #57636C; line-height: 1.6;">
          Sua conta foi criada com sucesso! 🎉 Agora você pode:
        </p>
        
        <div style="background: #f0f4ff; border-left: 4px solid #170073; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
          <p style="margin: 8px 0; font-size: 13px; color: #170073;"><strong>✨ Participar de leilões</strong> - Colecione os melhores animais da região</p>
          <p style="margin: 8px 0; font-size: 13px; color: #170073;"><strong>🎲 Jogar rifas</strong> - Chances incríveis de ganhar prêmios</p>
          <p style="margin: 8px 0; font-size: 13px; color: #170073;"><strong>👨‍⚖️ Consultas especializadas</strong> - Advogado, veterinário e muito mais</p>
          <p style="margin: 8px 0; font-size: 13px; color: #170073;"><strong>📢 Anunciar seus animais</strong> - Venda e monetize sua criação</p>
        </div>
        
        <p style="margin: 0 0 20px; font-size: 14px; color: #57636C; line-height: 1.6;">
          <strong>Primeiros passos:</strong>
        </p>
        
        <ol style="margin: 0 0 20px; padding-left: 20px; font-size: 13px; color: #57636C; line-height: 1.8;">
          <li>Complete seu perfil com foto e dados de contato</li>
          <li>Adicione sua carteira (PIX para saques)</li>
          <li>Explore leilões e rifas disponíveis</li>
          <li>Marque seus favoritos para receber alertas!</li>
        </ol>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${appUrl}/" style="display: inline-block; background: linear-gradient(135deg, #170073, #00A893); color: #fff; padding: 12px 32px; border-radius: 10px; text-decoration: none; font-weight: 800; font-size: 14px;">Começar Agora</a>
        </div>
        
        <hr style="border: none; border-top: 1px solid #e8ecf0; margin: 30px 0;">
        
        <p style="margin: 0; font-size: 12px; color: #9E9E9E; line-height: 1.6;">
          Dúvidas? Acesse nosso suporte ou entre em contato com nossa equipe. Estamos aqui para ajudar! 💪
        </p>
      </div>
      
      <div style="background: #f8fafc; padding: 16px; text-align: center; border-top: 1px solid #e8ecf0;">
        <p style="margin: 0; font-size: 11px; color: #BDBDBD;">
          © 2026 Clube do Galo. Todos os direitos reservados.
        </p>
      </div>
    </div>
  </body>
</html>
        `,
        from_name: 'Clube do Galo'
      });

      // Registrar que enviou
      await base44.asServiceRole.entities.Notificacao.create({
        destinatario_email: usuario.email,
        titulo: 'Email de boas-vindas enviado',
        mensagem: 'Você recebeu nosso email de boas-vindas',
        tipo: 'boas_vindas',
        lida: false,
        icone: '🎉',
      });

      enviados++;
    }

    return Response.json({ verificados: usuarios.length, enviados });
  } catch (error) {
    console.error('Erro ao enviar emails boas-vindas:', error);
    return Response.json({ erro: error.message }, { status: 500 });
  }
});