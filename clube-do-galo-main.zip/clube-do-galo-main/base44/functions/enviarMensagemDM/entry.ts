import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { destinatario_email, conteudo } = await req.json();

    if (!destinatario_email || !conteudo) {
      return Response.json({ error: 'Dados incompletos' }, { status: 400 });
    }

    if (user.email === destinatario_email) {
      return Response.json({ error: 'Não pode enviar mensagem para si mesmo' }, { status: 400 });
    }

    // Criar conversa DM ou usar existente
    const conversas = await base44.asServiceRole.entities.ConversaDM.filter({});
    
    let conversa = conversas.find(c => 
      (c.usuario1_email === user.email && c.usuario2_email === destinatario_email) ||
      (c.usuario2_email === user.email && c.usuario1_email === destinatario_email)
    );

    if (!conversa) {
      // Buscar dados do usuário 2
      const usuario2Dados = await base44.asServiceRole.entities.User.filter({ email: destinatario_email });
      const usuario2 = usuario2Dados[0];
      
      conversa = await base44.asServiceRole.entities.ConversaDM.create({
        usuario1_id: user.id,
        usuario1_nome: user.full_name || user.email,
        usuario1_email: user.email,
        usuario2_id: usuario2?.id,
        usuario2_nome: usuario2?.full_name || destinatario_email,
        usuario2_email: destinatario_email,
        ultima_mensagem: conteudo,
        ultima_mensagem_data: new Date().toISOString()
      });
    }

    // Criar mensagem
    const mensagem = await base44.asServiceRole.entities.MensagemDM.create({
      conversa_id: conversa.id,
      remetente_id: user.id,
      remetente_email: user.email,
      remetente_nome: user.full_name || user.email,
      conteudo,
      lida: false
    });

    // Atualizar última mensagem
    await base44.asServiceRole.entities.ConversaDM.update(conversa.id, {
      ultima_mensagem: conteudo,
      ultima_mensagem_data: new Date().toISOString()
    });

    // Notificar
    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_email: destinatario_email,
      titulo: '💬 Mensagem direta',
      mensagem: `${user.full_name || user.email}: "${conteudo.substring(0, 40)}${conteudo.length > 40 ? '...' : ''}"`,
      tipo: 'dm',
      lida: false,
      icone: '💬',
      link: `/dm/${conversa.id}`
    });

    return Response.json({
      sucesso: true,
      conversa_id: conversa.id,
      mensagem_id: mensagem.id
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});