import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { conversa_id } = await req.json();

    // Buscar todas mensagens da conversa não lidas para o usuário
    const mensagens = await base44.asServiceRole.entities.ChatMensagem.filter({
      conversa_id
    });

    const mensagensNaoLidas = mensagens.filter(m => 
      !m.lida && m.remetente_email !== user.email
    );

    // Marcar como lidas
    for (const msg of mensagensNaoLidas) {
      await base44.asServiceRole.entities.ChatMensagem.update(msg.id, {
        lida: true
      });
    }

    return Response.json({
      sucesso: true,
      marcadas: mensagensNaoLidas.length
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});