import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin' && user.role !== 'master_admin') {
      return Response.json({ error: 'Acesso negado' }, { status: 403 });
    }

    // Buscar todas as atribuições de planos
    const mensalidades = await base44.asServiceRole.entities.Mensalidade.list('-created_date', 200);
    const usuarios = await base44.asServiceRole.entities.User.list('-created_date', 200);

    // Agrupar por quem atribuiu (criador)
    const relatorio = {};
    
    mensalidades.forEach(m => {
      const usuarioAtribuido = usuarios.find(u => u.email === m.usuario_email);
      const chave = m.created_by || 'Sistema';
      
      if (!relatorio[chave]) {
        relatorio[chave] = [];
      }
      
      relatorio[chave].push({
        usuario_nome: usuarioAtribuido?.full_name || m.usuario_email,
        usuario_email: m.usuario_email,
        plano: m.plano,
        valor: m.valor,
        data_inicio: m.data_inicio,
        status: m.status,
        criado_em: m.created_date,
      });
    });

    // Gerar PDF ou JSON do relatório
    const relatorioDados = {
      data_geracao: new Date().toISOString(),
      total_atribuicoes: mensalidades.length,
      por_atribuidor: Object.entries(relatorio).map(([atribuidor, items]) => ({
        atribuidor,
        total: items.length,
        atribuicoes: items,
      })),
    };

    // Enviar notificação para todos os admins
    const admins = usuarios.filter(u => u.role === 'admin' || u.role === 'master_admin');
    for (const admin of admins) {
      await base44.asServiceRole.entities.Notificacao.create({
        destinatario_email: admin.email,
        titulo: '📊 Relatório de Atribuições de Cargo',
        mensagem: `Total de ${mensalidades.length} planos atribuídos. Verifique o painel de admin para detalhes.`,
        tipo: 'admin',
        lida: false,
        icone: '📊',
        metadata_json: JSON.stringify(relatorioDados),
      });
    }

    return Response.json(relatorioDados);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});