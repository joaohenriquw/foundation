import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { 
      valor, 
      tipo_pagamento = 'pix', // pix, cartao, boleto
      tipo_transacao = 'deposito', // deposito, saque
      descricao = 'Transação na plataforma'
    } = await req.json();

    if (!valor || valor <= 0) {
      return Response.json({ error: 'Valor inválido' }, { status: 400 });
    }

    // 1. Buscar configuração NyxPay
    const gateways = await base44.asServiceRole.entities.GatewayConfig.filter({
      provider: 'nyxpay',
      ativo: true
    });

    const gateway = gateways[0];
    if (!gateway || !gateway.api_key) {
      return Response.json({ 
        error: 'Gateway NyxPay não configurado',
        mensagem: 'Admin deve configurar as chaves da API' 
      }, { status: 400 });
    }

    // 2. Preparar payload para NyxPay
    const payload = {
      amount: valor,
      payment_method: tipo_pagamento,
      customer_name: user.full_name || user.email,
      customer_email: user.email,
      customer_cpf_cnpj: user.cpf || '', // Deve existir no User
      customer_phone: user.telefone || '', // Deve existir no User
      postback_url: `${Deno.env.get('API_URL') || 'https://seu-dominio.com'}/api/v1/nyxpayWebhook`,
      order_id: `${tipo_transacao}-${user.id || user.email}-${Date.now()}`,
      description: descricao
    };

    // 3. Fazer requisição para NyxPay
    const response = await fetch('https://app.nyxpay.shop/api/v1/transactions', {
      method: 'POST',
      headers: {
        'X-API-Key': gateway.api_key,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const dadosNyxpay = await response.json();

    if (!response.ok) {
      // Registrar erro
      await base44.asServiceRole.entities.Transacao.create({
        txn_id: payload.order_id,
        evento: 'transacao_criada',
        status: 'rejected',
        valor,
        forma_pagamento: tipo_pagamento,
        cliente_nome: user.full_name || user.email,
        cliente_email: user.email,
        payload_raw: JSON.stringify(payload),
        erro: JSON.stringify(dadosNyxpay)
      });

      return Response.json({ 
        error: 'Erro ao criar transação',
        detalhes: dadosNyxpay 
      }, { status: 400 });
    }

    // 4. Registrar transação na base
    const transacao = await base44.asServiceRole.entities.Transacao.create({
      txn_id: dadosNyxpay.id || payload.order_id,
      evento: 'transacao_criada',
      status: 'pending',
      valor,
      forma_pagamento: tipo_pagamento,
      cliente_nome: user.full_name || user.email,
      cliente_email: user.email,
      payload_raw: JSON.stringify(dadosNyxpay),
      data_nyxpay: new Date().toISOString()
    });

    // 5. Se é deposito, criar registro Deposito
    if (tipo_transacao === 'deposito') {
      await base44.asServiceRole.entities.Deposito.create({
        usuario_id: user.id || user.email,
        usuario_email: user.email,
        usuario_nome: user.full_name || user.email,
        valor,
        txn_id: dadosNyxpay.id || payload.order_id,
        qr_code: dadosNyxpay.qr_code || '', // Pix
        pix_copia_cola: dadosNyxpay.copy_paste || '', // Pix
        status: 'aguardando_pagamento',
        data_solicitacao: new Date().toISOString(),
        data_expiracao: new Date(Date.now() + 3600000).toISOString() // 1h
      });
    }

    return Response.json({
      sucesso: true,
      transacao: {
        id: transacao.id,
        txn_id: dadosNyxpay.id || payload.order_id,
        valor,
        status: 'pending',
        tipo: tipo_transacao,
        metodo: tipo_pagamento
      },
      paymentData: {
        qr_code: dadosNyxpay.qr_code,
        copy_paste: dadosNyxpay.copy_paste,
        payment_url: dadosNyxpay.payment_url,
        expires_at: dadosNyxpay.expires_at
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});