import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { post_id, conteudo } = await req.json();

    if (!post_id || !conteudo) {
      return Response.json({ error: 'Dados incompletos' }, { status: 400 });
    }

    // Buscar post
    const posts = await base44.asServiceRole.entities.Post.filter({ id: post_id });
    if (posts.length === 0) {
      return Response.json({ error: 'Post não encontrado' }, { status: 404 });
    }

    const post = posts[0];

    // Criar comentário
    const comentario = await base44.asServiceRole.entities.ComentarioPost.create({
      post_id,
      autor_id: user.id || user.email,
      autor_nome: user.full_name || user.email,
      autor_email: user.email,
      conteudo,
      curtidas: 0
    });

    // Atualizar contador
    await base44.asServiceRole.entities.Post.update(post_id, {
      comentarios_count: (post.comentarios_count || 0) + 1
    });

    // Notificar autor do post
    if (post.autor_email !== user.email) {
      await base44.asServiceRole.entities.Notificacao.create({
        destinatario_id: post.autor_id,
        destinatario_email: post.autor_email,
        titulo: '💬 Novo comentário',
        mensagem: `${user.full_name || user.email} comentou: "${conteudo.substring(0, 40)}..."`,
        tipo: 'social',
        lida: false,
        icone: '💬',
        link: `/post/${post_id}`
      });
    }

    return Response.json({
      sucesso: true,
      comentario: {
        id: comentario.id,
        conteudo,
        autor: user.full_name || user.email
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});