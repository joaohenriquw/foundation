import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { rifa_id } = await req.json();

    if (!rifa_id) {
      return Response.json({ erro: "rifa_id obrigatório" }, { status: 400 });
    }

    const rifa = await base44.asServiceRole.entities.Rifa.filter({ id: rifa_id });
    if (!rifa || rifa.length === 0) {
      return Response.json({ erro: "Rifa não encontrada" }, { status: 404 });
    }

    const rifaData = rifa[0];

    // Se tipo_sorteio = manual, apenas notificar dono
    if (rifaData.tipo_sorteio === "manual") {
      await base44.asServiceRole.entities.Notificacao.create({
        destinatario_id: rifaData.dono_id,
        destinatario_email: rifaData.dono_email,
        titulo: `🎟️ Hora de Sortear!`,
        mensagem: `A rifa "${rifaData.titulo}" chegou na data de sorteio. Clique para realizar o sorteio manual.`,
        tipo: "rifa",
        icone: "🎰",
        link: `/rifas`
      });

      return Response.json({
        sucesso: true,
        tipo: "manual",
        mensagem: "Dono notificado para sorteio manual"
      });
    }

    // Sorteio automático
    const bilhetes = await base44.asServiceRole.entities.RifaBilhete.filter({
      rifa_id: rifaData.id,
      status: "pago"
    }, null, 10000);

    if (bilhetes.length === 0) {
      return Response.json({
        erro: "Nenhum bilhete vendido para sortear",
        sucesso: false
      }, { status: 400 });
    }

    // Selecionar vencedor aleatório
    const indiceSorteado = Math.floor(Math.random() * bilhetes.length);
    const bilheteSorteado = bilhetes[indiceSorteado];

    // Atualizar rifa com dados do vencedor
    await base44.asServiceRole.entities.Rifa.update(rifa_id, {
      ganhador_id: bilheteSorteado.comprador_id,
      ganhador_nome: bilheteSorteado.comprador_nome,
      ganhador_email: bilheteSorteado.comprador_email,
      ganhador_numero: bilheteSorteado.numero,
      ganhador_notificado: false
    });

    // Invocar notificação de vencedor
    await base44.asServiceRole.functions.invoke('notificarVencedorRifa', {
      rifa_id: rifa_id
    });

    return Response.json({
      sucesso: true,
      tipo: "automatico",
      ganhador: bilheteSorteado.comprador_nome,
      numero: bilheteSorteado.numero
    });
  } catch (error) {
    return Response.json({
      erro: error.message,
      sucesso: false
    }, { status: 500 });
  }
});