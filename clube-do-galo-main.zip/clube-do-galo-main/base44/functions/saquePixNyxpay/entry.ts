import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    const { valor, pixChave, pixTipo } = payload;

    if (!valor || valor <= 0) {
      return Response.json({ error: 'Valor inválido' }, { status: 400 });
    }

    if (!pixChave || !pixTipo) {
      return Response.json({ error: 'Chave PIX inválida' }, { status: 400 });
    }

    // Buscar credenciais da NyxPay
    const gateways = await base44.asServiceRole.entities.GatewayConfig.filter({
      provider: 'nyxpay',
      ativo: true
    });

    if (!gateways.length) {
      return Response.json({
        error: 'Gateway NyxPay não configurado. Solicite ao admin que configure as credenciais.'
      }, { status: 400 });
    }

    const config = gateways[0];
    const api_key = config.api_key;

    // Validar se o usuário tem saldo
    const userData = await base44.auth.me();
    const saldo = userData.saldo_carteira || 0;

    if (valor > saldo) {
      return Response.json({ error: 'Saldo insuficiente' }, { status: 400 });
    }

    // Chamada real à API NyxPay para processar saque
    let saqueId = null;
    try {
      const nyxpayResponse = await fetch('https://api.nyxpay.shop/v1/payout', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${api_key}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: valor,
          pix_key: pixChave,
          pix_key_type: pixTipo,
          description: `Saque Clube do Galo - ${user.email}`,
          customer: {
            email: user.email,
            name: user.full_name || 'Usuário',
          },
        }),
      });

      if (!nyxpayResponse.ok) {
        const err = await nyxpayResponse.json();
        return Response.json(
          { error: 'Erro ao processar saque na NyxPay: ' + (err.message || 'Erro desconhecido') },
          { status: 400 }
        );
      }

      const nyxpayData = await nyxpayResponse.json();

      // Registrar saque em BD
      try {
        const saque = await base44.asServiceRole.entities.Saque.create({
          usuario_email: user.email,
          valor: valor,
          pix_chave: pixChave,
          pix_tipo: pixTipo,
          status: 'processando',
          nyxpay_payout_id: nyxpayData.payout_id,
        });
        saqueId = saque.id;
      } catch (e) {
        console.log('Aviso: Não foi possível registrar saque em BD');
      }
    } catch (e) {
      console.error('Erro ao chamar NyxPay:', e);
      return Response.json(
        { error: 'Erro ao processar saque: ' + e.message },
        { status: 500 }
      );
    }

    // Atualizar saldo do usuário
    const novoSaldo = saldo - valor;
    try {
      await base44.auth.updateMe({
        saldo_carteira: novoSaldo,
      });
    } catch (e) {
      console.log('Aviso: Não foi possível atualizar saldo');
    }

    return Response.json({
      success: true,
      mensagem: `Saque de R$ ${valor.toFixed(2)} solicitado com sucesso.`,
      saque_id: saqueId,
      novo_saldo: novoSaldo,
    });
  } catch (error) {
    console.error('Erro saquePixNyxpay:', error);
    return Response.json(
      { error: error.message || 'Erro ao processar saque' },
      { status: 500 }
    );
  }
});