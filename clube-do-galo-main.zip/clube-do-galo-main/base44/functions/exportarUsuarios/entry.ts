import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'master_admin') {
      return Response.json({ error: 'Acesso negado' }, { status: 403 });
    }

    // Buscar todos os usuários
    const usuarios = await base44.asServiceRole.entities.User.list('-created_date', 100000);

    // Formatar para CSV
    const csv = [
      ['email', 'full_name', 'role', 'created_date'].join(','),
      ...usuarios.map(u => [
        `"${u.email || ''}"`,
        `"${u.full_name || ''}"`,
        `"${u.role || 'user'}"`,
        `"${u.created_date || ''}"`
      ].join(','))
    ].join('\n');

    return new Response(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': 'attachment; filename=usuarios_export.csv'
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});