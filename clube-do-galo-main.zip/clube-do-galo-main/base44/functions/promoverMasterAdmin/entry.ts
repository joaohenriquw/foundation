import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Não autenticado' }, { status: 401 });
    }

    // Obter todos os admins
    const admins = await base44.asServiceRole.entities.User.filter({ role: 'admin' });

    // Converter todos para master_admin
    for (const admin of admins) {
      await base44.asServiceRole.entities.User.update(admin.id, { role: 'master_admin' });
    }

    return Response.json({
      sucesso: true,
      mensagem: `${admins.length} administrador(es) promovido(s) para Master Admin!`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});