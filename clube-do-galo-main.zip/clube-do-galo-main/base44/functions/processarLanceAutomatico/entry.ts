import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { leilao_id, limite_maximo, parcelas = 1 } = await req.json();

    if (!leilao_id || !limite_maximo) {
      return Response.json({ error: 'Dados inválidos' }, { status: 400 });
    }

    // 1. Buscar leilão
    const leiloes = await base44.asServiceRole.entities.Leilao.filter({ id: leilao_id });
    const leilao = leiloes[0];

    if (!leilao) {
      return Response.json({ error: 'Leilão não encontrado' }, { status: 404 });
    }

    // 2. Validações básicas
    if (leilao.status !== 'ativo') {
      return Response.json({ error: 'Leilão não está ativo' }, { status: 400 });
    }

    if (user.email === leilao.dono_email) {
      return Response.json({ error: 'Você não pode dar lance no seu próprio leilão' }, { status: 400 });
    }

    // 3. Buscar lances atuais
    const lances = await base44.asServiceRole.entities.LeilaoLance.filter(
      { leilao_id },
      '-created_date',
      1
    );
    const maiorLanceAtual = lances[0]?.valor || leilao.lance_minimo;

    // 4. Calcular próximo lance automático
    const proximoLance = maiorLanceAtual + 1;

    if (proximoLance > limite_maximo) {
      return Response.json({
        sucesso: false,
        motivo: 'limite_atingido',
        mensagem: `Lance mínimo necessário (R$ ${proximoLance.toFixed(2)}) supera seu limite (R$ ${limite_maximo.toFixed(2)})`,
        lance_necessario: proximoLance,
        limite_configurado: limite_maximo
      });
    }

    // 5. Validar saldo
    const users = await base44.asServiceRole.entities.User.filter({ email: user.email });
    const userData = users[0];
    const saldoAtual = userData?.saldo || 0;

    if (saldoAtual < proximoLance) {
      return Response.json({
        sucesso: false,
        motivo: 'saldo_insuficiente',
        mensagem: `Saldo insuficiente. Necessário: R$ ${proximoLance.toFixed(2)}, Disponível: R$ ${saldoAtual.toFixed(2)}`,
        saldo_necessario: proximoLance,
        saldo_disponivel: saldoAtual
      });
    }

    // 6. Registrar lance automático
    const lance = await base44.asServiceRole.entities.LeilaoLance.create({
      leilao_id,
      user_id: user.id || user.email,
      user_nome: user.full_name || user.email,
      user_email: user.email,
      valor: proximoLance,
      parcelas,
      valor_parcela: proximoLance / parcelas,
      automatico: true,
      limite_maximo,
    });

    // 7. Atualizar leilão
    await base44.asServiceRole.entities.Leilao.update(leilao_id, {
      maior_lance: proximoLance,
      maior_lance_user_id: user.id || user.email,
      maior_lance_user_nome: user.full_name || user.email,
      maior_lance_user_email: user.email,
    });

    // 8. Notificar dono
    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_id: leilao.dono_id,
      destinatario_email: leilao.dono_email,
      titulo: `🤖 Lance automático em "${leilao.titulo}"`,
      mensagem: `${user.full_name || user.email} ativou lance automático. Próximo: R$ ${proximoLance.toFixed(2)}`,
      tipo: 'leilao',
      link: `/leilao/${leilao_id}`,
      icone: '🤖',
    });

    return Response.json({
      sucesso: true,
      lance_automatico: {
        id: lance.id,
        valor: proximoLance,
        parcelas,
        limite_maximo,
        timestamp: new Date().toISOString()
      },
      leilao_atualizado: {
        maior_lance: proximoLance,
        maior_lancista: user.full_name || user.email
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});