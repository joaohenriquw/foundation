import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Buscar banners expirados
    const agora = new Date().toISOString();
    const anuncios = await base44.asServiceRole.entities.Anuncio.filter({ ativo: true });
    
    const expirados = anuncios.filter(a => new Date(a.data_fim) < new Date(agora));

    for (const anuncio of expirados) {
      await base44.asServiceRole.entities.Anuncio.delete(anuncio.id);
    }

    return Response.json({
      success: true,
      message: `${expirados.length} banner(s) deletado(s)`,
      deletados: expirados.length,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});