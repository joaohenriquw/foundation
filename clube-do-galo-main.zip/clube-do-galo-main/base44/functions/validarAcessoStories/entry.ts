import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const users = await base44.asServiceRole.entities.User.filter({ email: user.email });
    const userData = users[0];
    const planoAtual = userData?.plano || 'iniciante';

    // Admins têm acesso total
    if (userData?.role === 'admin') {
      return Response.json({
        tem_acesso: true,
        plano_atual: 'admin',
        slots_restantes: 999,
        mensagem: '✅ Acesso permitido (admin)'
      });
    }

    // Limite de stories por dia por plano
    const LIMITES_DIARIOS = {
      iniciante: 1,
      standard: 3,
      gold: 4,
      premium: 999
    };

    const limiteDiario = LIMITES_DIARIOS[planoAtual];

    // Contar stories criadas hoje
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);

    const storiesHoje = await base44.asServiceRole.entities.Story.filter({
      autor_id: user.id || user.email
    });

    const storiesCriadasHoje = storiesHoje.filter(s => {
      const dataCriacao = new Date(s.created_date);
      dataCriacao.setHours(0, 0, 0, 0);
      return dataCriacao.getTime() === hoje.getTime();
    }).length;

    if (storiesCriadasHoje >= limiteDiario) {
      return Response.json({
        tem_acesso: false,
        plano_atual: planoAtual,
        stories_criadas_hoje: storiesCriadasHoje,
        limite_diario: limiteDiario,
        mensagem: `⏳ Limite diário atingido (${limiteDiario}/dia). Volte amanhã ou faça upgrade.`,
        link_upgrade: '/planos'
      });
    }

    return Response.json({
      tem_acesso: true,
      plano_atual: planoAtual,
      stories_criadas_hoje: storiesCriadasHoje,
      limite_diario: limiteDiario,
      slots_restantes: limiteDiario - storiesCriadasHoje,
      mensagem: `✅ Acesso permitido. ${limiteDiario - storiesCriadasHoje} stories restantes hoje.`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});