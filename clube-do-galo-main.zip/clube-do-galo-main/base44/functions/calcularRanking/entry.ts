import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { tipo_ranking = 'criadores', limite = 20 } = await req.json();

    if (tipo_ranking === 'criadores') {
      const usuarios = await base44.asServiceRole.entities.User.list('-created_date', 1000);

      const ranking = await Promise.all(
        usuarios.map(async (u) => {
          const [leiloes, rifas, avaliacoes] = await Promise.all([
            base44.asServiceRole.entities.Leilao.filter({ dono_email: u.email }),
            base44.asServiceRole.entities.Rifa.filter({ dono_email: u.email }),
            base44.asServiceRole.entities.Avaliacao.filter({ vendedor_email: u.email })
          ]);

          const receitaLeiloes = leiloes
            .filter(l => l.status === 'encerrado')
            .reduce((acc, l) => acc + (l.maior_lance || 0), 0);

          const receitaRifas = rifas.reduce((acc, r) => acc + (r.arrecadado || 0), 0);
          const notaMedia = avaliacoes.length > 0
            ? (avaliacoes.reduce((acc, a) => acc + (a.nota || 0), 0) / avaliacoes.length).toFixed(2)
            : 0;

          return {
            usuario: u.full_name || u.email,
            email: u.email,
            plano: u.plano || 'iniciante',
            leiloes_criados: leiloes.length,
            rifas_criadas: rifas.length,
            receita_total: (receitaLeiloes + receitaRifas).toFixed(2),
            nota_media: parseFloat(notaMedia),
            avaliacoes_count: avaliacoes.length,
            score: (leiloes.length * 10) + (rifas.length * 8) + parseFloat(notaMedia) + (avaliacoes.length * 2)
          };
        })
      );

      const rankingOrdenado = ranking
        .sort((a, b) => b.score - a.score)
        .slice(0, limite)
        .map((r, idx) => ({ ...r, posicao: idx + 1 }));

      // Encontrar posição do usuário atual
      const minhaposicao = rankingOrdenado.findIndex(r => r.email === user.email) + 1;

      return Response.json({
        sucesso: true,
        tipo_ranking: 'criadores',
        ranking: rankingOrdenado,
        minha_posicao: minhaposicao || 'Não classificado',
        total_criadores: ranking.length
      });
    }

    if (tipo_ranking === 'compradores') {
      const lances = await base44.asServiceRole.entities.LeilaoLance.filter({});
      const bilhetes = await base44.asServiceRole.entities.RifaBilhete.filter({});

      const compradores = {};

      lances.forEach(l => {
        if (!compradores[l.user_email]) {
          compradores[l.user_email] = {
            nome: l.user_nome,
            email: l.user_email,
            lances_totais: 0,
            gasto_total: 0,
            leiloes_participados: 0,
            rifas_participadas: 0
          };
        }
        compradores[l.user_email].lances_totais += 1;
        compradores[l.user_email].gasto_total += l.valor || 0;
        compradores[l.user_email].leiloes_participados += 1;
      });

      bilhetes.forEach(b => {
        if (!compradores[b.comprador_email]) {
          compradores[b.comprador_email] = {
            nome: b.comprador_nome,
            email: b.comprador_email,
            lances_totais: 0,
            gasto_total: 0,
            leiloes_participados: 0,
            rifas_participadas: 0
          };
        }
        compradores[b.comprador_email].gasto_total += b.valor || 0;
        compradores[b.comprador_email].rifas_participadas += 1;
      });

      const rankingCompradores = Object.values(compradores)
        .map(c => ({
          ...c,
          gasto_total: parseFloat(c.gasto_total.toFixed(2)),
          score: (c.lances_totais * 5) + (c.gasto_total / 100)
        }))
        .sort((a, b) => b.score - a.score)
        .slice(0, limite)
        .map((r, idx) => ({ ...r, posicao: idx + 1 }));

      return Response.json({
        sucesso: true,
        tipo_ranking: 'compradores',
        ranking: rankingCompradores,
        total_compradores: Object.keys(compradores).length
      });
    }

    return Response.json({ error: 'Tipo de ranking inválido' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});