import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Buscar leilões que vão encerrar entre agora e 15 minutos (margem de segurança)
    const agora = new Date();
    const daqui15min = new Date(agora.getTime() + 15 * 60 * 1000);
    const daqui10min = new Date(agora.getTime() + 10 * 60 * 1000);
    const daqui5min = new Date(agora.getTime() + 5 * 60 * 1000);

    // Buscar leilões ativos terminando em ~10 min
    const leiloes = await base44.asServiceRole.entities.Leilao.filter({ 
      status: 'ativo',
      data_fim: { $gte: daqui5min.toISOString(), $lte: daqui15min.toISOString() }
    });

    if (leiloes.length === 0) {
      return Response.json({ processados: 0, mensagem: 'Nenhum leilão próximo de encerrar' });
    }

    let notificacoesEnviadas = 0;

    for (const leilao of leiloes) {
      // Buscar usuários que favoritaram este leilão
      const favoritos = await base44.asServiceRole.entities.Favorito.filter({
        animal_id: leilao.animal_id
      });

      for (const fav of favoritos) {
        // Buscar dados do usuário para pegar WhatsApp (se tiver)
        const usuariosInfo = await base44.asServiceRole.entities.User.filter({
          email: fav.usuario_email
        });
        
        const usuario = usuariosInfo?.[0];
        if (!usuario) continue;

        // Calcular tempo restante
        const tempoRestante = new Date(leilao.data_fim) - agora;
        const minutos = Math.floor(tempoRestante / 60000);

        // Criar mensagem WhatsApp
        const mensagem = `🔔 *Atenção!* Seu leilão favorito *"${leilao.animal_nome}"* (Anilha: ${leilao.animal_anilha}) encerra em *${minutos} minutos*! ⏰\n\nLance atual: *R$ ${Number(leilao.maior_lance || leilao.lance_minimo).toFixed(2).replace('.', ',')}*\n\nVocê ainda pode dar seu lance! 🔨\n\nAcesse: ${process.env.APP_URL || 'https://clube-do-galo.app'}/leilao/${leilao.id}`;

        // Enviar notificação interna
        await base44.asServiceRole.entities.Notificacao.create({
          destinatario_email: fav.usuario_email,
          titulo: `⏰ ${leilao.animal_nome} encerra em ${minutos}min`,
          mensagem: `Leilão favorito terminando! Lance atual: R$ ${Number(leilao.maior_lance || leilao.lance_minimo).toFixed(2)}`,
          tipo: 'leilao_favorito',
          lida: false,
          icone: '⏰',
          metadata_json: JSON.stringify({
            leilao_id: leilao.id,
            tempo_restante_minutos: minutos,
            whatsapp_message: mensagem,
            animal_nome: leilao.animal_nome,
          }),
        });

        notificacoesEnviadas++;
      }
    }

    return Response.json({
      processados: leiloes.length,
      notificacoes_enviadas: notificacoesEnviadas,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error('Erro ao notificar favoritos:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});