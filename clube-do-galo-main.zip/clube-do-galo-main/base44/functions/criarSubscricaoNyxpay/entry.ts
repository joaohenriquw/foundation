import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { plano } = await req.json();

    if (!plano || !['mensal', 'semestral', 'anual'].includes(plano)) {
      return Response.json({ error: 'Plano inválido' }, { status: 400 });
    }

    // 1. Buscar gateway NyxPay
    const gateways = await base44.asServiceRole.entities.GatewayConfig.filter({
      provider: 'nyxpay',
      ativo: true
    });

    const gateway = gateways[0];
    if (!gateway || !gateway.api_key) {
      return Response.json({ 
        error: 'Gateway NyxPay não configurado' 
      }, { status: 400 });
    }

    // 2. Dados do plano
    const PLANOS = {
      mensal: {
        duracao_dias: 30,
        valor: 9.90,
        nome: 'Mensal - 30 dias'
      },
      semestral: {
        duracao_dias: 180,
        valor: 49.90,
        nome: 'Semestral - 6 meses'
      },
      anual: {
        duracao_dias: 365,
        valor: 79.90,
        nome: 'Anual - 12 meses'
      }
    };

    const dadosPlano = PLANOS[plano];

    // 3. Preparar transação para NyxPay
    const payload = {
      amount: dadosPlano.valor,
      payment_method: 'pix',
      customer_name: user.full_name || user.email,
      customer_email: user.email,
      customer_cpf_cnpj: user.cpf || '',
      postback_url: `${Deno.env.get('API_URL') || 'https://seu-dominio.com'}/api/v1/nyxpayWebhook`,
      order_id: `subscription-${plano}-${user.id || user.email}-${Date.now()}`,
      description: `Assinatura ${dadosPlano.nome}`
    };

    // 4. Criar transação no NyxPay
    const response = await fetch('https://app.nyxpay.shop/api/v1/transactions', {
      method: 'POST',
      headers: {
        'X-API-Key': gateway.api_key,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const dadosNyxpay = await response.json();

    if (!response.ok) {
      return Response.json({ 
        error: 'Erro ao criar transação',
        detalhes: dadosNyxpay 
      }, { status: 400 });
    }

    // 5. Criar registro de assinatura pendente
    const mensalidade = await base44.asServiceRole.entities.Mensalidade.create({
      usuario_id: user.id || user.email,
      usuario_email: user.email,
      plano,
      valor: dadosPlano.valor,
      stripe_subscription_id: dadosNyxpay.id,
      data_inicio: new Date().toISOString(),
      data_vencimento: new Date(Date.now() + dadosPlano.duracao_dias * 24 * 3600 * 1000).toISOString(),
      status: 'ativa',
      renovacao_automatica: true
    });

    // 6. Registrar transação
    await base44.asServiceRole.entities.Transacao.create({
      txn_id: dadosNyxpay.id,
      evento: 'subscription_created',
      status: 'pending',
      valor: dadosPlano.valor,
      forma_pagamento: 'pix',
      cliente_nome: user.full_name || user.email,
      cliente_email: user.email,
      payload_raw: JSON.stringify(dadosNyxpay)
    });

    // 7. Atualizar plano do usuário
    await base44.asServiceRole.entities.User.update(user.id || user.email, {
      plano: plano === 'mensal' ? 'standard' : plano === 'semestral' ? 'gold' : 'premium'
    });

    return Response.json({
      sucesso: true,
      mensalidade: {
        id: mensalidade.id,
        plano,
        valor: dadosPlano.valor,
        status: 'ativa'
      },
      pagamento: {
        qr_code: dadosNyxpay.qr_code,
        copy_paste: dadosNyxpay.copy_paste,
        payment_url: dadosNyxpay.payment_url,
        txn_id: dadosNyxpay.id
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});