import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const agora = new Date();
    const limite24h = new Date(agora.getTime() - 24 * 60 * 60 * 1000);

    const stories = await base44.asServiceRole.entities.Story.list("-created_date", 500);

    let deletadas = 0;
    for (const story of stories) {
      let expirou = false;

      // Verifica pela data_expiracao se existir
      if (story.data_expiracao) {
        expirou = new Date(story.data_expiracao) < agora;
      } else if (story.created_date) {
        // Fallback: expira 24h após criação
        expirou = new Date(story.created_date) < limite24h;
      }

      if (expirou) {
        await base44.asServiceRole.entities.Story.delete(story.id);
        deletadas++;
      }
    }

    return Response.json({ sucesso: true, deletadas });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});