import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Buscar rifas ativas com data_sorteio vencida
    const rifasVencidas = await base44.asServiceRole.entities.Rifa.filter({
      status: "ativa"
    }, "-created_date", 100);

    const agora = new Date();
    const processadas = [];

    for (const rifa of rifasVencidas) {
      const dataSorteio = new Date(rifa.data_sorteio);
      
      // Se data de sorteio passou, encerrar
      if (dataSorteio <= agora) {
        // Atualizar status
        await base44.asServiceRole.entities.Rifa.update(rifa.id, {
          status: "encerrada"
        });

        // Invocar função de sorteio
        await base44.asServiceRole.functions.invoke('sortearRifa', {
          rifa_id: rifa.id
        });

        processadas.push({
          id: rifa.id,
          titulo: rifa.titulo,
          acao: "sorteio_iniciado"
        });
      }
    }

    return Response.json({
      sucesso: true,
      processadas: processadas.length,
      detalhes: processadas
    });
  } catch (error) {
    return Response.json({
      erro: error.message,
      sucesso: false
    }, { status: 500 });
  }
});