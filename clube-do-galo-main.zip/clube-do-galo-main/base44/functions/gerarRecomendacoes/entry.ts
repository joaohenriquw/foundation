import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 1. Buscar favoritos do usuário
    const favoritos = await base44.asServiceRole.entities.Favorito.filter({
      usuario_email: user.email
    });

    // 2. Analisar padrões (espécie, preço)
    const especiesPreferidas = {};
    const precosPreferidos = [];

    favoritos.forEach(fav => {
      especiesPreferidas[fav.animal_especie] = (especiesPreferidas[fav.animal_especie] || 0) + 1;
      if (fav.animal_valor) precosPreferidos.push(fav.animal_valor);
    });

    const especiePrincipal = Object.keys(especiesPreferidas).sort(
      (a, b) => especiesPreferidas[b] - especiesPreferidas[a]
    )[0];

    const precioMedio = precosPreferidos.length > 0 
      ? precosPreferidos.reduce((a, b) => a + b) / precosPreferidos.length
      : 0;

    // 3. Buscar leilões similares
    const leiloesSimilares = await base44.asServiceRole.entities.Leilao.filter({
      status: 'ativo',
      animal_especie: especiePrincipal
    }, '-created_date', 10);

    // 4. Buscar rifas similares
    const rifasSimilares = await base44.asServiceRole.entities.Rifa.filter({
      status: 'ativa'
    }, '-arrecadado', 10);

    // 5. Usuários com interesses similares
    const usuariosSimilares = await base44.asServiceRole.entities.Favorito.filter({
      animal_especie: especiePrincipal
    });

    const emailsSimilares = [...new Set(usuariosSimilares.map(f => f.usuario_email))];

    // 6. Score de relevância
    const recomendacoes = leiloesSimilares
      .filter(l => !favoritos.some(f => f.animal_id === l.animal_id))
      .slice(0, 5)
      .map(l => ({
        ...l,
        relevancia: 'alta',
        motivo: `Similar ao seu interesse em ${especiePrincipal}`
      }));

    return Response.json({
      sucesso: true,
      usuario: {
        email: user.email,
        favoritos_count: favoritos.length,
        especie_preferida: especiePrincipal,
        preco_medio_interesse: precioMedio.toFixed(2)
      },
      recomendacoes: {
        leiloes: recomendacoes,
        rifas: rifasSimilares.slice(0, 3),
        usuarios_similares: emailsSimilares.length
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});