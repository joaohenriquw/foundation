import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    // Apenas admin pode disparar sincronização
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    // Buscar config do NyxPay
    const configs = await base44.asServiceRole.entities.GatewayConfig.filter({ provider: 'nyxpay', ativo: true });
    if (!configs.length) {
      return Response.json({ erro: 'Gateway não configurado' }, { status: 400 });
    }
    const config = configs[0];

    // Sincronizar depósitos pendentes
    const depositos = await base44.asServiceRole.entities.Deposito.filter({ status: 'aguardando_pagamento' }, '-created_date', 100);
    let atualizacoes = 0;

    for (const dep of depositos) {
      try {
        const res = await fetch(`https://api.nyxpay.com.br/transactions/${dep.txn_id}`, {
          headers: { Authorization: `Bearer ${config.api_key}` }
        });
        const data = await res.json();

        if (data.status === 'paid' || data.status === 'completed') {
          await base44.asServiceRole.entities.Deposito.update(dep.id, { status: 'concluido', data_confirmacao: new Date().toISOString() });
          
          // Atualizar saldo do user
          const users = await base44.asServiceRole.entities.User.filter({ email: dep.usuario_email });
          if (users.length > 0) {
            const saldoAtual = users[0].saldo || 0;
            await base44.asServiceRole.entities.User.update(users[0].id, { saldo: saldoAtual + dep.valor });
          }

          // Notificar user
          await base44.asServiceRole.entities.Notificacao.create({
            destinatario_email: dep.usuario_email,
            titulo: '✅ Depósito confirmado',
            mensagem: `R$ ${dep.valor.toFixed(2)} foi creditado na sua carteira.`,
            tipo: 'sistema',
            icone: '💰'
          });
          atualizacoes++;
        } else if (data.status === 'expired' || data.status === 'failed') {
          await base44.asServiceRole.entities.Deposito.update(dep.id, { status: 'cancelado' });
        }
      } catch (e) {
        console.error(`Erro ao sincronizar depósito ${dep.id}:`, e.message);
      }
    }

    // Sincronizar saques pendentes
    const saques = await base44.asServiceRole.entities.Saque.filter({ status: 'processando' }, '-created_date', 100);
    for (const saq of saques) {
      try {
        const res = await fetch(`https://api.nyxpay.com.br/transactions/${saq.txn_id}`, {
          headers: { Authorization: `Bearer ${config.api_key}` }
        });
        const data = await res.json();

        if (data.status === 'completed') {
          await base44.asServiceRole.entities.Saque.update(saq.id, { status: 'concluido', data_conclusao: new Date().toISOString() });
          await base44.asServiceRole.entities.Notificacao.create({
            destinatario_email: saq.usuario_email,
            titulo: '✅ Saque processado',
            mensagem: `Seu saque de R$ ${saq.valor.toFixed(2)} foi transferido para a chave PIX ${saq.pix_chave}.`,
            tipo: 'sistema',
            icone: '💸'
          });
          atualizacoes++;
        } else if (data.status === 'failed') {
          await base44.asServiceRole.entities.Saque.update(saq.id, { status: 'falha', motivo_cancelamento: data.error_message || 'Erro no gateway' });
        }
      } catch (e) {
        console.error(`Erro ao sincronizar saque ${saq.id}:`, e.message);
      }
    }

    return Response.json({ sucesso: true, atualizacoes, timestamp: new Date().toISOString() });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});