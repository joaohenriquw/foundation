import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const PLANO_FEATURES = {
  iniciante: {
    pode_criar_leilao: false,
    pode_criar_rifa: false,
    stories_por_dia: 1,
    animais_vitrine: 0,
  },
  standard: {
    pode_criar_leilao: true,
    pode_criar_rifa: true,
    stories_por_dia: 3,
    animais_vitrine: 1,
  },
  gold: {
    pode_criar_leilao: true,
    pode_criar_rifa: true,
    stories_por_dia: 4,
    animais_vitrine: 4,
  },
  premium: {
    pode_criar_leilao: true,
    pode_criar_rifa: true,
    stories_por_dia: 999,
    animais_vitrine: 999,
  },
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const { feature } = await req.json();

    if (!feature) {
      return Response.json({ error: 'Feature não informada' }, { status: 400 });
    }

    // Buscar plano ativo
    const assinaturas = await base44.asServiceRole.entities.Mensalidade.filter(
      { usuario_email: user.email, status: 'ativa' },
      '-created_date',
      1
    );

    let plano = 'iniciante'; // Plano padrão
    let dataVencimento = null;

    if (assinaturas.length > 0) {
      const assinatura = assinaturas[0];
      plano = assinatura.plano;
      dataVencimento = assinatura.data_vencimento;

      // Verificar se expirou
      if (new Date(dataVencimento) < new Date()) {
        plano = 'iniciante';
      }
    }

    const features = PLANO_FEATURES[plano] || PLANO_FEATURES.iniciante;

    return Response.json({
      success: true,
      plano_atual: plano,
      data_vencimento: dataVencimento,
      pode_acessar: features[feature] !== false && features[feature] !== 0,
      feature_value: features[feature],
      message: features[feature] 
        ? `✅ Você tem acesso a este recurso no plano ${plano}`
        : `❌ Este recurso não está disponível no plano ${plano}`,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});