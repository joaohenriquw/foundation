import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { leilao_id, tipo, user_id } = await req.json();

    if (!leilao_id || !tipo) {
      return Response.json({ error: 'leilao_id e tipo são obrigatórios' }, { status: 400 });
    }

    const leilao = await base44.entities.Leilao.filter({ id: leilao_id });
    if (!leilao.length) {
      return Response.json({ error: 'Leilão não encontrado' }, { status: 404 });
    }

    const leilaoData = leilao[0];
    let titulo = '';
    let mensagem = '';
    let icone = '';

    if (tipo === 'novo_lance') {
      titulo = '🔨 Novo lance!';
      mensagem = `${leilaoData.maior_lance_user_nome} deu um lance de R$ ${Number(leilaoData.maior_lance).toFixed(2)} em "${leilaoData.animal_nome}"`;
      icone = '🔨';
    } else if (tipo === 'encerramento_proximo') {
      titulo = '⏰ Leilão encerrado em breve!';
      mensagem = `Faltam 5 minutos para o encerramento do leilão de "${leilaoData.animal_nome}". Dê seu último lance!`;
      icone = '⏰';
    }

    // Buscar todos os usuários que deram lance neste leilão
    const lances = await base44.entities.LeilaoLance.filter({ leilao_id });
    const usuariosUnicos = [...new Set(lances.map(l => l.user_email))];

    // Criar notificação para cada participante (exceto o dono)
    for (const email of usuariosUnicos) {
      if (email !== leilaoData.dono_email) {
        await base44.entities.Notificacao.create({
          destinatario_email: email,
          titulo,
          mensagem,
          tipo: 'leilao',
          lida: false,
          link: `/leilao/${leilao_id}`,
          icone,
        });
      }
    }

    // Se é novo lance, notificar o dono também
    if (tipo === 'novo_lance') {
      await base44.entities.Notificacao.create({
        destinatario_email: leilaoData.dono_email,
        titulo,
        mensagem,
        tipo: 'leilao',
        lida: false,
        link: `/leilao/${leilao_id}`,
        icone,
      });
    }

    return Response.json({ success: true, notificados: usuariosUnicos.length });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});