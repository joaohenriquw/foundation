import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { conversa_id, conteudo } = await req.json();

    if (!conversa_id || !conteudo) {
      return Response.json({ error: 'Dados incompletos' }, { status: 400 });
    }

    // Buscar conversa
    const conversas = await base44.asServiceRole.entities.ChatConversa.filter({ id: conversa_id });
    if (conversas.length === 0) {
      return Response.json({ error: 'Conversa não encontrada' }, { status: 404 });
    }

    const conv = conversas[0];

    // Verificar se usuário é participante da conversa
    const ehParticipante = user.email === conv.usuario_email || user.email === conv.profissional_email;
    if (!ehParticipante) {
      return Response.json({ error: 'Você não tem permissão para enviar mensagens nesta conversa' }, { status: 403 });
    }

    // Criar mensagem
    const mensagem = await base44.asServiceRole.entities.ChatMensagem.create({
      conversa_id,
      remetente_id: user.id || user.email,
      remetente_nome: user.full_name || user.email,
      remetente_email: user.email,
      conteudo,
      lida: false
    });

    // Determinar destinatário e buscar dados corretos
    const ehProfissional = user.email === conv.profissional_email;
    const destinatarioEmail = ehProfissional ? conv.usuario_email : conv.profissional_email;
    const destinatarioId = ehProfissional ? conv.usuario_id : conv.profissional_id;
    const destinatarioNome = ehProfissional ? conv.usuario_nome : conv.profissional_nome;

    // Notificar outro participante
    if (destinatarioId && destinatarioEmail) {
      await base44.asServiceRole.entities.Notificacao.create({
        destinatario_id: destinatarioId,
        destinatario_email: destinatarioEmail,
      titulo: '💬 Nova mensagem de consultoria',
      mensagem: `${user.full_name || user.email}: "${conteudo.substring(0, 50)}${conteudo.length > 50 ? '...' : ''}"`,
      tipo: 'consultoria',
      lida: false,
      icone: '💬',
      link: `/chat/${conversa_id}`
      });
    }

    // Atualizar última mensagem da conversa
    await base44.asServiceRole.entities.ChatConversa.update(conversa_id, {
      ultima_mensagem: conteudo,
      ultima_mensagem_data: new Date().toISOString()
    });

    return Response.json({
      sucesso: true,
      mensagem: {
        id: mensagem.id,
        conteudo,
        remetente: user.full_name || user.email,
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});