import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user?.email) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { tipo_relatorio = 'dashboard' } = await req.json();

    // Dashboard geral para admin
    if (tipo_relatorio === 'dashboard') {
      const [usuarios, leiloes, rifas, transacoes] = await Promise.all([
        base44.asServiceRole.entities.User.list('-created_date', 1000),
        base44.asServiceRole.entities.Leilao.filter({ status: 'ativo' }),
        base44.asServiceRole.entities.Rifa.filter({ status: 'ativa' }),
        base44.asServiceRole.entities.Transacao.filter({})
      ]);

      const arrecadacaoTotal = transacoes
        .filter(t => t.status === 'approved')
        .reduce((acc, t) => acc + (t.valor || 0), 0);

      const leiloesEncerrados = await base44.asServiceRole.entities.Leilao.filter({ status: 'encerrado' });
      const rifasEncerradas = await base44.asServiceRole.entities.Rifa.filter({ status: 'encerrada' });

      const maiorLeilao = leiloesEncerrados.sort((a, b) => (b.maior_lance || 0) - (a.maior_lance || 0))[0];
      const maiorRifa = rifasEncerradas.sort((a, b) => (b.arrecadado || 0) - (a.arrecadado || 0))[0];

      return Response.json({
        sucesso: true,
        relatorio: 'dashboard',
        timestamp: new Date().toISOString(),
        kpis: {
          usuarios_total: usuarios.length,
          leiloes_ativos: leiloes.length,
          rifas_ativas: rifas.length,
          arrecadacao_total: arrecadacaoTotal.toFixed(2),
          leiloes_encerrados: leiloesEncerrados.length,
          rifas_encerradas: rifasEncerradas.length
        },
        records: {
          maior_leilao: maiorLeilao ? {
            titulo: maiorLeilao.titulo,
            valor: maiorLeilao.maior_lance,
            dono: maiorLeilao.dono_nome
          } : null,
          maior_rifa: maiorRifa ? {
            titulo: maiorRifa.titulo,
            valor: maiorRifa.arrecadado,
            dono: maiorRifa.dono_nome
          } : null
        },
        usuarios_top: usuarios.slice(0, 10).map(u => ({
          email: u.email,
          nome: u.full_name,
          plano: u.plano,
          saldo: u.saldo || 0
        }))
      });
    }

    // Relatório por criador
    if (tipo_relatorio === 'criador') {
      const [meusleiloes, minhasrifas, minhasfavoritos] = await Promise.all([
        base44.asServiceRole.entities.Leilao.filter({ dono_email: user.email }),
        base44.asServiceRole.entities.Rifa.filter({ dono_email: user.email }),
        base44.asServiceRole.entities.Favorito.filter({ proprietario_id: user.id || user.email })
      ]);

      const arrecadacaoLeiloes = meusleiloes
        .filter(l => l.status === 'encerrado')
        .reduce((acc, l) => acc + (l.maior_lance || 0), 0);

      const arrecadacaoRifas = minhasrifas
        .reduce((acc, r) => acc + (r.arrecadado || 0), 0);

      return Response.json({
        sucesso: true,
        relatorio: 'criador',
        criador: user.full_name || user.email,
        dados: {
          leiloes_total: meusleiloes.length,
          leiloes_ativos: meusleiloes.filter(l => l.status === 'ativo').length,
          leiloes_encerrados: meusleiloes.filter(l => l.status === 'encerrado').length,
          arrecadacao_leiloes: arrecadacaoLeiloes.toFixed(2),
          rifas_total: minhasrifas.length,
          arrecadacao_rifas: arrecadacaoRifas.toFixed(2),
          animais_na_vitrine: minhasfavoritos.length,
          receita_total: (arrecadacaoLeiloes + arrecadacaoRifas).toFixed(2)
        }
      });
    }

    return Response.json({ error: 'Tipo de relatório inválido' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});