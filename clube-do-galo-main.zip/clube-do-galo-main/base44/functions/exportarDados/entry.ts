import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user?.email) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { tipo = 'csv', formato_dados = 'leiloes' } = await req.json();

    if (formato_dados === 'leiloes') {
      const leiloes = await base44.asServiceRole.entities.Leilao.filter({
        dono_email: user.email
      }, '-created_date', 1000);

      if (tipo === 'csv') {
        // Cabeçalho CSV
        let csv = 'Título,Animal,Anilha,Status,Lance Mínimo,Maior Lance,Ganhador,Data Início,Data Fim\n';

        leiloes.forEach(l => {
          csv += `"${l.titulo}","${l.animal_nome}","${l.animal_anilha}","${l.status}",${l.lance_minimo},${l.maior_lance},"${l.ganhador_nome || ''}","${l.data_inicio}","${l.data_fim}"\n`;
        });

        return new Response(csv, {
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': 'attachment; filename=leiloes.csv'
          }
        });
      }

      if (tipo === 'json') {
        return Response.json({
          formato: 'json',
          tipo: 'leiloes',
          total: leiloes.length,
          dados: leiloes.map(l => ({
            id: l.id,
            titulo: l.titulo,
            animal: l.animal_nome,
            anilha: l.animal_anilha,
            status: l.status,
            lanceMinimo: l.lance_minimo,
            maiorLance: l.maior_lance,
            ganhador: l.ganhador_nome || null,
            dataInicio: l.data_inicio,
            dataFim: l.data_fim,
            dataCriacao: l.created_date
          }))
        });
      }
    }

    if (formato_dados === 'rifas') {
      const rifas = await base44.asServiceRole.entities.Rifa.filter({
        dono_email: user.email
      }, '-created_date', 1000);

      if (tipo === 'csv') {
        let csv = 'Título,Animal,Total Bilhetes,Bilhetes Vendidos,Valor Bilhete,Arrecadado,Status,Data Início,Data Fim\n';

        rifas.forEach(r => {
          csv += `"${r.titulo}","${r.animal_nome}",${r.total_bilhetes},${r.bilhetes_vendidos},"${r.valor_bilhete}","${r.arrecadado}","${r.status}","${r.data_inicio}","${r.data_fim}"\n`;
        });

        return new Response(csv, {
          headers: {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': 'attachment; filename=rifas.csv'
          }
        });
      }

      if (tipo === 'json') {
        return Response.json({
          formato: 'json',
          tipo: 'rifas',
          total: rifas.length,
          dados: rifas.map(r => ({
            id: r.id,
            titulo: r.titulo,
            animal: r.animal_nome,
            totalBilhetes: r.total_bilhetes,
            bilhetesVendidos: r.bilhetes_vendidos,
            valorBilhete: r.valor_bilhete,
            arrecadado: r.arrecadado,
            percentualVenda: ((r.bilhetes_vendidos / r.total_bilhetes) * 100).toFixed(2),
            status: r.status,
            dataInicio: r.data_inicio,
            dataFim: r.data_fim
          }))
        });
      }
    }

    return Response.json({ error: 'Tipo de dado inválido' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});