import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Busca animais com foto
    const animais = await base44.asServiceRole.entities.Animal.list('-updated_date', 20);
    const comFoto = animais.filter(a => a.foto_url && a.proprietario_id);

    if (comFoto.length === 0) {
      return Response.json({ error: 'Nenhum animal com foto encontrado' }, { status: 400 });
    }

    // Cria leilões para os primeiros 5 animais com foto
    const leiloesParaCriar = comFoto.slice(0, 5).map(animal => ({
      animal_id: animal.id,
      animal_nome: animal.nome,
      animal_anilha: animal.anilha,
      animal_foto_url: animal.foto_url,
      animal_especie: animal.especie,
      dono_id: animal.proprietario_id,
      dono_nome: animal.proprietario_nome,
      dono_email: animal.proprietario_email,
      dono_whatsapp: animal.whatsapp,
      titulo: `${animal.nome} - ${animal.especie}`,
      descricao: `Animal em excelente condição. ${animal.observacoes || ''}`,
      lance_minimo: animal.valor_estimado ? animal.valor_estimado * 0.8 : 500,
      maior_lance: 0,
      data_inicio: new Date().toISOString(),
      data_fim: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      status: 'ativo'
    }));

    const criados = await base44.asServiceRole.entities.Leilao.bulkCreate(leiloesParaCriar);

    return Response.json({
      success: true,
      leiloes_criados: criados.length,
      message: `${criados.length} leilões criados com fotos`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});