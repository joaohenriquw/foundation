import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Buscar conversas onde o usuário é participante
    const conversasUsuario = await base44.asServiceRole.entities.ChatConversa.filter({ usuario_email: user.email });
    const conversasProfissional = await base44.asServiceRole.entities.ChatConversa.filter({ profissional_email: user.email });
    const minhasConversas = [...conversasUsuario, ...conversasProfissional];

    // Para cada conversa, contar mensagens não lidas
    const conversasComMensagens = await Promise.all(
      minhasConversas.map(async (c) => {
        const mensagens = await base44.asServiceRole.entities.ChatMensagem.filter({
          conversa_id: c.id
        }, '-created_date', 1000);

        const naoLidas = mensagens.filter(m => !m.lida && m.remetente_email !== user.email).length;

        return {
          ...c,
          total_mensagens: mensagens.length,
          nao_lidas: naoLidas,
          ultima_mensagem_preview: c.ultima_mensagem ? c.ultima_mensagem.substring(0, 60) : '',
          outra_parte: user.email === c.usuario_email ? {
            nome: c.profissional_nome,
            email: c.profissional_email,
            tipo_profissional: c.tipo
          } : {
            nome: c.usuario_nome,
            email: c.usuario_email
          }
        };
      })
    );

    // Ordenar por última mensagem (mais recentes primeiro)
    conversasComMensagens.sort((a, b) => 
      new Date(b.ultima_mensagem_data || 0) - new Date(a.ultima_mensagem_data || 0)
    );

    return Response.json({
      sucesso: true,
      conversas: conversasComMensagens
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});