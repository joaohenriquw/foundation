import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const users = await base44.asServiceRole.entities.User.filter({ email: user.email });
    const userData = users[0];
    const planoAtual = userData?.plano || 'iniciante';

    // Admins têm acesso total
    if (userData?.role === 'admin') {
      return Response.json({
        tem_acesso: true,
        plano_atual: 'admin',
        mensagem: '✅ Acesso permitido (admin)',
        slots_restantes: 999
      });
    }

    const PLANOS_COM_ACESSO = ['gold', 'premium'];

    if (!PLANOS_COM_ACESSO.includes(planoAtual)) {
      return Response.json({
        tem_acesso: false,
        plano_atual: planoAtual,
        mensagem: `❌ Apenas planos Gold e Premium podem criar rifas. Seu plano: ${planoAtual}`,
        planos_permitidos: PLANOS_COM_ACESSO,
        link_upgrade: '/planos'
      });
    }

    // Verificar limite de rifas ativas por plano
    const rifasAtivas = await base44.asServiceRole.entities.Rifa.filter({
      dono_email: user.email,
      status: 'ativa'
    });

    const LIMITES = {
      gold: 2,
      premium: 999
    };

    const limite = LIMITES[planoAtual];
    const jaUsou = rifasAtivas.length;

    if (jaUsou >= limite) {
      return Response.json({
        tem_acesso: false,
        plano_atual: planoAtual,
        rifas_ativas: jaUsou,
        limite_permitido: limite,
        mensagem: `❌ Você atingiu o limite de ${limite} rifas simultâneas para o plano ${planoAtual}`,
        link_upgrade: '/planos'
      });
    }

    return Response.json({
      tem_acesso: true,
      plano_atual: planoAtual,
      rifas_ativas: jaUsou,
      limite_permitido: limite,
      slots_restantes: limite - jaUsou,
      mensagem: `✅ Acesso permitido. ${limite - jaUsou} slots restantes.`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});