import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { conversa_id } = await req.json();

    if (!conversa_id) {
      return Response.json({ error: 'Conversa não especificada' }, { status: 400 });
    }

    // Buscar mensagens
    const mensagens = await base44.asServiceRole.entities.MensagemDM.filter({
      conversa_id
    }, '-created_date', 100);

    // Marcar como lidas
    const naoLidas = mensagens.filter(m => !m.lida && m.remetente_email !== user.email);
    
    for (const msg of naoLidas) {
      await base44.asServiceRole.entities.MensagemDM.update(msg.id, {
        lida: true
      });
    }

    return Response.json({
      sucesso: true,
      mensagens: mensagens.reverse()
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});