import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    
    // Criar leilão exemplo
    const leilao = await base44.entities.Leilao.create({
      animal_id: "exemplo_galo_001",
      animal_nome: "Reprodutor Ouro Imperial",
      animal_anilha: "RI-2024-010",
      animal_foto_url: "https://images.unsplash.com/photo-1444464666175-1642a9734776?w=500&h=400&fit=crop",
      animal_especie: "Galo",
      anilhas_filhas_qtd: 45,
      dono_id: "demo_user",
      dono_nome: "Demo Criador",
      dono_email: "criador@demo.com",
      dono_whatsapp: "+5585987654321",
      titulo: "Reprodutor Ouro Imperial - Linhagem Premium",
      descricao: "Galo de excelente linhagem com pedigree comprovado. 45 filhas já produzidas com sucesso. Teste gratuito de genética disponível.",
      lance_minimo: 1500,
      maior_lance: 0,
      data_inicio: new Date(Date.now() - 3600000).toISOString(),
      data_fim: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // 7 dias
      status: "ativo",
      ganhador_notificado: false,
      pagamento_confirmado: false,
    });

    return Response.json({ 
      success: true, 
      message: "Leilão exemplo criado com sucesso",
      leilao_id: leilao.id 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});