import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    const { email } = payload;

    if (email !== user.email) {
      return Response.json({ 
        data: { 
          sucesso: false, 
          erro: 'Email não corresponde ao usuário autenticado' 
        } 
      }, { status: 400 });
    }

    // Delete all user-related data
    // Deletar anilhas
    const anilhas = await base44.asServiceRole.entities.AnilhaFilha.filter({ usuario_email: user.email });
    for (const a of anilhas) {
      await base44.asServiceRole.entities.AnilhaFilha.delete(a.id);
    }

    // Deletar bilhetes de rifa
    const bilhetes = await base44.asServiceRole.entities.RifaBilhete.filter({ comprador_email: user.email });
    for (const b of bilhetes) {
      await base44.asServiceRole.entities.RifaBilhete.delete(b.id);
    }

    // Deletar lances em leilões
    const lances = await base44.asServiceRole.entities.LeilaoLance.filter({ user_email: user.email });
    for (const l of lances) {
      await base44.asServiceRole.entities.LeilaoLance.delete(l.id);
    }

    // Deletar comentários
    const comentarios = await base44.asServiceRole.entities.LeilaoComentario.filter({ user_email: user.email });
    for (const c of comentarios) {
      await base44.asServiceRole.entities.LeilaoComentario.delete(c.id);
    }

    // Deletar notificações
    const notifs = await base44.asServiceRole.entities.Notificacao.filter({ destinatario_email: user.email });
    for (const n of notifs) {
      await base44.asServiceRole.entities.Notificacao.delete(n.id);
    }

    // Deletar mensagens DM
    const dms = await base44.asServiceRole.entities.MensagemDM.filter({ remetente_email: user.email });
    for (const dm of dms) {
      await base44.asServiceRole.entities.MensagemDM.delete(dm.id);
    }

    // Deletar conversas de consultoria
    const consultorias = await base44.asServiceRole.entities.ChatConversa.filter({ usuario_email: user.email });
    for (const c of consultorias) {
      await base44.asServiceRole.entities.ChatConversa.delete(c.id);
    }

    // Registrar auditoria
    try {
      await base44.asServiceRole.entities.AuditoriaLog.create({
        usuario_email: user.email,
        acao: 'deletar_conta',
        descricao: `Conta deletada permanentemente por solicitação do usuário`,
        data: new Date().toISOString(),
      });
    } catch (e) {
      console.error('Erro ao registrar auditoria:', e);
    }

    return Response.json({
      data: {
        sucesso: true,
        mensagem: 'Conta deletada com sucesso',
      }
    });
  } catch (error) {
    console.error('Erro ao deletar conta:', error);
    return Response.json({
      data: {
        sucesso: false,
        erro: error.message || 'Erro ao deletar conta',
      }
    }, { status: 500 });
  }
});