import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch(() => null);

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    // Buscar anilhas que venceram
    const hoje = new Date().toISOString().split('T')[0];
    const anilhasParaConverter = await base44.entities.AnilhaFilha.filter({
      status: 'pronto_para_troca',
      data_troca_definitiva: { $lte: hoje }
    });

    const resultados = [];

    for (const anilha of anilhasParaConverter) {
      // Criar novo animal adulto
      const novoAnimal = await base44.entities.Animal.create({
        nome: `${anilha.animal_pai_nome} x ${anilha.animal_mae_nome} - Filhote`,
        anilha: anilha.anilha_numero,
        pai_id: anilha.animal_pai_id,
        pai_nome: anilha.animal_pai_nome,
        mae_id: anilha.animal_mae_id,
        mae_nome: anilha.animal_mae_nome,
        data_de_nascimento: anilha.data_criacao,
        sexo: 'macho', // default, usuário ajusta depois
        saude_status: 'excelente',
        status_vitrine: 'indisponivel',
        status_atual: 'ativo',
        combate_vitrias: 0,
        combate_derrotas: 0,
        tipo_categoria: 'criacao',
      });

      // Atualizar anilha
      await base44.entities.AnilhaFilha.update(anilha.id, {
        status: 'convertida',
        animal_adulto_id: novoAnimal.id,
        cor_anilha_definitiva: anilha.cor_anilha_definitiva || 'pendente',
      });

      // Notificar criador
      await base44.entities.Notificacao.create({
        destinatario_email: anilha.usuario_email,
        titulo: '🐣 Filhote Pronto para Troca',
        mensagem: `A anilha ${anilha.anilha_numero} foi promovida a Animal adulto. Escolha a cor definitiva!`,
        tipo: 'anilha',
        icone: '🐣',
        lida: false,
      });

      resultados.push({ anilha_id: anilha.id, animal_novo_id: novoAnimal.id });
    }

    return Response.json({
      sucesso: true,
      convertidas: resultados.length,
      detalhes: resultados,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});