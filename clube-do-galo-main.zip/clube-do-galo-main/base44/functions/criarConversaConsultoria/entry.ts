import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { tipo_consultoria, descricao } = await req.json();

    if (!['advogado_civil', 'advogado_criminal', 'veterinario'].includes(tipo_consultoria)) {
      return Response.json({ error: 'Tipo de consultoria inválido' }, { status: 400 });
    }

    // Buscar consultor disponível do tipo especificado
    let consultores = await base44.asServiceRole.entities.User.filter({});
    const consultoresDisponiveis = consultores.filter(c => c.role === tipo_consultoria);

    let consultor;
    if (consultoresDisponiveis.length > 0) {
      consultor = consultoresDisponiveis[0];
    } else {
      // Se não houver consultor, retornar erro
      return Response.json({ 
        error: `Nenhum ${tipo_consultoria.replace('_', ' ')} disponível neste momento` 
      }, { status: 400 });
    }

    // Criar conversa
    const conversa = await base44.asServiceRole.entities.ChatConversa.create({
      usuario_id: user.id,
      usuario_nome: user.full_name || user.email,
      usuario_email: user.email,
      profissional_id: consultor.id,
      profissional_nome: consultor.full_name || consultor.email,
      profissional_email: consultor.email,
      tipo: tipo_consultoria,
      status: 'ativa',
      ultima_mensagem: descricao || 'Consultoria iniciada'
    });

    // Criar primeira mensagem do usuário
    if (descricao) {
      await base44.asServiceRole.entities.ChatMensagem.create({
        conversa_id: conversa.id,
        remetente_id: user.id || user.email,
        remetente_nome: user.full_name || user.email,
        remetente_email: user.email,
        conteudo: descricao,
        lida: false
      });
    }

    // Notificar consultor
    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_id: consultor.id,
      destinatario_email: consultor.email,
      titulo: '💬 Nova conversa de consultoria',
      mensagem: `${user.full_name || user.email} iniciou uma consultoria de ${tipo_consultoria.replace('_', ' ')}.`,
      tipo: 'consultoria',
      lida: false,
      icone: '💬',
      link: `/chat/${conversa.id}`
    });

    return Response.json({
      sucesso: true,
      conversa: {
        id: conversa.id,
        tipo: tipo_consultoria,
        consultor: consultor.full_name || consultor.email,
        status: 'ativa'
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});