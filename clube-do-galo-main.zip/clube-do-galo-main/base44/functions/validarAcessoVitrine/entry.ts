import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const users = await base44.asServiceRole.entities.User.filter({ email: user.email });
    const userData = users[0];
    const planoAtual = userData?.plano || 'iniciante';

    // Admins têm acesso total
    if (userData?.role === 'admin') {
      return Response.json({
        tem_acesso: true,
        limite_atingido: false,
        plano_atual: 'admin',
        slots_restantes: 999,
        mensagem: '✅ Acesso permitido (admin)'
      });
    }

    // Plano iniciante: sem acesso
    if (planoAtual === 'iniciante') {
      return Response.json({
        tem_acesso: false,
        plano_atual: planoAtual,
        mensagem: `❌ Plano Iniciante não tem acesso à Vitrine. Upgrade para Standard ou acima.`,
        link_upgrade: '/planos'
      });
    }

    // Verificar limite de animais na vitrine por plano
    const vitrinaAtiva = await base44.asServiceRole.entities.VitrineExposicao.filter({
      proprietario_id: user.id || user.email,
      ativa: true
    });

    const LIMITES = {
      standard: 1,
      gold: 5,
      premium: 999
    };

    const limite = LIMITES[planoAtual] || 0;
    const jaUsou = vitrinaAtiva.length;

    if (jaUsou >= limite) {
      return Response.json({
        tem_acesso: true,
        limite_atingido: true,
        plano_atual: planoAtual,
        animais_na_vitrine: jaUsou,
        limite_permitido: limite,
        mensagem: `⚠️ Limite de ${limite} animais na vitrine atingido. Remova algum ou faça upgrade.`,
        link_upgrade: '/planos'
      });
    }

    return Response.json({
      tem_acesso: true,
      limite_atingido: false,
      plano_atual: planoAtual,
      animais_na_vitrine: jaUsou,
      limite_permitido: limite,
      slots_restantes: limite - jaUsou,
      mensagem: `✅ Acesso permitido. ${limite - jaUsou} slots restantes na vitrine.`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});