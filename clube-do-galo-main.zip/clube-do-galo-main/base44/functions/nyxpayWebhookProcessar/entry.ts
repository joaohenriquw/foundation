import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return Response.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    const base44 = createClientFromRequest(req);

    // Buscar config do gateway para validar assinatura
    const gateways = await base44.asServiceRole.entities.GatewayConfig.filter({
      provider: 'nyxpay',
      ativo: true
    });

    if (!gateways.length) {
      console.error('Gateway não configurado');
      return Response.json({ error: 'Gateway não configurado' }, { status: 400 });
    }

    const config = gateways[0];
    const webhook_secret = config.webhook_secret;
    const body = await req.text();
    const signature = req.headers.get('x-nyxpay-signature');

    // Validar assinatura (HMAC-SHA256)
    if (!await validarAssinatura(body, signature, webhook_secret)) {
      console.error('Assinatura inválida');
      return Response.json({ error: 'Assinatura inválida' }, { status: 401 });
    }

    const evento = JSON.parse(body);

    // Processar apenas eventos de pagamento confirmado
    if (evento.event === 'payment.approved' || evento.event === 'pix.received') {
      const { transaction_id, amount, customer, status } = evento.data;

      if (!transaction_id || !amount || !customer?.email) {
        return Response.json({ error: 'Dados incompletos' }, { status: 400 });
      }

      // Buscar depósito pendente
      const depositos = await base44.asServiceRole.entities.Deposito.filter({
        usuario_email: customer.email,
        nyxpay_transaction_id: transaction_id,
        status: 'pendente'
      });

      if (depositos.length > 0) {
        const deposito = depositos[0];

        // Atualizar depósito para confirmado
        await base44.asServiceRole.entities.Deposito.update(deposito.id, {
          status: 'confirmado',
          data_confirmacao: new Date().toISOString()
        });

        // Buscar usuário e adicionar saldo
        const usuarios = await base44.asServiceRole.entities.User.filter({
          email: customer.email
        });

        if (usuarios.length > 0) {
          const user = usuarios[0];
          const novoSaldo = (user.saldo_carteira || 0) + amount;

          await base44.asServiceRole.entities.User.update(user.id, {
            saldo_carteira: novoSaldo
          });

          console.log(`✅ Depósito de R$ ${amount} confirmado para ${customer.email}`);
        }
      }

      // Processar saque confirmado
      const saques = await base44.asServiceRole.entities.Saque.filter({
        nyxpay_payout_id: transaction_id,
        status: 'processando'
      });

      if (saques.length > 0) {
        const saque = saques[0];

        await base44.asServiceRole.entities.Saque.update(saque.id, {
          status: 'confirmado',
          data_confirmacao: new Date().toISOString()
        });

        console.log(`✅ Saque de R$ ${amount} confirmado para ${customer.email}`);
      }
    }

    // Processar divisão de lucros (quando há venda/leilão/rifa)
    if (evento.event === 'sale.completed') {
      const { amount, reference_id, reference_type } = evento.data;

      // Referência pode ser: leilao_123, rifa_456, etc
      const [tipo, id] = reference_id.split('_');

      if (tipo === 'leilao') {
        await processarDivisaoLeilao(base44, id, amount);
      } else if (tipo === 'rifa') {
        await processarDivisaoRifa(base44, id, amount);
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    console.error('Erro webhook NyxPay:', error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
});

// Validar assinatura HMAC-SHA256
async function validarAssinatura(body, signature, secret) {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const digest = await crypto.subtle.sign('HMAC', key, encoder.encode(body));
  const digestHex = Array.from(new Uint8Array(digest))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
  return digestHex === signature;
}

// Processar divisão de lucro do leilão
async function processarDivisaoLeilao(base44, leilaoId, valor) {
  const TAXA_ADMIN = 0.10; // 10% taxa
  const TAXA_GATEWAY = 0.38;

  const socios = {
    'Jéder': 0.50,
    'João': 0.20,
    'Álvaro': 0.20,
    'Lucas': 0.10,
  };

  const valorAposGateway = valor - TAXA_GATEWAY;
  const comissao = valorAposGateway * TAXA_ADMIN;

  // Distribuir comissão entre sócios
  for (const [nome, percentual] of Object.entries(socios)) {
    const valor_socio = comissao * percentual;

    try {
      await base44.asServiceRole.entities.ComissaoLeilao.create({
        leilao_id: leilaoId,
        socio_nome: nome,
        percentual: percentual,
        valor_bruto: valor,
        taxa_gateway: TAXA_GATEWAY,
        valor_comissao: valor_socio,
        status: 'creditado',
        data_creditacao: new Date().toISOString()
      });
    } catch (e) {
      console.log(`Aviso: Não foi possível registrar comissão para ${nome}`);
    }
  }

  console.log(`✅ Divisão de lucro leilão ${leilaoId} processada`);
}

// Processar divisão de lucro da rifa
async function processarDivisaoRifa(base44, rifaId, valor) {
  const TAXA_ADMIN = 0.10;
  const TAXA_GATEWAY = 0.38;

  const socios = {
    'Jéder': 0.50,
    'João': 0.20,
    'Álvaro': 0.20,
    'Lucas': 0.10,
  };

  const valorAposGateway = valor - TAXA_GATEWAY;
  const comissao = valorAposGateway * TAXA_ADMIN;

  for (const [nome, percentual] of Object.entries(socios)) {
    const valor_socio = comissao * percentual;

    try {
      await base44.asServiceRole.entities.ComissaoRifa.create({
        rifa_id: rifaId,
        socio_nome: nome,
        percentual: percentual,
        valor_bruto: valor,
        taxa_gateway: TAXA_GATEWAY,
        valor_comissao: valor_socio,
        status: 'creditado',
        data_creditacao: new Date().toISOString()
      });
    } catch (e) {
      console.log(`Aviso: Não foi possível registrar comissão para ${nome}`);
    }
  }

  console.log(`✅ Divisão de lucro rifa ${rifaId} processada`);
}