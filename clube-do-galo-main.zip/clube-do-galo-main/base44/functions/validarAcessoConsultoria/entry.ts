import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const users = await base44.asServiceRole.entities.User.filter({ email: user.email });
    const userData = users[0];
    const planoAtual = userData?.plano || 'iniciante';

    // Admins têm acesso total
    if (userData?.role === 'admin') {
      return Response.json({
        tem_acesso: true,
        plano_atual: 'admin',
        tipos_disponiveis: ['advogado_civil', 'advogado_criminal', 'veterinario'],
        mensagem: '✅ Acesso permitido (admin)'
      });
    }

    const PLANOS_COM_ACESSO = ['premium'];

    if (!PLANOS_COM_ACESSO.includes(planoAtual)) {
      return Response.json({
        tem_acesso: false,
        plano_atual: planoAtual,
        mensagem: `❌ Apenas plano Premium tem acesso a Consultorias Jurídicas e Veterinárias. Seu plano: ${planoAtual}`,
        planos_permitidos: PLANOS_COM_ACESSO,
        link_upgrade: '/planos'
      });
    }

    // Verificar se já tem consultorias ativas
    const consultoriasAbertas = await base44.asServiceRole.entities.ChatConversa.filter({
      usuario_email: user.email,
      status: 'ativa'
    });

    // Limite: 2 consultorias simultâneas para premium
    const LIMITE = 2;

    if (consultoriasAbertas.length >= LIMITE) {
      return Response.json({
        tem_acesso: true,
        consultorias_abertas: consultoriasAbertas.length,
        limite_simultaneas: LIMITE,
        limit_atingido: true,
        mensagem: `⚠️ Você tem ${consultoriasAbertas.length} consultorias ativas. Máximo: ${LIMITE}.`,
        consultorias: consultoriasAbertas.map(c => ({
          id: c.id,
          tipo: c.tipo,
          profissional: c.profissional_nome,
          status: c.status
        }))
      });
    }

    return Response.json({
      tem_acesso: true,
      plano_atual: planoAtual,
      consultorias_abertas: consultoriasAbertas.length,
      limite_simultaneas: LIMITE,
      limit_atingido: false,
      slots_restantes: LIMITE - consultoriasAbertas.length,
      tipos_disponiveis: ['advogado_civil', 'advogado_criminal', 'veterinario'],
      mensagem: `✅ Acesso permitido. ${LIMITE - consultoriasAbertas.length} consultorias restantes.`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});