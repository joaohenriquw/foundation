import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const conexoes = new Map(); // leilaoId -> Set de WritableStream

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const leilaoId = url.searchParams.get('leilao_id');
  const action = url.searchParams.get('action');

  // Conectar ao SSE
  if (action === 'connect' && req.headers.get('accept') === 'text/event-stream') {
    const headers = {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
    };

    let aborted = false;
    const { readable, writable } = new TransformStream();
    
    // Adicionar esta conexão
    if (!conexoes.has(leilaoId)) {
      conexoes.set(leilaoId, new Set());
    }
    conexoes.get(leilaoId).add(writable);

    // Enviar confirmação
    const writer = writable.getWriter();
    await writer.write(new TextEncoder().encode('data: {"conectado":true}\n\n'));

    // Monitorar desconexão
    req.signal.addEventListener('abort', () => {
      aborted = true;
      conexoes.get(leilaoId)?.delete(writable);
      writer.close();
    });

    return new Response(readable, { headers });
  }

  // Broadcast de lances (chamado quando há novo lance)
  if (action === 'lance' && req.method === 'POST') {
    try {
      const base44 = createClientFromRequest(req);
      const body = await req.json();
      const { leilao_id, lance_valor, lancador_nome, lancador_email } = body;

      const conexoesList = conexoes.get(leilao_id);
      if (conexoesList && conexoesList.size > 0) {
        const evento = {
          tipo: 'lance',
          valor: lance_valor,
          lancador: lancador_nome,
          email: lancador_email,
          timestamp: new Date().toISOString(),
        };

        for (const writable of conexoesList) {
          try {
            const writer = writable.getWriter();
            await writer.write(
              new TextEncoder().encode(`data: ${JSON.stringify(evento)}\n\n`)
            );
            writer.releaseLock();
          } catch (e) {
            conexoesList.delete(writable);
          }
        }
      }

      return Response.json({ sucesso: true });
    } catch (error) {
      return Response.json({ error: error.message }, { status: 500 });
    }
  }

  // Encerramento do leilão
  if (action === 'encerrar' && req.method === 'POST') {
    try {
      const body = await req.json();
      const { leilao_id, ganhador_nome, ganhador_email } = body;

      const conexoesList = conexoes.get(leilao_id);
      if (conexoesList && conexoesList.size > 0) {
        const evento = {
          tipo: 'encerramento',
          ganhador: ganhador_nome,
          email: ganhador_email,
          mensagem: `Leilão encerrado! Ganhador: ${ganhador_nome}`,
          timestamp: new Date().toISOString(),
        };

        for (const writable of conexoesList) {
          try {
            const writer = writable.getWriter();
            await writer.write(
              new TextEncoder().encode(`data: ${JSON.stringify(evento)}\n\n`)
            );
            writer.close();
          } catch (e) {
            // ignore
          }
        }
      }

      conexoes.delete(leilao_id);
      return Response.json({ sucesso: true });
    } catch (error) {
      return Response.json({ error: error.message }, { status: 500 });
    }
  }

  return Response.json({ error: 'Invalid request' }, { status: 400 });
});