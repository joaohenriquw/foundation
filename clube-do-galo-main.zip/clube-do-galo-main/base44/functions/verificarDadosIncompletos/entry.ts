import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Dados obrigatórios
    const dadosObrigatorios = ['cpf', 'whatsapp', 'nome_criatorio'];
    const dadosFaltando = dadosObrigatorios.filter(campo => !user[campo]);

    if (dadosFaltando.length === 0) {
      return Response.json({ completo: true, dadosFaltando: [] });
    }

    // Criar notificação para usuário
    const notificacao = await base44.entities.Notificacao.create({
      destinatario_id: user.id,
      destinatario_email: user.email,
      titulo: '📋 Complete seu cadastro',
      mensagem: `Faltam os seguintes dados: ${dadosFaltando.map(d => d.replace('_', ' ')).join(', ')}. Acesse seu perfil para atualizar.`,
      tipo: 'sistema',
      icone: '⚠️',
      link: '/perfil-usuario?aba=dados'
    });

    return Response.json({
      completo: false,
      dadosFaltando: dadosFaltando,
      notificacaoId: notificacao.id
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});