import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { post_id, descurtir = false } = await req.json();

    // Buscar post
    const posts = await base44.asServiceRole.entities.Post.filter({ id: post_id });
    if (posts.length === 0) {
      return Response.json({ error: 'Post não encontrado' }, { status: 404 });
    }

    const post = posts[0];

    // Buscar se já curtiu
    const curtidas = await base44.asServiceRole.entities.CurtidaPost.filter({
      post_id,
      usuario_email: user.email
    });

    if (descurtir) {
      // Remover curtida
      if (curtidas.length > 0) {
        await base44.asServiceRole.entities.CurtidaPost.delete(curtidas[0].id);
        await base44.asServiceRole.entities.Post.update(post_id, {
          curtidas: Math.max(0, (post.curtidas || 0) - 1)
        });
      }
      return Response.json({ sucesso: true, curtido: false });
    }

    if (curtidas.length === 0) {
      // Adicionar curtida
      await base44.asServiceRole.entities.CurtidaPost.create({
        post_id,
        usuario_id: user.id || user.email,
        usuario_email: user.email,
        usuario_nome: user.full_name || user.email
      });

      await base44.asServiceRole.entities.Post.update(post_id, {
        curtidas: (post.curtidas || 0) + 1
      });

      // Notificar autor
      if (post.autor_email !== user.email) {
        await base44.asServiceRole.entities.Notificacao.create({
          destinatario_id: post.autor_id,
          destinatario_email: post.autor_email,
          titulo: '❤️ Alguém curtiu seu post',
          mensagem: `${user.full_name || user.email} curtiu seu post`,
          tipo: 'social',
          lida: false,
          icone: '❤️',
          link: `/post/${post_id}`
        });
      }
    }

    return Response.json({ sucesso: true, curtido: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});