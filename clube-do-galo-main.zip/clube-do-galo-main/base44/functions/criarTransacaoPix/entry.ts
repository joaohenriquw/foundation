import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 401 });
    }

    const { amount, tipo, leilao_id, rifa_id, plano } = await req.json();

    if (!amount || !tipo) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
    }

    const apiKey = Deno.env.get('NYXPAY_API_KEY');
    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'Gateway not configured' }), { status: 500 });
    }

    // Construir metadata baseada no tipo
    const metadata = { tipo };
    if (tipo === 'leilao') metadata.leilao_id = leilao_id;
    if (tipo === 'rifa') metadata.rifa_id = rifa_id;
    if (tipo === 'plano') metadata.plano = plano;

    // Criar transação na NyxPay
    const nyxResponse = await fetch('https://app.nyxpay.shop/api/v1/transactions', {
      method: 'POST',
      headers: {
        'X-API-Key': apiKey,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount,
        payment_method: 'pix',
        customer_name: user.full_name,
        customer_email: user.email,
        customer_cpf_cnpj: '00000000000000', // TODO: adicionar campo de CPF/CNPJ no usuário
        metadata,
      }),
    });

    if (!nyxResponse.ok) {
      const error = await nyxResponse.json();
      return new Response(JSON.stringify({ error: error.message || 'Payment gateway error' }), { status: 400 });
    }

    const nyxData = await nyxResponse.json();

    // Registrar transação na base44
    const transacao = await base44.entities.Transacao.create({
      txn_id: nyxData.id,
      evento: tipo,
      status: 'pending',
      valor: amount,
      forma_pagamento: 'pix',
      cliente_nome: user.full_name,
      cliente_email: user.email,
      payload_raw: JSON.stringify(nyxData),
      data_nyxpay: new Date().toISOString(),
    });

    return new Response(JSON.stringify({
      success: true,
      transacao_id: transacao.id,
      nyxpay_id: nyxData.id,
      pix_qrcode: nyxData.pix_qrcode,
      pix_key: nyxData.pix_key,
      expires_at: nyxData.expires_at,
    }), { status: 201 });
  } catch (error) {
    console.error('Error creating transaction:', error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
});