import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { usuario_email, deixarSeguir = false } = await req.json();

    if (usuario_email === user.email) {
      return Response.json({ error: 'Não pode seguir a si mesmo' }, { status: 400 });
    }

    // Buscar relacionamento
    const relacao = await base44.asServiceRole.entities.Seguidor.filter({
      seguidor_email: user.email,
      seguindo_email: usuario_email
    });

    if (deixarSeguir) {
      // Deixar de seguir
      if (relacao.length > 0) {
        await base44.asServiceRole.entities.Seguidor.delete(relacao[0].id);
      }
      return Response.json({ sucesso: true, seguindo: false });
    }

    if (relacao.length === 0) {
      // Começar a seguir
      await base44.asServiceRole.entities.Seguidor.create({
        seguidor_id: user.id || user.email,
        seguidor_nome: user.full_name || user.email,
        seguidor_email: user.email,
        seguindo_id: usuario_email,
        seguindo_nome: usuario_email,
        seguindo_email: usuario_email
      });

      // Notificar
      await base44.asServiceRole.entities.Notificacao.create({
        destinatario_email: usuario_email,
        titulo: '👤 Novo seguidor',
        mensagem: `${user.full_name || user.email} começou a te seguir`,
        tipo: 'social',
        lida: false,
        icone: '👤'
      });
    }

    return Response.json({ sucesso: true, seguindo: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});