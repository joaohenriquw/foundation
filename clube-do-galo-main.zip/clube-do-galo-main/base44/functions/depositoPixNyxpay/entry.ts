import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

// Validar CPF (simples)
function validarCPF(cpf) {
  const numeros = cpf.replace(/\D/g, '');
  return numeros.length === 11 && numeros !== '00000000000' && numeros !== '11111111111';
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    const { valor, cpf, nome } = payload;

    if (!valor || valor <= 0) {
      return Response.json({ error: 'Valor inválido' }, { status: 400 });
    }
    
    // Se CPF não foi fornecido, usar um genérico (a NyxPay valida depois)
    let cpfFinal = cpf ? cpf.replace(/\D/g, '') : '';
    if (cpfFinal && !validarCPF(cpfFinal)) {
      return Response.json({ error: 'CPF inválido. Use 11 dígitos válidos ou deixe em branco.' }, { status: 400 });
    }
    // Se vazio, usar CPF de teste
    if (!cpfFinal) {
      cpfFinal = '00000000000'; // Será tratado pela gateway
    }

    // Buscar credenciais da NyxPay
    const gateways = await base44.asServiceRole.entities.GatewayConfig.filter({
      provider: 'nyxpay',
      ativo: true
    });

    if (!gateways.length) {
      return Response.json({ error: 'Gateway NyxPay não configurado.' }, { status: 400 });
    }

    const api_key = gateways[0].api_key;

    const requestBody = {
      amount: valor,
      payment_method: 'pix',
      customer_name: nome || user.full_name || 'Usuário',
      customer_email: user.email,
      customer_cpf_cnpj: cpfFinal,
      postback_url: 'https://app.nyxpay.shop/api/v1/webhook',
    };

    const nyxpayResponse = await fetch('https://app.nyxpay.shop/api/v1/transactions', {
      method: 'POST',
      headers: {
        'X-API-Key': api_key,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    const nyxpayData = await nyxpayResponse.json();

    if (!nyxpayResponse.ok || !nyxpayData.success) {
      const msg = nyxpayData?.transaction?.message || nyxpayData?.message || 'Erro desconhecido';
      return Response.json({ error: 'Erro NyxPay: ' + msg }, { status: 400 });
    }

    const txn = nyxpayData.transaction;

    if (txn.status === 'rejected') {
      return Response.json({ error: 'Transação rejeitada: ' + (txn.message || 'Dados inválidos') }, { status: 400 });
    }

    // Registrar depósito pendente
    try {
      await base44.asServiceRole.entities.Deposito.create({
        usuario_id: user.id,
        usuario_email: user.email,
        usuario_nome: user.full_name,
        valor: valor,
        txn_id: txn.id,
        qr_code: txn.pix_qr_code,
        pix_copia_cola: txn.pix_copy_paste,
        status: 'aguardando_pagamento',
        data_solicitacao: new Date().toISOString(),
      });
    } catch (e) {
      // Silenciosamente continua
    }

    return Response.json({
      success: true,
      data: {
        qr_code: txn.pix_qr_code || '',
        pix_copia_cola: txn.pix_copy_paste || txn.pix_qr_code || '',
        transaction_id: txn.id,
      },
      valor: valor,
      mensagem: 'QR Code gerado com sucesso',
    });
  } catch (error) {
    return Response.json({ error: error.message || 'Erro ao gerar QR Code' }, { status: 500 });
  }
});