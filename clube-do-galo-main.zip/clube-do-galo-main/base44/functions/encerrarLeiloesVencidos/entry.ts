import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Buscar leilões ativos com data_fim vencida
    const agora = new Date().toISOString();
    const leiloesAtivos = await base44.asServiceRole.entities.Leilao.filter({ status: 'ativo' }, '-created_date', 200);
    
    let encerrados = 0;
    for (const leilao of leiloesAtivos) {
      if (new Date(leilao.data_fim) <= new Date(agora)) {
        // Encerrar leilão
        await base44.asServiceRole.entities.Leilao.update(leilao.id, {
          status: 'encerrado'
        });

        // Se tem maior lance, notificar ganhador
        if (leilao.maior_lance_user_email) {
          await base44.asServiceRole.entities.Notificacao.create({
            destinatario_email: leilao.maior_lance_user_email,
            titulo: '🏆 Você venceu o leilão!',
            mensagem: `Parabéns! Você arrematou "${leilao.animal_nome}" por R$ ${Number(leilao.maior_lance).toFixed(2)}. Acesse o leilão para ver o QR Code PIX.`,
            tipo: 'leilao',
            icone: '🏆',
            link: `/leilao/${leilao.id}`
          });

          // Notificar dono
          await base44.asServiceRole.entities.Notificacao.create({
            destinatario_email: leilao.dono_email,
            titulo: '✅ Leilão encerrado',
            mensagem: `Seu leilão de "${leilao.animal_nome}" foi arrematado por ${leilao.maior_lance_user_nome} por R$ ${Number(leilao.maior_lance).toFixed(2)}.`,
            tipo: 'leilao',
            icone: '✅',
            link: `/leilao/${leilao.id}`
          });
        }

        encerrados++;
      }
    }

    return Response.json({ sucesso: true, leiloesEncerrados: encerrados, timestamp: new Date().toISOString() });
  } catch (error) {
    console.error('Erro ao encerrar leilões:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});