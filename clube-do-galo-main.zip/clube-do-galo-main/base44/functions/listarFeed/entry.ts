import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { tipo = 'seguindo', limite = 20 } = await req.json();

    let posts = [];

    if (tipo === 'seguindo') {
      // Buscar usuários que o usuário segue
      const seguindo = await base44.asServiceRole.entities.Seguidor.filter({
        seguidor_email: user.email
      });

      const emailsSeguindo = seguindo.map(s => s.seguindo_email);
      emailsSeguindo.push(user.email); // Incluir próprios posts

      // Buscar posts desses usuários
      for (const email of emailsSeguindo) {
        const userPosts = await base44.asServiceRole.entities.Post.filter({
          autor_email: email,
          visivel: true
        }, '-created_date', 10);
        posts = posts.concat(userPosts);
      }
    } else if (tipo === 'todos') {
      // Feed público
      posts = await base44.asServiceRole.entities.Post.filter({
        visivel: true
      }, '-created_date', limite);
    }

    // Ordenar por data
    posts.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    posts = posts.slice(0, limite);

    // Enriquecer com dados do usuário logado
    const postsEnriquecidos = await Promise.all(
      posts.map(async (p) => {
        // Verificar se curtiu
        const curtidas = await base44.asServiceRole.entities.CurtidaPost.filter({
          post_id: p.id,
          usuario_email: user.email
        });

        // Buscar comentários
        const comentarios = await base44.asServiceRole.entities.ComentarioPost.filter({
          post_id: p.id
        }, '-created_date', 5);

        return {
          ...p,
          curtido_por_mim: curtidas.length > 0,
          comentarios: comentarios
        };
      })
    );

    return Response.json({
      sucesso: true,
      feed: postsEnriquecidos
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});