import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { 
      tipo = 'leilao', // leilao, rifa, animal
      termo = '',
      filtros = {},
      ordenacao = '-created_date',
      limite = 20,
      pagina = 1
    } = await req.json();

    let resultados = [];

    if (tipo === 'leilao') {
      // Busca em leilões
      let query = { status: filtros.status || 'ativo' };
      
      if (termo) {
        query.titulo = { $contains: termo };
      }
      if (filtros.animal_especie) {
        query.animal_especie = filtros.animal_especie;
      }
      if (filtros.lance_minimo_from) {
        query.lance_minimo = { $gte: filtros.lance_minimo_from };
      }
      if (filtros.lance_minimo_to) {
        query.lance_minimo = { $lte: filtros.lance_minimo_to };
      }

      resultados = await base44.asServiceRole.entities.Leilao.filter(
        query,
        ordenacao,
        limite
      );
    }

    if (tipo === 'rifa') {
      // Busca em rifas
      let query = { status: filtros.status || 'ativa' };
      
      if (termo) {
        query.titulo = { $contains: termo };
      }
      if (filtros.preco_bilhete_from) {
        query.valor_bilhete = { $gte: filtros.preco_bilhete_from };
      }
      if (filtros.preco_bilhete_to) {
        query.valor_bilhete = { $lte: filtros.preco_bilhete_to };
      }

      resultados = await base44.asServiceRole.entities.Rifa.filter(
        query,
        ordenacao,
        limite
      );
    }

    if (tipo === 'animal') {
      // Busca em animais
      let query = { status_vitrine: 'disponivel' };
      
      if (termo) {
        query.nome = { $contains: termo };
      }
      if (filtros.especie) {
        query.especie = filtros.especie;
      }
      if (filtros.sexo) {
        query.sexo = filtros.sexo;
      }
      if (filtros.valor_from) {
        query.valor_estimado = { $gte: filtros.valor_from };
      }
      if (filtros.valor_to) {
        query.valor_estimado = { $lte: filtros.valor_to };
      }
      if (filtros.saude) {
        query.saude_status = filtros.saude;
      }

      resultados = await base44.asServiceRole.entities.Animal.filter(
        query,
        ordenacao,
        limite
      );
    }

    // Paginar
    const skip = (pagina - 1) * limite;
    const resultadosPaginados = resultados.slice(skip, skip + limite);

    return Response.json({
      sucesso: true,
      busca: {
        tipo,
        termo,
        filtros,
        ordenacao
      },
      resultados: resultadosPaginados,
      paginacao: {
        total: resultados.length,
        pagina,
        limite,
        total_paginas: Math.ceil(resultados.length / limite)
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});