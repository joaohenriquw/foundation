import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const alertEmail = Deno.env.get('CLUB_ALERT_EMAIL') || '';

  if (!alertEmail) {
    return Response.json({ error: 'CLUB_ALERT_EMAIL não configurado' }, { status: 500 });
  }

  const hoje = new Date().toISOString().split('T')[0];

  // Busca todas anilhas aguardando troca e sem notificação enviada
  const anilhas = await base44.asServiceRole.entities.AnilhaFilha.filter({
    status: 'aguardando_troca',
    notificacao_enviada: false,
  });

  const vencidas = anilhas.filter(a => a.data_prevista_troca && a.data_prevista_troca <= hoje);

  if (vencidas.length === 0) {
    return Response.json({ message: 'Nenhuma anilha vencida', total: 0 });
  }

  // Agrupa por lote
  const lotes = {};
  for (const a of vencidas) {
    const key = a.lote_id || a.id;
    if (!lotes[key]) lotes[key] = { anilhas: [], pai: a.animal_pai_nome, mae: a.animal_mae_nome, origem: a.animal_origem_nome };
    lotes[key].anilhas.push(a);
  }

  let emailBody = `<h2>🚨 Anilhas Filhas — Troca Urgente</h2>
<p>As seguintes anilhas precisam ser trocadas da cor colorida para a <strong>numeração definitiva</strong> com cadastro completo:</p>`;

  for (const [loteId, lote] of Object.entries(lotes)) {
    emailBody += `<h3>📿 Lote: ${loteId}</h3>`;
    emailBody += `<p><strong>Origem:</strong> ${lote.origem || '—'} | <strong>Pai:</strong> ${lote.pai || '—'} | <strong>Mãe:</strong> ${lote.mae || '—'}</p>`;
    emailBody += `<table border="1" cellpadding="6" style="border-collapse:collapse">
      <tr><th>Anilha</th><th>Cor</th><th>Vencimento</th></tr>`;
    for (const a of lote.anilhas) {
      emailBody += `<tr><td>${a.numero_anilha}</td><td>${a.cor_anilha}</td><td>${a.data_prevista_troca}</td></tr>`;
    }
    emailBody += `</table><br>`;
  }

  emailBody += `<p><strong>Ação necessária:</strong> Troque as anilhas coloridas pela numeração definitiva e realize o cadastro completo dos filhotes no sistema.</p>`;

  await base44.asServiceRole.integrations.Core.SendEmail({
    to: alertEmail,
    subject: `🚨 URGENTE: ${vencidas.length} anilha(s) precisam de troca — Clube do Galo`,
    body: emailBody,
  });

  // Marca como notificadas
  for (const a of vencidas) {
    await base44.asServiceRole.entities.AnilhaFilha.update(a.id, { notificacao_enviada: true });
  }

  console.log(`[AnilhasVencidas] ${vencidas.length} anilhas notificadas para ${alertEmail}`);
  return Response.json({ message: 'Notificações enviadas', total: vencidas.length });
});