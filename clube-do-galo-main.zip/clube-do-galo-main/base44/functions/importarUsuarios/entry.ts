import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'master_admin') {
      return Response.json({ error: 'Acesso negado' }, { status: 403 });
    }

    const { usuarios } = await req.json();

    if (!Array.isArray(usuarios) || usuarios.length === 0) {
      return Response.json({ error: 'Lista de usuários inválida' }, { status: 400 });
    }

    // Validar e preparar dados
    const usuariosValidos = usuarios
      .filter(u => u.email && u.full_name)
      .map(u => ({
        email: u.email,
        full_name: u.full_name,
        role: u.role || 'user'
      }));

    if (usuariosValidos.length === 0) {
      return Response.json({ error: 'Nenhum usuário válido na lista' }, { status: 400 });
    }

    // Importar em chunks de 100
    const chunkSize = 100;
    let importados = 0;
    let erros = [];

    for (let i = 0; i < usuariosValidos.length; i += chunkSize) {
      const chunk = usuariosValidos.slice(i, i + chunkSize);
      
      try {
        await base44.asServiceRole.entities.User.bulkCreate(chunk);
        importados += chunk.length;
      } catch (error) {
        erros.push({
          chunk: Math.floor(i / chunkSize),
          mensagem: error.message
        });
      }
    }

    // Log da importação
    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_email: user.email,
      titulo: '📊 Importação de Usuários Concluída',
      mensagem: `${importados} usuários importados com sucesso. ${erros.length} chunks com erro.`,
      tipo: 'sistema',
      icone: '📊'
    });

    return Response.json({
      sucesso: true,
      total: usuariosValidos.length,
      importados,
      erros
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});