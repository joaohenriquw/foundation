import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch(() => null);

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Criar animais de exemplo
    const animaisExemplo = [
      {
        nome: "Rei do Norte",
        anilha: "EX-2024-001",
        especie: "Galo Combatente",
        tipo_categoria: "elenco_principal",
        sexo: "macho",
        cor_plumagem: "Vermelho ouro",
        saude_status: "excelente",
        status_vitrine: "disponivel",
        valor_estimado: 4500,
        premiacoes: "Campeão Regional 2024",
        observacoes: "Linhagem pura portuguesa. Excelente temperamento.",
        proprietario_id: user.id,
        proprietario_nome: user.full_name,
        proprietario_email: user.email,
      },
      {
        nome: "Trovão Dourado",
        anilha: "EX-2024-002",
        especie: "Galo Shamo",
        tipo_categoria: "reprodutor",
        sexo: "macho",
        cor_plumagem: "Dourado",
        saude_status: "excelente",
        status_vitrine: "disponivel",
        valor_estimado: 8200,
        premiacoes: "3 temporadas invicto",
        observacoes: "Reprodutor premium, filhos campeões.",
        proprietario_id: user.id,
        proprietario_nome: user.full_name,
        proprietario_email: user.email,
      },
      {
        nome: "Sultão Negro",
        anilha: "EX-2023-087",
        especie: "Galo Índio",
        tipo_categoria: "elenco_principal",
        sexo: "macho",
        cor_plumagem: "Negro",
        saude_status: "excelente",
        status_vitrine: "disponivel",
        valor_estimado: 6000,
        observacoes: "Linhagem Índio legítimo, porte avantajado.",
        proprietario_id: user.id,
        proprietario_nome: user.full_name,
        proprietario_email: user.email,
      },
      {
        nome: "Guerreiro da Caatinga",
        anilha: "EX-2024-055",
        especie: "Galo Brasileiro",
        tipo_categoria: "elenco_principal",
        sexo: "macho",
        cor_plumagem: "Vermelho",
        saude_status: "excelente",
        status_vitrine: "disponivel",
        valor_estimado: 5500,
        premiacoes: "Vários títulos",
        observacoes: "Sangue nordestino legítimo, resistente e ágil.",
        proprietario_id: user.id,
        proprietario_nome: user.full_name,
        proprietario_email: user.email,
      },
    ];

    // Criar animais
    const animaisCriados = [];
    for (const animal of animaisExemplo) {
      const criado = await base44.entities.Animal.create(animal);
      animaisCriados.push(criado);
    }

    // Criar exposições na vitrine
    const dataExpiracao = new Date();
    dataExpiracao.setDate(dataExpiracao.getDate() + 45);

    const exposicoes = [];
    for (const animal of animaisCriados) {
      const exp = await base44.entities.VitrineExposicao.create({
        animal_id: animal.id,
        animal_nome: animal.nome,
        animal_anilha: animal.anilha,
        animal_especie: animal.especie,
        animal_foto_url: "",
        animal_valor: animal.valor_estimado,
        proprietario_id: user.id,
        proprietario_nome: user.full_name,
        plano_expositore: "premium",
        data_expiracao: dataExpiracao.toISOString().split('T')[0],
        ativa: true,
        descricao: animal.observacoes,
      });
      exposicoes.push(exp);
    }

    return Response.json({
      sucesso: true,
      mensagem: `${animaisCriados.length} animais criados e ${exposicoes.length} exposições adicionadas à vitrine.`,
      animais: animaisCriados,
      exposicoes,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});