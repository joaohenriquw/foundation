import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const conversas = await base44.asServiceRole.entities.ConversaDM.filter({});

    // Filtrar conversas do usuário
    const minhasConversas = conversas.filter(c =>
      c.usuario1_email === user.email || c.usuario2_email === user.email
    );

    // Enriquecer com mensagens não lidas
    const conversasEnriquecidas = await Promise.all(
      minhasConversas.map(async (c) => {
        const mensagens = await base44.asServiceRole.entities.MensagemDM.filter({
          conversa_id: c.id
        }, '-created_date', 1000);

        const naoLidas = mensagens.filter(m => 
          !m.lida && m.remetente_email !== user.email
        ).length;

        const outraEmail = c.usuario1_email === user.email ? c.usuario2_email : c.usuario1_email;
        
        return {
          ...c,
          nao_lidas: naoLidas,
          outra_email: outraEmail,
          total_mensagens: mensagens.length,
          ultima_preview: c.ultima_mensagem?.substring(0, 50)
        };
      })
    );

    // Ordenar por última mensagem
    conversasEnriquecidas.sort((a, b) =>
      new Date(b.ultima_mensagem_data || 0) - new Date(a.ultima_mensagem_data || 0)
    );

    return Response.json({
      sucesso: true,
      conversas: conversasEnriquecidas
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});