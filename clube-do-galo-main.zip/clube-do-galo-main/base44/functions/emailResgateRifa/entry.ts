import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const { automation, data } = await req.json();
    const base44 = createClientFromRequest(req);

    const rifa = data;
    if (rifa.status !== 'finalizada' || !rifa.ganhador_email) {
      return Response.json({ ignorado: true });
    }

    const appUrl = 'https://clube-do-galo.app';

    await base44.integrations.Core.SendEmail({
      to: rifa.ganhador_email,
      subject: `🎉 Parabéns! Você ganhou na rifa de ${rifa.animal_nome}!`,
      body: `
<html>
  <body style="font-family: 'DM Sans', sans-serif; background: #f8fafc; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
      <div style="background: linear-gradient(135deg, #E91E63, #FF6090); padding: 40px 20px; text-align: center; color: #fff;">
        <div style="font-size: 48px; margin-bottom: 16px;">🎲</div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 900;">Sorte Grande!</h1>
        <p style="margin: 8px 0 0; opacity: 0.9; font-size: 14px;">Você foi sorteado(a)!</p>
      </div>
      
      <div style="padding: 40px 24px;">
        <p style="margin: 0 0 20px; font-size: 16px; color: #101213;">
          Parabéns, ${rifa.ganhador_nome.split(' ')[0]}! 🎉
        </p>
        
        <div style="background: #ffe1e1; border-left: 4px solid #E91E63; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
          <p style="margin: 0 0 8px; font-size: 14px; color: #C2185B;">
            <strong>${rifa.animal_nome}</strong>
          </p>
          <p style="margin: 0 0 8px; font-size: 13px; color: #C2185B;">
            Bilhete: <strong>${rifa.numero_bilhete_ganhador}</strong>
          </p>
          <p style="margin: 0; font-size: 13px; color: #C2185B;">
            Prêmio: <strong>R$ ${Number(rifa.valor_total).toFixed(2).replace('.', ',')}</strong>
          </p>
        </div>
        
        <p style="margin: 0 0 16px; font-size: 13px; color: #57636C; line-height: 1.6;">
          Seu bilhete foi sorteado na rifa do(a) ${rifa.animal_nome}! 🎊
        </p>
        
        <p style="margin: 0 0 20px; font-size: 13px; color: #57636C;">
          <strong>O que fazer agora:</strong>
        </p>
        
        <ol style="margin: 0 0 20px; padding-left: 20px; font-size: 13px; color: #57636C; line-height: 1.8;">
          <li>Entre em contato com o proprietário para combinações</li>
          <li>Confirme a entrega do animal</li>
          <li>Acompanhe o status na plataforma</li>
        </ol>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${appUrl}/rifa/${rifa.id}" style="display: inline-block; background: #E91E63; color: #fff; padding: 12px 32px; border-radius: 10px; text-decoration: none; font-weight: 800; font-size: 14px;">Ver Detalhes</a>
        </div>
        
        <p style="margin: 20px 0 0; font-size: 12px; color: #9E9E9E;">
          Proprietário: ${rifa.proprietario_nome}<br>
          Contato: ${rifa.proprietario_whatsapp || rifa.proprietario_email}
        </p>
      </div>
    </div>
  </body>
</html>
      `,
      from_name: 'Clube do Galo - Rifas'
    });

    return Response.json({ enviado: true, email: rifa.ganhador_email });
  } catch (error) {
    console.error('Erro ao enviar email rifa:', error);
    return Response.json({ erro: error.message }, { status: 500 });
  }
});