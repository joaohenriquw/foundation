import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { leilao_id, valor, parcelas = 1 } = await req.json();

    if (!leilao_id || !valor) {
      return Response.json({ error: 'Dados inválidos' }, { status: 400 });
    }

    // 1. Buscar leilão
    const leiloes = await base44.asServiceRole.entities.Leilao.filter({ id: leilao_id });
    const leilao = leiloes[0];

    if (!leilao) {
      return Response.json({ error: 'Leilão não encontrado' }, { status: 404 });
    }

    // 2. Validações
    if (leilao.status !== 'ativo') {
      return Response.json({ error: 'Leilão não está ativo' }, { status: 400 });
    }

    if (new Date(leilao.data_fim) <= new Date()) {
      return Response.json({ error: 'Leilão já expirou' }, { status: 400 });
    }

    if (user.email === leilao.dono_email) {
      return Response.json({ error: 'Você não pode dar lance no seu próprio leilão' }, { status: 400 });
    }

    // 3. Validar valor mínimo
    const maiorLance = leilao.maior_lance || leilao.lance_minimo;
    if (valor <= maiorLance) {
      return Response.json({ 
        error: `Lance deve ser maior que R$ ${Number(maiorLance).toFixed(2)}`,
        maior_lance_atual: maiorLance 
      }, { status: 400 });
    }

    // 4. Validar saldo do usuário
    const users = await base44.asServiceRole.entities.User.filter({ email: user.email });
    const userData = users[0];
    const saldoAtual = userData?.saldo || 0;

    if (saldoAtual < valor) {
      return Response.json({ 
        error: `Saldo insuficiente. Necessário: R$ ${valor.toFixed(2)}, Disponível: R$ ${saldoAtual.toFixed(2)}`,
        saldo_necessario: valor,
        saldo_disponivel: saldoAtual
      }, { status: 400 });
    }

    // 5. Criar registro de lance
    const lance = await base44.asServiceRole.entities.LeilaoLance.create({
      leilao_id,
      user_id: user.id || user.email,
      user_nome: user.full_name || user.email,
      user_email: user.email,
      valor,
      parcelas,
      valor_parcela: valor / parcelas,
    });

    // 6. Atualizar leilão com maior lance
    await base44.asServiceRole.entities.Leilao.update(leilao_id, {
      maior_lance: valor,
      maior_lance_user_id: user.id || user.email,
      maior_lance_user_nome: user.full_name || user.email,
      maior_lance_user_email: user.email,
    });

    // 7. Notificar dono sobre novo lance
    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_id: leilao.dono_id,
      destinatario_email: leilao.dono_email,
      titulo: `🔨 Novo lance em "${leilao.titulo}"`,
      mensagem: `${user.full_name || user.email} deu um lance de R$ ${valor.toFixed(2).replace('.', ',')}`,
      tipo: 'leilao',
      link: `/leilao/${leilao_id}`,
      icone: '🔨',
    });

    // 8. Notificar lance automático anterior (se houve)
    if (leilao.maior_lance_user_email && leilao.maior_lance_user_email !== user.email) {
      await base44.asServiceRole.entities.Notificacao.create({
        destinatario_id: leilao.maior_lance_user_id,
        destinatario_email: leilao.maior_lance_user_email,
        titulo: `📉 Você foi superado em "${leilao.titulo}"`,
        mensagem: `Novo lance de R$ ${valor.toFixed(2).replace('.', ',')} superou o seu.`,
        tipo: 'leilao',
        link: `/leilao/${leilao_id}`,
        icone: '📉',
      });
    }

    return Response.json({
      sucesso: true,
      lance: {
        id: lance.id,
        valor,
        parcelas,
        valor_parcela: valor / parcelas,
        timestamp: new Date().toISOString()
      },
      leilao_atualizado: {
        id: leilao_id,
        maior_lance: valor,
        maior_lancista: user.full_name || user.email
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});