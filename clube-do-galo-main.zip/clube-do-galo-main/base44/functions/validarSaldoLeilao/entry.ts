import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const { valor_lance } = await req.json();

    if (!valor_lance || valor_lance <= 0) {
      return Response.json({ error: 'Valor inválido' }, { status: 400 });
    }

    // Buscar usuário com saldo
    const users = await base44.asServiceRole.entities.User.filter({ email: user.email });
    if (!users.length) {
      return Response.json({ error: 'Usuário não encontrado' }, { status: 404 });
    }

    const saldoAtual = users[0].saldo_carteira || 0;
    const temSaldo = saldoAtual >= valor_lance;

    return Response.json({
      success: true,
      saldo_atual: saldoAtual,
      valor_lance: valor_lance,
      tem_saldo_suficiente: temSaldo,
      mensagem: temSaldo ? 'Saldo suficiente' : `Saldo insuficiente. Você tem R$ ${saldoAtual.toFixed(2)}, mas precisa de R$ ${valor_lance.toFixed(2)}`,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});