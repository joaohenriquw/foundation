import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

const GATEWAY_FIXO = 0.38;
const TAXA_ADMIN = 0.10;

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { leilao_id } = await req.json();

    const leilao = await base44.entities.Leilao.filter({ id: leilao_id });
    if (!leilao || leilao.length === 0) {
      return Response.json({ error: 'Leilão não encontrado' }, { status: 404 });
    }

    const l = leilao[0];
    const valorTotal = Number(l.maior_lance);
    const parcelas = Number(l.ganhador_parcelas || 1);

    // Cálculos
    const valorParcela = valorTotal / parcelas;
    const taxaGateway = GATEWAY_FIXO;
    const taxaAdmin = valorTotal * TAXA_ADMIN;
    
    const valorLiquidoVendedor = valorTotal - taxaGateway - taxaAdmin;
    const valorParcelaVendedor = valorLiquidoVendedor / parcelas;

    // Distribuição por socio (se houver)
    const socios = await base44.asServiceRole.entities.Socio.filter({ ativo: true });
    
    const distribuicao = {
      leilao_id,
      data_calculo: new Date().toISOString(),
      valor_total: valorTotal,
      parcelas,
      valor_parcela_primeira: valorParcela.toFixed(2),
      
      // Breakdown
      taxa_gateway: taxaGateway.toFixed(2),
      taxa_admin_percentual: (TAXA_ADMIN * 100) + '%',
      taxa_admin_valor: taxaAdmin.toFixed(2),
      
      // Para o vendedor
      valor_liquido_vendedor: valorLiquidoVendedor.toFixed(2),
      valor_parcela_vendedor: valorParcelaVendedor.toFixed(2),
      
      // Distribuição entre sócios
      socios_distribuicao: socios.map(s => ({
        socio_nome: s.nome,
        socio_email: s.email,
        percentual: s.percentual_leilao,
        valor_total: ((taxaAdmin * (s.percentual_leilao / 100))).toFixed(2),
        valor_parcela: ((taxaAdmin / parcelas * (s.percentual_leilao / 100))).toFixed(2),
      })),
      
      // PIX primeira parcela
      pix_primeira_parcela: {
        valor: valorParcela.toFixed(2),
        referencia: `LEI-${leilao_id.substring(0, 8)}`,
        descricao: `Primeira parcela (${1} de ${parcelas}) - Leilão ${l.animal_nome}`,
      },
    };

    // Salvar distribuição no leilão
    await base44.entities.Leilao.update(leilao_id, {
      distribuicao_json: JSON.stringify(distribuicao),
    });

    return Response.json(distribuicao);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});