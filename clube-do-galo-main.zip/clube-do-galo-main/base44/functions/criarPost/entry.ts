import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { conteudo, tipo = 'texto', midia_url } = await req.json();

    if (!conteudo || conteudo.trim().length === 0) {
      return Response.json({ error: 'Conteúdo vazio' }, { status: 400 });
    }

    const post = await base44.asServiceRole.entities.Post.create({
      autor_id: user.id || user.email,
      autor_nome: user.full_name || user.email,
      autor_email: user.email,
      conteudo,
      tipo,
      midia_url: midia_url || null,
      curtidas: 0,
      comentarios_count: 0,
      compartilhamentos: 0,
      visivel: true
    });

    return Response.json({
      sucesso: true,
      post: {
        id: post.id,
        conteudo: post.conteudo,
        autor: post.autor_nome,
        criado_em: post.created_date
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});