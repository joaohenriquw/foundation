import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    if (req.method !== 'POST') {
      return Response.json({ error: 'Method not allowed' }, { status: 405 });
    }

    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const signature = req.headers.get('X-DarkPay-Signature');

    // 1. Buscar gateway para validar assinatura
    const gateways = await base44.asServiceRole.entities.GatewayConfig.filter({
      provider: 'nyxpay',
      ativo: true
    });

    const gateway = gateways[0];
    if (!gateway || !gateway.webhook_secret) {
      return Response.json({ error: 'Gateway config not found' }, { status: 400 });
    }

    // 2. Validar assinatura HMAC
    const crypto = await import('crypto');
    const expected = crypto.createHmac('sha256', gateway.webhook_secret)
      .update(JSON.stringify(body))
      .digest('hex');

    if (!signature || signature !== expected) {
      return Response.json({ error: 'Invalid signature' }, { status: 401 });
    }

    // 3. Registrar webhook na base
    await base44.asServiceRole.entities.Transacao.create({
      txn_id: body.data?.id || body.id,
      evento: body.event,
      status: body.data?.status || 'updated',
      valor: body.data?.amount,
      forma_pagamento: body.data?.payment_method,
      cliente_nome: body.data?.customer_name,
      cliente_email: body.data?.customer_email,
      payload_raw: JSON.stringify(body),
      data_nyxpay: body.timestamp
    });

    // 4. Processar eventos
    const { event, data } = body;

    if (event === 'transaction.approved') {
      // Deposito aprovado
      const depositos = await base44.asServiceRole.entities.Deposito.filter({
        txn_id: data.id
      });

      if (depositos.length > 0) {
        const deposito = depositos[0];

        // Atualizar deposito
        await base44.asServiceRole.entities.Deposito.update(deposito.id, {
          status: 'concluido',
          data_confirmacao: new Date().toISOString()
        });

        // Creditar saldo do usuário
        const users = await base44.asServiceRole.entities.User.filter({
          email: deposito.usuario_email
        });

        if (users.length > 0) {
          const user = users[0];
          const novoSaldo = (user.saldo || 0) + deposito.valor;
          await base44.asServiceRole.entities.User.update(user.id, {
            saldo: novoSaldo
          });
        }

        // Notificar usuário
        await base44.asServiceRole.entities.Notificacao.create({
          destinatario_id: deposito.usuario_id,
          destinatario_email: deposito.usuario_email,
          titulo: '✅ Depósito confirmado!',
          mensagem: `Seu depósito de R$ ${deposito.valor.toFixed(2).replace('.', ',')} foi confirmado e creditado.`,
          tipo: 'sistema',
          icone: '✅'
        });
      }
    }

    if (event === 'transaction.rejected') {
      // Deposito rejeitado
      const depositos = await base44.asServiceRole.entities.Deposito.filter({
        txn_id: data.id
      });

      if (depositos.length > 0) {
        const deposito = depositos[0];

        await base44.asServiceRole.entities.Deposito.update(deposito.id, {
          status: 'cancelado'
        });

        // Notificar
        await base44.asServiceRole.entities.Notificacao.create({
          destinatario_id: deposito.usuario_id,
          destinatario_email: deposito.usuario_email,
          titulo: '❌ Depósito rejeitado',
          mensagem: `Seu depósito de R$ ${deposito.valor.toFixed(2).replace('.', ',')} foi rejeitado.`,
          tipo: 'sistema',
          icone: '❌'
        });
      }
    }

    if (event === 'withdrawal.completed') {
      // Saque concluído
      const saques = await base44.asServiceRole.entities.Saque.filter({
        txn_id: data.id
      });

      if (saques.length > 0) {
        const saque = saques[0];

        await base44.asServiceRole.entities.Saque.update(saque.id, {
          status: 'concluido',
          data_conclusao: new Date().toISOString()
        });

        await base44.asServiceRole.entities.Notificacao.create({
          destinatario_id: saque.usuario_id,
          destinatario_email: saque.usuario_email,
          titulo: '✅ Saque concluído!',
          mensagem: `Seu saque de R$ ${saque.valor.toFixed(2).replace('.', ',')} foi concluído.`,
          tipo: 'sistema',
          icone: '✅'
        });
      }
    }

    return Response.json({ sucesso: true, recebido: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});