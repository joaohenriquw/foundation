import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { rifa_id } = await req.json();

    if (!rifa_id) {
      return Response.json({ erro: "rifa_id obrigatório" }, { status: 400 });
    }

    const rifa = await base44.asServiceRole.entities.Rifa.filter({ id: rifa_id });
    if (!rifa || rifa.length === 0) {
      return Response.json({ erro: "Rifa não encontrada" }, { status: 404 });
    }

    const rifaData = rifa[0];

    // Verificar se tem ganhador
    if (!rifaData.ganhador_email) {
      return Response.json({
        erro: "Rifa não tem ganhador designado",
        sucesso: false
      }, { status: 400 });
    }

    // Notificar ganhador
    const mensagemGanhador = `🎉 Você venceu o sorteio da rifa "${rifaData.titulo}"!\n\n` +
      `🎟️ Número: ${rifaData.ganhador_numero}\n` +
      `🏆 Prêmio: ${rifaData.animal_nome} (Anilha: ${rifaData.animal_anilha})\n\n` +
      `Clique para mais detalhes e combinações de entrega.`;

    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_id: rifaData.ganhador_id,
      destinatario_email: rifaData.ganhador_email,
      titulo: `🎉 Parabéns! Você venceu!`,
      mensagem: mensagemGanhador,
      tipo: "rifa",
      icone: "🏆",
      link: `/rifa/${rifa_id}`
    });

    // Notificar dono da conclusão
    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_id: rifaData.dono_id,
      destinatario_email: rifaData.dono_email,
      titulo: `✅ Sorteio Realizado`,
      mensagem: `A rifa "${rifaData.titulo}" foi sorteada. Ganhador: ${rifaData.ganhador_nome} (Número ${rifaData.ganhador_numero}).`,
      tipo: "rifa",
      icone: "✅"
    });

    // Marcar como notificado
    await base44.asServiceRole.entities.Rifa.update(rifa_id, {
      ganhador_notificado: true
    });

    return Response.json({
      sucesso: true,
      ganhador: rifaData.ganhador_nome,
      email: rifaData.ganhador_email
    });
  } catch (error) {
    return Response.json({
      erro: error.message,
      sucesso: false
    }, { status: 500 });
  }
});