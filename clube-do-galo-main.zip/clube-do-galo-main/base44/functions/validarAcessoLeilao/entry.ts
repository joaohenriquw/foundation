import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const userData = await base44.entities.User.filter({ email: user.email });
    const userProfile = userData[0];

    if (!userProfile) {
      return Response.json({
        tem_acesso: false,
        mensagem: 'Perfil não encontrado',
        plano: 'indefinido'
      });
    }

    // Admins têm acesso total
    if (userProfile.role === 'admin') {
      return Response.json({
        tem_acesso: true,
        plano: 'admin',
        usuario: userProfile.full_name || user.email,
        mensagem: 'Acesso total (admin)'
      });
    }

    const plano = userProfile.plano || 'iniciante';
    const PLANOS_COM_ACESSO_LEILAO = ['standard', 'gold', 'premium'];
    const temAcesso = PLANOS_COM_ACESSO_LEILAO.includes(plano);

    // Verificar se tem subscription ativa (para planos pagos)
    if (plano !== 'iniciante' && temAcesso) {
      const subscriptions = await base44.entities.Mensalidade.filter({
        usuario_email: user.email,
        status: 'ativa'
      });
      if (subscriptions.length === 0) {
        return Response.json({
          tem_acesso: false,
          mensagem: 'Sua assinatura expirou. Renove para continuar participando de leilões.',
          plano,
          info_plano: {
            standard: 'Standard: Leilões limitados',
            gold: 'Gold: Leilões ilimitados',
            premium: 'Premium: Tudo liberado'
          }[plano]
        });
      }
    }

    return Response.json({
      tem_acesso: temAcesso,
      plano,
      usuario: userProfile.full_name || user.email,
      mensagem: temAcesso
        ? `Acesso permitido (${plano})`
        : `Seu plano ${plano} não permite participar de leilões. Upgrade para Standard, Gold ou Premium.`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});