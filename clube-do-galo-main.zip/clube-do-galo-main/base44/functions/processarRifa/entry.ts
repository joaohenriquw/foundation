import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { rifa_id, quantidade_bilhetes, valor_bilhete } = await req.json();

    if (!rifa_id || !quantidade_bilhetes || !valor_bilhete) {
      return Response.json({ error: 'Dados inválidos' }, { status: 400 });
    }

    // 1. Buscar rifa
    const rifas = await base44.asServiceRole.entities.Rifa.filter({ id: rifa_id });
    const rifa = rifas[0];

    if (!rifa) {
      return Response.json({ error: 'Rifa não encontrada' }, { status: 404 });
    }

    // 2. Validações
    if (rifa.status !== 'ativa') {
      return Response.json({ error: 'Rifa não está ativa' }, { status: 400 });
    }

    if (new Date(rifa.data_fim) <= new Date()) {
      return Response.json({ error: 'Rifa já expirou' }, { status: 400 });
    }

    // 3. Validar bilhetes disponíveis
    const bilhetesCriados = await base44.asServiceRole.entities.RifaBilhete.filter({ rifa_id });
    const bilhetesRestantes = rifa.total_bilhetes - bilhetesCriados.length;

    if (quantidade_bilhetes > bilhetesRestantes) {
      return Response.json({ 
        error: `Bilhetes insuficientes. Disponíveis: ${bilhetesRestantes}`,
        bilhetes_solicitados: quantidade_bilhetes,
        bilhetes_disponiveis: bilhetesRestantes
      }, { status: 400 });
    }

    // 4. Validar saldo do usuário
    const valorTotal = quantidade_bilhetes * valor_bilhete;
    const users = await base44.asServiceRole.entities.User.filter({ email: user.email });
    const userData = users[0];
    const saldoAtual = userData?.saldo || 0;

    if (saldoAtual < valorTotal) {
      return Response.json({ 
        error: `Saldo insuficiente para ${quantidade_bilhetes} bilhetes`,
        valor_necessario: valorTotal,
        valor_disponivel: saldoAtual
      }, { status: 400 });
    }

    // 5. Criar bilhetes
    const bilhetes = [];
    const proximoNumero = bilhetesCriados.length + 1;

    for (let i = 0; i < quantidade_bilhetes; i++) {
      const bilhete = await base44.asServiceRole.entities.RifaBilhete.create({
        rifa_id,
        numero_bilhete: proximoNumero + i,
        comprador_id: user.id || user.email,
        comprador_email: user.email,
        comprador_nome: user.full_name || user.email,
        valor: valor_bilhete,
        status: 'ativo',
      });
      bilhetes.push(bilhete);
    }

    // 6. Atualizar saldo do usuário (débito)
    await base44.asServiceRole.entities.User.update(userData.id, {
      saldo: saldoAtual - valorTotal
    });

    // 7. Atualizar rifa (bilhetes vendidos)
    await base44.asServiceRole.entities.Rifa.update(rifa_id, {
      bilhetes_vendidos: bilhetesCriados.length + quantidade_bilhetes,
      arrecadado: (rifa.arrecadado || 0) + valorTotal
    });

    // 8. Notificar comprador
    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_id: user.id || user.email,
      destinatario_email: user.email,
      titulo: `🎟️ Bilhetes da rifa "${rifa.titulo}" confirmados!`,
      mensagem: `Você comprou ${quantidade_bilhetes} bilhetes por R$ ${valorTotal.toFixed(2).replace('.', ',')}. Números: ${proximoNumero} a ${proximoNumero + quantidade_bilhetes - 1}`,
      tipo: 'rifa',
      link: `/rifa/${rifa_id}`,
      icone: '🎟️',
    });

    // 9. Notificar dono sobre venda
    await base44.asServiceRole.entities.Notificacao.create({
      destinatario_id: rifa.dono_id,
      destinatario_email: rifa.dono_email,
      titulo: `💰 ${quantidade_bilhetes} bilhetes vendidos em "${rifa.titulo}"`,
      mensagem: `${user.full_name || user.email} comprou ${quantidade_bilhetes} bilhetes. Arrecadado: R$ ${valorTotal.toFixed(2).replace('.', ',')}`,
      tipo: 'rifa',
      link: `/rifa/${rifa_id}`,
      icone: '💰',
    });

    return Response.json({
      sucesso: true,
      bilhetes_criados: {
        quantidade: quantidade_bilhetes,
        numeros: Array.from({ length: quantidade_bilhetes }, (_, i) => proximoNumero + i),
        valor_unitario: valor_bilhete,
        valor_total: valorTotal
      },
      rifa_atualizada: {
        id: rifa_id,
        bilhetes_vendidos: bilhetesCriados.length + quantidade_bilhetes,
        total_bilhetes: rifa.total_bilhetes,
        arrecadado: (rifa.arrecadado || 0) + valorTotal
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});