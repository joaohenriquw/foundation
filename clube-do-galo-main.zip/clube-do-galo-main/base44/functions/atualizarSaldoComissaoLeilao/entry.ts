import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { leilao_id } = await req.json();

    if (!leilao_id) {
      return Response.json({ error: 'Leilão não informado' }, { status: 400 });
    }

    // Buscar leilão encerrado
    const leiloes = await base44.asServiceRole.entities.Leilao.filter({ id: leilao_id });
    if (!leiloes.length) {
      return Response.json({ error: 'Leilão não encontrado' }, { status: 404 });
    }

    const leilao = leiloes[0];

    // Verificar se já foi processado
    if (leilao.pagamento_confirmado) {
      return Response.json({ success: false, message: 'Leilão já foi processado' });
    }

    if (leilao.status !== 'encerrado') {
      return Response.json({ success: false, message: 'Leilão ainda não foi encerrado' });
    }

    const valorLance = leilao.maior_lance;
    const ganhadorEmail = leilao.ganhador_email;
    const vendedorEmail = leilao.dono_email;

    // Buscar configuração de sócios
    const socios = await base44.asServiceRole.entities.Socio.filter({ ativo: true });
    let taxaAdmin = 0.10; // 10% padrão
    
    if (socios.length > 0) {
      const percentualTotal = socios.reduce((sum, s) => sum + (s.percentual_leilao || 0), 0);
      taxaAdmin = percentualTotal / 100;
    }

    const valorComissao = valorLance * taxaAdmin;
    const valorVendedor = valorLance * (1 - taxaAdmin);

    // Buscar usuários
    const ganhadores = await base44.asServiceRole.entities.User.filter({ email: ganhadorEmail });
    const vendedores = await base44.asServiceRole.entities.User.filter({ email: vendedorEmail });

    if (ganhadores.length && vendedores.length) {
      const ganhador = ganhadores[0];
      const vendedor = vendedores[0];

      // Atualizar saldo do vendedor (adiciona)
      const novoSaldoVendedor = (vendedor.saldo_carteira || 0) + valorVendedor;
      await base44.asServiceRole.entities.User.update(vendedor.id, {
        saldo_carteira: novoSaldoVendedor,
      });

      // Registrar transação Transacao
      await base44.asServiceRole.entities.Transacao.create({
        txn_id: `LEILAO_${leilao_id}`,
        evento: 'leilao.comissao',
        status: 'approved',
        valor: valorVendedor,
        forma_pagamento: 'comissao',
        cliente_nome: vendedor.full_name,
        cliente_email: vendedorEmail,
        payload_raw: JSON.stringify({ leilao_id, tipo: 'comissao' }),
        data_nyxpay: new Date().toISOString(),
      });

      // Notificar vendedor
      await base44.asServiceRole.entities.Notificacao.create({
        destinatario_id: vendedor.id,
        destinatario_email: vendedorEmail,
        titulo: '💰 Leilão Finalizado - Comissão Adicionada',
        mensagem: `Seu leilão foi finalizado! Você recebeu R$ ${valorVendedor.toFixed(2)} (após comissão de 10%). O valor já está em sua carteira.`,
        tipo: 'leilao',
        icone: '💰',
        lida: false,
      });

      // Marcar como processado
      await base44.asServiceRole.entities.Leilao.update(leilao_id, {
        pagamento_confirmado: true,
      });

      return Response.json({
        success: true,
        vendedor_email: vendedorEmail,
        valor_comissao: valorComissao,
        valor_vendedor: valorVendedor,
        novo_saldo: novoSaldoVendedor,
      });
    }

    return Response.json({ success: false, message: 'Usuários não encontrados' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});