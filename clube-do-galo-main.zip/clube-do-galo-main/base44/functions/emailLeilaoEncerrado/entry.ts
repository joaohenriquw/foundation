import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const { automation, data, old_data } = await req.json();
    const base44 = createClientFromRequest(req);

    const leilao = data;
    if (leilao.status !== 'encerrado' || old_data?.status === 'encerrado') {
      return Response.json({ ignorado: true, motivo: 'Status não mudou para encerrado' });
    }

    const appUrl = 'https://clube-do-galo.app';

    // Email para GANHADOR
    if (leilao.ganhador_email && leilao.ganhador_nome) {
      await base44.integrations.Core.SendEmail({
        to: leilao.ganhador_email,
        subject: `🏆 Parabéns! Você ganhou o leilão de ${leilao.animal_nome}!`,
        body: `
<html>
  <body style="font-family: 'DM Sans', sans-serif; background: #f8fafc; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
      <div style="background: linear-gradient(135deg, #F0A500, #FFD700); padding: 40px 20px; text-align: center; color: #101213;">
        <div style="font-size: 48px; margin-bottom: 16px;">🏆</div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 900;">Parabéns, ${leilao.ganhador_nome.split(' ')[0]}!</h1>
        <p style="margin: 8px 0 0; opacity: 0.85; font-size: 14px;">Você venceu o leilão!</p>
      </div>
      
      <div style="padding: 40px 24px;">
        <div style="background: #fff8e1; border-left: 4px solid #F0A500; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
          <p style="margin: 0; font-size: 14px; color: #856404; font-weight: 700;">
            Animal: <strong>${leilao.animal_nome}</strong> (Anilha: ${leilao.animal_anilha})
          </p>
          <p style="margin: 8px 0 0; font-size: 14px; color: #856404;">
            Lance final: <strong>R$ ${Number(leilao.maior_lance).toFixed(2).replace('.', ',')}</strong>
          </p>
        </div>
        
        <p style="margin: 0 0 16px; font-size: 14px; color: #57636C;">
          Seu leilão foi encerrado! 🎉
        </p>
        
        <p style="margin: 0 0 20px; font-size: 13px; color: #57636C; line-height: 1.6;">
          <strong>Próximos passos:</strong>
        </p>
        
        <ol style="margin: 0 0 20px; padding-left: 20px; font-size: 13px; color: #57636C; line-height: 1.8;">
          <li>Confirme sua intenção de compra</li>
          <li>Acerte as condições de pagamento (${leilao.ganhador_parcelas || 1}x)</li>
          <li>Finalize o pagamento via PIX</li>
          <li>Combine a entrega com o vendedor</li>
        </ol>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${appUrl}/leilao/${leilao.id}" style="display: inline-block; background: #F0A500; color: #fff; padding: 12px 32px; border-radius: 10px; text-decoration: none; font-weight: 800; font-size: 14px;">Ver Detalhes</a>
        </div>
        
        <p style="margin: 20px 0 0; font-size: 12px; color: #9E9E9E; line-height: 1.6;">
          Contato do vendedor: <strong>${leilao.dono_whatsapp || leilao.dono_email}</strong>
        </p>
      </div>
    </div>
  </body>
</html>
        `,
        from_name: 'Clube do Galo - Leilões'
      });
    }

    // Email para VENDEDOR
    if (leilao.dono_email) {
      await base44.integrations.Core.SendEmail({
        to: leilao.dono_email,
        subject: `✅ Seu leilão de ${leilao.animal_nome} foi encerrado!`,
        body: `
<html>
  <body style="font-family: 'DM Sans', sans-serif; background: #f8fafc; padding: 20px;">
    <div style="max-width: 600px; margin: 0 auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
      <div style="background: linear-gradient(135deg, #170073, #00A893); padding: 40px 20px; text-align: center; color: #fff;">
        <div style="font-size: 48px; margin-bottom: 16px;">✅</div>
        <h1 style="margin: 0; font-size: 24px; font-weight: 900;">Leilão Encerrado!</h1>
      </div>
      
      <div style="padding: 40px 24px;">
        <p style="margin: 0 0 20px; font-size: 14px; color: #57636C;">
          ${leilao.dono_nome.split(' ')[0]}, seu leilão foi finalizado com sucesso! 🎉
        </p>
        
        <div style="background: #f0f4ff; border-left: 4px solid #170073; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
          <p style="margin: 0 0 8px; font-size: 13px; color: #57636C;"><strong>Animal:</strong> ${leilao.animal_nome}</p>
          <p style="margin: 0 0 8px; font-size: 13px; color: #57636C;"><strong>Ganhador:</strong> ${leilao.ganhador_nome}</p>
          <p style="margin: 0 0 8px; font-size: 13px; color: #57636C;"><strong>Lance final:</strong> R$ ${Number(leilao.maior_lance).toFixed(2).replace('.', ',')}</p>
          <p style="margin: 0; font-size: 13px; color: #57636C;"><strong>Parcelas:</strong> ${leilao.ganhador_parcelas || 1}x</p>
        </div>
        
        <p style="margin: 0 0 16px; font-size: 12px; color: #9E9E9E;">
          Você receberá o valor referente à sua comissão na próxima semana após confirmação de pagamento.
        </p>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${appUrl}/leilao/${leilao.id}" style="display: inline-block; background: linear-gradient(135deg, #170073, #00A893); color: #fff; padding: 12px 32px; border-radius: 10px; text-decoration: none; font-weight: 800; font-size: 14px;">Acompanhar</a>
        </div>
      </div>
    </div>
  </body>
</html>
        `,
        from_name: 'Clube do Galo - Leilões'
      });
    }

    return Response.json({ enviados: true, ganhador: leilao.ganhador_email, vendedor: leilao.dono_email });
  } catch (error) {
    console.error('Erro ao enviar email leilão encerrado:', error);
    return Response.json({ erro: error.message }, { status: 500 });
  }
});