import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { teste_type } = await req.json();

    // Testes de Permissão Cruzada
    if (teste_type === 'criar_consultoria_vet') {
      try {
        const consultores = await base44.asServiceRole.entities.User.filter({ role: 'veterinario' });
        if (consultores.length === 0) {
          return Response.json({ erro: 'Nenhum veterinário disponível' }, { status: 400 });
        }

        const conversa = await base44.asServiceRole.entities.ChatConversa.create({
          usuario_id: user.id,
          usuario_nome: user.full_name || user.email,
          usuario_email: user.email,
          profissional_id: consultores[0].id,
          profissional_nome: consultores[0].full_name || consultores[0].email,
          profissional_email: consultores[0].email,
          tipo: 'veterinario',
          status: 'ativa',
          ultima_mensagem: 'Teste iniciado'
        });

        return Response.json({
          teste: 'criar_consultoria_vet',
          status: 'PASSOU',
          conversa_id: conversa.id,
          tipo: 'veterinario',
          validacoes: {
            usuario_id_preenchido: !!conversa.usuario_id,
            profissional_id_preenchido: !!conversa.profissional_id,
            status_correto: conversa.status === 'ativa',
            tipo_correto: conversa.tipo === 'veterinario'
          }
        });
      } catch (e) {
        return Response.json({ teste: 'criar_consultoria_vet', status: 'FALHOU', erro: e.message }, { status: 500 });
      }
    }

    // Teste de Envio de Mensagem
    if (teste_type === 'enviar_mensagem_consultoria') {
      try {
        const conversas = await base44.asServiceRole.entities.ChatConversa.filter({ usuario_email: user.email });
        if (conversas.length === 0) {
          return Response.json({ erro: 'Nenhuma conversa encontrada' }, { status: 400 });
        }

        const msg = await base44.asServiceRole.entities.ChatMensagem.create({
          conversa_id: conversas[0].id,
          remetente_id: user.id,
          remetente_email: user.email,
          remetente_nome: user.full_name || user.email,
          conteudo: 'Teste de mensagem - ' + new Date().toISOString(),
          lida: false
        });

        return Response.json({
          teste: 'enviar_mensagem_consultoria',
          status: 'PASSOU',
          mensagem_id: msg.id,
          validacoes: {
            remetente_id_preenchido: !!msg.remetente_id,
            conteudo_salvo: !!msg.conteudo,
            lida_false: msg.lida === false
          }
        });
      } catch (e) {
        return Response.json({ teste: 'enviar_mensagem_consultoria', status: 'FALHOU', erro: e.message }, { status: 500 });
      }
    }

    // Teste de Notificação
    if (teste_type === 'validar_notificacao') {
      try {
        const notificacoes = await base44.asServiceRole.entities.Notificacao.filter({
          tipo: 'consultoria'
        }, '-created_date', 10);

        const notificacaoRecente = notificacoes.find(n => n.destinatario_id && n.destinatario_email);

        return Response.json({
          teste: 'validar_notificacao',
          status: notificacaoRecente ? 'PASSOU' : 'FALHOU',
          validacoes: {
            destinatario_id_preenchido: !!notificacaoRecente?.destinatario_id,
            destinatario_email_preenchido: !!notificacaoRecente?.destinatario_email,
            link_funcional: notificacaoRecente?.link?.includes('/chat/'),
            total_notificacoes: notificacoes.length
          }
        });
      } catch (e) {
        return Response.json({ teste: 'validar_notificacao', status: 'FALHOU', erro: e.message }, { status: 500 });
      }
    }

    // Teste de Historico de Mensagens
    if (teste_type === 'carregar_historico') {
      try {
        const conversas = await base44.asServiceRole.entities.ChatConversa.filter({ usuario_email: user.email });
        if (conversas.length === 0) {
          return Response.json({ erro: 'Nenhuma conversa' }, { status: 400 });
        }

        const mensagens = await base44.asServiceRole.entities.ChatMensagem.filter({
          conversa_id: conversas[0].id
        }, '-created_date', 100);

        // Validar ordem cronológica
        let ordemCorreta = true;
        for (let i = 1; i < mensagens.length; i++) {
          if (new Date(mensagens[i].created_date) > new Date(mensagens[i - 1].created_date)) {
            ordemCorreta = false;
            break;
          }
        }

        return Response.json({
          teste: 'carregar_historico',
          status: ordemCorreta ? 'PASSOU' : 'FALHOU',
          validacoes: {
            total_mensagens: mensagens.length,
            ordem_cronologica_correta: ordemCorreta,
            mensagens_nao_duplicadas: mensagens.length === new Set(mensagens.map(m => m.id)).size
          }
        });
      } catch (e) {
        return Response.json({ teste: 'carregar_historico', status: 'FALHOU', erro: e.message }, { status: 500 });
      }
    }

    // Teste de DM entre Usuários
    if (teste_type === 'criar_dm') {
      try {
        const usuarios = await base44.asServiceRole.entities.User.filter({});
        const outro = usuarios.find(u => u.email !== user.email);
        
        if (!outro) {
          return Response.json({ erro: 'Precisa de outro usuário' }, { status: 400 });
        }

        const dm = await base44.asServiceRole.entities.ConversaDM.create({
          usuario1_id: user.id,
          usuario1_nome: user.full_name || user.email,
          usuario1_email: user.email,
          usuario2_id: outro.id,
          usuario2_nome: outro.full_name || outro.email,
          usuario2_email: outro.email,
          ultima_mensagem: 'Teste DM',
          ultima_mensagem_data: new Date().toISOString()
        });

        return Response.json({
          teste: 'criar_dm',
          status: 'PASSOU',
          dm_id: dm.id,
          validacoes: {
            usuario2_id_preenchido: !!dm.usuario2_id,
            usuario2_nome_preenchido: !!dm.usuario2_nome,
            usuario2_email_preenchido: !!dm.usuario2_email
          }
        });
      } catch (e) {
        return Response.json({ teste: 'criar_dm', status: 'FALHOU', erro: e.message }, { status: 500 });
      }
    }

    // Teste de Performance - Carregar 100 Mensagens
    if (teste_type === 'performance_100_msgs') {
      try {
        const inicio = Date.now();
        const conversas = await base44.asServiceRole.entities.ChatConversa.filter({ usuario_email: user.email });
        
        if (conversas.length === 0) {
          return Response.json({ erro: 'Nenhuma conversa' }, { status: 400 });
        }

        const msgs = await base44.asServiceRole.entities.ChatMensagem.filter({
          conversa_id: conversas[0].id
        }, '-created_date', 100);

        const tempo = Date.now() - inicio;

        return Response.json({
          teste: 'performance_100_msgs',
          status: tempo < 2500 ? 'PASSOU' : 'FALHOU',
          metricas: {
            tempo_ms: tempo,
            mensagens_carregadas: msgs.length,
            taxa_sucesso: tempo < 2500
          }
        });
      } catch (e) {
        return Response.json({ teste: 'performance_100_msgs', status: 'FALHOU', erro: e.message }, { status: 500 });
      }
    }

    // Teste de Resiliência - Validar Erro 403 para Acesso Não-Autorizado
    if (teste_type === 'validar_permissoes') {
      try {
        const conversas = await base44.asServiceRole.entities.ChatConversa.filter({});
        const conversaNaoMinha = conversas.find(c => c.usuario_email !== user.email && c.profissional_email !== user.email);

        if (!conversaNaoMinha) {
          return Response.json({
            teste: 'validar_permissoes',
            status: 'INCONCLUSO',
            msg: 'Nenhuma conversa de terceiro encontrada'
          });
        }

        // Tentar enviar mensagem (será bloqueada no backend)
        try {
          await base44.asServiceRole.entities.ChatMensagem.create({
            conversa_id: conversaNaoMinha.id,
            remetente_id: user.id,
            remetente_email: user.email,
            remetente_nome: user.full_name || user.email,
            conteudo: 'Teste acesso não autorizado',
            lida: false
          });
          // Se chegou aqui, é um problema
          return Response.json({ teste: 'validar_permissoes', status: 'FALHOU', motivo: 'Acesso não autorizado não foi bloqueado' });
        } catch (e) {
          // Erro esperado
          return Response.json({
            teste: 'validar_permissoes',
            status: 'PASSOU',
            validacoes: {
              acesso_bloqueado: true,
              erro_esperado: true
            }
          });
        }
      } catch (e) {
        return Response.json({ teste: 'validar_permissoes', status: 'FALHOU', erro: e.message }, { status: 500 });
      }
    }

    return Response.json({ erro: 'Tipo de teste não encontrado' }, { status: 400 });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});