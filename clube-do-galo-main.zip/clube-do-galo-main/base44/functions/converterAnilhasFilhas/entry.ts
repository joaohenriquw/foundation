import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Buscar anilhas filhas que chegaram na data de troca
    const hoje = new Date().toISOString().split('T')[0];
    const anilhas = await base44.entities.AnilhaFilha.filter({
      usuario_email: user.email,
      status: 'incubando',
      data_troca_definitiva: hoje
    });

    if (anilhas.length === 0) {
      return Response.json({ message: 'Nenhuma anilha para converter' });
    }

    // Para cada anilha, criar um cadastro de adulto automático
    for (const anilha of anilhas) {
      const novoAnimal = await base44.entities.Animal.create({
        nome: `${anilha.animal_pai_nome} x ${anilha.animal_mae_nome}`,
        anilha: anilha.anilha_numero,
        especie: 'galo',
        tipo_categoria: 'elenco_principal',
        origem: 'filho',
        data_de_nascimento: new Date(anilha.data_criacao).toISOString().split('T')[0],
        sexo: 'macho',
        cor_plumagem: anilha.cor_anilha_definitiva,
        peso_gramas: 0,
        saude_status: 'excelente',
        status_vitrine: 'indisponivel',
        proprietario_email: user.email,
        proprietario_id: user.id,
        proprietario_nome: user.full_name || user.email,
        pai_id: anilha.animal_pai_id,
        pai_nome: anilha.animal_pai_nome,
        mae_id: anilha.animal_mae_id,
        mae_nome: anilha.animal_mae_nome,
        anilha_asa_numero: anilha.anilha_numero,
      });

      // Marcar anilha como convertida
      await base44.entities.AnilhaFilha.update(anilha.id, {
        status: 'convertida',
        animal_adulto_id: novoAnimal.id,
      });

      // Criar notificação
      await base44.entities.Notificacao.create({
        destinatario_id: user.id,
        destinatario_email: user.email,
        titulo: 'Anilha Filha Convertida',
        mensagem: `A anilha ${anilha.anilha_numero} completou 30 dias e foi automaticamente convertida em um novo cadastro de adulto.`,
        tipo: 'anilha',
        link: `/animal/${novoAnimal.id}`,
        icone: '💍',
      });
    }

    return Response.json({ 
      success: true, 
      convertidas: anilhas.length,
      message: `${anilhas.length} anilha(s) convertida(s) com sucesso`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});